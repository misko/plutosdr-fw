
module tb;
 reg clk=0; always #5 clk=~clk;
 reg reset=1,valid=0;
 reg signed [15:0] xi=0,xq=0;
 reg [63:0] idx=0;
 wire initializing,fault,cv,detected;
 wire [63:0] first;
 wire [13:0] phase,n;
 wire [14:0] peak;
 wire [27:0] sum;
 wire [42:0] sumsq;
 reg [31:0] samples[0:299999];
 integer k;
 starlink_coarse25_detector dut(.clk(clk),.reset(reset),.sample_valid(valid),
 .sample_i(xi),.sample_q(xq),.sample_index(idx),.initializing(initializing),.fault(fault),
 .candidate_valid(cv),.detected(detected),.candidate_map_first_index(first),
 .candidate_phase(phase),.candidate_peak(peak),.candidate_background_sum(sum),
 .candidate_background_sumsq(sumsq),.candidate_background_count(n));
 always @(posedge clk) begin
  #1;
  if(fault) $fatal(1,"detector fault during full-rate replay");
  if(cv) $display("MAP %0d %0d %0d %0d %0d %0d %0d",first,phase,peak,sum,sumsq,n,detected);
 end
 initial begin
  $readmemh("input.mem",samples);
  repeat(3) @(negedge clk); reset=0;
  for(k=0;k<300000;k=k+1) begin
   {xq,xi}=samples[k]; idx=k; valid=1;
   @(negedge clk); valid=0;
   repeat(39) @(negedge clk);
  end
  repeat(40000) @(negedge clk);
  $finish;
 end
endmodule

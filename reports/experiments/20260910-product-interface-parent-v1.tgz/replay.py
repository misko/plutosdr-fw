"""Independent compile/replay of the frozen first20 interface behavior cases.

Not the owner's three inverse tests, future full matrix, actual FFT or timing.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
SOURCE = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/product-interface-v1.LqlAtZom/cases/interface0/original')
PINS = {
    'starlink_pss_epoch_sealed_bank.v': 'd9c2382f9087ccd2088fa5a5d3fed5c6fe885359d6d4c367ed2ea81ce099d9f6',
    'starlink_pss_product_sealed_interface.v': '65ddceaceb9a3242ce06c83c55cd168647571f02257119206932043e7186c7aa',
    'starlink_pss_checked_product_read_interface.v': 'bffc0b294dca53c89f8d98250d497eba844f3df7a6a767cf6ef5b36355d38130',
    'starlink_pss_block_mailbox.v': 'e85122eb6689ff49b31aa5a0c200e2666786629055b4f45856fe79fb829dbb55',
    'tb_starlink_pss_product_sealed_interface.sv': '91f7bf1ba3e53f5d6a9f614eb42ff1c3bca6c42824f33dcdef62e5149a22dfd7',
    'product_sealed_interface_cases.svh': '1f299e6d98c2acbeead8892a09604f6c6af6f63838b7e98bd78a6589ac61db0c',
    'starlink_pss_realtime_result_guard.v': '09ab35339d55ddf88e813830322d21574d0794c489c9749f68113e9da7807be2',
    'starlink_pss_spectrum_product.v': 'f4fd79f2744cbaf4d7caa6afdf2781ab588fff612266cdb377593bbb31076669',
    'starlink_pss_realtime_input_guard.v': 'eb1f968a30ae0371421cfb0766c7f8bf0c23411e730717cd0d4924be0604109e',
}


def hashes(root):
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in PINS}


assert hashes(SOURCE) == PINS
CASE = HERE / 'compiled'
CASE.mkdir(exist_ok=False)
for name in PINS:
    shutil.copyfile(SOURCE / name, CASE / name)
assert hashes(CASE) == PINS
env = {key: value for key, value in os.environ.items()
       if key not in {'PYTHONHOME', 'PYTHONPATH', 'PYTHONOPTIMIZE', 'LD_LIBRARY_PATH'}}


def run(name, command):
    result = subprocess.run(command, cwd=CASE, env=env, text=True, capture_output=True, timeout=30, check=False)
    log = result.stdout + result.stderr
    with (CASE / (name + '.log')).open('x') as stream:
        stream.write(log)
    with (CASE / (name + '.json')).open('x') as stream:
        json.dump({'command': command, 'exit': result.returncode}, stream)
    assert result.returncode == 0 and not re.search(r'(?im)^.*(?:error:|FATAL:)', log), log
    return log


run('compile', ['iverilog', '-g2012', '-Wall', '-I', '.', '-s', 'tb_starlink_pss_product_sealed_interface',
                '-o', 'sim.vvp', *[name for name in PINS if not name.endswith('.svh')]])
matrix = [(0, 0, 37), (100, 0, 37), (100, 0, 511)]
matrix += [(101, bit, 37) for bit in range(3)]
matrix += [(102, bit, 37) for bit in (0, 69, 74)]
matrix += [(103, 0, 37), (105, 0, 37)] + [(104, bit, 37) for bit in range(8)]
matrix += [(106, 0, 37)]
assert len(matrix) == 20
receipts = []
for kind, bit, target in matrix:
    log = run(f'case-{kind}-{bit}-{target}', ['vvp', 'sim.vvp', f'+CASE={kind}', f'+BIT={bit}', f'+TARGET={target}'])
    if kind in (0, 106) or (kind == 100 and target == 511):
        jobs = 8 if kind == 0 else 1
        assert f'PRODUCT_ADAPTER_PASS case={kind} jobs={jobs}' in log
        assert log.count('take=512 seal_delta=2 publish_delta=3') == jobs
        if kind == 100:
            assert 'PRODUCT_INTERFACE_FINAL_STALL_PASS raw=4 stall=4' in log
    elif kind in (100, 101):
        assert f'PRODUCT_INTERFACE_NEGATIVE_PASS kind={kind}' in log
    else:
        assert f'PRODUCT_INTERFACE_SNAPSHOT_PASS kind={kind}' in log
    receipts.append({'kind': kind, 'bit': bit, 'target': target, 'exit': 0})
assert hashes(SOURCE) == hashes(CASE) == PINS
result = {'scope': 'first20_frozen_interface_behavior_cases_only', 'cases': receipts,
          'source_sha256': PINS, 'source_unchanged': True, 'vendor_calls': 0,
          'graph_qualification': False, 'top_qualification': False}
with (HERE / 'verification.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps({'cases_passed': len(receipts), 'source_unchanged': True, 'scope': result['scope']}, indent=2))

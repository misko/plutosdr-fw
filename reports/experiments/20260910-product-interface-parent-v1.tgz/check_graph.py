"""Read-only complete-node graph check of the independently compiled snapshot."""
import ast
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
AUDIT = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/product-graph-parent.i0Uyyjei/audit_v2.py')
# Load only the reviewed two function definitions and parser constants, not its
# original-run audit or its output-writing statements.
tree = ast.parse(AUDIT.read_text())
selected = [node for node in tree.body if
            isinstance(node, ast.FunctionDef) and node.name in {'parse', 'first_cycle'} or
            isinstance(node, ast.Assign) and len(node.targets) == 1 and
            isinstance(node.targets[0], ast.Name) and node.targets[0].id in {'TOKEN', 'ALLOWED'}]
assert len(selected) == 4
namespace = {'re': re}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(AUDIT), 'exec'), namespace)
netlist = HERE / 'compiled/sim.vvp'
source = netlist.read_bytes()
graph, aliases = namespace['parse'](source.decode())
cycle = namespace['first_cycle'](graph)
drivers = {}
for node, name in aliases.items():
    for driver in graph[node]:
        drivers.setdefault(driver, []).append(name)
result = {'scope': 'FIRST_INTERFACE_SNAPSHOT_COMPLETE_CONTINUOUS_GRAPH',
          'nodes': len(graph), 'LS_nodes': sum(n.startswith('LS_') for n in graph),
          'netlist_sha256': hashlib.sha256(source).hexdigest(),
          'structural_cycle_found': cycle is not None,
          'cycle': [{'label': n, 'aliases': drivers.get(n, [])} for n in (cycle or [])]}
with (HERE / 'graph.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))

// Additive interface witnesses only; original848 fixture preserved separately.
  integer iface_stall=0,iface_raw=0,iface_head=0,iface_receipt=0,iface_phase=0;
  reg iface_forcing=0,iface_finished=0;
  reg [74:0] iface_old_head,iface_changed;
  reg [1:0] iface_old_lease,iface_changed_lease;
  always @(posedge clk) begin
    if(score && resetn && peer_resetn) begin
      if(handoff !== (guard.awaiting_ack && destination_ready && !guard_fault && !guard.idle_fault_now))
        $fatal(1,"INTERFACE_ACTUAL_GUARD_ACK_DIVERGED");
      if(dut.read_head_valid && !inverse_enable)begin
        iface_head=iface_head+1;
        if(core_take || core_valid || dut.read_head_metadata!==dut.reader.descriptor ||
           dut.read_head_lease!==dut.reader.lease_slot[dut.reader.head])
          $fatal(1,"INTERFACE_UNENABLED_HEAD_MISMATCH");
      end
      if(dut.handoff_seen && !adapter_fault && current_faults==0 && !dut.queue_validation_fault)begin
        iface_receipt=iface_receipt+1;
        if(!dut.handoff_owned) $fatal(1,"INTERFACE_PERSISTENT_RECEIPT_MISSING");
      end
      if(iface_forcing && product_valid!==0)begin
        iface_raw=iface_raw+1;
        if(dut.bank.input_valid!==product_valid) $fatal(1,"INTERFACE_RAW_OFFER_MASKED");
        if(product_take) $fatal(1,"INTERFACE_READY_ZERO_TAKE");
      end
    end
  end
  always @(negedge clk)begin
    if(score && kind==100 && !iface_finished)begin
      if(!iface_forcing && product_valid && product_position==target)begin
        force dut.product_ready=0;iface_forcing=1;
      end else if(iface_forcing)begin
        iface_stall=iface_stall+1;
        if(iface_stall==4)begin release dut.product_ready;iface_forcing=0;iface_finished=1;end
      end
    end
    // READY0 cannot hide genuinely new closed offers or X/Z raw controls.
    if(score && kind==101 && !iface_finished && dut.final_taken)begin
      force dut.product_ready=0;iface_forcing=1;iface_finished=1;
      case(bit_index)
        0: force dut.product_valid=1;
        1: force dut.product_valid=1'bx;
        2: force dut.product_valid=1'bz;
      endcase
      #0.001;
      if(publication || handoff || product_take) $fatal(1,"INTERFACE_CLOSED_RAW_CURRENT_ESCAPE");
    end
    if(score && kind==106 && !iface_finished && dut.queue_prefetched)begin
      forward_phase=0;iface_phase=iface_phase+1;
      #0.001;if(handoff_valid || handoff) $fatal(1,"INTERFACE_WRONG_PHASE_HANDOFF");
      if(iface_phase==3)begin forward_phase=1;iface_finished=1;end
    end
  end
  task interface_after_wait;
    begin
      if(kind==100 && target==37)begin
        if(!adapter_fault || !iface_raw || !iface_stall || pubs || handoffs)
          $fatal(1,"INTERFACE_INTERIOR_READY_FAULT_MISSING");
        $display("PRODUCT_INTERFACE_NEGATIVE_PASS kind=100 raw=%0d stall=%0d",iface_raw,iface_stall);$finish;
      end
      if(kind==100 && target==511)begin
        if(adapter_fault || iface_raw<4 || iface_stall!=4 || !iface_finished)
          $fatal(1,"INTERFACE_FINAL_READY_HOLD_MISSING");
        $display("PRODUCT_INTERFACE_FINAL_STALL_PASS raw=%0d stall=%0d",iface_raw,iface_stall);
      end
      if(kind==101)begin
        if(!adapter_fault || !iface_raw || !issuer_reasons[3] || (bit_index!=0 && !bank_reasons[7]))
          $fatal(1,"INTERFACE_RAW_DIAGNOSTIC_MISSING");
        $display("PRODUCT_INTERFACE_NEGATIVE_PASS kind=101 bit=%0d raw=%0d reasons=%h/%h",bit_index,iface_raw,bank_reasons,issuer_reasons);$finish;
      end
      if(kind>=102 && kind<=105)begin
        if(!handoffs || guard_busy || !dut.handoff_owned || !dut.read_head_valid || core_take || !iface_head)
          $fatal(1,"INTERFACE_ACK_HEAD_BOUNDARY_MISSING");
        if(kind==102)begin
          // Deliberate private corruption establishes independent signal
          // sources, not admission safety (the future top binder is absent).
          iface_old_head=dut.read_head_metadata;iface_old_lease=dut.read_head_lease;
          iface_changed=dut.expected_metadata ^ (75'b1<<bit_index);
          iface_changed_lease=dut.lease_reference+1'b1;
          force dut.expected_metadata=iface_changed;force dut.lease_reference=iface_changed_lease;
          #0.001;
          if(dut.admitted_metadata!==iface_changed || dut.read_head_metadata!==iface_old_head ||
             dut.admitted_lease!==iface_changed_lease || dut.read_head_lease!==iface_old_lease)
            $fatal(1,"INTERFACE_ADMISSION_HEAD_ALIAS");
        end
        if(kind==103)begin
          repeat(4)tick();
          if(!dut.handoff_owned || handoff || guard_busy || reusable || core_take || iface_receipt<4)
            $fatal(1,"INTERFACE_POST_ACK_RECEIPT_MISSING");
        end
        if(kind==104)begin
          @(negedge clk);injected_faults=8'b1<<bit_index;#0.001;
          if(dut.handoff_owned || dut.read_head_valid || core_take || lease_release)
            $fatal(1,"INTERFACE_CURRENT_RECEIPT_VETO_MISSING");
          tick();if(!adapter_fault)$fatal(1,"INTERFACE_CURRENT_REASON_MISSING");
        end
        if(kind==105)begin
          force dut.reader.good=0;#0.001;
          if(dut.read_head_valid || core_take) $fatal(1,"INTERFACE_UNCHECKED_HEAD_VISIBLE");
        end
        $display("PRODUCT_INTERFACE_SNAPSHOT_PASS kind=%0d bit=%0d head=%0d receipt=%0d",kind,bit_index,iface_head,iface_receipt);$finish;
      end
    end
  endtask

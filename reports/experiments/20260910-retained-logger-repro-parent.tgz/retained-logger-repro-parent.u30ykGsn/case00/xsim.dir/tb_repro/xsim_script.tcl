xsim {tb_repro} -autoloadwcfg -runall

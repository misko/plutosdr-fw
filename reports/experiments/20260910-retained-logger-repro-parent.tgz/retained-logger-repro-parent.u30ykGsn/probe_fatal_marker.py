"""Read frozen checker; test a complete scripted log plus real kernel marker."""
import json
from pathlib import Path
import sys
import types

here=Path(__file__).resolve().parent
root=here.parent/'retained-output-actual-prelaunch-declaration-v3/source_snapshot'
for name,path in (('tests',root/'tests'),('tests.starlink_oracle',root/'tests/starlink_oracle')):
    package=types.ModuleType(name)
    package.__path__=[str(path)]
    package.__package__=name
    sys.modules[name]=package
from tests.starlink_oracle.retained_output_actual_result import verify_result
source=here.parent/'retained-declaration-parent.nu4VLvyG/cases/retained_actual_script0/run'
text=(source/'simulation.log').read_text()
cases={
    'untouched':text,
    'kernel_error':text+'\nFATAL_ERROR: Vivado Simulator kernel has discovered an exceptional condition from which it cannot recover.\n',
    'ordinary_error':text+'\nFatal: deliberate negative control\n',
}
results={}
for name,log in cases.items():
    path=here/(name+'.log')
    with path.open('x') as stream:stream.write(log)
    try:
        verify_result(path,source/'actual_words.csv',kind='OFFLINE_SCRIPT_NOT_FFT')
        results[name]={'accepted':True}
    except ValueError as exc:
        results[name]={'accepted':False,'error':str(exc)}
(here/'fatal-marker-probe.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results))
assert results['untouched']['accepted'] and not results['ordinary_error']['accepted']

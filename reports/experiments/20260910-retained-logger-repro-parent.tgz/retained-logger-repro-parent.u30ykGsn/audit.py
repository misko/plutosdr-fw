"""Independently classify all minimal vendor cases, including zero-exit crashes."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
results=json.loads((root/'results.json').read_text())
assert [r['case'] for r in results]==list(range(12))
crashes={2,3,8,9}
header='context,stream,job,position,data,start,exponent,fast,slow,time_fs\n'
source='0,source,0,0,123456789abc,00000000000003e8,003,939,536,2000000\n'
for row in results:
    case=row['case'];work=root/f'case{case:02d}'
    for stage in ('compile','elaborate','simulate'):
        receipt=json.loads((work/(stage+'.terminal.json')).read_text())
        assert receipt==row[stage] and receipt['exit']==0 and not receipt['timeout']
    assert hashlib.sha256((work/'bench.sv').read_bytes()).hexdigest()=='2d76d74eb8012c8b4d627aadb8beeaf068e31c61085e80a131ab1fe69571e5f6'
    log=(work/'simulate.outer.log').read_text()
    data=(work/'logger_rows.csv').read_bytes()
    if case in crashes:
        assert 'FATAL_ERROR: Vivado Simulator kernel' in log
        assert 'LOGGER_REPRO_COMPLETED' not in log
        assert data==(header+source+'0,').encode()
    else:
        stream=('input' if case<6 else 'raw')+('I' if case%2 else 'F')
        assert data==(header+source+f'0,{stream},0,0,123456789abc,00000000000003e8,003,939,536,3000000\n').encode()
        assert f'LOGGER_REPRO_COMPLETED case={case} rows=2' in log
        assert 'FATAL_ERROR' not in log
report={'cases':12,'literal_and_ifelse_exact':8,'conditional_kernel_crashes':sorted(crashes),
        'all_tool_exit_codes':0,'fft_or_runtime_qualification':False}
(root/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))

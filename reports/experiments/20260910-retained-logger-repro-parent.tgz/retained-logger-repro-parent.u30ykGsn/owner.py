"""Twelve bounded minimal XSim formatter cases; no FFT or receiver runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

root=Path(__file__).resolve().parent
source=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired/hdl/library/starlink_pss_acquisition/retained_output_actual/logger_repro/tb_retained_logger_repro.sv')
expected='2d76d74eb8012c8b4d627aadb8beeaf068e31c61085e80a131ab1fe69571e5f6'
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
shutil.copy2(source,root/'bench.sv')
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
binpath='/opt/Xilinx/Vivado/2022.2/bin/'
results=[]
def execute(work,phase,args):
    start=time.monotonic()
    timeout=False
    with (work/(phase+'.outer.log')).open('x') as log:
        process=subprocess.Popen(args,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        (work/(phase+'.process.json')).write_text(json.dumps({'pid':process.pid,'command':args,'wall_limit':30}))
        try: code=process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            timeout=True
            os.killpg(process.pid,signal.SIGTERM)
            try: code=process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                code=process.wait(timeout=5)
    receipt={'exit':code,'timeout':timeout,'elapsed_seconds':time.monotonic()-start}
    (work/(phase+'.terminal.json')).write_text(json.dumps(receipt,indent=2))
    return receipt
for case in range(12):
    work=root/f'case{case:02d}'
    work.mkdir()
    shutil.copy2(root/'bench.sv',work/'bench.sv')
    record={'case':case}
    record['compile']=execute(work,'compile',[binpath+'xvlog','--sv','bench.sv','--log','xvlog.log'])
    if record['compile']['exit']==0:
        record['elaborate']=execute(work,'elaborate',[binpath+'xelab','--debug','typical','--relax','--mt','2',
            '--generic_top',f'CASE={case}','--snapshot','tb_repro','work.tb','--log','xelab.log'])
        if record['elaborate']['exit']==0:
            record['simulate']=execute(work,'simulate',[binpath+'xsim','tb_repro','-runall','-log','xsim.log'])
    log=(work/'simulate.outer.log').read_text() if (work/'simulate.outer.log').exists() else ''
    rows=(work/'logger_rows.csv').read_bytes() if (work/'logger_rows.csv').exists() else b''
    stream=('input' if case<6 else 'raw')+('I' if case%2 else 'F')
    golden=('context,stream,job,position,data,start,exponent,fast,slow,time_fs\n'
            '0,source,0,0,123456789abc,00000000000003e8,003,939,536,2000000\n'
            f'0,{stream},0,0,123456789abc,00000000000003e8,003,939,536,3000000\n').encode()
    record.update(completed=f'LOGGER_REPRO_COMPLETED case={case} rows=2' in log,
                  kernel_crash='FATAL_ERROR: Vivado Simulator kernel' in log,
                  exact_two_rows=rows==golden,csv_bytes=len(rows),
                  source_unchanged=hashlib.sha256((work/'bench.sv').read_bytes()).hexdigest()==expected)
    results.append(record)
    (root/'results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(record),flush=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
assert len(results)==12 and all(r['source_unchanged'] for r in results)
print('LOGGER_REPRO_TWELVE_TERMINAL_NOT_FFT_QUALIFICATION',flush=True)

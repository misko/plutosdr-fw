"""Independent saved-run audit; no simulation, vendor tool or source imports."""
import hashlib
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET


def require(condition, message):
    if not condition:
        raise ValueError(message)


def composition(log, stall):
    pubs = [(int(a), int(b)) for a, b in re.findall(
        r"^OFFLINE_PUBLICATION block=(\d+) cycle=(\d+)$", log, re.M)]
    dispatch = [(int(a), int(b)) for a, b in re.findall(
        r"^OFFLINE_DISPATCH block=(\d+) clocks=(\d+)$", log, re.M)]
    acks = [int(a) for a in re.findall(r"^OFFLINE_REAL_ACK cycle=(\d+)$", log, re.M)]
    require([a for a, _ in pubs] == [0, 1, 2], "publication inventory")
    require(dispatch == [(1, 8), (2, 8)], "eight-clock dispatch")
    require(len(acks) == 3, "real ACK inventory")
    cycles = [b for _, b in pubs]
    intervals = [b-a for a, b in zip(cycles, cycles[1:])]
    require(all(a < b for a, b in zip(cycles, acks)), "ACK after publication")
    require(all(cycles[i]+8 < acks[i] < cycles[i+1] for i in range(2)),
            "next forward dispatch overlaps old reader; next publication follows real ACK")
    require(all(n == 3645 if stall < 2 else n in (4911, 4912) for n in intervals),
            "observed publication interval")
    summaries = re.findall(r"^OFFLINE_PASS composition SCRIPTED_NOT_FFT (.+)$", log, re.M)
    require(len(summaries) == 1, "one composition PASS")
    counts = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", summaries[0])}
    require(all(counts.get(k) == 1536 for k in ("source", "forward", "product", "inverse", "read")),
            "exact five-stream inventory")
    require(counts.get("first_dispatch") == 8 and counts.get("overlap_input") == 1024,
            "actual overlapped inputs")
    require(counts.get("overlap_read") == (1022 if stall < 2 else 0), "reader profile")
    return {"stall": stall, "publication_cycles": cycles, "real_ack_cycles": acks,
            "dispatch_cycles": [cycles[i] + 8 for i in range(2)],
            "publication_intervals": intervals, "counts": counts}


def main():
    run, snapshot = map(Path, sys.argv[1:])
    manifest = snapshot / "source.sha256"
    require(hashlib.sha256(manifest.read_bytes()).hexdigest() ==
            "c923aa74ad6274b19142e0b1735eacc6e0acf62eb9e42b3aacd0fcbb16060ab9", "manifest pin")
    pins = manifest.read_text().splitlines()
    require(len(pins) == 42, "42 source pins")
    for line in pins:
        expected, relative = line.split(maxsplit=1)
        relative = relative.removeprefix("*")
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "safe pin")
        require(hashlib.sha256((snapshot / relative).read_bytes()).hexdigest() == expected, relative)
    suite = ET.parse(run / "results.xml").getroot().find("testsuite")
    require(suite is not None, "test suite")
    require(all(suite.get(k) == v for k, v in
                {"tests": "17", "errors": "0", "failures": "0", "skipped": "0"}.items()), "17 passing tests")
    expected_names = {f"test_scripted_three_bank_composition[{p}-{s}]"
                      for p in (0.1, 1.3, 4.7) for s in range(3)}
    expected_names |= {f"test_fresh_mailbox_epoch_with_paused_slow_clock[{p}-{s}]"
                       for p in (0.1, 1.3, 2.9, 4.7) for s in range(2)}
    require({c.get("name") for c in suite.findall("testcase")} == expected_names, "case identities")
    rows = []
    for i in range(9):
        directory = run / f"pytest/test_scripted_three_bank_compo{i}/composition"
        require((directory / "exit.txt").read_text() == "compile=0\nsimulation=0\n", "terminal exits")
        log = (directory / "simulation.log").read_text()
        row = composition(log, i % 3)
        row["phase_ns"] = (0.1, 1.3, 4.7)[i // 3]
        row["log_sha256"] = hashlib.sha256(log.encode()).hexdigest()
        rows.append(row)
    for i in range(8):
        directory = run / f"pytest/test_fresh_mailbox_epoch_with_{i}/epoch"
        require((directory / "exit.txt").read_text() == "compile=0\nsimulation=0\n", "epoch exits")
        log = (directory / "simulation.log").read_text()
        require(re.findall(r"^OFFLINE_PASS paused slow reset side=(\d) fresh_source_words=(\d+)$", log, re.M)
                == [(str(i % 2), "512")], "fresh mailbox epoch inventory")
    healthy = (run / "pytest/test_scripted_three_bank_compo0/composition/simulation.log").read_text()
    mutants = [healthy.replace("clocks=8", "clocks=9", 1),
               healthy.replace("read=1536", "read=1535"),
               healthy.replace("OFFLINE_PUBLICATION block=1 cycle=8207", "OFFLINE_PUBLICATION block=1 cycle=8208"),
               healthy.replace("OFFLINE_REAL_ACK cycle=5466", "OFFLINE_REAL_ACK cycle=4563")]
    for mutated in mutants:
        require(mutated != healthy, "active audit mutation")
        try:
            composition(mutated, 0)
        except ValueError:
            pass
        else:
            raise ValueError("bad trace accepted")
    result = {"scope": "SCRIPTED_NOT_FFT; no routing, physical clock or sustained receiver claim",
              "source_files": 42, "behavior_cases": 17, "audit_mutants_rejected": 4,
              "rows": rows,
              "clock_conversion_only_us": {str(mhz): {str(n): n / mhz for n in (3645, 4912)}
                                           for mhz in (130, 140, 175)},
              "canonical_block_budget_us": 447 / 15}
    with (run / "parent-audit.json").open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print("PASS: 42 source pins, 17 behavioral cases, nine timing/ACK inventories, four audit mutants")


if __name__ == "__main__":
    main()

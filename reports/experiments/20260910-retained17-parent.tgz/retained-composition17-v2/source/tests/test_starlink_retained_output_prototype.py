"""Offline-only control prototype; scripted ports are never actual FFT evidence."""

import pytest

from tests.starlink_oracle.retained_output_prototype import (
    BASELINE, PINS, RTL, composition_sources, guard_equivalence_bench, inverse_view, run_sv, verify_baseline,
)


def test_original_source_and_vector_pins():
    verify_baseline()
    assert len(PINS) == 17


@pytest.mark.parametrize("kind,name", [
    ("guard", "starlink_pss_result_guard_owner_view.v"),
    ("mailbox", "starlink_pss_mailbox_owner_view.v"),
])
def test_exact_owner_view_inverse(kind, name):
    inverse_view((RTL / name).read_text(), kind)


@pytest.mark.parametrize("kind,name,old,new", [
    ("guard", "starlink_pss_result_guard_owner_view.v", "age <= age + 1'b1", "age <= age"),
    ("guard", "starlink_pss_result_guard_owner_view.v", "assign owner_active = active;", "assign owner_active = 1'b0;"),
    ("mailbox", "starlink_pss_mailbox_owner_view.v", "acknowledge_toggle <= request_sync[1]", "acknowledge_toggle <= 0"),
])
def test_inverse_rejects_body_and_observation_mutants(kind, name, old, new):
    text = (RTL / name).read_text()
    assert old in text
    with pytest.raises(ValueError):
        inverse_view(text.replace(old, new), kind)


@pytest.mark.parametrize("kind", range(12))
def test_owner_public_boundary(tmp_path, kind):
    run_sv(tmp_path / "owner", (RTL / "tb/tb_retained_owner.sv").read_text(),
           [RTL / "starlink_pss_retained_output_owner.v"], parameters=[f"-Ptb.KIND={kind}"])


@pytest.mark.parametrize("kind", range(1, 15))
@pytest.mark.parametrize("offset", range(14))
def test_cutover_raw_event_every_edge(tmp_path, kind, offset):
    run_sv(tmp_path / "cutover", (RTL / "tb/tb_cutover.sv").read_text(),
           [RTL / "starlink_pss_core_job_cutover.v"],
           parameters=[f"-Ptb.KIND={kind}", f"-Ptb.OFFSET={offset}"])


def test_cutover_healthy_closure_and_early_matching_status(tmp_path):
    run_sv(tmp_path / "cutover", (RTL / "tb/tb_cutover.sv").read_text(),
           [RTL / "starlink_pss_core_job_cutover.v"])


@pytest.mark.parametrize("stall", range(3))
@pytest.mark.parametrize("phase", [0.1, 1.3, 4.7])
def test_scripted_three_bank_composition(tmp_path, stall, phase):
    run_sv(tmp_path / "composition", (RTL / "tb/tb_retained_composition.sv").read_text(),
           composition_sources(), parameters=[f"-Ptb.STALL={stall}", f"-Ptb.SLOW_PHASE={phase}"])


@pytest.mark.parametrize("side", [0, 1])
@pytest.mark.parametrize("phase", [0.1, 1.3, 2.9, 4.7])
def test_fresh_mailbox_epoch_with_paused_slow_clock(tmp_path, side, phase):
    run_sv(tmp_path / "epoch", (RTL / "tb/tb_retained_epoch.sv").read_text(),
           [RTL / "starlink_pss_mailbox_owner_view.v", RTL / "starlink_pss_retained_epoch_barrier.v"],
           parameters=[f"-Ptb.SIDE={side}", f"-Ptb.PHASE={phase}"])


def test_unconditional_guard_equivalence_and_unchanged_faults(tmp_path):
    run_sv(tmp_path / "guard", guard_equivalence_bench(), [
        BASELINE / "starlink_pss_realtime_result_guard.v", BASELINE / "starlink_pss_block_mailbox.v",
        RTL / "starlink_pss_result_guard_owner_view.v", RTL / "baseline_tests/tb_starlink_pss_realtime_result_guard.sv",
    ])


@pytest.mark.parametrize("profile", [0, 1])
def test_default_wrapper_unconditional_equivalence(tmp_path, profile):
    run_sv(tmp_path / "default", (RTL / "tb/tb_retained_default.sv").read_text(),
           composition_sources(), parameters=[f"-Ptb.PROFILE={profile}"])


@pytest.mark.parametrize("kind", range(1, 9))
@pytest.mark.parametrize("offset", range(14))
def test_composed_cutover_fault_every_sample(tmp_path, kind, offset):
    run_sv(tmp_path / "raw", (RTL / "tb/tb_retained_composition.sv").read_text(),
           composition_sources(), parameters=["-DRETAINED_FAULT_STIMULUS",
             f"-Ptb.FAULT_KIND={kind}", f"-Ptb.FAULT_OFFSET={offset}"])


@pytest.mark.parametrize("boundary,kind", [(1, 1), (1, 2), (1, 3), (2, 4), (2, 1), (2, 2), (2, 3)])
def test_original_raw_ready_and_late_ack_boundaries(tmp_path, boundary, kind):
    run_sv(tmp_path / "ack", (RTL / "tb/tb_retained_composition.sv").read_text(),
           composition_sources(), parameters=["-DRETAINED_FAULT_STIMULUS",
             f"-Ptb.FAULT_KIND={kind}", f"-Ptb.FAULT_BOUNDARY={boundary}"])


@pytest.mark.parametrize("phase", [0.1, 1.3, 4.7])
def test_retained_provisional_prefix_while_new_forward_exists(tmp_path, phase):
    run_sv(tmp_path / "prefix", (RTL / "tb/tb_retained_composition.sv").read_text(),
           composition_sources(), parameters=["-DRETAINED_FAULT_STIMULUS",
             "-Ptb.FAULT_KIND=4", "-Ptb.FAULT_BOUNDARY=3", f"-Ptb.SLOW_PHASE={phase}"])

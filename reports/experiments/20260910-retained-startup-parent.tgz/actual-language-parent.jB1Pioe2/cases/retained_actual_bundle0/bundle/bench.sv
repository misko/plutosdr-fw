// Additive actual harness: real generated FFT required for actual qualification.
`timescale 1ns/1fs
module tb;
  integer STALL=0;
  parameter integer FAULT_KIND=0,FAULT_OFFSET=0,FAULT_BOUNDARY=0;
  integer RESET_SIDE=0;localparam BLOCKS=3;
  localparam real SLOW_PHASE=1.3;
  reg clk=0,fft_clk=0,resetn=0,fft_resetn=0,run_slow=1,new_epoch=0;
  always #2.857143 fft_clk=~fft_clk;
  initial begin #(SLOW_PHASE);forever begin #5;if(run_slow)clk=~clk;end end
  retained_clock_witness #(.SLOW_PHASE(SLOW_PHASE)) clocks(.fast_clk(fft_clk),.slow_clk(clk),.slow_clock_enabled(run_slow));
  reg input_valid=0;wire input_ready;reg[35:0]input_data=0;
  reg[8:0]input_position=0;reg input_last=0;reg[63:0]input_block_start=0;
  wire output_valid,output_last,fault;reg output_ready=1;
  wire[35:0]output_data;wire[8:0]output_position;wire[74:0]output_metadata;
  starlink_pss_fft_bank_owned_retained_output_probe #(.ENABLE_RETAINED_OUTPUT(1),
    .REGISTERED_SCHEDULING(1),.BOUNDARY_ROUND_SAT(1),.REGISTER_OPERANDS(1),
    .LOCAL_FIRST_ADMISSION(1)) dut(.*);
  `define D dut.retained.island
  reg[31:0]samples[0:1405];reg[35:0]forwards[0:1535],products[0:1535],inverses[0:1535];
  reg[4:0]fe[0:2],ie[0:2];
  integer fast_cycles=0,slow_cycles=0,forward_jobs=0,inverse_jobs=0,read_count=0;
  integer source_count=0,forward_words=0,product_words=0,inverse_words=0,status_count=0;
  integer slow_edges=0,resume_edge=0,output_fixture_base=0,last_forward_admit=-1,max_forward_interval=0;
  integer max_retained_wait=0,max_inverse_publication_interval=0;
  integer ack_f_input=0,ack_f_output=0,ack_f_handoff=0,held_final_prefetch=0,parked_full_source=0;
  integer ack_zero_controls=0;
  integer overlap_inputs=0,overlap_reads=0,retained_finals=0,parked_wait_i=0;
  integer last_inverse_publish=-1,last_real_release=-1,first_dispatch=-1;
  integer selected_fixture=0,raw_words=0,raw_phase=0;
  reg inject_frame=0,inject_output=0,inject_status=0,inject_vendor=0,fault_injected=0,collision_done=0;
  integer inverse_publications=0,publication_anchor=0,fault_anchor=0,boundary_edge=0;
  reg stalled=0;reg[120:0]held_output;
  always @(posedge fft_clk)begin
    fast_cycles=fast_cycles+1;
    if(`D.fast_running)begin
      if(!fault_injected&&(fault!==0||`D.any_fast_fault!==0))$fatal(1,"composition health cycle=%0d state=%0d fault=%b cut=%h owner=%h f=%h i=%h",fast_cycles,`D.state,`D.any_fast_fault,`D.cutover_reasons,`D.retained_reasons,`D.owners[0].result_guard.faults_now,`D.owners[1].result_guard.faults_now);
      if(`D.job_accept)begin
        if(`D.next_inverse)begin
          if(inverse_jobs>0&&last_real_release<0&&!(RESET_SIDE!=0&&new_epoch&&inverse_jobs==1))$fatal(1,"next inverse before real read release");
          if(last_real_release>=0&&fast_cycles<=last_real_release)$fatal(1,"next inverse requires registered actual release");
          if(`D.retained_published!==0)$fatal(1,"next inverse retained old owner");
          inverse_jobs=inverse_jobs+1;
        end else begin
          if(forward_jobs>0&&!(RESET_SIDE!=0&&new_epoch&&forward_jobs==2))begin
            if(last_inverse_publish<0||`D.retained_published!==1)$fatal(1,"no retained overlap at next F");
            if(first_dispatch<0)first_dispatch=fast_cycles-last_inverse_publish;
            $display("OFFLINE_DISPATCH block=%0d clocks=%0d",forward_jobs,fast_cycles-last_inverse_publish);
            if(fast_cycles-last_forward_admit>max_forward_interval)max_forward_interval=fast_cycles-last_forward_admit;
          end
          last_forward_admit=fast_cycles;
          forward_jobs=forward_jobs+1;
        end
        selected_fixture=(forward_jobs-1)%3;raw_words=0;raw_phase=`D.next_inverse;
        $display("OFFLINE_JOB phase=%0d fixture=%0d admit_cycle=%0d",raw_phase,selected_fixture,fast_cycles);
      end
      if(`D.core_status_valid&&inject_status===0)begin
        if(raw_words!=2||`D.core_status_data!=={3'b0,(raw_phase?ie[selected_fixture]:fe[selected_fixture])})$fatal(1,"third raw status");
        status_count=status_count+1;
      end
      if(`D.core_output_valid&&inject_output===0)begin
        if(`D.core_output_user[8:0]!==9'(raw_words)||`D.core_output_last!==(raw_words==511))$fatal(1,"raw ordinal");
        raw_words=raw_words+1;
      end
      if(`D.forward_retirement_valid&&`D.product_bank_ready)begin
        if(`D.return_position!==9'(forward_words%512)||`D.return_data!==forwards[selected_fixture*512+`D.return_position]||`D.return_metadata[4:0]!==fe[selected_fixture])$fatal(1,"forward exact word");
        forward_words=forward_words+1;
      end
      if(`D.product_valid&&`D.product_bank_ready)begin
        if(`D.product_position!==9'(product_words%512)||{`D.product_q,`D.product_i}!==products[selected_fixture*512+`D.product_position]||`D.product_exponent!==fe[selected_fixture])$fatal(1,"product exact word");
        product_words=product_words+1;
      end
      if(`D.guard_private_out[1]&&`D.output_bank_ready)begin
        if(`D.guard_return_position[1]!==9'(inverse_words%512)||`D.guard_return_data[1]!==inverses[selected_fixture*512+`D.guard_return_position[1]])$fatal(1,"private inverse exact word");
        inverse_words=inverse_words+1;
      end
      if(`D.guard_commit_out[1]&&`D.output_bank_ready)begin
        inverse_publications=inverse_publications+1;
        if(fault_injected)$fatal(1,"new inverse publication after current fault");
        if(last_inverse_publish>=0&&fast_cycles-last_inverse_publish>max_inverse_publication_interval)
          max_inverse_publication_interval=fast_cycles-last_inverse_publish;
        last_inverse_publish=fast_cycles;last_real_release=-1;
        $display("OFFLINE_PUBLICATION block=%0d cycle=%0d",inverse_jobs-1,fast_cycles);
      end
      if(`D.guard_ack[1]&&!fault_injected)begin
        if({`D.retained_owner.inverse_admit,`D.retained_owner.inverse_publication,`D.retained_owner.transfer_consumed}!==3'b000)
          $fatal(1,"healthy actual guard ACK controls must be independently known zero");
        ack_zero_controls=ack_zero_controls+1;
        $display("OFFLINE_ACK_CONTROLS cycle=%0d admit=0 publication=0 transfer=0",fast_cycles);
      end
      if(`D.reader_release)begin
        if(fast_cycles-last_inverse_publish>max_retained_wait)max_retained_wait=fast_cycles-last_inverse_publish;
        last_real_release=fast_cycles;$display("OFFLINE_REAL_ACK cycle=%0d",fast_cycles);
        if(!`D.routed_inverse&&`D.core_input_valid&&`D.core_input_ready)ack_f_input=ack_f_input+1;
        if(!`D.routed_inverse&&`D.core_output_valid)ack_f_output=ack_f_output+1;
        if(`D.forward_committed&&`D.owners[0].result_guard.awaiting_ack)ack_f_handoff=ack_f_handoff+1;
      end
      if(`D.retained_published&&`D.core_input_valid&&`D.core_input_ready&&!`D.routed_inverse)
        overlap_inputs=overlap_inputs+1;
      if(`D.retained_published&&!`D.core_aresetn&&output_valid)retained_finals=retained_finals+1;
      if(`D.retained_published&&`D.product_bank_valid&&`D.next_inverse&&`D.state==2)
        parked_wait_i=parked_wait_i+1;
      if(`D.retained_published&&`D.product_bank_valid&&`D.source_valid&&`D.next_inverse&&`D.state==2)
        parked_full_source=parked_full_source+1;
      if(output_valid&&output_last&&!output_ready&&`D.retained_published)held_final_prefetch=held_final_prefetch+1;
      if(fast_cycles>1500000)$fatal(1,"whole-bench fast deadline");
    end
  end
  always @(negedge clk)begin
    slow_cycles=slow_cycles+1;
    output_ready=(RESET_SIDE!=0&&!new_epoch)||STALL==6 ? 0 : STALL==0 ? 1 : STALL==1 ? (slow_cycles%17<13) :
      STALL==5 ? (!output_last||inverse_jobs==BLOCKS||`D.forward_committed) :
      (`D.retained_published&&fast_cycles-last_inverse_publish>(STALL==2?2200:STALL==4?500:9000));
  end
  always @(posedge clk)begin
    slow_edges=slow_edges+1;
    if(input_valid&&input_ready)source_count=source_count+1;
    if(resetn&&fft_resetn)begin
      if(stalled&&output_valid&&{output_data,output_position,output_last,output_metadata}!==held_output)$fatal(1,"retained read payload changed");
      stalled=output_valid&&!output_ready;held_output={output_data,output_position,output_last,output_metadata};
      if(output_valid&&output_ready)begin
        if(output_data!==inverses[(output_fixture_base+read_count/512)%3*512+read_count%512]||
          output_position!==9'(read_count%512)||output_last!==(read_count%512==511)||
          output_metadata!=={1'b1,64'(1000+(output_fixture_base+read_count/512)*447),fe[(output_fixture_base+read_count/512)%3],ie[(output_fixture_base+read_count/512)%3]})
          $fatal(1,"old reader exact identity/payload count=%0d",read_count);
        if(!`D.routed_inverse&&`D.cutover.owner_open)overlap_reads=overlap_reads+1;
        read_count=read_count+1;
      end
    end else stalled=0;
  end
  integer block_index,word_index,drain_anchor;
  task automatic run_context;begin
    $readmemh("samples_ci16.mem",samples);$readmemh("forward_q17.mem",forwards);
    $readmemh("product_q17.mem",products);$readmemh("inverse_q17.mem",inverses);
    $readmemh("forward_exponents.mem",fe);$readmemh("inverse_exponents.mem",ie);
    repeat(10)@(negedge fft_clk);resetn=1;fft_resetn=1;
    for(block_index=0;block_index<BLOCKS;block_index=block_index+1)begin
      if(RESET_SIDE!=0&&block_index==2)begin
        wait(`D.retained_published&&!`D.routed_inverse&&actual_inputs>=64);
        @(negedge clk);run_slow=0;
        $display("RACT_SLOW_PAUSE context=%0d slow=%0d fast=%0d time_fs=%0.0f",context_id,slow_edges,fast_cycles,$realtime*1000000.0);
        if(`D.source_valid!==1||output_valid!==1||read_count!=0)$fatal(1,"old full source/retained reader reset premise");
        @(negedge fft_clk);if(RESET_SIDE==1)resetn=0;else fft_resetn=0;
        #0.001;if(`D.fast_running!==0||output_valid!==0)$fatal(1,"common reset did not close outputs");
        repeat(4)@(negedge fft_clk);resetn=1;fft_resetn=1;
        repeat(20)begin @(negedge fft_clk);if(`D.fast_running!==0||`D.job_accept!==0)$fatal(1,"paused clock stale rearm");end
        resume_edge=slow_edges;run_slow=1;
        $display("RACT_SLOW_RESUME context=%0d slow=%0d fast=%0d time_fs=%0.0f",context_id,slow_edges,fast_cycles,$realtime*1000000.0);
        wait(`D.fast_running);
        if(slow_edges-resume_edge<4||output_valid!==0||`D.source_valid!==0||`D.retained_published!==0)
          $fatal(1,"fresh common reset barrier failed");
        new_epoch=1;output_fixture_base=2;last_inverse_publish=-1;last_real_release=-1;
        $display("OFFLINE_RESET side=%0d old_output_unread=512 aborted_F_input_prefix_at_least64 fresh_purge_slow_edges=%0d",RESET_SIDE,slow_edges-resume_edge);
      end
      for(word_index=0;word_index<512;word_index=word_index+1)begin
        @(negedge clk);input_valid=1;input_position=9'(word_index);input_last=word_index==511;
        input_block_start=1000+block_index*447;
        input_data={samples[block_index*447+word_index][31:16],2'b0,samples[block_index*447+word_index][15:0],2'b0};
        do begin @(posedge clk);end while(input_ready!==1'b1);
        #0.001;
      end
      @(negedge clk);input_valid=0;
    end
    if(FAULT_KIND!=0)wait(collision_done);
    drain_anchor=fast_cycles;
    while(read_count!=(RESET_SIDE!=0?512:BLOCKS*512)||!`D.retained_reusable)begin
      @(negedge fft_clk);
      if(fast_cycles-drain_anchor>=25000)begin
        if(STALL==6)begin
          if(`D.retained_published!==1||`D.retained_reusable!==0||read_count!=0||
            `D.owners[0].result_guard.active!==0||`D.owners[1].result_guard.active!==0||
            `D.any_fast_fault!==0)$fatal(1,"stopped-reader protocol classification");
          $display("OFFLINE_DRAIN_TIMEOUT anchor=%0d cycle=%0d elapsed=%0d retained=1 guard_active=0/0 read=0",drain_anchor,fast_cycles,fast_cycles-drain_anchor);
        end
        $fatal(1,"25000-fast bounded result drain");
      end
    end
    repeat(20)@(negedge fft_clk);
    if(source_count!=BLOCKS*512||forward_jobs!=BLOCKS||inverse_jobs!=(RESET_SIDE!=0?2:BLOCKS)||
      forward_words!=(RESET_SIDE!=0?1024:BLOCKS*512)||product_words!=forward_words||inverse_words!=forward_words||
      status_count!=(RESET_SIDE!=0?4:BLOCKS*2)||overlap_inputs==0||
      (RESET_SIDE==0&&STALL<2&&overlap_reads==0)||((STALL==2||STALL==3)&&parked_wait_i==0)||retained_finals==0)
      $fatal(1,"inventory source%0d F%0d I%0d fw%0d p%0d iw%0d status%0d overlap%0d/%0d reset%0d",source_count,forward_jobs,inverse_jobs,forward_words,product_words,inverse_words,status_count,overlap_inputs,overlap_reads,retained_finals);
    if(RESET_SIDE==0&&STALL<=2&&max_forward_interval>5215)$fatal(1,"175 fast service cap");
    if(STALL==3&&max_retained_wait<=8192)$fatal(1,"long reader did not outlive active watchdog");
    if(ack_f_input!=0)$fatal(1,"unexpected unreachable175/100 early sampled ACK");
    if(STALL==4&&ack_f_output==0)$fatal(1,"missing real ACK during F raw output");
    if(STALL==5&&(ack_f_handoff==0||held_final_prefetch==0))$fatal(1,"missing held final/real ACK handoff");
    if(STALL==2&&parked_full_source==0)$fatal(1,"next complete source not retained behind full product");
    if(ack_zero_controls!=(RESET_SIDE!=0?1:BLOCKS))$fatal(1,"complete healthy ACK zero-control witnesses");
    $display("OFFLINE_ACK_PHASE input=%0d output=%0d handoff=%0d held_final_prefetch=%0d parked_full_source=%0d",ack_f_input,ack_f_output,ack_f_handoff,held_final_prefetch,parked_full_source);
    $display("OFFLINE_SERVICE max_forward_interval=%0d max_inverse_publication_interval=%0d max_retained_wait=%0d capacity_claim=%0d",max_forward_interval,max_inverse_publication_interval,max_retained_wait,RESET_SIDE==0&&STALL<=2);
    $display("OFFLINE_PASS composition DERIVED_CONTEXT source=%0d forward=%0d product=%0d inverse=%0d read=%0d overlap_input=%0d overlap_read=%0d first_dispatch=%0d",source_count,forward_words,product_words,inverse_words,read_count,overlap_inputs,overlap_reads,first_dispatch);
  end endtask
  initial begin #9000000;$fatal(1,"absolute offline timeout");end
  // Script-only injected-fault process absent in the seven approved contexts.

  localparam O=1,R=1,B=1,L=1,FAST_MHZ=175,QUICK_MUTATION=0,REGISTERED_SCHEDULING=1;
  // BEGIN PAYLOAD_BUBBLE_SHADOW: additive independent frozen arithmetic chain.
  wire [31:0] payload_checks, payload_join_occupied, payload_product_occupied;
  wire [31:0] payload_join_invalid, payload_product_invalid;
  starlink_pss_bank_arithmetic_shadow #(.O(O)) payload_shadow (
    .clk(fft_clk), .resetn(`D.fast_running), .flush(1'b0),
    .input_valid(`D.joiner.input_valid), .product_enable(!`D.fast_fault),
    .output_ready(`D.product.output_ready),
    .input_i(`D.joiner.input_i), .input_q(`D.joiner.input_q),
    .input_position(`D.joiner.input_bin_index), .input_exponent(`D.joiner.input_block_exponent),
    .input_last(`D.joiner.input_last), .input_start(`D.joiner.input_block_start_index),
    .join_controls({`D.joiner.input_ready, `D.joiner.output_valid, `D.joiner.output_bin_index,
      `D.joiner.output_block_exponent, `D.joiner.output_last, `D.joiner.output_block_start_index,
      `D.joiner.accepted_pulse, `D.joiner.emitted_pulse, `D.joiner.input_block_complete_pulse,
      `D.joiner.sequence_error_pulse, `D.joiner.metadata_error_pulse, `D.joiner.protocol_fault}),
    .join_payload({`D.joiner.output_i, `D.joiner.output_q, `D.joiner.output_kernel_i, `D.joiner.output_kernel_q}),
    .product_outputs({`D.product.input_ready, `D.product.output_valid, `D.product.output_i,
      `D.product.output_q, `D.product.arithmetic.output_bin_index, `D.product.output_block_exponent,
      `D.product.output_last, `D.product.arithmetic.output_block_start_index, `D.product.arithmetic.output_overflow,
      `D.product.overflow_pulse}),
    .product_private({`D.product.arithmetic.product_valid, `D.product.arithmetic.product_ii, `D.product.arithmetic.product_qq,
      `D.product.arithmetic.product_iq, `D.product.arithmetic.product_qi}),
    .checks(payload_checks), .join_occupied(payload_join_occupied), .product_occupied(payload_product_occupied),
    .join_invalid_differences(payload_join_invalid), .product_invalid_differences(payload_product_invalid)
  );
  // END PAYLOAD_BUBBLE_SHADOW
  // BEGIN FORWARD_RETIREMENT_SHADOW: additive frozen old full guard/chain.
  wire forward_old_valid, forward_old_private;
  wire [31:0] forward_checks, forward_cycles, forward_current, forward_sticky;
  starlink_pss_forward_retirement_shadow #(.ENABLED(1),.COMPLETED(1),.PREFLIGHT(1)) forward_shadow (
    .clk(`D.owners[0].result_guard.clk),
    .resetn(`D.owners[0].result_guard.resetn),
    .job_valid(`D.owners[0].result_guard.job_valid),
    .job_descriptor(`D.owners[0].result_guard.job_descriptor),
    .input_bank_reserved(`D.owners[0].result_guard.input_bank_reserved),
    .output_bank_reserved(`D.owners[0].result_guard.output_bank_reserved),
    .certified_input_beat(`D.owners[0].result_guard.certified_input_beat),
    .certified_input_complete(`D.owners[0].result_guard.certified_input_complete),
    .final_fence_certified(`D.owners[0].result_guard.final_fence_certified),
    .external_fault_now(`D.owners[0].result_guard.external_fault_now),
    .phase_input_fault_now(`D.owners[0].result_guard.phase_input_fault_now),
    .completed_input_certified(`D.owners[0].result_guard.completed_input_certified),
    .completed_input_fault_now(`D.owners[0].result_guard.completed_input_fault_now),
    .preflight_fault_evidence_now(`D.owners[0].result_guard.preflight_fault_evidence_now),
    .core_event_frame_started(`D.owners[0].result_guard.core_event_frame_started),
    .core_output_tdata(`D.owners[0].result_guard.core_output_tdata),
    .core_output_tuser(`D.owners[0].result_guard.core_output_tuser),
    .core_output_tvalid(`D.owners[0].result_guard.core_output_tvalid),
    .core_output_tlast(`D.owners[0].result_guard.core_output_tlast),
    .core_status_tdata(`D.owners[0].result_guard.core_status_tdata),
    .core_status_tvalid(`D.owners[0].result_guard.core_status_tvalid),
    .mailbox_input_ready(`D.owners[0].result_guard.mailbox_input_ready),
    .mailbox_input_fault(`D.owners[0].result_guard.mailbox_input_fault),
    .inverse_phase(1'b0),
    .forward_mailbox_fault(`D.owners[0].result_guard.forward_mailbox_fault),
    .mailbox_current_fault_now(`D.output_bank_framing_fault_now),
    .actual_public({`D.owners[0].result_guard.job_ready,`D.owners[0].result_guard.mailbox_input_valid,`D.owners[0].result_guard.mailbox_private_valid,`D.owners[0].result_guard.mailbox_commit_valid,`D.owners[0].result_guard.mailbox_input_data,`D.owners[0].result_guard.mailbox_input_position,`D.owners[0].result_guard.mailbox_input_last,`D.owners[0].result_guard.mailbox_input_metadata,`D.owners[0].result_guard.busy,`D.owners[0].result_guard.commit_pulse,`D.owners[0].result_guard.protocol_fault,`D.owners[0].result_guard.fault_reasons}),
    .actual_forward_valid(`D.forward_retirement_valid),
    .old_valid(forward_old_valid),
    .old_private_valid(forward_old_private),
    .checks(forward_checks),
    .forward_cycles(forward_cycles),
    .inverse_current_faults(forward_current),
    .sticky_forward_faults(forward_sticky)
  );
  // This second frozen arithmetic chain is driven by OLD certified retirement,
  // not by the candidate join input. All existing shadows remain untouched.
  starlink_pss_bank_arithmetic_shadow #(.O(O)) forward_chain_shadow (
    .clk(fft_clk), .resetn(`D.fast_running), .flush(1'b0),
    .input_valid(forward_old_valid && !`D.next_inverse && !`D.fast_fault && `D.product_bank_ready),
    .product_enable(!`D.fast_fault), .output_ready(`D.product.output_ready),
    .input_i(`D.joiner.input_i), .input_q(`D.joiner.input_q),
    .input_position(`D.joiner.input_bin_index), .input_exponent(`D.joiner.input_block_exponent),
    .input_last(`D.joiner.input_last), .input_start(`D.joiner.input_block_start_index),
    .join_controls({`D.joiner.input_ready, `D.joiner.output_valid, `D.joiner.output_bin_index,
      `D.joiner.output_block_exponent, `D.joiner.output_last, `D.joiner.output_block_start_index,
      `D.joiner.accepted_pulse, `D.joiner.emitted_pulse, `D.joiner.input_block_complete_pulse,
      `D.joiner.sequence_error_pulse, `D.joiner.metadata_error_pulse, `D.joiner.protocol_fault}),
    .join_payload({`D.joiner.output_i, `D.joiner.output_q, `D.joiner.output_kernel_i, `D.joiner.output_kernel_q}),
    .product_outputs({`D.product.input_ready, `D.product.output_valid, `D.product.output_i,
      `D.product.output_q, `D.product.arithmetic.output_bin_index, `D.product.output_block_exponent,
      `D.product.output_last, `D.product.arithmetic.output_block_start_index, `D.product.arithmetic.output_overflow,
      `D.product.overflow_pulse}),
    .product_private({`D.product.arithmetic.product_valid, `D.product.arithmetic.product_ii, `D.product.arithmetic.product_qq,
      `D.product.arithmetic.product_iq, `D.product.arithmetic.product_qi}),
    .checks(), .join_occupied(), .product_occupied(), .join_invalid_differences(), .product_invalid_differences()
  );
  always @(posedge fft_clk) begin
    #0.001;
    if (`D.joiner.input_valid !==
        (forward_old_valid && !`D.next_inverse && !`D.fast_fault && `D.product_bank_ready))
      $fatal(1, "FORWARD_ACTUAL_JOIN_INPUT_MISMATCH");
    if (`D.output_bank.input_valid !== (`D.return_private_valid && `D.next_inverse))
      $fatal(1, "FORWARD_ACTUAL_BANK_PHASE_WIRING_BROKEN");
  end
  // END FORWARD_RETIREMENT_SHADOW
// Additive observer and binding only; no original stimulus/check retiming.
starlink_pss_local_admission_actual_observer #(.L(L)) local_guard_observer (
  .clk(`D.input_guard.clk), .resetn(`D.input_guard.resetn),
  .job_start(`D.input_guard.job_start), .job_descriptor(`D.input_guard.job_descriptor),
  .input_enable(`D.input_guard.input_enable), .input_valid(`D.input_guard.input_valid),
  .input_data(`D.input_guard.input_data), .input_position(`D.input_guard.input_position),
  .input_last(`D.input_guard.input_last), .input_metadata(`D.input_guard.input_metadata),
  .core_input_tready(`D.input_guard.core_input_tready),
  .actual_view({`D.input_guard.input_ready,`D.input_guard.input_transport_ready,`D.input_guard.core_input_tdata,
    `D.input_guard.core_input_tvalid,`D.input_guard.core_input_tlast,`D.input_guard.certified_input_beat,`D.input_guard.certified_input_complete,
    `D.input_guard.input_complete,`D.input_guard.fault_now,`D.input_guard.duplicate_start_fault_now,`D.input_guard.fault_events_now,
    `D.input_guard.protocol_fault,`D.input_guard.fault_reasons,`D.input_guard.job_started,`D.input_guard.input_started,`D.input_guard.descriptor,`D.input_guard.expected_position,
    `D.input_guard.slot_open,`D.input_guard.eligible,`D.input_guard.metadata_valid,`D.input_guard.identity_matches,`D.input_guard.errors_now,
    `D.input_guard.framing_error,`D.input_guard.delivery_error,`D.input_guard.duplicate_start})
);
initial begin
  #0.01;
  if ((L !== 0 && L !== 1) || R !== 1 || B !== 1 || O !== 1 || FAST_MHZ !== 175 ||
      QUICK_MUTATION !== 0 || `D.LOCAL_FIRST_ADMISSION !== L ||
      `D.input_guard.LOCAL_FIRST_ADMISSION !== L ||
      `D.input_guard.CHECK_INPUT_BLOCK_IDENTITY !== 1 ||
      `D.input_guard.BALANCED_IDENTITY_EQ !== 1 ||
      local_guard_observer.L !== L || local_guard_observer.default_guard.LOCAL_FIRST_ADMISSION !== 0)
    $fatal(1,"LOCAL_ADMISSION_ACTUAL_INSTANCE_BINDING_MISMATCH");
end

// Read-only sampled core interface and event-indexed receipt; no vendor internals.
integer actual_inputs=0,actual_raw=0,actual_status=0,actual_frames=0,actual_config=0;
integer actual_jobs=0,actual_commits=0,actual_aborts=0,actual_input_total=0;
integer actual_raw_total=0,actual_status_total=0,actual_fixture=0;
integer actual_admit=0,actual_first_input=0,actual_last_input=0,actual_first_raw=0;
integer actual_reset_low=0,actual_frame_cycle=0;
reg actual_inverse=0,actual_active=0,actual_previous_resetn=0;
reg[63:0]actual_start=0;
reg[35:0]actual_expected;
reg[4:0]actual_exponent;
task automatic actual_word(input string stream,input integer job,input integer pos,
  input reg[47:0]data,input reg[63:0]start,input reg[9:0]exponent);
  $fdisplay(words_log,"%0d,%s,%0d,%0d,%012h,%016h,%03h,%0d,%0d,%0.0f",
    context_id,stream,job,pos,data,start,exponent,fast_cycles,slow_edges,$realtime*1000000.0);
endtask
always @(posedge fft_clk)begin
  #0; // inactive region before NBA; source stimulus is driven on falling edges.
  if(`D.fast_running)begin
    if((^({`D.core_aresetn,`D.job_accept,`D.config_valid,`D.config_ready,
      `D.core_input_valid,`D.core_input_ready,`D.core_output_valid,`D.core_status_valid,
      `D.event_frame,`D.event_last_unexpected,`D.event_last_missing,`D.event_input_halt,
      `D.certified_input_beat,`D.certified_input_complete}))===1'bx)
      $fatal(1,"unknown actual core protocol control");
    if(!`D.core_aresetn)actual_reset_low=actual_reset_low+1;
    if(`D.core_aresetn&&!actual_previous_resetn)begin
      if(actual_reset_low<2)$fatal(1,"actual sampled reset shorter than two cycles");
      $display("RACT_RESET_RELEASE context=%0d cycle=%0d sampled_low=%0d",context_id,fast_cycles,actual_reset_low);
      actual_reset_low=0;
    end
    actual_previous_resetn=`D.core_aresetn;
    if(`D.job_accept)begin
      if(actual_active)$fatal(1,"actual overlapping core owners");
      actual_start=`D.engine_metadata[68:5];
      if(actual_start<1000||(actual_start-1000)%447!=0||(actual_start-1000)/447>2)
        $fatal(1,"actual independent source identity");
      actual_fixture=(actual_start-1000)/447;actual_inverse=`D.next_inverse;
      actual_inputs=0;actual_raw=0;actual_status=0;actual_frames=0;actual_config=0;
      actual_admit=fast_cycles;actual_active=1;actual_jobs=actual_jobs+1;
      $display("RACT_ADMIT context=%0d job=%0d inverse=%0d start=%0d cycle=%0d source_valid=%b source_start=%0d retained=%b",
        context_id,actual_jobs,actual_inverse,actual_start,fast_cycles,`D.source_valid,`D.source_metadata[68:5],`D.retained_published);
    end
    if(`D.config_valid&&`D.config_ready)begin
      if(!actual_active||actual_config!=0||fast_cycles-actual_admit!=3||
        `D.shared_xfft.s_axis_config_tdata!==(actual_inverse?8'h00:8'h01))$fatal(1,"actual config handshake/timing");
      actual_config=actual_config+1;
    end
    if(`D.certified_input_beat!==(`D.core_input_valid&&`D.core_input_ready))
      $fatal(1,"physical/certified core input mismatch");
    if(`D.core_input_valid&&`D.core_input_ready)begin
      if(!actual_active||actual_config!=1||actual_inputs>=512)$fatal(1,"unowned actual core input");
      actual_expected=actual_inverse?products[actual_fixture*512+actual_inputs]:
        {samples[actual_fixture*447+actual_inputs][31:16],2'b0,samples[actual_fixture*447+actual_inputs][15:0],2'b0};
      if(`D.core_input_data!=={6'b0,actual_expected[35:18],6'b0,actual_expected[17:0]}||
         `D.core_input_last!==(actual_inputs==511))
        $fatal(1,"actual48 input context=%0d job=%0d ordinal=%0d actual=%h expected=%h",context_id,actual_jobs,actual_inputs,`D.core_input_data,{6'b0,actual_expected[35:18],6'b0,actual_expected[17:0]});
      if(actual_inputs==0)actual_first_input=fast_cycles;
      actual_last_input=fast_cycles;
      actual_word(actual_inverse?"inputI":"inputF",actual_fixture,actual_inputs,`D.core_input_data,actual_start,0);
      actual_inputs=actual_inputs+1;actual_input_total=actual_input_total+1;
      if(`D.certified_input_complete!==(actual_inputs==512))$fatal(1,"actual physical final certification");
    end else if(`D.certified_input_complete)$fatal(1,"completion without physical final input");
    if(`D.event_frame)begin
      if(!actual_active||actual_frames!=0||actual_inputs!=1)$fatal(1,"actual fresh frame ordinal");
      actual_frames=actual_frames+1;actual_frame_cycle=fast_cycles;
    end
    actual_exponent=actual_inverse?ie[actual_fixture]:fe[actual_fixture];
    if(`D.core_status_valid)begin
      if(!actual_active||actual_inputs!=512||actual_status!=0||actual_raw!=2||
         `D.core_status_data!=={3'b0,actual_exponent})$fatal(1,"actual status join/ordinal/exponent");
      actual_status=actual_status+1;actual_status_total=actual_status_total+1;
      $display("RACT_STATUS context=%0d job=%0d ordinal=%0d cycle=%0d",context_id,actual_jobs,actual_raw,fast_cycles);
    end
    if(`D.core_output_valid)begin
      if(!actual_active||actual_inputs!=512||actual_frames!=1||actual_raw>=512)
        $fatal(1,"unowned actual raw output");
      actual_expected=actual_inverse?inverses[actual_fixture*512+actual_raw]:forwards[actual_fixture*512+actual_raw];
      // PG109 May4 2022 printed p21: output TDATA sign-extends to byte boundaries.
      if(`D.core_output_data!=={{6{actual_expected[35]}},actual_expected[35:18],{6{actual_expected[17]}},actual_expected[17:0]}||
         `D.core_output_user!=={3'b0,actual_exponent,7'b0,9'(actual_raw)}||
         `D.core_output_last!==(actual_raw==511))$fatal(1,"actual raw packed payload/index/exponent");
      if(actual_raw==0)begin
        actual_first_raw=fast_cycles;
        if(fast_cycles-actual_last_input!=781)$fatal(1,"actual raw first absolute service");
      end
      if(actual_raw==511&&fast_cycles-actual_admit!=1809)$fatal(1,"actual raw last absolute service");
      actual_word(actual_inverse?"rawI":"rawF",actual_fixture,actual_raw,`D.core_output_data,actual_start,{5'b0,actual_exponent});
      actual_raw=actual_raw+1;actual_raw_total=actual_raw_total+1;
    end
    if(`D.return_commit_valid&&`D.result_destination_ready)begin
      if(!actual_active||actual_inputs!=512||actual_raw!=512||actual_status!=1||actual_frames!=1||
         actual_config!=1||actual_last_input-actual_first_input+1!=513||fast_cycles-actual_admit!=1810)
        $fatal(1,"actual complete transform absolute service/inventory");
      $display("RACT_JOB context=%0d job=%0d inverse=%0d fixture=%0d admit=%0d config_delta=3 input_first=%0d input_last=%0d raw_first=%0d publication=%0d inputs=512 raw=512 status=1 frame=1",
        context_id,actual_jobs,actual_inverse,actual_fixture,actual_admit,actual_first_input,actual_last_input,actual_first_raw,fast_cycles);
      actual_commits=actual_commits+1;actual_active=0;
    end
    if(`D.product_valid&&`D.product_bank_ready)
      actual_word("product",actual_fixture,`D.product_position,{12'b0,`D.product_q,`D.product_i},actual_start,{5'b0,`D.product_exponent});
    if(`D.guard_private_out[1]&&`D.output_bank_ready)
      actual_word("privateI",actual_fixture,`D.guard_return_position[1],{12'b0,`D.guard_return_data[1]},actual_start,`D.guard_return_metadata[1][9:0]);
    if(`D.guard_commit_out[1]&&`D.output_bank_ready)
      $display("RACT_SOURCE_ELIGIBILITY context=%0d cycle=%0d source_valid=%b source_start=%0d",context_id,fast_cycles,`D.source_valid,`D.source_metadata[68:5]);
  end else begin actual_previous_resetn=0;actual_reset_low=0;end
end
always @(negedge resetn or negedge fft_resetn)begin
  if(actual_active)begin
    if(context_id<5||actual_inverse||actual_fixture!=1||actual_inputs<64||actual_inputs>=512||
       actual_raw!=0||actual_status!=0||actual_config!=1||actual_frames!=1)
      $fatal(1,"unexpected reset of actual core owner");
    $display("RACT_ABORT context=%0d job=%0d fixture=%0d inputs=%0d first=%0d last=%0d raw=0 status=0 cycle=%0d",
      context_id,actual_jobs,actual_fixture,actual_inputs,actual_first_input,actual_last_input,fast_cycles);
    actual_aborts=actual_aborts+1;actual_active=0;
  end
end
always @(posedge clk)begin
  #0;
  if(input_valid&&input_ready)actual_word("source",int'((input_block_start-1000)/447),input_position,{12'b0,input_data},input_block_start,0);
  if(output_valid&&output_ready)actual_word("read",int'((output_metadata[73:10]-1000)/447),output_position,{12'b0,output_data},output_metadata[73:10],output_metadata[9:0]);
end

// Test orchestration only: seven fixed contexts, one DUT and one FFT instance.
integer context_id=-1, context_done=0, words_log=0;
integer total_source=0,total_forward=0,total_product=0,total_inverse=0,total_read=0;
integer total_F=0,total_I=0;
task automatic prepare_context(input integer id,input integer stall,input integer side);
  begin
    @(negedge fft_clk); resetn=0;fft_resetn=0;input_valid=0;run_slow=1;
    repeat(8)@(negedge fft_clk);
    context_id=id;STALL=stall;RESET_SIDE=side;new_epoch=0;
    forward_jobs=0;inverse_jobs=0;read_count=0;source_count=0;
    forward_words=0;product_words=0;inverse_words=0;status_count=0;
    output_fixture_base=0;last_forward_admit=-1;max_forward_interval=0;
    max_retained_wait=0;max_inverse_publication_interval=0;
    ack_f_input=0;ack_f_output=0;ack_f_handoff=0;held_final_prefetch=0;parked_full_source=0;
    ack_zero_controls=0;overlap_inputs=0;overlap_reads=0;retained_finals=0;parked_wait_i=0;
    last_inverse_publish=-1;last_real_release=-1;first_dispatch=-1;
    selected_fixture=0;raw_words=0;raw_phase=0;inverse_publications=0;
    stalled=0;held_output=0;
    $display("RACT_BEGIN context=%0d stall=%0d reset=%0d cycle=%0d",id,stall,side,fast_cycles);
  end
endtask
task automatic finish_context;
  begin
    if(context_id!=context_done)$fatal(1,"actual context identity/order");
    if(actual_active||actual_inputs!=512||actual_raw!=512||actual_status!=1)
      $fatal(1,"actual current core not complete at context end");
    if(`D.retained_reusable!==1||`D.retained_published!==0||`D.state!==`D.WAIT_BANK||
       `D.next_inverse!==0||`D.any_fast_fault!==0||output_valid!==0)
      $fatal(1,"actual context terminal ownership");
    if(local_guard_observer.current_faults!=0||local_guard_observer.sticky_faults!=0||
       local_guard_observer.duplicate_checks!=0)$fatal(1,"unexpected healthy input observer fault");
    total_source=total_source+source_count;total_forward=total_forward+forward_words;
    total_product=total_product+product_words;total_inverse=total_inverse+inverse_words;
    total_read=total_read+read_count;total_F=total_F+forward_jobs;total_I=total_I+inverse_jobs;
    $display("RACT_CONTEXT context=%0d source=%0d F=%0d I=%0d forward=%0d product=%0d inverse=%0d read=%0d status=%0d dispatch=%0d service=%0d publication_interval=%0d retained_wait=%0d cycle=%0d",
      context_id,source_count,forward_jobs,inverse_jobs,forward_words,product_words,inverse_words,
      read_count,status_count,first_dispatch,max_forward_interval,max_inverse_publication_interval,max_retained_wait,fast_cycles);
    context_done=context_done+1;
  end
endtask
initial begin
  if(FAULT_KIND!==0||FAULT_OFFSET!==0||FAULT_BOUNDARY!==0||BLOCKS!==3)
    $fatal(1,"only seven fixed actual contexts admitted");
  words_log=$fopen("actual_words.csv","w");if(!words_log)$fatal(1,"actual numerical log open");
  $fdisplay(words_log,"context,stream,job,position,data,start,exponent,fast,slow,time_fs");
  prepare_context(0,0,0);run_context();finish_context();
  prepare_context(1,1,0);run_context();finish_context();
  prepare_context(2,2,0);run_context();finish_context();
  prepare_context(3,4,0);run_context();finish_context();
  prepare_context(4,5,0);run_context();finish_context();
  prepare_context(5,0,1);run_context();finish_context();
  prepare_context(6,0,2);run_context();finish_context();
  if(context_done!=7||total_source!=10752||total_F!=21||total_I!=19||
     total_forward!=9728||total_product!=9728||total_inverse!=9728||total_read!=8704||
     actual_jobs!=40||actual_commits!=38||actual_aborts!=2||actual_raw_total!=19456||
     actual_status_total!=38||local_guard_observer.forward_starts!=21||
     local_guard_observer.inverse_starts!=19||local_guard_observer.pre_checks<1024||
     local_guard_observer.post_checks!=local_guard_observer.pre_checks||
     local_guard_observer.reset_checks<7||local_guard_observer.closed_prefetch==0||
     payload_checks<1024||payload_join_occupied==0||payload_product_occupied==0||
     forward_checks<1024||forward_cycles==0)$fatal(1,"actual seven-context total/shadow inventory");
  $fclose(words_log);
  $display("RACT_SHADOW input_pre=%0d input_post=%0d input_resets=%0d Fstarts=%0d Istarts=%0d arithmetic=%0d retirement=%0d",
    local_guard_observer.pre_checks,local_guard_observer.post_checks,local_guard_observer.reset_checks,
    local_guard_observer.forward_starts,local_guard_observer.inverse_starts,payload_checks,forward_checks);
  $display("RACT_PASS contexts=7 source=10752 F=21 I=19 pairs=19 aborted_F=2 forward=9728 product=9728 inverse=9728 read=8704 raw=19456 status=38 physical_inputs=%0d discarded_old_unread=1024",actual_input_total);
  $finish;
end

  `undef D

  // Test-only unconditionally sampled baseline guards; no DUT feedback.
  starlink_pss_realtime_result_guard #(.USE_COMPLETED_INPUT_FAULT(1),
    .USE_PREFLIGHT_REASON_ONLY(1),.USE_FORWARD_RETIREMENT(1)) baseline_guard_0(.clk(dut.retained.island.owners[0].result_guard.clk),
.resetn(dut.retained.island.owners[0].result_guard.resetn),
.job_valid(dut.retained.island.owners[0].result_guard.job_valid),
.job_descriptor(dut.retained.island.owners[0].result_guard.job_descriptor),
.input_bank_reserved(dut.retained.island.owners[0].result_guard.input_bank_reserved),
.output_bank_reserved(dut.retained.island.owners[0].result_guard.output_bank_reserved),
.certified_input_beat(dut.retained.island.owners[0].result_guard.certified_input_beat),
.certified_input_complete(dut.retained.island.owners[0].result_guard.certified_input_complete),
.final_fence_certified(dut.retained.island.owners[0].result_guard.final_fence_certified),
.external_fault_now(dut.retained.island.owners[0].result_guard.external_fault_now),
.phase_input_fault_now(dut.retained.island.owners[0].result_guard.phase_input_fault_now),
.completed_input_certified(dut.retained.island.owners[0].result_guard.completed_input_certified),
.completed_input_fault_now(dut.retained.island.owners[0].result_guard.completed_input_fault_now),
.preflight_fault_evidence_now(dut.retained.island.owners[0].result_guard.preflight_fault_evidence_now),
.core_event_frame_started(dut.retained.island.owners[0].result_guard.core_event_frame_started),
.core_output_tdata(dut.retained.island.owners[0].result_guard.core_output_tdata),
.core_output_tuser(dut.retained.island.owners[0].result_guard.core_output_tuser),
.core_output_tvalid(dut.retained.island.owners[0].result_guard.core_output_tvalid),
.core_output_tlast(dut.retained.island.owners[0].result_guard.core_output_tlast),
.core_status_tdata(dut.retained.island.owners[0].result_guard.core_status_tdata),
.core_status_tvalid(dut.retained.island.owners[0].result_guard.core_status_tvalid),
.mailbox_input_ready(dut.retained.island.owners[0].result_guard.mailbox_input_ready),
.mailbox_input_fault(dut.retained.island.owners[0].result_guard.mailbox_input_fault),
.inverse_phase(dut.retained.island.owners[0].result_guard.inverse_phase),
.forward_mailbox_fault(dut.retained.island.owners[0].result_guard.forward_mailbox_fault));
  always @(posedge fft_clk or negedge fft_clk)begin #0.001;if(baseline_guard_0.job_ready !== dut.retained.island.owners[0].result_guard.job_ready) $fatal(1,"unconditional owner0 job_ready");
if(baseline_guard_0.mailbox_input_valid !== dut.retained.island.owners[0].result_guard.mailbox_input_valid) $fatal(1,"unconditional owner0 mailbox_input_valid");
if(baseline_guard_0.mailbox_private_valid !== dut.retained.island.owners[0].result_guard.mailbox_private_valid) $fatal(1,"unconditional owner0 mailbox_private_valid");
if(baseline_guard_0.mailbox_commit_valid !== dut.retained.island.owners[0].result_guard.mailbox_commit_valid) $fatal(1,"unconditional owner0 mailbox_commit_valid");
if(baseline_guard_0.forward_retirement_valid !== dut.retained.island.owners[0].result_guard.forward_retirement_valid) $fatal(1,"unconditional owner0 forward_retirement_valid");
if(baseline_guard_0.mailbox_input_data !== dut.retained.island.owners[0].result_guard.mailbox_input_data) $fatal(1,"unconditional owner0 mailbox_input_data");
if(baseline_guard_0.mailbox_input_position !== dut.retained.island.owners[0].result_guard.mailbox_input_position) $fatal(1,"unconditional owner0 mailbox_input_position");
if(baseline_guard_0.mailbox_input_last !== dut.retained.island.owners[0].result_guard.mailbox_input_last) $fatal(1,"unconditional owner0 mailbox_input_last");
if(baseline_guard_0.mailbox_input_metadata !== dut.retained.island.owners[0].result_guard.mailbox_input_metadata) $fatal(1,"unconditional owner0 mailbox_input_metadata");
if(baseline_guard_0.busy !== dut.retained.island.owners[0].result_guard.busy) $fatal(1,"unconditional owner0 busy");
if(baseline_guard_0.commit_pulse !== dut.retained.island.owners[0].result_guard.commit_pulse) $fatal(1,"unconditional owner0 commit_pulse");
if(baseline_guard_0.protocol_fault !== dut.retained.island.owners[0].result_guard.protocol_fault) $fatal(1,"unconditional owner0 protocol_fault");
if(baseline_guard_0.fault_reasons !== dut.retained.island.owners[0].result_guard.fault_reasons) $fatal(1,"unconditional owner0 fault_reasons");
if(baseline_guard_0.active_private !== dut.retained.island.owners[0].result_guard.active_private) $fatal(1,"unconditional owner0 active_private");
if(baseline_guard_0.awaiting_ack !== dut.retained.island.owners[0].result_guard.awaiting_ack) $fatal(1,"unconditional owner0 awaiting_ack");
if(baseline_guard_0.descriptor !== dut.retained.island.owners[0].result_guard.descriptor) $fatal(1,"unconditional owner0 descriptor");
if(baseline_guard_0.input_count !== dut.retained.island.owners[0].result_guard.input_count) $fatal(1,"unconditional owner0 input_count");
if(baseline_guard_0.output_count !== dut.retained.island.owners[0].result_guard.output_count) $fatal(1,"unconditional owner0 output_count");
if(baseline_guard_0.input_complete_seen !== dut.retained.island.owners[0].result_guard.input_complete_seen) $fatal(1,"unconditional owner0 input_complete_seen");
if(baseline_guard_0.frame_seen !== dut.retained.island.owners[0].result_guard.frame_seen) $fatal(1,"unconditional owner0 frame_seen");
if(baseline_guard_0.status_seen !== dut.retained.island.owners[0].result_guard.status_seen) $fatal(1,"unconditional owner0 status_seen");
if(baseline_guard_0.exponent_seen !== dut.retained.island.owners[0].result_guard.exponent_seen) $fatal(1,"unconditional owner0 exponent_seen");
if(baseline_guard_0.status_exponent !== dut.retained.island.owners[0].result_guard.status_exponent) $fatal(1,"unconditional owner0 status_exponent");
if(baseline_guard_0.output_exponent !== dut.retained.island.owners[0].result_guard.output_exponent) $fatal(1,"unconditional owner0 output_exponent");
if(baseline_guard_0.age !== dut.retained.island.owners[0].result_guard.age) $fatal(1,"unconditional owner0 age");
if(baseline_guard_0.return_occupied !== dut.retained.island.owners[0].result_guard.return_occupied) $fatal(1,"unconditional owner0 return_occupied");
if(baseline_guard_0.return_last !== dut.retained.island.owners[0].result_guard.return_last) $fatal(1,"unconditional owner0 return_last");
if(baseline_guard_0.return_data !== dut.retained.island.owners[0].result_guard.return_data) $fatal(1,"unconditional owner0 return_data");
if(baseline_guard_0.return_position !== dut.retained.island.owners[0].result_guard.return_position) $fatal(1,"unconditional owner0 return_position");
if(baseline_guard_0.return_exponent !== dut.retained.island.owners[0].result_guard.return_exponent) $fatal(1,"unconditional owner0 return_exponent"); end
  starlink_pss_realtime_result_guard #(.USE_COMPLETED_INPUT_FAULT(1),
    .USE_PREFLIGHT_REASON_ONLY(1),.USE_FORWARD_RETIREMENT(1)) baseline_guard_1(.clk(dut.retained.island.owners[1].result_guard.clk),
.resetn(dut.retained.island.owners[1].result_guard.resetn),
.job_valid(dut.retained.island.owners[1].result_guard.job_valid),
.job_descriptor(dut.retained.island.owners[1].result_guard.job_descriptor),
.input_bank_reserved(dut.retained.island.owners[1].result_guard.input_bank_reserved),
.output_bank_reserved(dut.retained.island.owners[1].result_guard.output_bank_reserved),
.certified_input_beat(dut.retained.island.owners[1].result_guard.certified_input_beat),
.certified_input_complete(dut.retained.island.owners[1].result_guard.certified_input_complete),
.final_fence_certified(dut.retained.island.owners[1].result_guard.final_fence_certified),
.external_fault_now(dut.retained.island.owners[1].result_guard.external_fault_now),
.phase_input_fault_now(dut.retained.island.owners[1].result_guard.phase_input_fault_now),
.completed_input_certified(dut.retained.island.owners[1].result_guard.completed_input_certified),
.completed_input_fault_now(dut.retained.island.owners[1].result_guard.completed_input_fault_now),
.preflight_fault_evidence_now(dut.retained.island.owners[1].result_guard.preflight_fault_evidence_now),
.core_event_frame_started(dut.retained.island.owners[1].result_guard.core_event_frame_started),
.core_output_tdata(dut.retained.island.owners[1].result_guard.core_output_tdata),
.core_output_tuser(dut.retained.island.owners[1].result_guard.core_output_tuser),
.core_output_tvalid(dut.retained.island.owners[1].result_guard.core_output_tvalid),
.core_output_tlast(dut.retained.island.owners[1].result_guard.core_output_tlast),
.core_status_tdata(dut.retained.island.owners[1].result_guard.core_status_tdata),
.core_status_tvalid(dut.retained.island.owners[1].result_guard.core_status_tvalid),
.mailbox_input_ready(dut.retained.island.owners[1].result_guard.mailbox_input_ready),
.mailbox_input_fault(dut.retained.island.owners[1].result_guard.mailbox_input_fault),
.inverse_phase(dut.retained.island.owners[1].result_guard.inverse_phase),
.forward_mailbox_fault(dut.retained.island.owners[1].result_guard.forward_mailbox_fault));
  always @(posedge fft_clk or negedge fft_clk)begin #0.001;if(baseline_guard_1.job_ready !== dut.retained.island.owners[1].result_guard.job_ready) $fatal(1,"unconditional owner1 job_ready");
if(baseline_guard_1.mailbox_input_valid !== dut.retained.island.owners[1].result_guard.mailbox_input_valid) $fatal(1,"unconditional owner1 mailbox_input_valid");
if(baseline_guard_1.mailbox_private_valid !== dut.retained.island.owners[1].result_guard.mailbox_private_valid) $fatal(1,"unconditional owner1 mailbox_private_valid");
if(baseline_guard_1.mailbox_commit_valid !== dut.retained.island.owners[1].result_guard.mailbox_commit_valid) $fatal(1,"unconditional owner1 mailbox_commit_valid");
if(baseline_guard_1.forward_retirement_valid !== dut.retained.island.owners[1].result_guard.forward_retirement_valid) $fatal(1,"unconditional owner1 forward_retirement_valid");
if(baseline_guard_1.mailbox_input_data !== dut.retained.island.owners[1].result_guard.mailbox_input_data) $fatal(1,"unconditional owner1 mailbox_input_data");
if(baseline_guard_1.mailbox_input_position !== dut.retained.island.owners[1].result_guard.mailbox_input_position) $fatal(1,"unconditional owner1 mailbox_input_position");
if(baseline_guard_1.mailbox_input_last !== dut.retained.island.owners[1].result_guard.mailbox_input_last) $fatal(1,"unconditional owner1 mailbox_input_last");
if(baseline_guard_1.mailbox_input_metadata !== dut.retained.island.owners[1].result_guard.mailbox_input_metadata) $fatal(1,"unconditional owner1 mailbox_input_metadata");
if(baseline_guard_1.busy !== dut.retained.island.owners[1].result_guard.busy) $fatal(1,"unconditional owner1 busy");
if(baseline_guard_1.commit_pulse !== dut.retained.island.owners[1].result_guard.commit_pulse) $fatal(1,"unconditional owner1 commit_pulse");
if(baseline_guard_1.protocol_fault !== dut.retained.island.owners[1].result_guard.protocol_fault) $fatal(1,"unconditional owner1 protocol_fault");
if(baseline_guard_1.fault_reasons !== dut.retained.island.owners[1].result_guard.fault_reasons) $fatal(1,"unconditional owner1 fault_reasons");
if(baseline_guard_1.active_private !== dut.retained.island.owners[1].result_guard.active_private) $fatal(1,"unconditional owner1 active_private");
if(baseline_guard_1.awaiting_ack !== dut.retained.island.owners[1].result_guard.awaiting_ack) $fatal(1,"unconditional owner1 awaiting_ack");
if(baseline_guard_1.descriptor !== dut.retained.island.owners[1].result_guard.descriptor) $fatal(1,"unconditional owner1 descriptor");
if(baseline_guard_1.input_count !== dut.retained.island.owners[1].result_guard.input_count) $fatal(1,"unconditional owner1 input_count");
if(baseline_guard_1.output_count !== dut.retained.island.owners[1].result_guard.output_count) $fatal(1,"unconditional owner1 output_count");
if(baseline_guard_1.input_complete_seen !== dut.retained.island.owners[1].result_guard.input_complete_seen) $fatal(1,"unconditional owner1 input_complete_seen");
if(baseline_guard_1.frame_seen !== dut.retained.island.owners[1].result_guard.frame_seen) $fatal(1,"unconditional owner1 frame_seen");
if(baseline_guard_1.status_seen !== dut.retained.island.owners[1].result_guard.status_seen) $fatal(1,"unconditional owner1 status_seen");
if(baseline_guard_1.exponent_seen !== dut.retained.island.owners[1].result_guard.exponent_seen) $fatal(1,"unconditional owner1 exponent_seen");
if(baseline_guard_1.status_exponent !== dut.retained.island.owners[1].result_guard.status_exponent) $fatal(1,"unconditional owner1 status_exponent");
if(baseline_guard_1.output_exponent !== dut.retained.island.owners[1].result_guard.output_exponent) $fatal(1,"unconditional owner1 output_exponent");
if(baseline_guard_1.age !== dut.retained.island.owners[1].result_guard.age) $fatal(1,"unconditional owner1 age");
if(baseline_guard_1.return_occupied !== dut.retained.island.owners[1].result_guard.return_occupied) $fatal(1,"unconditional owner1 return_occupied");
if(baseline_guard_1.return_last !== dut.retained.island.owners[1].result_guard.return_last) $fatal(1,"unconditional owner1 return_last");
if(baseline_guard_1.return_data !== dut.retained.island.owners[1].result_guard.return_data) $fatal(1,"unconditional owner1 return_data");
if(baseline_guard_1.return_position !== dut.retained.island.owners[1].result_guard.return_position) $fatal(1,"unconditional owner1 return_position");
if(baseline_guard_1.return_exponent !== dut.retained.island.owners[1].result_guard.return_exponent) $fatal(1,"unconditional owner1 return_exponent"); end
endmodule

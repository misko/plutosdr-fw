proc version args {return 2022.2}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/actual-language-parent.jB1Pioe2/cases/retained_actual_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} 3a0eb7872722b65764178c813ec96946e61ce0ac226c0202ea0a70d24e559eeb {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/actual-language-parent.jB1Pioe2/cases/test_runner_early_admission_re0/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/actual-language-parent.jB1Pioe2/cases/test_runner_early_admission_re0/runner.tcl}

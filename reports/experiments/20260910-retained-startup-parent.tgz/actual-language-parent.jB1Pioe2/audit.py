"""Verify the exact two-source language-only delta and independent test receipts."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
recovery=root.parent
old=json.loads((recovery/'retained-output-actual-prelaunch-v1/manifest.json').read_text())
new_path=recovery/'retained-output-actual-prelaunch-language-v2/manifest.json'
assert hashlib.sha256(new_path.read_bytes()).hexdigest()=='3a0eb7872722b65764178c813ec96946e61ce0ac226c0202ea0a70d24e559eeb'
new=json.loads(new_path.read_text())
changed=[p for p in old['sources'] if old['sources'][p]!=new['sources'][p]]
assert set(changed)=={'tests/test_starlink_retained_output_actual_bundle.py','hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl'}
assert old['compiled']==new['compiled'] and old['vectors']==new['vectors']
assert old['files']['bench.sv']==new['files']['bench.sv'] and old['files']['profile.tcl']==new['files']['profile.tcl']
pins=json.loads((root/'source-pins.json').read_text())
assert len(pins)==71 and all(new['sources'][p]['sha256']==pin for p,pin in pins.items())
assert json.loads((root/'execution.json').read_text())=={'exit':0,'changed':[],'source_count':71}
suite=ET.parse(root/'results.xml').getroot().find('testsuite')
assert all(suite.get(k)==v for k,v in {'tests':'31','failures':'0','errors':'0','skipped':'0'}.items())
ledgers=list((root/'cases').rglob('offline_language_selection.txt'))
assert len(ledgers)==2
for p in ledgers:
    lines=p.read_text().splitlines()
    assert lines[0]=='OFFLINE_STUB_EXACT_SYSTEMVERILOG_COMPILE_PLAN_NOT_VENDOR'
    expected=[str(p.parent/'actual_not_executed/inputs'/n) for n in new['compiled']+['bench.sv']]
    assert lines[1:]==expected and len(set(expected))==27
result={'tests':31,'unchanged_source_count':69,'changed_sources':changed,
        'unchanged_bench_profile_vectors':True,'exact_27_file_ledgers':2,'actual_execution':False}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

"""Independent full preparation gate. Tcl tests are stubs, never vendor calls."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root=Path(__file__).resolve().parent
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
sys.path.insert(0,str(tree))
from tests.starlink_oracle import retained_output_actual_bundle as bundle
from tests.starlink_oracle import retained_output_actual as actual

actual.verify_originals()
names=bundle.source_names()
assert len(names)==71
pins={p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in names}
assert pins['tests/starlink_oracle/retained_output_actual_bundle.py']=='8bc9a42cfd41b7b55a5b302c7eac3a5b6ba74a23d715386b12b9b0f0283825f8'
assert pins['tests/test_starlink_retained_output_actual_bundle.py']=='36ef44f70887ab61c4ae366fd22efa6f4a01ac69b780aa82810f27f8ba75805d'
assert pins['tools/prepare_starlink_retained_output_actual.py']=='2f6b38867dd89a3f827b3acd60315aa2057f3134c6285bde1fbbbebf26c605b2'
assert pins['hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl']=='7867e76a88c833996f99c881d5065b3a86877bd02c0838c307524de3fe926d38'
for p in pins:
    target=root/'source'/p;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(tree/p,target)
(root/'source-pins.json').write_text(json.dumps(pins,indent=2))
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
env['TMPDIR']=str(root)
cmd=[sys.executable,'-B','-m','pytest','-q',
     'tests/test_starlink_retained_output_actual_bundle.py','--basetemp',str(root/'cases'),
     '-p','no:cacheprovider','--junitxml',str(root/'results.xml')]
(root/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(tree),'kind':'OFFLINE_SCRIPT_AND_TCL_STUBS_NOT_VENDOR'},indent=2))
result=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=300)
(root/'pytest.log').write_text(result.stdout+result.stderr)
changed=[p for p,pin in pins.items() if hashlib.sha256((tree/p).read_bytes()).hexdigest()!=pin]
(root/'execution.json').write_text(json.dumps({'exit':result.returncode,'changed':changed,'source_count':len(pins)},indent=2))
print('\n'.join((result.stdout+result.stderr).splitlines()[-12:]),flush=True)
assert result.returncode==0 and not changed,(result.returncode,changed)

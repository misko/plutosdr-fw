"""Verify committed actual/query archives without extraction or execution."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

REPO = '/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic'
ACTUAL = '27ca617027c7ffb0ce19998d75e048f26b92f334'
QUERY = '3df5cd42414a0b18d848f48281caedf727dfe457'
STEM = '20260910-inverse-sealed-actual-v2'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(commit, name):
    require(PurePosixPath(name).name == name, 'plain name required')
    return subprocess.check_output(['git', '-C', REPO, 'show', commit + ':reports/experiments/' + name])


def members(data, receipt, count):
    expected = {**receipt['files'], 'inventory.json': receipt['inventory_sha256']}
    require('inventory.json' not in receipt['files'], 'separate inventory pin')
    actual = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        for entry in archive:
            path = PurePosixPath(entry.name)
            require(entry.isfile() and not path.is_absolute() and '..' not in path.parts
                    and path.as_posix() == entry.name and entry.name not in actual,
                    'unsafe/duplicate archive member')
            actual[entry.name] = hashlib.file_digest(archive.extractfile(entry), 'sha256').hexdigest()
    require(len(actual) == count and actual == expected, 'complete member hash closure')
    return actual


parts = json.loads(blob(ACTUAL, STEM + '.parts.json'))
receipt = json.loads(blob(ACTUAL, STEM + '.json'))
require(parts['format'] == 'starlink-portable-archive-parts-v1'
        and parts['max_part_bytes'] == 41943040 and len(parts['parts']) == 4, 'parts schema')
chunks = []
for index, part in enumerate(parts['parts']):
    require(part['index'] == index and part['name'] == STEM + f'.tgz.part{index:03}', 'part order/name')
    data = blob(ACTUAL, part['name'])
    require(len(data) == part['bytes'] and 0 < len(data) <= 41943040 and sha(data) == part['sha256'], 'part size/hash')
    chunks.append(data)
data = b''.join(chunks)
actual_hash = '236cedcd7f2c7fb29fb3f17e4f3e974b375335e13b6849380d3b6b5dc96ce11e'
require(len(data) == 140855181 and sha(data) == actual_hash, 'external actual archive pin')
require(parts['archive'] == {'name': STEM + '.tgz', 'bytes': len(data), 'sha256': actual_hash}, 'parts whole pin')
actual_members = members(data, receipt, 210)
require(receipt['original_exit'] == 0 and receipt['original_handle'] == 77697, 'original actual terminal')
query_stem = '20260910-inverse-sealed-recorded-history-v1'
query_receipt = json.loads(blob(QUERY, query_stem + '.json'))
query_data = blob(QUERY, query_stem + '.tgz')
query_hash = '5caf98ae3ccd9fa84b1bb59bed84c6aa5477f34fb4eb30554b1b5c2e5d084dc6'
require(len(query_data) == 162070 and sha(query_data) == query_hash, 'external query archive pin')
members(query_data, query_receipt, 26)
external = query_receipt['external_already_archived_payload']
require(external['archive_sha256'] == actual_hash and external['archive'] == STEM + '.tgz'
        and external['bytes'] == 133627003 and external['sha256'] ==
        '96418352ac9d6b2b9849bcad5a6d0dd3829ede343b0625dccb5d5bb86592171c', 'WDB external reference')
require(actual_members[external['member']] == external['sha256'], 'WDB member resolved in verified actual archive')
result = {'actual_commit': ACTUAL, 'query_commit': QUERY, 'parts_verified': 4,
          'actual_members_verified': 210, 'query_members_verified': 26,
          'external_WDB_reference_verified': True, 'extracted_or_executed': False}
with (Path(__file__).parent / 'verification.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))

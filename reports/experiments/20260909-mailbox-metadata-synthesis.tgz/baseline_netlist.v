// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (lin64) Build 3671981 Fri Oct 14 04:59:54 MDT 2022
// Date        : Wed Sep  9 22:58:34 2026
// Host        : gauss running 64-bit Ubuntu 26.04 LTS
// Command     : write_verilog -mode funcsim /tmp/starlink-metadata-equality.cihpiD/synthesis-v1/baseline_netlist.v
// Design      : starlink_pss_block_mailbox
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* ADDRESS_WIDTH = "9" *) (* DATA_WIDTH = "36" *) (* DEPTH = "512" *) 
(* EXPLICIT_COMMIT = "1" *) (* LAST_POSITION = "9'b111111111" *) (* METADATA_WIDTH = "75" *) 
(* NETLIST_CHECKSUM = "8c58ddce" *) (* RESET_RELEASE_EXTERNAL = "1" *) 
(* NotValidForBitStream *)
module starlink_pss_block_mailbox
   (input_clk,
    input_resetn,
    input_valid,
    input_commit_authorized,
    input_ready,
    input_data,
    input_position,
    input_last,
    input_metadata,
    input_fault,
    input_framing_fault_now,
    output_clk,
    output_resetn,
    output_valid,
    output_ready,
    output_data,
    output_position,
    output_last,
    output_metadata);
  input input_clk;
  input input_resetn;
  input input_valid;
  input input_commit_authorized;
  output input_ready;
  input [35:0]input_data;
  input [8:0]input_position;
  input input_last;
  input [74:0]input_metadata;
  output input_fault;
  output input_framing_fault_now;
  input output_clk;
  input output_resetn;
  output output_valid;
  input output_ready;
  output [35:0]output_data;
  output [8:0]output_position;
  output output_last;
  output [74:0]output_metadata;

  (* async_reg = "true" *) wire [1:0]acknowledge_sync;
  wire acknowledge_toggle;
  wire acknowledge_toggle_i_1_n_0;
  wire input_clk;
  wire input_commit_authorized;
  wire [35:0]input_data;
  wire input_fault;
  wire input_fault_i_2_n_0;
  wire input_framing_fault_now;
  wire input_framing_fault_now_INST_0_i_10_n_0;
  wire input_framing_fault_now_INST_0_i_13_n_0;
  wire input_framing_fault_now_INST_0_i_18_n_0;
  wire input_framing_fault_now_INST_0_i_23_n_0;
  wire input_framing_fault_now_INST_0_i_28_n_0;
  wire input_framing_fault_now_INST_0_i_33_n_0;
  wire input_framing_valid1;
  wire input_framing_valid113_in;
  wire input_last;
  wire [74:0]input_metadata;
  wire [8:0]input_position;
  wire input_resetn;
  wire input_valid;
  wire [74:0]metadata_in_hold;
  wire metadata_load;
  wire metadata_out_hold;
  wire output_clk;
  wire [35:0]output_data;
  wire [74:0]output_metadata;
  wire [8:0]output_position;
  wire output_ready;
  wire output_resetn;
  wire output_valid;
  wire p_0_in__0;
  wire [1:1]p_0_in__1;
  wire [8:0]read_address;
  wire \read_address[0]_i_1_n_0 ;
  wire \read_address[0]_i_2_n_0 ;
  wire \read_address[1]_i_1_n_0 ;
  wire \read_address[2]_i_1_n_0 ;
  wire \read_address[3]_i_1_n_0 ;
  wire \read_address[4]_i_1_n_0 ;
  wire \read_address[5]_i_1_n_0 ;
  wire \read_address[6]_i_1_n_0 ;
  wire \read_address[7]_i_1_n_0 ;
  wire \read_address[8]_i_1_n_0 ;
  wire read_all_loaded_i_1_n_0;
  wire read_all_loaded_reg_n_0;
  wire read_valid;
  wire read_valid_i_1_n_0;
  wire reading;
  wire reading_i_1_n_0;
  (* async_reg = "true" *) wire [1:0]request_sync;
  wire \request_sync[1]_i_1_n_0 ;
  wire request_toggle_i_1_n_0;
  wire request_toggle_reg_n_0;
  wire starlink_pss_bl_net_1;
  wire starlink_pss_bl_net_10;
  wire starlink_pss_bl_net_11;
  wire starlink_pss_bl_net_12;
  wire starlink_pss_bl_net_13;
  wire starlink_pss_bl_net_14;
  wire starlink_pss_bl_net_15;
  wire starlink_pss_bl_net_16;
  wire starlink_pss_bl_net_17;
  wire starlink_pss_bl_net_18;
  wire starlink_pss_bl_net_19;
  wire starlink_pss_bl_net_2;
  wire starlink_pss_bl_net_20;
  wire starlink_pss_bl_net_21;
  wire starlink_pss_bl_net_22;
  wire starlink_pss_bl_net_23;
  wire starlink_pss_bl_net_24;
  wire starlink_pss_bl_net_25;
  wire starlink_pss_bl_net_26;
  wire starlink_pss_bl_net_27;
  wire starlink_pss_bl_net_28;
  wire starlink_pss_bl_net_29;
  wire starlink_pss_bl_net_3;
  wire starlink_pss_bl_net_30;
  wire starlink_pss_bl_net_31;
  wire starlink_pss_bl_net_32;
  wire starlink_pss_bl_net_33;
  wire starlink_pss_bl_net_34;
  wire starlink_pss_bl_net_35;
  wire starlink_pss_bl_net_36;
  wire starlink_pss_bl_net_37;
  wire starlink_pss_bl_net_38;
  wire starlink_pss_bl_net_39;
  wire starlink_pss_bl_net_4;
  wire starlink_pss_bl_net_40;
  wire starlink_pss_bl_net_41;
  wire starlink_pss_bl_net_42;
  wire starlink_pss_bl_net_43;
  wire starlink_pss_bl_net_5;
  wire starlink_pss_bl_net_6;
  wire starlink_pss_bl_net_7;
  wire starlink_pss_bl_net_8;
  wire starlink_pss_bl_net_9;
  wire write_position0;
  wire \write_position[0]_i_1_n_0 ;
  wire \write_position[2]_i_1_n_0 ;
  wire \write_position[3]_i_1_n_0 ;
  wire \write_position[4]_i_1_n_0 ;
  wire \write_position[5]_i_1_n_0 ;
  wire \write_position[6]_i_1_n_0 ;
  wire \write_position[7]_i_1_n_0 ;
  wire \write_position[8]_i_1_n_0 ;
  wire \write_position[8]_i_3_n_0 ;
  wire [8:0]write_position_reg;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_1_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_1_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_10_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_10_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_13_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_13_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_18_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_18_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_23_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_23_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_28_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_28_O_UNCONNECTED;
  wire [3:1]NLW_input_framing_fault_now_INST_0_i_3_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_3_O_UNCONNECTED;
  wire [2:0]NLW_input_framing_fault_now_INST_0_i_33_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_33_O_UNCONNECTED;

  assign input_ready = starlink_pss_bl_net_1;
  assign output_last = starlink_pss_bl_net_8;
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \acknowledge_sync_reg[0] 
       (.C(input_clk),
        .CE(1'b1),
        .D(acknowledge_toggle),
        .Q(acknowledge_sync[0]),
        .R(p_0_in__0));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \acknowledge_sync_reg[1] 
       (.C(input_clk),
        .CE(1'b1),
        .D(acknowledge_sync[0]),
        .Q(acknowledge_sync[1]),
        .R(p_0_in__0));
  FDRE acknowledge_toggle_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(acknowledge_toggle_i_1_n_0),
        .Q(acknowledge_toggle),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE input_fault_reg
       (.C(input_clk),
        .CE(1'b1),
        .D(input_fault_i_2_n_0),
        .Q(input_fault),
        .R(p_0_in__0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_1
       (.CI(1'b0),
        .CO({NLW_input_framing_fault_now_INST_0_i_1_CO_UNCONNECTED[3],input_framing_valid113_in,NLW_input_framing_fault_now_INST_0_i_1_CO_UNCONNECTED[1:0]}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_1_O_UNCONNECTED[3:0]),
        .S({1'b0,starlink_pss_bl_net_18,starlink_pss_bl_net_17,starlink_pss_bl_net_16}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_10
       (.CI(input_framing_fault_now_INST_0_i_13_n_0),
        .CO({input_framing_fault_now_INST_0_i_10_n_0,NLW_input_framing_fault_now_INST_0_i_10_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_10_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_42,starlink_pss_bl_net_41,starlink_pss_bl_net_40,starlink_pss_bl_net_39}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_13
       (.CI(input_framing_fault_now_INST_0_i_18_n_0),
        .CO({input_framing_fault_now_INST_0_i_13_n_0,NLW_input_framing_fault_now_INST_0_i_13_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_13_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_38,starlink_pss_bl_net_37,starlink_pss_bl_net_36,starlink_pss_bl_net_35}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_18
       (.CI(input_framing_fault_now_INST_0_i_23_n_0),
        .CO({input_framing_fault_now_INST_0_i_18_n_0,NLW_input_framing_fault_now_INST_0_i_18_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_18_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_34,starlink_pss_bl_net_33,starlink_pss_bl_net_32,starlink_pss_bl_net_31}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_23
       (.CI(input_framing_fault_now_INST_0_i_28_n_0),
        .CO({input_framing_fault_now_INST_0_i_23_n_0,NLW_input_framing_fault_now_INST_0_i_23_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_23_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_30,starlink_pss_bl_net_29,starlink_pss_bl_net_28,starlink_pss_bl_net_27}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_28
       (.CI(input_framing_fault_now_INST_0_i_33_n_0),
        .CO({input_framing_fault_now_INST_0_i_28_n_0,NLW_input_framing_fault_now_INST_0_i_28_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_28_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_26,starlink_pss_bl_net_25,starlink_pss_bl_net_24,starlink_pss_bl_net_23}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_3
       (.CI(input_framing_fault_now_INST_0_i_10_n_0),
        .CO({NLW_input_framing_fault_now_INST_0_i_3_CO_UNCONNECTED[3:1],input_framing_valid1}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_3_O_UNCONNECTED[3:0]),
        .S({1'b0,1'b0,1'b0,starlink_pss_bl_net_43}));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 input_framing_fault_now_INST_0_i_33
       (.CI(1'b0),
        .CO({input_framing_fault_now_INST_0_i_33_n_0,NLW_input_framing_fault_now_INST_0_i_33_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_33_O_UNCONNECTED[3:0]),
        .S({starlink_pss_bl_net_22,starlink_pss_bl_net_21,starlink_pss_bl_net_20,starlink_pss_bl_net_19}));
  FDRE \metadata_in_hold_reg[0] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[0]),
        .Q(metadata_in_hold[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[10] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[10]),
        .Q(metadata_in_hold[10]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[11] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[11]),
        .Q(metadata_in_hold[11]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[12] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[12]),
        .Q(metadata_in_hold[12]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[13] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[13]),
        .Q(metadata_in_hold[13]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[14] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[14]),
        .Q(metadata_in_hold[14]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[15] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[15]),
        .Q(metadata_in_hold[15]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[16] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[16]),
        .Q(metadata_in_hold[16]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[17] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[17]),
        .Q(metadata_in_hold[17]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[18] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[18]),
        .Q(metadata_in_hold[18]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[19] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[19]),
        .Q(metadata_in_hold[19]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[1] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[1]),
        .Q(metadata_in_hold[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[20] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[20]),
        .Q(metadata_in_hold[20]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[21] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[21]),
        .Q(metadata_in_hold[21]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[22] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[22]),
        .Q(metadata_in_hold[22]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[23] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[23]),
        .Q(metadata_in_hold[23]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[24] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[24]),
        .Q(metadata_in_hold[24]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[25] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[25]),
        .Q(metadata_in_hold[25]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[26] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[26]),
        .Q(metadata_in_hold[26]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[27] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[27]),
        .Q(metadata_in_hold[27]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[28] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[28]),
        .Q(metadata_in_hold[28]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[29] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[29]),
        .Q(metadata_in_hold[29]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[2] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[2]),
        .Q(metadata_in_hold[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[30] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[30]),
        .Q(metadata_in_hold[30]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[31] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[31]),
        .Q(metadata_in_hold[31]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[32] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[32]),
        .Q(metadata_in_hold[32]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[33] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[33]),
        .Q(metadata_in_hold[33]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[34] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[34]),
        .Q(metadata_in_hold[34]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[35] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[35]),
        .Q(metadata_in_hold[35]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[36] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[36]),
        .Q(metadata_in_hold[36]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[37] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[37]),
        .Q(metadata_in_hold[37]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[38] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[38]),
        .Q(metadata_in_hold[38]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[39] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[39]),
        .Q(metadata_in_hold[39]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[3] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[3]),
        .Q(metadata_in_hold[3]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[40] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[40]),
        .Q(metadata_in_hold[40]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[41] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[41]),
        .Q(metadata_in_hold[41]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[42] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[42]),
        .Q(metadata_in_hold[42]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[43] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[43]),
        .Q(metadata_in_hold[43]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[44] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[44]),
        .Q(metadata_in_hold[44]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[45] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[45]),
        .Q(metadata_in_hold[45]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[46] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[46]),
        .Q(metadata_in_hold[46]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[47] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[47]),
        .Q(metadata_in_hold[47]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[48] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[48]),
        .Q(metadata_in_hold[48]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[49] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[49]),
        .Q(metadata_in_hold[49]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[4] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[4]),
        .Q(metadata_in_hold[4]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[50] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[50]),
        .Q(metadata_in_hold[50]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[51] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[51]),
        .Q(metadata_in_hold[51]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[52] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[52]),
        .Q(metadata_in_hold[52]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[53] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[53]),
        .Q(metadata_in_hold[53]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[54] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[54]),
        .Q(metadata_in_hold[54]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[55] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[55]),
        .Q(metadata_in_hold[55]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[56] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[56]),
        .Q(metadata_in_hold[56]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[57] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[57]),
        .Q(metadata_in_hold[57]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[58] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[58]),
        .Q(metadata_in_hold[58]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[59] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[59]),
        .Q(metadata_in_hold[59]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[5] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[5]),
        .Q(metadata_in_hold[5]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[60] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[60]),
        .Q(metadata_in_hold[60]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[61] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[61]),
        .Q(metadata_in_hold[61]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[62] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[62]),
        .Q(metadata_in_hold[62]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[63] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[63]),
        .Q(metadata_in_hold[63]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[64] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[64]),
        .Q(metadata_in_hold[64]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[65] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[65]),
        .Q(metadata_in_hold[65]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[66] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[66]),
        .Q(metadata_in_hold[66]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[67] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[67]),
        .Q(metadata_in_hold[67]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[68] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[68]),
        .Q(metadata_in_hold[68]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[69] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[69]),
        .Q(metadata_in_hold[69]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[6] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[6]),
        .Q(metadata_in_hold[6]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[70] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[70]),
        .Q(metadata_in_hold[70]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[71] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[71]),
        .Q(metadata_in_hold[71]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[72] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[72]),
        .Q(metadata_in_hold[72]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[73] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[73]),
        .Q(metadata_in_hold[73]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[74] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[74]),
        .Q(metadata_in_hold[74]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[7] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[7]),
        .Q(metadata_in_hold[7]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[8] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[8]),
        .Q(metadata_in_hold[8]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[9] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[9]),
        .Q(metadata_in_hold[9]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[0] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[0]),
        .Q(output_metadata[0]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[10] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[10]),
        .Q(output_metadata[10]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[11] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[11]),
        .Q(output_metadata[11]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[12] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[12]),
        .Q(output_metadata[12]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[13] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[13]),
        .Q(output_metadata[13]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[14] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[14]),
        .Q(output_metadata[14]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[15] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[15]),
        .Q(output_metadata[15]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[16] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[16]),
        .Q(output_metadata[16]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[17] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[17]),
        .Q(output_metadata[17]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[18] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[18]),
        .Q(output_metadata[18]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[19] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[19]),
        .Q(output_metadata[19]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[1] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[1]),
        .Q(output_metadata[1]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[20] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[20]),
        .Q(output_metadata[20]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[21] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[21]),
        .Q(output_metadata[21]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[22] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[22]),
        .Q(output_metadata[22]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[23] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[23]),
        .Q(output_metadata[23]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[24] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[24]),
        .Q(output_metadata[24]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[25] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[25]),
        .Q(output_metadata[25]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[26] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[26]),
        .Q(output_metadata[26]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[27] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[27]),
        .Q(output_metadata[27]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[28] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[28]),
        .Q(output_metadata[28]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[29] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[29]),
        .Q(output_metadata[29]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[2] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[2]),
        .Q(output_metadata[2]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[30] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[30]),
        .Q(output_metadata[30]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[31] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[31]),
        .Q(output_metadata[31]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[32] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[32]),
        .Q(output_metadata[32]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[33] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[33]),
        .Q(output_metadata[33]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[34] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[34]),
        .Q(output_metadata[34]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[35] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[35]),
        .Q(output_metadata[35]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[36] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[36]),
        .Q(output_metadata[36]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[37] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[37]),
        .Q(output_metadata[37]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[38] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[38]),
        .Q(output_metadata[38]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[39] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[39]),
        .Q(output_metadata[39]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[3] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[3]),
        .Q(output_metadata[3]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[40] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[40]),
        .Q(output_metadata[40]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[41] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[41]),
        .Q(output_metadata[41]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[42] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[42]),
        .Q(output_metadata[42]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[43] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[43]),
        .Q(output_metadata[43]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[44] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[44]),
        .Q(output_metadata[44]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[45] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[45]),
        .Q(output_metadata[45]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[46] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[46]),
        .Q(output_metadata[46]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[47] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[47]),
        .Q(output_metadata[47]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[48] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[48]),
        .Q(output_metadata[48]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[49] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[49]),
        .Q(output_metadata[49]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[4] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[4]),
        .Q(output_metadata[4]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[50] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[50]),
        .Q(output_metadata[50]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[51] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[51]),
        .Q(output_metadata[51]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[52] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[52]),
        .Q(output_metadata[52]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[53] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[53]),
        .Q(output_metadata[53]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[54] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[54]),
        .Q(output_metadata[54]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[55] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[55]),
        .Q(output_metadata[55]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[56] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[56]),
        .Q(output_metadata[56]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[57] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[57]),
        .Q(output_metadata[57]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[58] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[58]),
        .Q(output_metadata[58]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[59] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[59]),
        .Q(output_metadata[59]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[5] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[5]),
        .Q(output_metadata[5]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[60] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[60]),
        .Q(output_metadata[60]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[61] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[61]),
        .Q(output_metadata[61]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[62] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[62]),
        .Q(output_metadata[62]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[63] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[63]),
        .Q(output_metadata[63]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[64] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[64]),
        .Q(output_metadata[64]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[65] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[65]),
        .Q(output_metadata[65]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[66] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[66]),
        .Q(output_metadata[66]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[67] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[67]),
        .Q(output_metadata[67]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[68] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[68]),
        .Q(output_metadata[68]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[69] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[69]),
        .Q(output_metadata[69]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[6] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[6]),
        .Q(output_metadata[6]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[70] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[70]),
        .Q(output_metadata[70]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[71] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[71]),
        .Q(output_metadata[71]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[72] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[72]),
        .Q(output_metadata[72]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[73] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[73]),
        .Q(output_metadata[73]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[74] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[74]),
        .Q(output_metadata[74]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[7] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[7]),
        .Q(output_metadata[7]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[8] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[8]),
        .Q(output_metadata[8]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[9] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(metadata_in_hold[9]),
        .Q(output_metadata[9]),
        .R(1'b0));
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p4_d32" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p4_d32" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  (* RTL_RAM_BITS = "18432" *) 
  (* RTL_RAM_NAME = "payload_memory_reg" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "511" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "35" *) 
  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    payload_memory_reg
       (.ADDRARDADDR({read_address,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({write_position_reg,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CLKARDCLK(output_clk),
        .CLKBWRCLK(input_clk),
        .DIADI(input_data[15:0]),
        .DIBDI(input_data[31:16]),
        .DIPADIP(input_data[33:32]),
        .DIPBDIP(input_data[35:34]),
        .DOADO(output_data[15:0]),
        .DOBDO(output_data[31:16]),
        .DOPADOP(output_data[33:32]),
        .DOPBDOP(output_data[35:34]),
        .ENARDEN(starlink_pss_bl_net_13),
        .ENBWREN(input_valid),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .WEA({1'b0,1'b0}),
        .WEBWE({starlink_pss_bl_net_1,starlink_pss_bl_net_1,starlink_pss_bl_net_1,starlink_pss_bl_net_1}));
  FDRE \read_address_reg[0] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[0]_i_2_n_0 ),
        .Q(read_address[0]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[1] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[1]_i_1_n_0 ),
        .Q(read_address[1]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[2] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[2]_i_1_n_0 ),
        .Q(read_address[2]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[3] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[3]_i_1_n_0 ),
        .Q(read_address[3]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[4] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[4]_i_1_n_0 ),
        .Q(read_address[4]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[5] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[5]_i_1_n_0 ),
        .Q(read_address[5]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[6] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[6]_i_1_n_0 ),
        .Q(read_address[6]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[7] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[7]_i_1_n_0 ),
        .Q(read_address[7]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[8] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[8]_i_1_n_0 ),
        .Q(read_address[8]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE read_all_loaded_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(read_all_loaded_i_1_n_0),
        .Q(read_all_loaded_reg_n_0),
        .R(\request_sync[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[0] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[0]),
        .Q(output_position[0]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[1] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[1]),
        .Q(output_position[1]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[2] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[2]),
        .Q(output_position[2]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[3] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[3]),
        .Q(output_position[3]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[4] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[4]),
        .Q(output_position[4]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[5] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[5]),
        .Q(output_position[5]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[6] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[6]),
        .Q(output_position[6]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[7] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[7]),
        .Q(output_position[7]),
        .R(1'b0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDRE \read_output_position_reg[8] 
       (.C(output_clk),
        .CE(starlink_pss_bl_net_13),
        .D(read_address[8]),
        .Q(output_position[8]),
        .R(1'b0));
  FDRE read_valid_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(read_valid_i_1_n_0),
        .Q(read_valid),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE reading_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(reading_i_1_n_0),
        .Q(reading),
        .R(1'b0));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \request_sync_reg[0] 
       (.C(output_clk),
        .CE(1'b1),
        .D(request_toggle_reg_n_0),
        .Q(request_sync[0]),
        .R(\request_sync[1]_i_1_n_0 ));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \request_sync_reg[1] 
       (.C(output_clk),
        .CE(1'b1),
        .D(request_sync[0]),
        .Q(request_sync[1]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE request_toggle_reg
       (.C(input_clk),
        .CE(1'b1),
        .D(request_toggle_i_1_n_0),
        .Q(request_toggle_reg_n_0),
        .R(p_0_in__0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT1 #(
    .INIT(2'h1)) 
    starlink_pss_bl_LUT1_30
       (.I0(input_resetn),
        .O(p_0_in__0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT1 #(
    .INIT(2'h1)) 
    starlink_pss_bl_LUT1_32
       (.I0(output_resetn),
        .O(\request_sync[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT1 #(
    .INIT(2'h1)) 
    starlink_pss_bl_LUT1_33
       (.I0(write_position_reg[0]),
        .O(\write_position[0]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h1)) 
    starlink_pss_bl_LUT2
       (.I0(input_fault),
        .I1(\write_position[8]_i_1_n_0 ),
        .O(starlink_pss_bl_net_1));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_bl_LUT2_1
       (.I0(input_valid),
        .I1(starlink_pss_bl_net_1),
        .O(starlink_pss_bl_net_4));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_bl_LUT2_2
       (.I0(output_resetn),
        .I1(read_valid),
        .O(output_valid));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h6)) 
    starlink_pss_bl_LUT2_3
       (.I0(write_position_reg[0]),
        .I1(write_position_reg[1]),
        .O(p_0_in__1));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h4)) 
    starlink_pss_bl_LUT2_4
       (.I0(read_address[0]),
        .I1(starlink_pss_bl_net_13),
        .O(\read_address[0]_i_2_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h2)) 
    starlink_pss_bl_LUT2_5
       (.I0(starlink_pss_bl_net_4),
        .I1(starlink_pss_bl_net_5),
        .O(write_position0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h6)) 
    starlink_pss_bl_LUT2_6
       (.I0(write_position_reg[6]),
        .I1(starlink_pss_bl_net_2),
        .O(\write_position[6]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h7D)) 
    starlink_pss_bl_LUT3
       (.I0(input_resetn),
        .I1(acknowledge_sync[1]),
        .I2(request_toggle_reg_n_0),
        .O(\write_position[8]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h80)) 
    starlink_pss_bl_LUT3_1
       (.I0(output_ready),
        .I1(read_valid),
        .I2(starlink_pss_bl_net_8),
        .O(starlink_pss_bl_net_9));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'hAC)) 
    starlink_pss_bl_LUT3_2
       (.I0(request_sync[1]),
        .I1(acknowledge_toggle),
        .I2(starlink_pss_bl_net_9),
        .O(acknowledge_toggle_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h60)) 
    starlink_pss_bl_LUT3_3
       (.I0(read_address[0]),
        .I1(read_address[1]),
        .I2(starlink_pss_bl_net_13),
        .O(\read_address[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h48)) 
    starlink_pss_bl_LUT3_4
       (.I0(read_address[5]),
        .I1(starlink_pss_bl_net_13),
        .I2(starlink_pss_bl_net_12),
        .O(\read_address[5]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h80)) 
    starlink_pss_bl_LUT3_5
       (.I0(input_commit_authorized),
        .I1(input_framing_valid113_in),
        .I2(input_framing_valid1),
        .O(starlink_pss_bl_net_15));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h6A)) 
    starlink_pss_bl_LUT3_6
       (.I0(write_position_reg[2]),
        .I1(write_position_reg[0]),
        .I2(write_position_reg[1]),
        .O(\write_position[2]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h6C)) 
    starlink_pss_bl_LUT3_7
       (.I0(write_position_reg[6]),
        .I1(write_position_reg[7]),
        .I2(starlink_pss_bl_net_2),
        .O(\write_position[7]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    starlink_pss_bl_LUT4
       (.I0(write_position_reg[6]),
        .I1(write_position_reg[7]),
        .I2(write_position_reg[8]),
        .I3(starlink_pss_bl_net_2),
        .O(starlink_pss_bl_net_5));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h8000)) 
    starlink_pss_bl_LUT4_1
       (.I0(output_position[1]),
        .I1(output_position[5]),
        .I2(output_position[7]),
        .I3(starlink_pss_bl_net_7),
        .O(starlink_pss_bl_net_8));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h0220)) 
    starlink_pss_bl_LUT4_2
       (.I0(output_resetn),
        .I1(reading),
        .I2(request_sync[1]),
        .I3(acknowledge_toggle),
        .O(metadata_out_hold));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h7800)) 
    starlink_pss_bl_LUT4_3
       (.I0(read_address[0]),
        .I1(read_address[1]),
        .I2(read_address[2]),
        .I3(starlink_pss_bl_net_13),
        .O(\read_address[2]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h60C0)) 
    starlink_pss_bl_LUT4_4
       (.I0(read_address[5]),
        .I1(read_address[6]),
        .I2(starlink_pss_bl_net_13),
        .I3(starlink_pss_bl_net_12),
        .O(\read_address[6]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h7350)) 
    starlink_pss_bl_LUT4_5
       (.I0(output_ready),
        .I1(read_all_loaded_reg_n_0),
        .I2(read_valid),
        .I3(reading),
        .O(read_valid_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    starlink_pss_bl_LUT4_6
       (.I0(write_position_reg[2]),
        .I1(write_position_reg[0]),
        .I2(write_position_reg[1]),
        .I3(write_position_reg[3]),
        .O(\write_position[3]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h78F0)) 
    starlink_pss_bl_LUT4_7
       (.I0(write_position_reg[6]),
        .I1(write_position_reg[7]),
        .I2(write_position_reg[8]),
        .I3(starlink_pss_bl_net_2),
        .O(\write_position[8]_i_3_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h00FE00FF)) 
    starlink_pss_bl_LUT5
       (.I0(write_position_reg[0]),
        .I1(write_position_reg[3]),
        .I2(write_position_reg[7]),
        .I3(input_framing_valid1),
        .I4(starlink_pss_bl_net_3),
        .O(starlink_pss_bl_net_6));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hF0F070B0)) 
    starlink_pss_bl_LUT5_1
       (.I0(input_last),
        .I1(input_framing_valid113_in),
        .I2(starlink_pss_bl_net_4),
        .I3(starlink_pss_bl_net_5),
        .I4(starlink_pss_bl_net_6),
        .O(input_framing_fault_now));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h6CCCCCCC)) 
    starlink_pss_bl_LUT5_10
       (.I0(input_last),
        .I1(request_toggle_reg_n_0),
        .I2(starlink_pss_bl_net_4),
        .I3(starlink_pss_bl_net_5),
        .I4(starlink_pss_bl_net_15),
        .O(request_toggle_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h6AAAAAAA)) 
    starlink_pss_bl_LUT5_11
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[1]),
        .I4(write_position_reg[3]),
        .O(\write_position[4]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h00010000)) 
    starlink_pss_bl_LUT5_2
       (.I0(input_position[0]),
        .I1(input_position[1]),
        .I2(input_position[2]),
        .I3(input_position[3]),
        .I4(starlink_pss_bl_net_10),
        .O(starlink_pss_bl_net_11));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h080C0000)) 
    starlink_pss_bl_LUT5_3
       (.I0(output_ready),
        .I1(output_resetn),
        .I2(read_all_loaded_reg_n_0),
        .I3(read_valid),
        .I4(reading),
        .O(starlink_pss_bl_net_13));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    starlink_pss_bl_LUT5_4
       (.I0(read_address[0]),
        .I1(read_address[1]),
        .I2(read_address[2]),
        .I3(read_address[3]),
        .I4(read_address[4]),
        .O(starlink_pss_bl_net_12));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    starlink_pss_bl_LUT5_5
       (.I0(read_address[8]),
        .I1(read_address[5]),
        .I2(read_address[6]),
        .I3(read_address[7]),
        .I4(starlink_pss_bl_net_12),
        .O(starlink_pss_bl_net_14));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h1414FF14)) 
    starlink_pss_bl_LUT5_6
       (.I0(reading),
        .I1(request_sync[1]),
        .I2(acknowledge_toggle),
        .I3(starlink_pss_bl_net_13),
        .I4(starlink_pss_bl_net_14),
        .O(\read_address[0]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h7F800000)) 
    starlink_pss_bl_LUT5_7
       (.I0(read_address[0]),
        .I1(read_address[1]),
        .I2(read_address[2]),
        .I3(read_address[3]),
        .I4(starlink_pss_bl_net_13),
        .O(\read_address[3]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h7800F000)) 
    starlink_pss_bl_LUT5_8
       (.I0(read_address[5]),
        .I1(read_address[6]),
        .I2(read_address[7]),
        .I3(starlink_pss_bl_net_13),
        .I4(starlink_pss_bl_net_12),
        .O(\read_address[7]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h00008AA8)) 
    starlink_pss_bl_LUT5_9
       (.I0(output_resetn),
        .I1(reading),
        .I2(request_sync[1]),
        .I3(acknowledge_toggle),
        .I4(starlink_pss_bl_net_9),
        .O(reading_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008400420021001)) 
    starlink_pss_bl_LUT6
       (.I0(input_position[0]),
        .I1(input_position[1]),
        .I2(input_position[2]),
        .I3(write_position_reg[2]),
        .I4(write_position_reg[0]),
        .I5(write_position_reg[1]),
        .O(starlink_pss_bl_net_16));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8020401008020401)) 
    starlink_pss_bl_LUT6_1
       (.I0(input_position[3]),
        .I1(input_position[4]),
        .I2(input_position[5]),
        .I3(write_position_reg[4]),
        .I4(write_position_reg[3]),
        .I5(write_position_reg[5]),
        .O(starlink_pss_bl_net_17));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_10
       (.I0(input_metadata[21]),
        .I1(input_metadata[22]),
        .I2(input_metadata[23]),
        .I3(metadata_in_hold[23]),
        .I4(metadata_in_hold[22]),
        .I5(metadata_in_hold[21]),
        .O(starlink_pss_bl_net_26));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_11
       (.I0(input_metadata[24]),
        .I1(input_metadata[25]),
        .I2(input_metadata[26]),
        .I3(metadata_in_hold[26]),
        .I4(metadata_in_hold[25]),
        .I5(metadata_in_hold[24]),
        .O(starlink_pss_bl_net_27));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_12
       (.I0(input_metadata[27]),
        .I1(input_metadata[28]),
        .I2(input_metadata[29]),
        .I3(metadata_in_hold[29]),
        .I4(metadata_in_hold[28]),
        .I5(metadata_in_hold[27]),
        .O(starlink_pss_bl_net_28));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_13
       (.I0(input_metadata[30]),
        .I1(input_metadata[31]),
        .I2(input_metadata[32]),
        .I3(metadata_in_hold[32]),
        .I4(metadata_in_hold[31]),
        .I5(metadata_in_hold[30]),
        .O(starlink_pss_bl_net_29));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_14
       (.I0(input_metadata[33]),
        .I1(input_metadata[34]),
        .I2(input_metadata[35]),
        .I3(metadata_in_hold[35]),
        .I4(metadata_in_hold[34]),
        .I5(metadata_in_hold[33]),
        .O(starlink_pss_bl_net_30));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_15
       (.I0(input_metadata[36]),
        .I1(input_metadata[37]),
        .I2(input_metadata[38]),
        .I3(metadata_in_hold[38]),
        .I4(metadata_in_hold[37]),
        .I5(metadata_in_hold[36]),
        .O(starlink_pss_bl_net_31));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_16
       (.I0(input_metadata[39]),
        .I1(input_metadata[40]),
        .I2(input_metadata[41]),
        .I3(metadata_in_hold[41]),
        .I4(metadata_in_hold[40]),
        .I5(metadata_in_hold[39]),
        .O(starlink_pss_bl_net_32));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_17
       (.I0(input_metadata[42]),
        .I1(input_metadata[43]),
        .I2(input_metadata[44]),
        .I3(metadata_in_hold[44]),
        .I4(metadata_in_hold[43]),
        .I5(metadata_in_hold[42]),
        .O(starlink_pss_bl_net_33));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_18
       (.I0(input_metadata[45]),
        .I1(input_metadata[46]),
        .I2(input_metadata[47]),
        .I3(metadata_in_hold[47]),
        .I4(metadata_in_hold[46]),
        .I5(metadata_in_hold[45]),
        .O(starlink_pss_bl_net_34));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_19
       (.I0(input_metadata[48]),
        .I1(input_metadata[49]),
        .I2(input_metadata[50]),
        .I3(metadata_in_hold[50]),
        .I4(metadata_in_hold[49]),
        .I5(metadata_in_hold[48]),
        .O(starlink_pss_bl_net_35));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_bl_LUT6_2
       (.I0(input_position[6]),
        .I1(input_position[7]),
        .I2(input_position[8]),
        .I3(write_position_reg[6]),
        .I4(write_position_reg[7]),
        .I5(write_position_reg[8]),
        .O(starlink_pss_bl_net_18));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_20
       (.I0(input_metadata[51]),
        .I1(input_metadata[52]),
        .I2(input_metadata[53]),
        .I3(metadata_in_hold[53]),
        .I4(metadata_in_hold[52]),
        .I5(metadata_in_hold[51]),
        .O(starlink_pss_bl_net_36));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_21
       (.I0(input_metadata[54]),
        .I1(input_metadata[55]),
        .I2(input_metadata[56]),
        .I3(metadata_in_hold[56]),
        .I4(metadata_in_hold[55]),
        .I5(metadata_in_hold[54]),
        .O(starlink_pss_bl_net_37));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_22
       (.I0(input_metadata[57]),
        .I1(input_metadata[58]),
        .I2(input_metadata[59]),
        .I3(metadata_in_hold[59]),
        .I4(metadata_in_hold[58]),
        .I5(metadata_in_hold[57]),
        .O(starlink_pss_bl_net_38));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_23
       (.I0(input_metadata[60]),
        .I1(input_metadata[61]),
        .I2(input_metadata[62]),
        .I3(metadata_in_hold[62]),
        .I4(metadata_in_hold[61]),
        .I5(metadata_in_hold[60]),
        .O(starlink_pss_bl_net_39));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_24
       (.I0(input_metadata[63]),
        .I1(input_metadata[64]),
        .I2(input_metadata[65]),
        .I3(metadata_in_hold[65]),
        .I4(metadata_in_hold[64]),
        .I5(metadata_in_hold[63]),
        .O(starlink_pss_bl_net_40));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_25
       (.I0(input_metadata[66]),
        .I1(input_metadata[67]),
        .I2(input_metadata[68]),
        .I3(metadata_in_hold[68]),
        .I4(metadata_in_hold[67]),
        .I5(metadata_in_hold[66]),
        .O(starlink_pss_bl_net_41));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_26
       (.I0(input_metadata[69]),
        .I1(input_metadata[70]),
        .I2(input_metadata[71]),
        .I3(metadata_in_hold[71]),
        .I4(metadata_in_hold[70]),
        .I5(metadata_in_hold[69]),
        .O(starlink_pss_bl_net_42));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_27
       (.I0(input_metadata[72]),
        .I1(input_metadata[73]),
        .I2(input_metadata[74]),
        .I3(metadata_in_hold[74]),
        .I4(metadata_in_hold[73]),
        .I5(metadata_in_hold[72]),
        .O(starlink_pss_bl_net_43));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    starlink_pss_bl_LUT6_28
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[1]),
        .I4(write_position_reg[3]),
        .I5(write_position_reg[5]),
        .O(starlink_pss_bl_net_2));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    starlink_pss_bl_LUT6_29
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[1]),
        .I3(write_position_reg[5]),
        .I4(write_position_reg[6]),
        .I5(write_position_reg[8]),
        .O(starlink_pss_bl_net_3));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_3
       (.I0(input_metadata[0]),
        .I1(input_metadata[1]),
        .I2(input_metadata[2]),
        .I3(metadata_in_hold[2]),
        .I4(metadata_in_hold[1]),
        .I5(metadata_in_hold[0]),
        .O(starlink_pss_bl_net_19));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    starlink_pss_bl_LUT6_30
       (.I0(output_position[0]),
        .I1(output_position[2]),
        .I2(output_position[3]),
        .I3(output_position[4]),
        .I4(output_position[6]),
        .I5(output_position[8]),
        .O(starlink_pss_bl_net_7));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hFFCCFFCCDFCCEFCC)) 
    starlink_pss_bl_LUT6_31
       (.I0(input_last),
        .I1(input_fault),
        .I2(input_framing_valid113_in),
        .I3(starlink_pss_bl_net_4),
        .I4(starlink_pss_bl_net_5),
        .I5(starlink_pss_bl_net_6),
        .O(input_fault_i_2_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    starlink_pss_bl_LUT6_32
       (.I0(input_last),
        .I1(input_position[4]),
        .I2(input_position[5]),
        .I3(input_position[6]),
        .I4(input_position[7]),
        .I5(input_position[8]),
        .O(starlink_pss_bl_net_10));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0100000000000000)) 
    starlink_pss_bl_LUT6_33
       (.I0(write_position_reg[0]),
        .I1(write_position_reg[3]),
        .I2(write_position_reg[7]),
        .I3(starlink_pss_bl_net_4),
        .I4(starlink_pss_bl_net_3),
        .I5(starlink_pss_bl_net_11),
        .O(metadata_load));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7FFF800000000000)) 
    starlink_pss_bl_LUT6_34
       (.I0(read_address[0]),
        .I1(read_address[1]),
        .I2(read_address[2]),
        .I3(read_address[3]),
        .I4(read_address[4]),
        .I5(starlink_pss_bl_net_13),
        .O(\read_address[4]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h6AAA0000AAAA0000)) 
    starlink_pss_bl_LUT6_35
       (.I0(read_address[8]),
        .I1(read_address[5]),
        .I2(read_address[6]),
        .I3(read_address[7]),
        .I4(starlink_pss_bl_net_13),
        .I5(starlink_pss_bl_net_12),
        .O(\read_address[8]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hFFFFA88AA88AA88A)) 
    starlink_pss_bl_LUT6_36
       (.I0(read_all_loaded_reg_n_0),
        .I1(reading),
        .I2(request_sync[1]),
        .I3(acknowledge_toggle),
        .I4(starlink_pss_bl_net_13),
        .I5(starlink_pss_bl_net_14),
        .O(read_all_loaded_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    starlink_pss_bl_LUT6_37
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[1]),
        .I4(write_position_reg[3]),
        .I5(write_position_reg[5]),
        .O(\write_position[5]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_4
       (.I0(input_metadata[3]),
        .I1(input_metadata[4]),
        .I2(input_metadata[5]),
        .I3(metadata_in_hold[5]),
        .I4(metadata_in_hold[4]),
        .I5(metadata_in_hold[3]),
        .O(starlink_pss_bl_net_20));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_5
       (.I0(input_metadata[6]),
        .I1(input_metadata[7]),
        .I2(input_metadata[8]),
        .I3(metadata_in_hold[8]),
        .I4(metadata_in_hold[7]),
        .I5(metadata_in_hold[6]),
        .O(starlink_pss_bl_net_21));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8020401008020401)) 
    starlink_pss_bl_LUT6_6
       (.I0(input_metadata[10]),
        .I1(input_metadata[11]),
        .I2(input_metadata[9]),
        .I3(metadata_in_hold[11]),
        .I4(metadata_in_hold[10]),
        .I5(metadata_in_hold[9]),
        .O(starlink_pss_bl_net_22));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_7
       (.I0(input_metadata[12]),
        .I1(input_metadata[13]),
        .I2(input_metadata[14]),
        .I3(metadata_in_hold[14]),
        .I4(metadata_in_hold[13]),
        .I5(metadata_in_hold[12]),
        .O(starlink_pss_bl_net_23));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_8
       (.I0(input_metadata[15]),
        .I1(input_metadata[16]),
        .I2(input_metadata[17]),
        .I3(metadata_in_hold[17]),
        .I4(metadata_in_hold[16]),
        .I5(metadata_in_hold[15]),
        .O(starlink_pss_bl_net_24));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8008200240041001)) 
    starlink_pss_bl_LUT6_9
       (.I0(input_metadata[18]),
        .I1(input_metadata[19]),
        .I2(input_metadata[20]),
        .I3(metadata_in_hold[20]),
        .I4(metadata_in_hold[19]),
        .I5(metadata_in_hold[18]),
        .O(starlink_pss_bl_net_25));
  FDRE \write_position_reg[0] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[0]_i_1_n_0 ),
        .Q(write_position_reg[0]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[1] 
       (.C(input_clk),
        .CE(write_position0),
        .D(p_0_in__1),
        .Q(write_position_reg[1]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[2] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[2]_i_1_n_0 ),
        .Q(write_position_reg[2]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[3] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[3]_i_1_n_0 ),
        .Q(write_position_reg[3]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[4] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[4]_i_1_n_0 ),
        .Q(write_position_reg[4]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[5] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[5]_i_1_n_0 ),
        .Q(write_position_reg[5]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[6] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[6]_i_1_n_0 ),
        .Q(write_position_reg[6]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[7] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[7]_i_1_n_0 ),
        .Q(write_position_reg[7]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[8] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[8]_i_3_n_0 ),
        .Q(write_position_reg[8]),
        .R(\write_position[8]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif

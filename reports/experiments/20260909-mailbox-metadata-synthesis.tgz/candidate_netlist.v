// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (lin64) Build 3671981 Fri Oct 14 04:59:54 MDT 2022
// Date        : Wed Sep  9 22:58:43 2026
// Host        : gauss running 64-bit Ubuntu 26.04 LTS
// Command     : write_verilog -mode funcsim /tmp/starlink-metadata-equality.cihpiD/synthesis-v1/candidate_netlist.v
// Design      : starlink_pss_block_mailbox
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* ADDRESS_WIDTH = "9" *) (* DATA_WIDTH = "36" *) (* DEPTH = "512" *) 
(* EXPLICIT_COMMIT = "1" *) (* LAST_POSITION = "9'b111111111" *) (* METADATA_WIDTH = "75" *) 
(* NETLIST_CHECKSUM = "1579a577" *) (* RESET_RELEASE_EXTERNAL = "1" *) 
(* NotValidForBitStream *)
module starlink_pss_block_mailbox
   (input_clk,
    input_resetn,
    input_valid,
    input_commit_authorized,
    input_ready,
    input_data,
    input_position,
    input_last,
    input_metadata,
    input_fault,
    input_framing_fault_now,
    output_clk,
    output_resetn,
    output_valid,
    output_ready,
    output_data,
    output_position,
    output_last,
    output_metadata);
  input input_clk;
  input input_resetn;
  input input_valid;
  input input_commit_authorized;
  output input_ready;
  input [35:0]input_data;
  input [8:0]input_position;
  input input_last;
  input [74:0]input_metadata;
  output input_fault;
  output input_framing_fault_now;
  input output_clk;
  input output_resetn;
  output output_valid;
  input output_ready;
  output [35:0]output_data;
  output [8:0]output_position;
  output output_last;
  output [74:0]output_metadata;

  (* async_reg = "true" *) wire [1:0]acknowledge_sync;
  wire acknowledge_toggle;
  wire acknowledge_toggle_i_1_n_0;
  wire acknowledge_toggle_i_2_n_0;
  (* RTL_KEEP = "true" *) wire [4:0]\balanced_metadata.group_equal ;
  (* RTL_KEEP = "true" *) wire [24:0]\balanced_metadata.leaf_equal ;
  wire input_clk;
  wire input_commit_authorized;
  wire [35:0]input_data;
  wire input_fault;
  wire input_fault_i_1_n_0;
  wire input_fault_i_2_n_0;
  wire input_framing_fault_now;
  wire input_framing_fault_now_INST_0_i_10_n_0;
  wire input_framing_fault_now_INST_0_i_1_n_0;
  wire input_framing_fault_now_INST_0_i_2_n_0;
  wire input_framing_fault_now_INST_0_i_4_n_0;
  wire input_framing_fault_now_INST_0_i_5_n_0;
  wire input_framing_fault_now_INST_0_i_6_n_0;
  wire input_framing_fault_now_INST_0_i_7_n_0;
  wire input_framing_fault_now_INST_0_i_8_n_0;
  wire input_framing_fault_now_INST_0_i_9_n_0;
  wire input_framing_valid113_in;
  wire input_last;
  wire [74:0]input_metadata;
  wire [8:0]input_position;
  wire input_ready;
  wire input_resetn;
  wire input_valid;
  wire \metadata_in_hold[74]_i_2_n_0 ;
  wire \metadata_in_hold[74]_i_3_n_0 ;
  wire \metadata_in_hold_reg_n_0_[0] ;
  wire \metadata_in_hold_reg_n_0_[1] ;
  wire \metadata_in_hold_reg_n_0_[2] ;
  wire metadata_load;
  wire metadata_out_hold;
  wire output_clk;
  wire [35:0]output_data;
  wire output_last;
  wire output_last_INST_0_i_1_n_0;
  wire [74:0]output_metadata;
  wire [8:0]output_position;
  wire output_ready;
  wire output_resetn;
  wire output_valid;
  wire [2:0]p_0_in;
  wire [2:0]p_0_in10_in;
  wire [2:0]p_0_in13_in;
  wire [2:0]p_0_in16_in;
  wire [2:0]p_0_in19_in;
  wire [2:0]p_0_in1_in;
  wire [2:0]p_0_in22_in;
  wire [2:0]p_0_in25_in;
  wire [2:0]p_0_in28_in;
  wire [2:0]p_0_in31_in;
  wire [2:0]p_0_in34_in;
  wire [2:0]p_0_in37_in;
  wire [2:0]p_0_in40_in;
  wire [2:0]p_0_in43_in;
  wire [2:0]p_0_in46_in;
  wire [2:0]p_0_in49_in;
  wire [2:0]p_0_in4_in;
  wire [2:0]p_0_in52_in;
  wire [2:0]p_0_in55_in;
  wire [2:0]p_0_in58_in;
  wire [2:0]p_0_in61_in;
  wire [2:0]p_0_in64_in;
  wire [2:0]p_0_in67_in;
  wire [2:0]p_0_in7_in;
  wire [1:1]p_0_in__0;
  wire payload_memory_reg_i_1_n_0;
  wire [8:0]read_address;
  wire \read_address[0]_i_1_n_0 ;
  wire \read_address[0]_i_2_n_0 ;
  wire \read_address[0]_i_3_n_0 ;
  wire \read_address[1]_i_1_n_0 ;
  wire \read_address[2]_i_1_n_0 ;
  wire \read_address[3]_i_1_n_0 ;
  wire \read_address[4]_i_1_n_0 ;
  wire \read_address[5]_i_1_n_0 ;
  wire \read_address[5]_i_2_n_0 ;
  wire \read_address[6]_i_1_n_0 ;
  wire \read_address[6]_i_2_n_0 ;
  wire \read_address[7]_i_1_n_0 ;
  wire \read_address[8]_i_1_n_0 ;
  wire read_all_loaded3_out;
  wire read_all_loaded_i_1_n_0;
  wire read_all_loaded_reg_n_0;
  wire read_valid;
  wire read_valid_i_1_n_0;
  wire reading;
  wire reading_i_1_n_0;
  wire reading_i_2_n_0;
  (* async_reg = "true" *) wire [1:0]request_sync;
  wire \request_sync[1]_i_1_n_0 ;
  wire request_toggle_i_1_n_0;
  wire request_toggle_i_2_n_0;
  wire request_toggle_reg_n_0;
  wire write_position0;
  wire \write_position[0]_i_1_n_0 ;
  wire \write_position[2]_i_1_n_0 ;
  wire \write_position[3]_i_1_n_0 ;
  wire \write_position[4]_i_1_n_0 ;
  wire \write_position[5]_i_1_n_0 ;
  wire \write_position[6]_i_1_n_0 ;
  wire \write_position[7]_i_1_n_0 ;
  wire \write_position[8]_i_1_n_0 ;
  wire \write_position[8]_i_3_n_0 ;
  wire [8:0]write_position_reg;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_3_CO_UNCONNECTED;
  wire [3:0]NLW_input_framing_fault_now_INST_0_i_3_O_UNCONNECTED;

  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \acknowledge_sync_reg[0] 
       (.C(input_clk),
        .CE(1'b1),
        .D(acknowledge_toggle),
        .Q(acknowledge_sync[0]),
        .R(input_fault_i_1_n_0));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \acknowledge_sync_reg[1] 
       (.C(input_clk),
        .CE(1'b1),
        .D(acknowledge_sync[0]),
        .Q(acknowledge_sync[1]),
        .R(input_fault_i_1_n_0));
  LUT5 #(
    .INIT(32'hFFBF0080)) 
    acknowledge_toggle_i_1
       (.I0(request_sync[1]),
        .I1(output_ready),
        .I2(read_valid),
        .I3(acknowledge_toggle_i_2_n_0),
        .I4(acknowledge_toggle),
        .O(acknowledge_toggle_i_1_n_0));
  LUT5 #(
    .INIT(32'hBFFFFFFF)) 
    acknowledge_toggle_i_2
       (.I0(output_last_INST_0_i_1_n_0),
        .I1(output_position[5]),
        .I2(output_position[6]),
        .I3(output_position[3]),
        .I4(output_position[4]),
        .O(acknowledge_toggle_i_2_n_0));
  FDRE acknowledge_toggle_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(acknowledge_toggle_i_1_n_0),
        .Q(acknowledge_toggle),
        .R(\request_sync[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \balanced_metadata.group_equal_inferred_i_1 
       (.I0(\balanced_metadata.leaf_equal [19]),
        .I1(\balanced_metadata.leaf_equal [18]),
        .I2(\balanced_metadata.leaf_equal [22]),
        .I3(\balanced_metadata.leaf_equal [23]),
        .I4(\balanced_metadata.leaf_equal [20]),
        .I5(\balanced_metadata.leaf_equal [21]),
        .O(\balanced_metadata.group_equal [3]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \balanced_metadata.group_equal_inferred_i_2 
       (.I0(\balanced_metadata.leaf_equal [13]),
        .I1(\balanced_metadata.leaf_equal [12]),
        .I2(\balanced_metadata.leaf_equal [16]),
        .I3(\balanced_metadata.leaf_equal [17]),
        .I4(\balanced_metadata.leaf_equal [14]),
        .I5(\balanced_metadata.leaf_equal [15]),
        .O(\balanced_metadata.group_equal [2]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \balanced_metadata.group_equal_inferred_i_3 
       (.I0(\balanced_metadata.leaf_equal [7]),
        .I1(\balanced_metadata.leaf_equal [6]),
        .I2(\balanced_metadata.leaf_equal [10]),
        .I3(\balanced_metadata.leaf_equal [11]),
        .I4(\balanced_metadata.leaf_equal [8]),
        .I5(\balanced_metadata.leaf_equal [9]),
        .O(\balanced_metadata.group_equal [1]));
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    \balanced_metadata.group_equal_inferred_i_4 
       (.I0(\balanced_metadata.leaf_equal [1]),
        .I1(\balanced_metadata.leaf_equal [0]),
        .I2(\balanced_metadata.leaf_equal [4]),
        .I3(\balanced_metadata.leaf_equal [5]),
        .I4(\balanced_metadata.leaf_equal [2]),
        .I5(\balanced_metadata.leaf_equal [3]),
        .O(\balanced_metadata.group_equal [0]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_1 
       (.I0(input_metadata[72]),
        .I1(p_0_in67_in[0]),
        .I2(p_0_in67_in[2]),
        .I3(input_metadata[74]),
        .I4(p_0_in67_in[1]),
        .I5(input_metadata[73]),
        .O(\balanced_metadata.leaf_equal [24]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_10 
       (.I0(input_metadata[45]),
        .I1(p_0_in40_in[0]),
        .I2(p_0_in40_in[2]),
        .I3(input_metadata[47]),
        .I4(p_0_in40_in[1]),
        .I5(input_metadata[46]),
        .O(\balanced_metadata.leaf_equal [15]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_11 
       (.I0(input_metadata[42]),
        .I1(p_0_in37_in[0]),
        .I2(p_0_in37_in[2]),
        .I3(input_metadata[44]),
        .I4(p_0_in37_in[1]),
        .I5(input_metadata[43]),
        .O(\balanced_metadata.leaf_equal [14]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_12 
       (.I0(input_metadata[39]),
        .I1(p_0_in34_in[0]),
        .I2(p_0_in34_in[2]),
        .I3(input_metadata[41]),
        .I4(p_0_in34_in[1]),
        .I5(input_metadata[40]),
        .O(\balanced_metadata.leaf_equal [13]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_13 
       (.I0(input_metadata[36]),
        .I1(p_0_in31_in[0]),
        .I2(p_0_in31_in[2]),
        .I3(input_metadata[38]),
        .I4(p_0_in31_in[1]),
        .I5(input_metadata[37]),
        .O(\balanced_metadata.leaf_equal [12]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_14 
       (.I0(input_metadata[33]),
        .I1(p_0_in28_in[0]),
        .I2(p_0_in28_in[2]),
        .I3(input_metadata[35]),
        .I4(p_0_in28_in[1]),
        .I5(input_metadata[34]),
        .O(\balanced_metadata.leaf_equal [11]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_15 
       (.I0(input_metadata[30]),
        .I1(p_0_in25_in[0]),
        .I2(p_0_in25_in[2]),
        .I3(input_metadata[32]),
        .I4(p_0_in25_in[1]),
        .I5(input_metadata[31]),
        .O(\balanced_metadata.leaf_equal [10]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_16 
       (.I0(input_metadata[27]),
        .I1(p_0_in22_in[0]),
        .I2(p_0_in22_in[2]),
        .I3(input_metadata[29]),
        .I4(p_0_in22_in[1]),
        .I5(input_metadata[28]),
        .O(\balanced_metadata.leaf_equal [9]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_17 
       (.I0(input_metadata[24]),
        .I1(p_0_in19_in[0]),
        .I2(p_0_in19_in[2]),
        .I3(input_metadata[26]),
        .I4(p_0_in19_in[1]),
        .I5(input_metadata[25]),
        .O(\balanced_metadata.leaf_equal [8]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_18 
       (.I0(input_metadata[21]),
        .I1(p_0_in16_in[0]),
        .I2(p_0_in16_in[2]),
        .I3(input_metadata[23]),
        .I4(p_0_in16_in[1]),
        .I5(input_metadata[22]),
        .O(\balanced_metadata.leaf_equal [7]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_19 
       (.I0(input_metadata[18]),
        .I1(p_0_in13_in[0]),
        .I2(p_0_in13_in[2]),
        .I3(input_metadata[20]),
        .I4(p_0_in13_in[1]),
        .I5(input_metadata[19]),
        .O(\balanced_metadata.leaf_equal [6]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_2 
       (.I0(input_metadata[69]),
        .I1(p_0_in64_in[0]),
        .I2(p_0_in64_in[2]),
        .I3(input_metadata[71]),
        .I4(p_0_in64_in[1]),
        .I5(input_metadata[70]),
        .O(\balanced_metadata.leaf_equal [23]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_20 
       (.I0(input_metadata[15]),
        .I1(p_0_in10_in[0]),
        .I2(p_0_in10_in[2]),
        .I3(input_metadata[17]),
        .I4(p_0_in10_in[1]),
        .I5(input_metadata[16]),
        .O(\balanced_metadata.leaf_equal [5]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_21 
       (.I0(input_metadata[12]),
        .I1(p_0_in7_in[0]),
        .I2(p_0_in7_in[2]),
        .I3(input_metadata[14]),
        .I4(p_0_in7_in[1]),
        .I5(input_metadata[13]),
        .O(\balanced_metadata.leaf_equal [4]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_22 
       (.I0(input_metadata[9]),
        .I1(p_0_in4_in[0]),
        .I2(p_0_in4_in[2]),
        .I3(input_metadata[11]),
        .I4(p_0_in4_in[1]),
        .I5(input_metadata[10]),
        .O(\balanced_metadata.leaf_equal [3]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_23 
       (.I0(input_metadata[6]),
        .I1(p_0_in1_in[0]),
        .I2(p_0_in1_in[2]),
        .I3(input_metadata[8]),
        .I4(p_0_in1_in[1]),
        .I5(input_metadata[7]),
        .O(\balanced_metadata.leaf_equal [2]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_24 
       (.I0(input_metadata[3]),
        .I1(p_0_in[0]),
        .I2(p_0_in[2]),
        .I3(input_metadata[5]),
        .I4(p_0_in[1]),
        .I5(input_metadata[4]),
        .O(\balanced_metadata.leaf_equal [1]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_25 
       (.I0(input_metadata[0]),
        .I1(\metadata_in_hold_reg_n_0_[0] ),
        .I2(\metadata_in_hold_reg_n_0_[2] ),
        .I3(input_metadata[2]),
        .I4(\metadata_in_hold_reg_n_0_[1] ),
        .I5(input_metadata[1]),
        .O(\balanced_metadata.leaf_equal [0]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_3 
       (.I0(input_metadata[66]),
        .I1(p_0_in61_in[0]),
        .I2(p_0_in61_in[2]),
        .I3(input_metadata[68]),
        .I4(p_0_in61_in[1]),
        .I5(input_metadata[67]),
        .O(\balanced_metadata.leaf_equal [22]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_4 
       (.I0(input_metadata[63]),
        .I1(p_0_in58_in[0]),
        .I2(p_0_in58_in[2]),
        .I3(input_metadata[65]),
        .I4(p_0_in58_in[1]),
        .I5(input_metadata[64]),
        .O(\balanced_metadata.leaf_equal [21]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_5 
       (.I0(input_metadata[60]),
        .I1(p_0_in55_in[0]),
        .I2(p_0_in55_in[2]),
        .I3(input_metadata[62]),
        .I4(p_0_in55_in[1]),
        .I5(input_metadata[61]),
        .O(\balanced_metadata.leaf_equal [20]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_6 
       (.I0(input_metadata[57]),
        .I1(p_0_in52_in[0]),
        .I2(p_0_in52_in[2]),
        .I3(input_metadata[59]),
        .I4(p_0_in52_in[1]),
        .I5(input_metadata[58]),
        .O(\balanced_metadata.leaf_equal [19]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_7 
       (.I0(input_metadata[54]),
        .I1(p_0_in49_in[0]),
        .I2(p_0_in49_in[2]),
        .I3(input_metadata[56]),
        .I4(p_0_in49_in[1]),
        .I5(input_metadata[55]),
        .O(\balanced_metadata.leaf_equal [18]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_8 
       (.I0(input_metadata[51]),
        .I1(p_0_in46_in[0]),
        .I2(p_0_in46_in[2]),
        .I3(input_metadata[53]),
        .I4(p_0_in46_in[1]),
        .I5(input_metadata[52]),
        .O(\balanced_metadata.leaf_equal [17]));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    \balanced_metadata.leaf_equal_inferred_i_9 
       (.I0(input_metadata[48]),
        .I1(p_0_in43_in[0]),
        .I2(p_0_in43_in[2]),
        .I3(input_metadata[50]),
        .I4(p_0_in43_in[1]),
        .I5(input_metadata[49]),
        .O(\balanced_metadata.leaf_equal [16]));
  LUT1 #(
    .INIT(2'h1)) 
    input_fault_i_1
       (.I0(input_resetn),
        .O(input_fault_i_1_n_0));
  LUT2 #(
    .INIT(4'hE)) 
    input_fault_i_2
       (.I0(input_framing_fault_now),
        .I1(input_fault),
        .O(input_fault_i_2_n_0));
  FDRE input_fault_reg
       (.C(input_clk),
        .CE(1'b1),
        .D(input_fault_i_2_n_0),
        .Q(input_fault),
        .R(input_fault_i_1_n_0));
  LUT6 #(
    .INIT(64'hFF008F008F00FF00)) 
    input_framing_fault_now_INST_0
       (.I0(input_framing_fault_now_INST_0_i_1_n_0),
        .I1(input_framing_fault_now_INST_0_i_2_n_0),
        .I2(input_framing_valid113_in),
        .I3(input_framing_fault_now_INST_0_i_4_n_0),
        .I4(input_last),
        .I5(input_framing_fault_now_INST_0_i_5_n_0),
        .O(input_framing_fault_now));
  (* OPT_MODIFIED = "RETARGET" *) 
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    input_framing_fault_now_INST_0_i_1
       (.I0(\balanced_metadata.group_equal [0]),
        .I1(\balanced_metadata.group_equal [3]),
        .I2(\balanced_metadata.leaf_equal [24]),
        .I3(\balanced_metadata.group_equal [2]),
        .I4(\balanced_metadata.group_equal [1]),
        .O(input_framing_fault_now_INST_0_i_1_n_0));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    input_framing_fault_now_INST_0_i_10
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[1]),
        .I4(write_position_reg[3]),
        .I5(write_position_reg[5]),
        .O(input_framing_fault_now_INST_0_i_10_n_0));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    input_framing_fault_now_INST_0_i_2
       (.I0(input_framing_fault_now_INST_0_i_6_n_0),
        .I1(write_position_reg[5]),
        .I2(write_position_reg[6]),
        .I3(write_position_reg[3]),
        .I4(write_position_reg[4]),
        .O(input_framing_fault_now_INST_0_i_2_n_0));
  CARRY4 input_framing_fault_now_INST_0_i_3
       (.CI(1'b0),
        .CO({NLW_input_framing_fault_now_INST_0_i_3_CO_UNCONNECTED[3],input_framing_valid113_in,NLW_input_framing_fault_now_INST_0_i_3_CO_UNCONNECTED[1:0]}),
        .CYINIT(1'b1),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(NLW_input_framing_fault_now_INST_0_i_3_O_UNCONNECTED[3:0]),
        .S({1'b0,input_framing_fault_now_INST_0_i_7_n_0,input_framing_fault_now_INST_0_i_8_n_0,input_framing_fault_now_INST_0_i_9_n_0}));
  LUT5 #(
    .INIT(32'h00900000)) 
    input_framing_fault_now_INST_0_i_4
       (.I0(acknowledge_sync[1]),
        .I1(request_toggle_reg_n_0),
        .I2(input_resetn),
        .I3(input_fault),
        .I4(input_valid),
        .O(input_framing_fault_now_INST_0_i_4_n_0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hDFFF)) 
    input_framing_fault_now_INST_0_i_5
       (.I0(write_position_reg[7]),
        .I1(input_framing_fault_now_INST_0_i_10_n_0),
        .I2(write_position_reg[6]),
        .I3(write_position_reg[8]),
        .O(input_framing_fault_now_INST_0_i_5_n_0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    input_framing_fault_now_INST_0_i_6
       (.I0(write_position_reg[0]),
        .I1(write_position_reg[7]),
        .I2(write_position_reg[8]),
        .I3(write_position_reg[2]),
        .I4(write_position_reg[1]),
        .O(input_framing_fault_now_INST_0_i_6_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    input_framing_fault_now_INST_0_i_7
       (.I0(write_position_reg[8]),
        .I1(input_position[8]),
        .I2(write_position_reg[7]),
        .I3(input_position[7]),
        .I4(input_position[6]),
        .I5(write_position_reg[6]),
        .O(input_framing_fault_now_INST_0_i_7_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    input_framing_fault_now_INST_0_i_8
       (.I0(write_position_reg[5]),
        .I1(input_position[5]),
        .I2(write_position_reg[4]),
        .I3(input_position[4]),
        .I4(input_position[3]),
        .I5(write_position_reg[3]),
        .O(input_framing_fault_now_INST_0_i_8_n_0));
  LUT6 #(
    .INIT(64'h9009000000009009)) 
    input_framing_fault_now_INST_0_i_9
       (.I0(write_position_reg[2]),
        .I1(input_position[2]),
        .I2(write_position_reg[1]),
        .I3(input_position[1]),
        .I4(input_position[0]),
        .I5(write_position_reg[0]),
        .O(input_framing_fault_now_INST_0_i_9_n_0));
  LUT4 #(
    .INIT(16'h4004)) 
    input_ready_INST_0
       (.I0(input_fault),
        .I1(input_resetn),
        .I2(request_toggle_reg_n_0),
        .I3(acknowledge_sync[1]),
        .O(input_ready));
  LUT3 #(
    .INIT(8'h40)) 
    \metadata_in_hold[74]_i_1 
       (.I0(input_framing_fault_now_INST_0_i_2_n_0),
        .I1(\metadata_in_hold[74]_i_2_n_0 ),
        .I2(\metadata_in_hold[74]_i_3_n_0 ),
        .O(metadata_load));
  LUT5 #(
    .INIT(32'h00010000)) 
    \metadata_in_hold[74]_i_2 
       (.I0(input_position[2]),
        .I1(input_position[3]),
        .I2(input_position[0]),
        .I3(input_position[1]),
        .I4(input_framing_fault_now_INST_0_i_4_n_0),
        .O(\metadata_in_hold[74]_i_2_n_0 ));
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    \metadata_in_hold[74]_i_3 
       (.I0(input_position[6]),
        .I1(input_position[7]),
        .I2(input_position[4]),
        .I3(input_position[5]),
        .I4(input_last),
        .I5(input_position[8]),
        .O(\metadata_in_hold[74]_i_3_n_0 ));
  FDRE \metadata_in_hold_reg[0] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[0]),
        .Q(\metadata_in_hold_reg_n_0_[0] ),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[10] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[10]),
        .Q(p_0_in4_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[11] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[11]),
        .Q(p_0_in4_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[12] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[12]),
        .Q(p_0_in7_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[13] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[13]),
        .Q(p_0_in7_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[14] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[14]),
        .Q(p_0_in7_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[15] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[15]),
        .Q(p_0_in10_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[16] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[16]),
        .Q(p_0_in10_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[17] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[17]),
        .Q(p_0_in10_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[18] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[18]),
        .Q(p_0_in13_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[19] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[19]),
        .Q(p_0_in13_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[1] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[1]),
        .Q(\metadata_in_hold_reg_n_0_[1] ),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[20] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[20]),
        .Q(p_0_in13_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[21] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[21]),
        .Q(p_0_in16_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[22] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[22]),
        .Q(p_0_in16_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[23] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[23]),
        .Q(p_0_in16_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[24] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[24]),
        .Q(p_0_in19_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[25] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[25]),
        .Q(p_0_in19_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[26] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[26]),
        .Q(p_0_in19_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[27] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[27]),
        .Q(p_0_in22_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[28] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[28]),
        .Q(p_0_in22_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[29] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[29]),
        .Q(p_0_in22_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[2] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[2]),
        .Q(\metadata_in_hold_reg_n_0_[2] ),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[30] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[30]),
        .Q(p_0_in25_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[31] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[31]),
        .Q(p_0_in25_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[32] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[32]),
        .Q(p_0_in25_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[33] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[33]),
        .Q(p_0_in28_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[34] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[34]),
        .Q(p_0_in28_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[35] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[35]),
        .Q(p_0_in28_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[36] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[36]),
        .Q(p_0_in31_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[37] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[37]),
        .Q(p_0_in31_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[38] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[38]),
        .Q(p_0_in31_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[39] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[39]),
        .Q(p_0_in34_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[3] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[3]),
        .Q(p_0_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[40] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[40]),
        .Q(p_0_in34_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[41] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[41]),
        .Q(p_0_in34_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[42] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[42]),
        .Q(p_0_in37_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[43] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[43]),
        .Q(p_0_in37_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[44] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[44]),
        .Q(p_0_in37_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[45] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[45]),
        .Q(p_0_in40_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[46] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[46]),
        .Q(p_0_in40_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[47] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[47]),
        .Q(p_0_in40_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[48] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[48]),
        .Q(p_0_in43_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[49] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[49]),
        .Q(p_0_in43_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[4] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[4]),
        .Q(p_0_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[50] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[50]),
        .Q(p_0_in43_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[51] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[51]),
        .Q(p_0_in46_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[52] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[52]),
        .Q(p_0_in46_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[53] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[53]),
        .Q(p_0_in46_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[54] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[54]),
        .Q(p_0_in49_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[55] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[55]),
        .Q(p_0_in49_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[56] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[56]),
        .Q(p_0_in49_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[57] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[57]),
        .Q(p_0_in52_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[58] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[58]),
        .Q(p_0_in52_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[59] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[59]),
        .Q(p_0_in52_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[5] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[5]),
        .Q(p_0_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[60] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[60]),
        .Q(p_0_in55_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[61] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[61]),
        .Q(p_0_in55_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[62] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[62]),
        .Q(p_0_in55_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[63] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[63]),
        .Q(p_0_in58_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[64] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[64]),
        .Q(p_0_in58_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[65] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[65]),
        .Q(p_0_in58_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[66] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[66]),
        .Q(p_0_in61_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[67] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[67]),
        .Q(p_0_in61_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[68] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[68]),
        .Q(p_0_in61_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[69] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[69]),
        .Q(p_0_in64_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[6] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[6]),
        .Q(p_0_in1_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[70] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[70]),
        .Q(p_0_in64_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[71] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[71]),
        .Q(p_0_in64_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[72] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[72]),
        .Q(p_0_in67_in[0]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[73] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[73]),
        .Q(p_0_in67_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[74] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[74]),
        .Q(p_0_in67_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[7] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[7]),
        .Q(p_0_in1_in[1]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[8] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[8]),
        .Q(p_0_in1_in[2]),
        .R(1'b0));
  FDRE \metadata_in_hold_reg[9] 
       (.C(input_clk),
        .CE(metadata_load),
        .D(input_metadata[9]),
        .Q(p_0_in4_in[0]),
        .R(1'b0));
  LUT4 #(
    .INIT(16'h0440)) 
    \metadata_out_hold[74]_i_1 
       (.I0(reading),
        .I1(output_resetn),
        .I2(request_sync[1]),
        .I3(acknowledge_toggle),
        .O(metadata_out_hold));
  FDRE \metadata_out_hold_reg[0] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(\metadata_in_hold_reg_n_0_[0] ),
        .Q(output_metadata[0]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[10] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in4_in[1]),
        .Q(output_metadata[10]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[11] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in4_in[2]),
        .Q(output_metadata[11]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[12] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in7_in[0]),
        .Q(output_metadata[12]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[13] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in7_in[1]),
        .Q(output_metadata[13]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[14] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in7_in[2]),
        .Q(output_metadata[14]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[15] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in10_in[0]),
        .Q(output_metadata[15]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[16] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in10_in[1]),
        .Q(output_metadata[16]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[17] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in10_in[2]),
        .Q(output_metadata[17]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[18] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in13_in[0]),
        .Q(output_metadata[18]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[19] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in13_in[1]),
        .Q(output_metadata[19]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[1] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(\metadata_in_hold_reg_n_0_[1] ),
        .Q(output_metadata[1]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[20] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in13_in[2]),
        .Q(output_metadata[20]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[21] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in16_in[0]),
        .Q(output_metadata[21]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[22] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in16_in[1]),
        .Q(output_metadata[22]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[23] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in16_in[2]),
        .Q(output_metadata[23]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[24] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in19_in[0]),
        .Q(output_metadata[24]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[25] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in19_in[1]),
        .Q(output_metadata[25]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[26] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in19_in[2]),
        .Q(output_metadata[26]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[27] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in22_in[0]),
        .Q(output_metadata[27]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[28] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in22_in[1]),
        .Q(output_metadata[28]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[29] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in22_in[2]),
        .Q(output_metadata[29]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[2] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(\metadata_in_hold_reg_n_0_[2] ),
        .Q(output_metadata[2]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[30] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in25_in[0]),
        .Q(output_metadata[30]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[31] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in25_in[1]),
        .Q(output_metadata[31]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[32] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in25_in[2]),
        .Q(output_metadata[32]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[33] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in28_in[0]),
        .Q(output_metadata[33]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[34] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in28_in[1]),
        .Q(output_metadata[34]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[35] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in28_in[2]),
        .Q(output_metadata[35]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[36] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in31_in[0]),
        .Q(output_metadata[36]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[37] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in31_in[1]),
        .Q(output_metadata[37]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[38] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in31_in[2]),
        .Q(output_metadata[38]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[39] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in34_in[0]),
        .Q(output_metadata[39]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[3] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in[0]),
        .Q(output_metadata[3]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[40] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in34_in[1]),
        .Q(output_metadata[40]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[41] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in34_in[2]),
        .Q(output_metadata[41]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[42] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in37_in[0]),
        .Q(output_metadata[42]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[43] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in37_in[1]),
        .Q(output_metadata[43]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[44] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in37_in[2]),
        .Q(output_metadata[44]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[45] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in40_in[0]),
        .Q(output_metadata[45]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[46] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in40_in[1]),
        .Q(output_metadata[46]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[47] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in40_in[2]),
        .Q(output_metadata[47]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[48] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in43_in[0]),
        .Q(output_metadata[48]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[49] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in43_in[1]),
        .Q(output_metadata[49]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[4] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in[1]),
        .Q(output_metadata[4]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[50] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in43_in[2]),
        .Q(output_metadata[50]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[51] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in46_in[0]),
        .Q(output_metadata[51]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[52] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in46_in[1]),
        .Q(output_metadata[52]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[53] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in46_in[2]),
        .Q(output_metadata[53]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[54] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in49_in[0]),
        .Q(output_metadata[54]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[55] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in49_in[1]),
        .Q(output_metadata[55]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[56] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in49_in[2]),
        .Q(output_metadata[56]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[57] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in52_in[0]),
        .Q(output_metadata[57]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[58] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in52_in[1]),
        .Q(output_metadata[58]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[59] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in52_in[2]),
        .Q(output_metadata[59]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[5] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in[2]),
        .Q(output_metadata[5]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[60] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in55_in[0]),
        .Q(output_metadata[60]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[61] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in55_in[1]),
        .Q(output_metadata[61]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[62] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in55_in[2]),
        .Q(output_metadata[62]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[63] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in58_in[0]),
        .Q(output_metadata[63]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[64] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in58_in[1]),
        .Q(output_metadata[64]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[65] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in58_in[2]),
        .Q(output_metadata[65]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[66] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in61_in[0]),
        .Q(output_metadata[66]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[67] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in61_in[1]),
        .Q(output_metadata[67]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[68] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in61_in[2]),
        .Q(output_metadata[68]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[69] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in64_in[0]),
        .Q(output_metadata[69]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[6] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in1_in[0]),
        .Q(output_metadata[6]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[70] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in64_in[1]),
        .Q(output_metadata[70]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[71] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in64_in[2]),
        .Q(output_metadata[71]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[72] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in67_in[0]),
        .Q(output_metadata[72]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[73] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in67_in[1]),
        .Q(output_metadata[73]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[74] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in67_in[2]),
        .Q(output_metadata[74]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[7] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in1_in[1]),
        .Q(output_metadata[7]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[8] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in1_in[2]),
        .Q(output_metadata[8]),
        .R(1'b0));
  FDRE \metadata_out_hold_reg[9] 
       (.C(output_clk),
        .CE(metadata_out_hold),
        .D(p_0_in4_in[0]),
        .Q(output_metadata[9]),
        .R(1'b0));
  LUT5 #(
    .INIT(32'h00008000)) 
    output_last_INST_0
       (.I0(output_position[4]),
        .I1(output_position[3]),
        .I2(output_position[6]),
        .I3(output_position[5]),
        .I4(output_last_INST_0_i_1_n_0),
        .O(output_last));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    output_last_INST_0_i_1
       (.I0(output_position[0]),
        .I1(output_position[7]),
        .I2(output_position[8]),
        .I3(output_position[2]),
        .I4(output_position[1]),
        .O(output_last_INST_0_i_1_n_0));
  LUT2 #(
    .INIT(4'h8)) 
    output_valid_INST_0
       (.I0(read_valid),
        .I1(output_resetn),
        .O(output_valid));
  (* \MEM.PORTA.DATA_BIT_LAYOUT  = "p4_d32" *) 
  (* \MEM.PORTB.DATA_BIT_LAYOUT  = "p4_d32" *) 
  (* METHODOLOGY_DRC_VIOS = "{SYNTH-6 {cell *THIS*}}" *) 
  (* RTL_RAM_BITS = "18432" *) 
  (* RTL_RAM_NAME = "payload_memory_reg" *) 
  (* RTL_RAM_TYPE = "RAM_SDP" *) 
  (* ram_addr_begin = "0" *) 
  (* ram_addr_end = "511" *) 
  (* ram_offset = "0" *) 
  (* ram_slice_begin = "0" *) 
  (* ram_slice_end = "35" *) 
  RAMB18E1 #(
    .DOA_REG(0),
    .DOB_REG(0),
    .INIT_A(18'h00000),
    .INIT_B(18'h00000),
    .RAM_MODE("SDP"),
    .RDADDR_COLLISION_HWCONFIG("DELAYED_WRITE"),
    .READ_WIDTH_A(36),
    .READ_WIDTH_B(0),
    .RSTREG_PRIORITY_A("RSTREG"),
    .RSTREG_PRIORITY_B("RSTREG"),
    .SIM_COLLISION_CHECK("ALL"),
    .SIM_DEVICE("7SERIES"),
    .SRVAL_A(18'h00000),
    .SRVAL_B(18'h00000),
    .WRITE_MODE_A("WRITE_FIRST"),
    .WRITE_MODE_B("WRITE_FIRST"),
    .WRITE_WIDTH_A(0),
    .WRITE_WIDTH_B(36)) 
    payload_memory_reg
       (.ADDRARDADDR({read_address,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .ADDRBWRADDR({write_position_reg,1'b1,1'b1,1'b1,1'b1,1'b1}),
        .CLKARDCLK(output_clk),
        .CLKBWRCLK(input_clk),
        .DIADI(input_data[15:0]),
        .DIBDI(input_data[31:16]),
        .DIPADIP(input_data[33:32]),
        .DIPBDIP(input_data[35:34]),
        .DOADO(output_data[15:0]),
        .DOBDO(output_data[31:16]),
        .DOPADOP(output_data[33:32]),
        .DOPBDOP(output_data[35:34]),
        .ENARDEN(payload_memory_reg_i_1_n_0),
        .ENBWREN(input_valid),
        .REGCEAREGCE(1'b0),
        .REGCEB(1'b0),
        .RSTRAMARSTRAM(1'b0),
        .RSTRAMB(1'b0),
        .RSTREGARSTREG(1'b0),
        .RSTREGB(1'b0),
        .WEA({1'b0,1'b0}),
        .WEBWE({input_ready,input_ready,input_ready,input_ready}));
  LUT5 #(
    .INIT(32'h08080008)) 
    payload_memory_reg_i_1
       (.I0(reading),
        .I1(output_resetn),
        .I2(read_all_loaded_reg_n_0),
        .I3(read_valid),
        .I4(output_ready),
        .O(payload_memory_reg_i_1_n_0));
  LUT6 #(
    .INIT(64'h8A8A8AFF8AFF8A8A)) 
    \read_address[0]_i_1 
       (.I0(payload_memory_reg_i_1_n_0),
        .I1(\read_address[0]_i_3_n_0 ),
        .I2(read_address[8]),
        .I3(reading),
        .I4(acknowledge_toggle),
        .I5(request_sync[1]),
        .O(\read_address[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT5 #(
    .INIT(32'h00000B00)) 
    \read_address[0]_i_2 
       (.I0(output_ready),
        .I1(read_valid),
        .I2(read_all_loaded_reg_n_0),
        .I3(reading),
        .I4(read_address[0]),
        .O(\read_address[0]_i_2_n_0 ));
  LUT3 #(
    .INIT(8'hDF)) 
    \read_address[0]_i_3 
       (.I0(read_address[6]),
        .I1(\read_address[6]_i_2_n_0 ),
        .I2(read_address[7]),
        .O(\read_address[0]_i_3_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h28)) 
    \read_address[1]_i_1 
       (.I0(payload_memory_reg_i_1_n_0),
        .I1(read_address[0]),
        .I2(read_address[1]),
        .O(\read_address[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h2A80)) 
    \read_address[2]_i_1 
       (.I0(payload_memory_reg_i_1_n_0),
        .I1(read_address[1]),
        .I2(read_address[0]),
        .I3(read_address[2]),
        .O(\read_address[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT5 #(
    .INIT(32'h2AAA8000)) 
    \read_address[3]_i_1 
       (.I0(payload_memory_reg_i_1_n_0),
        .I1(read_address[2]),
        .I2(read_address[0]),
        .I3(read_address[1]),
        .I4(read_address[3]),
        .O(\read_address[3]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFF000080000000)) 
    \read_address[4]_i_1 
       (.I0(read_address[2]),
        .I1(read_address[0]),
        .I2(read_address[1]),
        .I3(read_address[3]),
        .I4(payload_memory_reg_i_1_n_0),
        .I5(read_address[4]),
        .O(\read_address[4]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT3 #(
    .INIT(8'h84)) 
    \read_address[5]_i_1 
       (.I0(\read_address[5]_i_2_n_0 ),
        .I1(payload_memory_reg_i_1_n_0),
        .I2(read_address[5]),
        .O(\read_address[5]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h7FFFFFFF)) 
    \read_address[5]_i_2 
       (.I0(read_address[3]),
        .I1(read_address[1]),
        .I2(read_address[0]),
        .I3(read_address[2]),
        .I4(read_address[4]),
        .O(\read_address[5]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT3 #(
    .INIT(8'h84)) 
    \read_address[6]_i_1 
       (.I0(\read_address[6]_i_2_n_0 ),
        .I1(payload_memory_reg_i_1_n_0),
        .I2(read_address[6]),
        .O(\read_address[6]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFFFFFFFFFF)) 
    \read_address[6]_i_2 
       (.I0(read_address[4]),
        .I1(read_address[2]),
        .I2(read_address[0]),
        .I3(read_address[1]),
        .I4(read_address[3]),
        .I5(read_address[5]),
        .O(\read_address[6]_i_2_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hB040)) 
    \read_address[7]_i_1 
       (.I0(\read_address[6]_i_2_n_0 ),
        .I1(read_address[6]),
        .I2(payload_memory_reg_i_1_n_0),
        .I3(read_address[7]),
        .O(\read_address[7]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'hDF002000)) 
    \read_address[8]_i_1 
       (.I0(read_address[6]),
        .I1(\read_address[6]_i_2_n_0 ),
        .I2(read_address[7]),
        .I3(payload_memory_reg_i_1_n_0),
        .I4(read_address[8]),
        .O(\read_address[8]_i_1_n_0 ));
  FDRE \read_address_reg[0] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[0]_i_2_n_0 ),
        .Q(read_address[0]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[1] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[1]_i_1_n_0 ),
        .Q(read_address[1]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[2] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[2]_i_1_n_0 ),
        .Q(read_address[2]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[3] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[3]_i_1_n_0 ),
        .Q(read_address[3]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[4] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[4]_i_1_n_0 ),
        .Q(read_address[4]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[5] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[5]_i_1_n_0 ),
        .Q(read_address[5]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[6] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[6]_i_1_n_0 ),
        .Q(read_address[6]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[7] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[7]_i_1_n_0 ),
        .Q(read_address[7]),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_address_reg[8] 
       (.C(output_clk),
        .CE(\read_address[0]_i_1_n_0 ),
        .D(\read_address[8]_i_1_n_0 ),
        .Q(read_address[8]),
        .R(\request_sync[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'hFFEBFF00)) 
    read_all_loaded_i_1
       (.I0(reading),
        .I1(acknowledge_toggle),
        .I2(request_sync[1]),
        .I3(read_all_loaded3_out),
        .I4(read_all_loaded_reg_n_0),
        .O(read_all_loaded_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT5 #(
    .INIT(32'h00800000)) 
    read_all_loaded_i_2
       (.I0(payload_memory_reg_i_1_n_0),
        .I1(read_address[8]),
        .I2(read_address[6]),
        .I3(\read_address[6]_i_2_n_0 ),
        .I4(read_address[7]),
        .O(read_all_loaded3_out));
  FDRE read_all_loaded_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(read_all_loaded_i_1_n_0),
        .Q(read_all_loaded_reg_n_0),
        .R(\request_sync[1]_i_1_n_0 ));
  FDRE \read_output_position_reg[0] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[0]),
        .Q(output_position[0]),
        .R(1'b0));
  FDRE \read_output_position_reg[1] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[1]),
        .Q(output_position[1]),
        .R(1'b0));
  FDRE \read_output_position_reg[2] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[2]),
        .Q(output_position[2]),
        .R(1'b0));
  FDRE \read_output_position_reg[3] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[3]),
        .Q(output_position[3]),
        .R(1'b0));
  FDRE \read_output_position_reg[4] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[4]),
        .Q(output_position[4]),
        .R(1'b0));
  FDRE \read_output_position_reg[5] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[5]),
        .Q(output_position[5]),
        .R(1'b0));
  FDRE \read_output_position_reg[6] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[6]),
        .Q(output_position[6]),
        .R(1'b0));
  FDRE \read_output_position_reg[7] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[7]),
        .Q(output_position[7]),
        .R(1'b0));
  FDRE \read_output_position_reg[8] 
       (.C(output_clk),
        .CE(payload_memory_reg_i_1_n_0),
        .D(read_address[8]),
        .Q(output_position[8]),
        .R(1'b0));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h4F44)) 
    read_valid_i_1
       (.I0(output_ready),
        .I1(read_valid),
        .I2(read_all_loaded_reg_n_0),
        .I3(reading),
        .O(read_valid_i_1_n_0));
  FDRE read_valid_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(read_valid_i_1_n_0),
        .Q(read_valid),
        .R(\request_sync[1]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h88880880)) 
    reading_i_1
       (.I0(reading_i_2_n_0),
        .I1(output_resetn),
        .I2(acknowledge_toggle),
        .I3(request_sync[1]),
        .I4(reading),
        .O(reading_i_1_n_0));
  LUT3 #(
    .INIT(8'hBF)) 
    reading_i_2
       (.I0(acknowledge_toggle_i_2_n_0),
        .I1(read_valid),
        .I2(output_ready),
        .O(reading_i_2_n_0));
  FDRE reading_reg
       (.C(output_clk),
        .CE(1'b1),
        .D(reading_i_1_n_0),
        .Q(reading),
        .R(1'b0));
  LUT1 #(
    .INIT(2'h1)) 
    \request_sync[1]_i_1 
       (.I0(output_resetn),
        .O(\request_sync[1]_i_1_n_0 ));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \request_sync_reg[0] 
       (.C(output_clk),
        .CE(1'b1),
        .D(request_toggle_reg_n_0),
        .Q(request_sync[0]),
        .R(\request_sync[1]_i_1_n_0 ));
  (* ASYNC_REG *) 
  (* KEEP = "yes" *) 
  FDRE \request_sync_reg[1] 
       (.C(output_clk),
        .CE(1'b1),
        .D(request_sync[0]),
        .Q(request_sync[1]),
        .R(\request_sync[1]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'hEFFFFFFF10000000)) 
    request_toggle_i_1
       (.I0(input_framing_fault_now_INST_0_i_5_n_0),
        .I1(input_framing_fault_now_INST_0_i_1_n_0),
        .I2(input_commit_authorized),
        .I3(input_framing_valid113_in),
        .I4(request_toggle_i_2_n_0),
        .I5(request_toggle_reg_n_0),
        .O(request_toggle_i_1_n_0));
  LUT6 #(
    .INIT(64'h2000002000000000)) 
    request_toggle_i_2
       (.I0(input_valid),
        .I1(input_fault),
        .I2(input_resetn),
        .I3(request_toggle_reg_n_0),
        .I4(acknowledge_sync[1]),
        .I5(input_last),
        .O(request_toggle_i_2_n_0));
  FDRE request_toggle_reg
       (.C(input_clk),
        .CE(1'b1),
        .D(request_toggle_i_1_n_0),
        .Q(request_toggle_reg_n_0),
        .R(input_fault_i_1_n_0));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \write_position[0]_i_1 
       (.I0(write_position_reg[0]),
        .O(\write_position[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'h6)) 
    \write_position[1]_i_1 
       (.I0(write_position_reg[0]),
        .I1(write_position_reg[1]),
        .O(p_0_in__0));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \write_position[2]_i_1 
       (.I0(write_position_reg[1]),
        .I1(write_position_reg[0]),
        .I2(write_position_reg[2]),
        .O(\write_position[2]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \write_position[3]_i_1 
       (.I0(write_position_reg[2]),
        .I1(write_position_reg[0]),
        .I2(write_position_reg[1]),
        .I3(write_position_reg[3]),
        .O(\write_position[3]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT5 #(
    .INIT(32'h7FFF8000)) 
    \write_position[4]_i_1 
       (.I0(write_position_reg[3]),
        .I1(write_position_reg[1]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[2]),
        .I4(write_position_reg[4]),
        .O(\write_position[4]_i_1_n_0 ));
  LUT6 #(
    .INIT(64'h7FFFFFFF80000000)) 
    \write_position[5]_i_1 
       (.I0(write_position_reg[4]),
        .I1(write_position_reg[2]),
        .I2(write_position_reg[0]),
        .I3(write_position_reg[1]),
        .I4(write_position_reg[3]),
        .I5(write_position_reg[5]),
        .O(\write_position[5]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h9)) 
    \write_position[6]_i_1 
       (.I0(input_framing_fault_now_INST_0_i_10_n_0),
        .I1(write_position_reg[6]),
        .O(\write_position[6]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT3 #(
    .INIT(8'hD2)) 
    \write_position[7]_i_1 
       (.I0(write_position_reg[6]),
        .I1(input_framing_fault_now_INST_0_i_10_n_0),
        .I2(write_position_reg[7]),
        .O(\write_position[7]_i_1_n_0 ));
  LUT3 #(
    .INIT(8'h6F)) 
    \write_position[8]_i_1 
       (.I0(request_toggle_reg_n_0),
        .I1(acknowledge_sync[1]),
        .I2(input_resetn),
        .O(\write_position[8]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h08000008)) 
    \write_position[8]_i_2 
       (.I0(input_framing_fault_now_INST_0_i_5_n_0),
        .I1(input_valid),
        .I2(input_fault),
        .I3(request_toggle_reg_n_0),
        .I4(acknowledge_sync[1]),
        .O(write_position0));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hDF20)) 
    \write_position[8]_i_3 
       (.I0(write_position_reg[7]),
        .I1(input_framing_fault_now_INST_0_i_10_n_0),
        .I2(write_position_reg[6]),
        .I3(write_position_reg[8]),
        .O(\write_position[8]_i_3_n_0 ));
  FDRE \write_position_reg[0] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[0]_i_1_n_0 ),
        .Q(write_position_reg[0]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[1] 
       (.C(input_clk),
        .CE(write_position0),
        .D(p_0_in__0),
        .Q(write_position_reg[1]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[2] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[2]_i_1_n_0 ),
        .Q(write_position_reg[2]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[3] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[3]_i_1_n_0 ),
        .Q(write_position_reg[3]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[4] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[4]_i_1_n_0 ),
        .Q(write_position_reg[4]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[5] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[5]_i_1_n_0 ),
        .Q(write_position_reg[5]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[6] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[6]_i_1_n_0 ),
        .Q(write_position_reg[6]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[7] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[7]_i_1_n_0 ),
        .Q(write_position_reg[7]),
        .R(\write_position[8]_i_1_n_0 ));
  FDRE \write_position_reg[8] 
       (.C(input_clk),
        .CE(write_position0),
        .D(\write_position[8]_i_3_n_0 ),
        .Q(write_position_reg[8]),
        .R(\write_position[8]_i_1_n_0 ));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif

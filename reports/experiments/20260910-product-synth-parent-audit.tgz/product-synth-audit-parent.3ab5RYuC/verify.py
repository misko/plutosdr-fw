"""Read-only source-specific synthesis audit; does not launch vendor tools."""
import hashlib
import json
from pathlib import Path
import re
import runpy

root = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz')
prepared = root / 'product-final-physical-prepared-v1'
run = root / 'product-final-synthesis-v1'
inventory = 'b3c446578c0c35f8e0f199aa12f66d8635b6f7d21c9b97713a5ffed2ac2b0f06'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert sha(prepared / 'SHA256SUMS') == inventory
assert sha(prepared / 'prepare_exact_control_physical.py') == 'd22bda330f571774a3099d0da9615a6a445e58fb4aecf43d10e6657fc954e876'
assert sha(prepared / 'run_exact_control_synthesis.py') == 'd0f36ce2817ab20baaff8668b6743e367d296f7a60e714099fe69aa5b6912111'
helper = runpy.run_path(str(prepared / 'prepare_exact_control_physical.py'))
settings = helper['verify_prepared'](prepared, run / 'synthesis/frozen_sources', inventory)
assert settings['producer_final'] == 1 and settings['rtl_count'] == 8
receipt = json.loads((run / 'terminal.json').read_text())
assert all(receipt[key] == 0 for key in ('before_audit','tool_returncode','after_audit','returncode'))
assert receipt['expected_sha256'] == inventory
owner = runpy.run_path(str(prepared / 'run_exact_control_synthesis.py'))
assert owner['completion'](run) == receipt['completion']
assert receipt['completion']['verified'] and not receipt['completion']['errors']
products = receipt['completion']['products']
assert set(products) == set(owner['PRODUCTS']) and len(products) == 8
for name, item in products.items():
    path = run / 'synthesis' / name
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
assert products['fft_bank_owned_synth.dcp']['sha256'] == '41c756bdc45635b1107d73ad741826e5a8f8fa276dc159468ec2355c16203aa6'
post = json.loads((run / 'after-inventory.json').read_text())
copied = run / 'synthesis/frozen_sources'
assert post['copied_sha256'] == {p.name: sha(p) for p in copied.iterdir()}
scope = (run / 'synthesis/scope.txt').read_text()
generic = next(line.split('=', 1)[1].split() for line in scope.splitlines() if line.startswith('effective_top_generics='))
for option in ('REGISTERED_SCHEDULING','DISTRIBUTED_FAST_FAULT','PRIVATE_NEXT_START_SCRATCH','PER_CAUSE_FAULT_CDC','PRIVATE_ROM_READ_AHEAD','PRIVATE_BLOCK_METADATA_READ_AHEAD','PRODUCER_LOCAL_FINAL_FENCE'):
    assert [v for v in generic if v.startswith(option+'=')] == [option+'=1']
for value, name in re.findall(r'([0-9a-f]{64})  (/[^\n]+)', scope):
    assert sha(Path(name)) == value, name
utilization = (run / 'synthesis/utilization.rpt').read_text()
assert '| Design       : starlink_pss_fft_bank_owned_product_fence' in utilization
assert '| Device       : xc7z010clg400-1' in utilization
print(json.dumps({'passed':True,'scope':'source_bound_synthesis_only_not_timing_or_receiver',
    'source_files':len(post['copied_sha256']),'products':products,
    'settings':settings,'wall_seconds':receipt['wall_seconds']}, indent=2))

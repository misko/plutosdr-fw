"""Independent integration-gap witness against frozen, unconnected v1 adapter.

Only a copied testbench is changed. Expected failures are evidence of a missing
actual-READY seam, not a regression of the original848 fixture assumptions.
No vendor FFT, top integration or physical claim.
"""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
FW = Path('/tmp/starlink-rom-prefetch.j829ht/fw')
sys.path.insert(0, str(FW))
TEST = FW / 'tests/starlink_oracle/test_product_sealed_adapter.py'
ACQ = FW / 'hdl/library/starlink_pss_acquisition'
EXPECTED = {
    TEST: '667d81221f41957efb9f7beadcd3686ba9b2c8d1b6dd07b15ed619bc2198b938',
    ACQ / 'starlink_pss_product_sealed_adapter.v': '054cccffabc661a90b2c8a20d63675db4ce64aa271bb09836b207691369f6fbd',
    ACQ / 'starlink_pss_checked_product_read.v': '30c8cb1dee84c2ebc4289cf101e85572d9655621db6075957557bab445251074',
    ACQ / 'tb/tb_starlink_pss_product_sealed_adapter.sv': 'c8bb28908c7541059dd2a8de5fc0f7bb07e185cfff5c6f4b9c77976e53608ec2',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert {p: sha(p) for p in EXPECTED} == EXPECTED
spec = importlib.util.spec_from_file_location('frozen_adapter_test', TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
anchor = '    if(score && kind==5 && dut.bank_valid'
insertion = '''    if(score && kind==14 && product_valid && product_position==target && !injected_once) begin
      force dut.product_ready=1'b0;
      injected_once=1;
      $display("PARENT_ACTUAL_READY_LOW target=%0d position=%0d",target,product_position);
    end
'''
compiled = module.compile_case(ROOT / 'copied_fixture', (
    'tb_starlink_pss_product_sealed_adapter.sv', anchor, insertion + anchor))
results = []
for position in (37, 511):
    code, log = module.execute(compiled, kind=14, target=position)
    assert code != 0 and log.count('PARENT_ACTUAL_READY_LOW') == 1
    assert 'PRODUCT_LOGICAL_TAKE_DIVERGED' in log, log
    results.append({'position': position, 'process_exit': code,
                    'expected_integration_gap_reproduced': True,
                    'marker': 'PRODUCT_LOGICAL_TAKE_DIVERGED'})
assert {p: sha(p) for p in EXPECTED} == EXPECTED
receipt = {'scope': 'frozen_v1_missing_actual_ready_seam_expected_counterexamples',
           'source_unchanged': True, 'cases': results, 'vendor_calls': 0,
           'original848_assumptions_unchanged': True}
with (ROOT / 'verification.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt, indent=2))

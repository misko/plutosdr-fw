module invalid; starlink_pss_spectrum_product_operand_register #(.REGISTER_OPERANDS(32'bz)) dut(); initial #1 $finish; endmodule

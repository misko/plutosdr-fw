module invalid; starlink_pss_spectrum_product_operand_register #(.DATA_WIDTH(1),.REGISTER_OPERANDS(1),.BOUNDARY_ROUND_SAT(1)) dut(); initial #1 $finish; endmodule

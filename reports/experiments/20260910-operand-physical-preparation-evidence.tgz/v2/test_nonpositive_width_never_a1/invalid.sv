module invalid; starlink_pss_spectrum_product_operand_register #(.DATA_WIDTH(-1)) dut(); initial #1 $finish; endmodule

module defaults; starlink_pss_spectrum_product_operand_register legacy();
starlink_pss_spectrum_product_operand_register #(.DATA_WIDTH(18),.BOUNDARY_ROUND_SAT(1)) forwarded();
initial begin if(legacy.REGISTER_OPERANDS !== 0 || legacy.BOUNDARY_ROUND_SAT !== 0 || legacy.DATA_WIDTH !== 24) $fatal(1,"bad omitted default");
if(forwarded.arithmetic.BOUNDARY_ROUND_SAT !== 1 || forwarded.arithmetic.DATA_WIDTH !== 18) $fatal(1,"bad actual forwarded parameter");
#1 $display("OPERAND_DEFAULT_PARAMETERS_PASS"); $finish; end endmodule

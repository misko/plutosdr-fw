module invalid; starlink_pss_spectrum_product_operand_register #(.BOUNDARY_ROUND_SAT(32'bx)) dut(); initial #1 $finish; endmodule

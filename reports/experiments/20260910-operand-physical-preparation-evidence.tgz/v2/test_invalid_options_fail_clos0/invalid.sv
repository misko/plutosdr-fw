module invalid; starlink_pss_spectrum_product_operand_register #(.REGISTER_OPERANDS(-1)) dut(); initial #1 $finish; endmodule

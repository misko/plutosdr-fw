"""Physical runner admission only: synthesis commands are forbidden stubs."""
import hashlib
import re
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "hdl/library/starlink_pss_acquisition"
RUNNER = RTL / "measure_spectrum_operand_boundary.tcl"
XDC = RTL / "starlink_pss_spectrum_operand_register_ooc.xdc"


def invoke(path, option, *, version="2022.2", cwd=None, after=""):
    script = f"""proc version {{args}} {{return {version}}}
proc set_param {{args}} {{}}
proc read_verilog {{args}} {{}}
proc synth_design {{args}} {{error SYNTHESIS_FENCED_NO_PHYSICAL_RUN}}
set argv [list {{{path}}} {{{option}}}]
set argc 2
set status [catch {{source {{{RUNNER}}}}} message]
puts "RESULT $status $message"
{after}
"""
    return subprocess.run(["tclsh"], input=script, cwd=cwd or ROOT, text=True,
                          capture_output=True, check=False, timeout=30)


@pytest.mark.parametrize("option", [0, 1])
def test_real_preflight_freezes_and_proves_parameters_before_synthesis(tmp_path, option):
    output = tmp_path / "run"
    result = invoke(output, option)
    assert result.returncode == 0 and not result.stderr, result.stderr
    assert "RESULT 1 SYNTHESIS_FENCED_NO_PHYSICAL_RUN" in result.stdout
    assert "OPERAND_BOUNDARY_PHYSICAL_MEASURED" not in result.stdout
    frozen = output / "frozen_sources"
    inventory = {name: digest for digest, name in
                 (line.split() for line in (output / "input_sources.sha256").read_text().splitlines())}
    assert len(inventory) == 6
    assert inventory == {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in frozen.iterdir()}
    assert (frozen / RUNNER.name).read_bytes() == RUNNER.read_bytes()
    assert (frozen / XDC.name).read_bytes() == XDC.read_bytes()
    assert (frozen / Path(__file__).name).read_bytes() == Path(__file__).read_bytes()
    assert (output / "parameter_probe.log").read_text().strip() == (
        f"OPERAND_PARAMETERS_VERIFIED width=18 round=1 registered={option} child_width=18 child_round=1 clocks=0")
    assert "tool_error=1 source_integrity_error=0" in (output / "result.txt").read_text()
    assert not list(output.glob("*.dcp"))


@pytest.mark.parametrize("option", [-1, 2, "1.0", "x", "", "00"])
def test_invalid_selection_never_allocates(tmp_path, option):
    output = tmp_path / "run"
    result = invoke(output, option)
    assert "expected NEW_OUTPUT and literal REGISTER_OPERANDS" in result.stdout
    assert not output.exists()


def test_version_and_nonoverwrite(tmp_path):
    output = tmp_path / "out"
    result = invoke(output, 0, version="2023.1")
    assert "Vivado2022.2 required" in result.stdout and not output.exists()
    output.mkdir(); (output / "sentinel").write_text("preserve")
    result = invoke(output, 1)
    assert "refusing to overwrite evidence" in result.stdout
    assert list(output.iterdir()) == [output / "sentinel"]
    assert (output / "sentinel").read_text() == "preserve"


def test_relative_output_is_resolved_before_cwd_change(tmp_path):
    result = invoke("relative-run", 1, cwd=tmp_path)
    assert "SYNTHESIS_FENCED_NO_PHYSICAL_RUN" in result.stdout
    assert (tmp_path / "relative-run/frozen_sources").is_dir()


@pytest.mark.parametrize("mutation", ["delete", "extra", "payload"])
def test_source_guard_rejects_full_inventory_change(tmp_path, mutation):
    commands = {
        "delete": "file delete [file join $frozen starlink_pss_spectrum_product.v]",
        "extra": "set h [open [file join $frozen extra] w]; puts $h extra; close $h",
        "payload": "set h [open [file join $frozen starlink_pss_spectrum_product.v] a]; puts $h changed; close $h",
    }
    result = invoke(tmp_path / "run", 0, after=commands[mutation] +
                    '\nputs "INTEGRITY [catch {operand_verify_sources $frozen $inventory} reason] $reason"')
    assert "INTEGRITY 1 frozen source" in result.stdout


def test_fixed_flow_constraints_and_inventory_contract():
    text = RUNNER.read_text(); constraints = XDC.read_text()
    old = (RTL / "measure_spectrum_round_boundary.tcl").read_text()
    start = old.index("create_clock -name product_clk")
    end = old.index("opt_design -directive ExploreArea")
    assert constraints.splitlines()[1:] == old[start:end].strip().splitlines()
    commands = ["-directive AreaOptimized_high", "opt_design -directive ExploreArea",
                "place_design", "phys_opt_design", "route_design"]
    positions = [text.index(command) for command in commands]
    assert positions == sorted(positions)
    for forbidden in ("set_false_path", "set_multicycle_path", "set_max_delay", "set_min_delay", "-force"):
        assert forbidden not in text and forbidden not in constraints
    assert "set_param general.maxThreads 2" in text
    assert "DATA_WIDTH=18 REGISTER_OPERANDS=$option BOUNDARY_ROUND_SAT=1" in text
    assert "-part xc7z010clg400-1" in text
    assert "foreach property {AREG BREG MREG PREG CREG ACASCREG BCASCREG}" in text
    assert "foreach required {CEA1 CEA2 CEB1 CEB2 CEM CEP}" in text
    assert "get_nets -quiet -of_objects $pin" in text
    for stage in ("synth", "route"):
        assert f"operand_dsp_inventory {stage}" in text
        assert f"operand_timing {stage}" in text
        assert f"utilization_{stage}.rpt" in text
    assert "foreach stage {synth opt route}" in text
    assert "-slack_lesser_than 0 -nworst 1 -max_paths 10000" in text
    assert "failed-endpoint inventory cap reached" in text
    assert text.index("set integrity [catch") > text.index("set status [catch")
    assert re.search(r'if \{\$status\} \{ return -options \$options \$message \}', text)
    assert "NOT_BANK_OR_TIMING_QUALIFICATION" in text

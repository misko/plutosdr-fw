"""Independent actual receipts/row inventory, exact golden bytes, causal event joins."""
import collections
import csv
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
sim=root/'run/project/retained_output_actual.sim/sim_1/behav/xsim'
log=(sim/'simulate.log').read_text()
assert not re.search(r'\b(fatal|error|fatal_error)\b',log,re.I)
execution=json.loads((root/'execution.json').read_text())
assert execution['vendor_exit']==0 and not execution['timed_out']
assert execution['original_source_check_exit']==execution['copied_source_check_exit']==0
assert execution['result_file_exists']
assert (root/'run/generated_ip_before.txt').read_bytes()==(root/'run/generated_ip_after.txt').read_bytes()
records=collections.defaultdict(list)
for line in log.splitlines():
    if line.startswith('RACT_'):
        fields={k:int(v) for k,v in (s.split('=') for s in line.split()[1:])}
        records[line.split()[0]].append(fields)
rows=list(csv.DictReader((sim/'actual_words.csv').open()))
counts=collections.Counter(row['stream'] for row in rows)
assert len(rows)==77953
assert counts=={'source':10752,'product':9728,'privateI':9728,'read':8704,
               'inputF':9857,'inputI':9728,'rawF':9728,'rawI':9728},counts
assert len(records['RACT_FRAME'])==40
assert len(records['RACT_JOB'])==38 and len(records['RACT_ABORT'])==2
by_input=collections.defaultdict(list)
for row in rows:
    if row['stream'] in ('inputF','inputI'):
        by_input[int(row['context']),row['stream'],int(row['job'])].append(int(row['fast']))
frames=[]
for frame,admit,release in zip(records['RACT_FRAME'],records['RACT_ADMIT'],records['RACT_RESET_RELEASE'],strict=True):
    assert frame['job']==admit['job']
    assert frame['admit']==admit['cycle']
    assert frame['release']==release['cycle']==admit['cycle']+2
    assert frame['config']==admit['cycle']+3
    assert release['context']==frame['context']==admit['context']
    stream='inputI' if frame['inverse'] else 'inputF'
    cycles=by_input[frame['context'],stream,frame['fixture']]
    before=sum(c<frame['cycle'] for c in cycles)
    on=sum(c==frame['cycle'] for c in cycles)
    assert (frame['before'],frame['on'],frame['after'])==(before,on,before+on)
    assert before+on>=1 and frame['end_cycle']==frame['cycle']+1
    frames.append({'job':frame['job'],'event_minus_admit':frame['cycle']-frame['admit'],
                   'inputs_at_event':before+on})
csv_sha=hashlib.sha256((sim/'actual_words.csv').read_bytes()).hexdigest()
# This equality checks every payload and clock coordinate, not just a score subset.
assert csv_sha=='07321b026a637e5922c56a84a955e58549056337198c952a9d73b1245cb4efaa'
report={'actual_exit':0,'csv_rows':len(rows),'csv_sha256':csv_sha,'stream_counts':dict(counts),
 'frame_measurements':frames,'frame_count':40,'complete_jobs':38,'aborted_jobs':2,
 'contexts':records['RACT_CONTEXT'],'shadows':records['RACT_SHADOW'],
 'generated_ip_unchanged':True,'physical_timing_or_continuous_rx_claim':False}
(root/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ('frame_measurements','contexts','shadows')}))

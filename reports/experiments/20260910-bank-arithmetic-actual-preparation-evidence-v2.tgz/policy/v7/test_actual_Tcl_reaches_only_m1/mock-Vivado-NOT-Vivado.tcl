proc version {args} {return 2022.2}
proc set_param {args} {}
proc create_project {args} {error "MOCK_PREPROJECT_STOP R=$::R B=$::B O=$::O"}
set argc 2
set argv [list {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-prep-v7/test_actual_Tcl_reaches_only_m1/p} {/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python}]
source {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-prep-v7/test_actual_Tcl_reaches_only_m1/p/frozen_sources/simulate_bank_arithmetic_actual.tcl}

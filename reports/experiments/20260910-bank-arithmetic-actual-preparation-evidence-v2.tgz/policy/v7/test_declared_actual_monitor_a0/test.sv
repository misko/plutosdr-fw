module tb;
      parameter integer O=0;
      reg clk=0; always #5 clk=!clk;
      reg resetn=0, flush=0, input_valid=0; wire input_ready;
      reg signed [17:0] input_i=333, input_q=-21, kernel_i=713, kernel_q=529;
      reg [8:0] input_bin_index=0; reg [4:0] input_block_exponent=5;
      reg input_last=0; reg [63:0] input_block_start_index=64'h800000000001;
      wire output_valid,output_last,output_overflow,overflow_pulse;
      wire signed [17:0] output_i,output_q; wire [8:0] output_bin_index;
      wire [4:0] output_block_exponent; wire [63:0] output_block_start_index;
      wire output_ready=1;
      integer cycle=0, admitted=-1, accepted=0;
      starlink_pss_spectrum_product_operand_register #(.DATA_WIDTH(18),.REGISTER_OPERANDS(O),
        .BOUNDARY_ROUND_SAT(O),.PRIVATE_PAYLOAD_BUBBLES(1)) dut(.*);
      always @(posedge clk) begin
        cycle=cycle+1;
        if(resetn && input_valid && input_ready) admitted=cycle;
        if(resetn && output_valid && output_ready) begin
          if(admitted<0 || cycle-admitted != 3+O) $fatal(1,"DECLARED_BANK_EDGE_BOUND_MISMATCH");
          accepted=accepted+1;
        end
      end
      initial begin
        repeat(2) @(negedge clk); resetn=1; input_valid=1;
        @(negedge clk); input_valid=0;
        repeat(8) @(negedge clk);
        if(accepted!=1) $fatal(1,"DECLARED_BANK_EDGE_MISSING_TOKEN");
        $display("DECLARED_BANK_EDGE_PASS O=%0d accept_to_bank_clocks=%0d",O,3+O); $finish;
      end
    endmodule
    
proc version {args} {return 2022.2}
proc set_param {args} {}
proc create_project {name directory args} {file mkdir $directory}
proc current_project {args} {return mock_project}
proc set_property {args} {}
proc get_ips {args} {return {}}
proc create_ip {args} {}
proc add_files {args} {}
proc get_filesets {args} {return sim_1}
proc get_files {args} {return {}}
proc close_sim {args} {}
proc close_project {args} {}
proc generate_target {args} {file mkdir [file dirname $::wrapper]; file copy {/tmp/starlink-completed-input.5EaJuD/forward-retirement-actual-v1/project/fft_bank_owned_slice.gen/sources_1/ip/starlink_pss_fft512_bfp18_rt_candidate/synth/starlink_pss_fft512_bfp18_rt_candidate.vhd} $::wrapper}
proc launch_simulation {args} {}
rename exec real_exec
proc exec {args} {
  if {[lsearch -exact $args results] >= 0} {
    set redirect [lsearch -exact $args >]
    if {$redirect >= 0} {
      set c [open [lindex $args [expr {$redirect+1}]] w]
      puts $c MOCK_RESULT_POSTPROCESS_ONLY; close $c
    }
    return MOCK_RESULT_POSTPROCESS_ONLY
  }
  return [uplevel 1 [linsert $args 0 real_exec]]
}
proc close_project {args} {
  set c [open [file join $::source_dir starlink_pss_kernel_rom.v] a]
  puts $c { // MOCK after-success mutation}; close $c
}
set argc 2
set argv [list {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-prep-v7/test_early_success_JSON_public0/p} {/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python}]
source {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-prep-v7/test_early_success_JSON_public0/p/frozen_sources/simulate_bank_arithmetic_actual.tcl}

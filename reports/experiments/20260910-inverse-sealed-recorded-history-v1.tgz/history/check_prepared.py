"""Offline Tcl mocks / owner AST only. Never imports or executes the owner."""
import ast
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).parent
SCRIPT = ROOT / 'read_original77697_wdb.tcl'
OWNER = ROOT / 'own_readonly_wdb.py'
plan = json.loads((ROOT / 'history_plan.json').read_text())
tree = ast.parse(OWNER.read_text())
calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
         and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
         and node.func.value.id == 'subprocess' and node.func.attr == 'run']
assert len(calls) == 1 and not any(isinstance(node, ast.While) for node in ast.walk(tree))
assert len(plan['snapshots']) == 64 and sum(group['count'] for group in plan['groups'].values()) == 148
times = [entry['time_fs'] for entry in plan['snapshots']]
assert times == sorted(times) and len(set(times)) == 64
before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
          for path in [SCRIPT, OWNER, ROOT / 'history_plan.json', *(ROOT / 'inputs').iterdir()]}
root = ROOT / 'offline-mocks'
root.mkdir(exist_ok=False)
receipts = []
for case in ('complete', 'blank'):
    directory = root / case
    directory.mkdir()
    mock = directory / 'mock_ONLY.tcl'
    body = '''set argc 0
proc version {args} {return 2022.2}
proc set_param {args} {}
set opens 0
proc open_wave_database {path} {
  if {![string match */inputs/tb_starlink_pss_inverse_sealed_actual_behav.wdb $path]} {error WRONG_COPY_PATH}
  incr ::opens
}
proc run {args} {error FORBIDDEN_SIMULATION_ADVANCE}
proc launch_simulation {args} {error FORBIDDEN_SIMULATION_LAUNCH}
proc restart {args} {error FORBIDDEN_SIMULATION_RESTART}
'''
    body += 'proc get_value_database {args} {return ' + ('MOCK_ONLY' if case == 'complete' else '{<Blank>}') + '}\n'
    body += f'source {{{SCRIPT}}}\nif {{$opens != 1}} {{error WRONG_OPEN_COUNT}}\nputs MOCK_ONLY_NOT_RECORDED_HISTORY\n'
    mock.write_text(body)
    result = subprocess.run(['tclsh', str(mock)], cwd=directory, capture_output=True, text=True, check=False, timeout=30)
    (directory / 'mock.log').write_text(result.stdout + result.stderr)
    if case == 'complete':
        assert result.returncode == 0 and result.stdout.count('INVERSE_WDB_VALUE\t') == 9472
        assert result.stdout.count('INVERSE_WDB_HISTORY_EXTRACTED arithmetic=115 observer=14 ownership=19 times=64 values=9472') == 1
        assert 'MOCK_ONLY_NOT_RECORDED_HISTORY' in result.stdout
    else:
        assert result.returncode != 0 and 'UNRECORDED_INTERNAL_HISTORY' in result.stderr
        assert 'INVERSE_WDB_HISTORY_EXTRACTED' not in result.stdout
        assert result.stdout.count('READ_ONLY_AFTER\t') == 4
    receipts.append({'case': case, 'mock_exit': result.returncode})
assert before == {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in before}
assert not (ROOT / 'query-owned-v1').exists()
print(json.dumps({'vendor_calls_executed': 0, 'mock_cases': receipts, 'inputs_unchanged': True,
                  'planned_snapshots': 64, 'planned_paths': 148, 'planned_values': 9472}, indent=2))

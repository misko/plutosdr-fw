"""Prepared ONE saved-WDB loader call; requires separate source-specific approval."""
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HERE = ROOT / 'query-owned-v1'
ORIGINAL = ROOT.parent / 'inverse-actual-prepared-v2.g5UoQ9Ag'
ACTUAL = ORIGINAL / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2'
SIM = ACTUAL / 'project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim'
SCRIPT = ROOT / 'read_original77697_wdb.tcl'
PLAN = ROOT / 'history_plan.json'
WDB_NAME = 'tb_starlink_pss_inverse_sealed_actual_behav.wdb'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def original_paths():
    return sorted(path for path in ORIGINAL.rglob('*') if path.is_file() and not path.is_symlink())


paths_before = original_paths()
INPUTS = [SCRIPT, Path(__file__), PLAN, *paths_before, *sorted((ROOT / 'inputs').iterdir())]
assert all(path.is_file() and not path.is_symlink() for path in INPUTS)
before = {str(path): digest(path) for path in INPUTS}
assert digest(SCRIPT) == 'e4db9fd25f16322dbfa04a9c886d5f73bbda55b806bdc02949b2a166addaed17'
assert digest(PLAN) == '4aaeaa9d7a20a2a9da4f3721dea5189909467ee9c7726666f38f69cb1ae4a605'
assert digest(ACTUAL / 'manifest.json') == '39b1c731eb6f001983d5e842b1861d059c6f1f7a9ad986c26cde2a341ed74853'
assert digest(ACTUAL / 'results.json') == 'a597c7ed82f419454d86d2840066bc8277191a292b4fa777454ac52c7e042c18'
plan = json.loads(PLAN.read_text())
assert {name: digest(SIM / name) for name in plan['original_file_sha256']} == plan['original_file_sha256']
assert digest(ROOT / 'inputs' / WDB_NAME) == digest(SIM / WDB_NAME) == '96418352ac9d6b2b9849bcad5a6d0dd3829ede343b0625dccb5d5bb86592171c'
HERE.mkdir(exist_ok=False)
command = ['/opt/Xilinx/Vivado/2022.2/bin/vivado', '-mode', 'batch', '-source', str(SCRIPT),
           '-log', str(HERE / 'vivado.log'), '-journal', str(HERE / 'vivado.jou')]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (HERE / 'before.json').open('x') as stream:
    json.dump({'started_utc': started, 'command': command, 'input_sha256': before}, stream, indent=2)
environment = dict(os.environ)
environment['LD_LIBRARY_PATH'] = '/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
(HERE / 'tmp').mkdir(exist_ok=False)
environment['TMPDIR'] = str(HERE / 'tmp')
status = None
error = None
begin = time.monotonic()
try:
    with (HERE / 'outer.log').open('x') as stream:
        status = subprocess.run(command, cwd=HERE, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
finally:
    after_error = None
    try:
        after = {str(path): digest(path) for path in INPUTS}
        original_names_unchanged = paths_before == original_paths()
    except Exception as exc:
        after = None
        original_names_unchanged = False
        after_error = repr(exc)
    receipt = {'started_utc': started, 'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'elapsed_seconds': time.monotonic()-begin, 'original_process_exit': status,
               'launch_error': error, 'after_error': after_error, 'input_unchanged': before == after,
               'original_names_unchanged': original_names_unchanged,
               'after_sha256': after, 'scope': 'saved_WDB_identical_copy_readonly_NO_simulation_advance'}
    with (HERE / 'terminal.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(status if status not in (None, 0) else (1 if error or after_error or before != after or not original_names_unchanged else 0))

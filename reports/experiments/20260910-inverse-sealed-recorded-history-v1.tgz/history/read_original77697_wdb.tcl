# READ ONLY saved original77697 WDB. No simulation launch, run, restart or write.
if {[version -short] ne "2022.2" || $argc != 0} { error "requires Vivado2022.2 and no arguments" }
set_param general.maxThreads 2
set sim /home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-wdb-prepared-v1.0elVwpXY/inputs
set wave [file join $sim tb_starlink_pss_inverse_sealed_actual_behav.wdb]
set arithmetic [file join $sim arithmetic_diagnostic_signals.txt]
set observer [file join $sim local_guard_diagnostic_signals.txt]
set ownership [file join $sim inverse_protocol_diagnostic_signals.txt]
set before {}
foreach path [list $wave $arithmetic $observer $ownership] {
  dict set before $path [exec sha256sum $path]
  puts "READ_ONLY_BEFORE\t[dict get $before $path]"
}
if {[lindex [dict get $before $wave] 0] ne "96418352ac9d6b2b9849bcad5a6d0dd3829ede343b0625dccb5d5bb86592171c"} {
  error "wrong original WDB"
}
set paths_by_group {}
foreach {group path count} [list arithmetic $arithmetic 115 observer $observer 14 ownership $ownership 19] {
  set channel [open $path r]; set paths [split [string trimright [read $channel] \n] \n]; close $channel
  if {[llength $paths] != $count || [llength [lsort -unique $paths]] != $count} { error "wrong original path inventory" }
  dict set paths_by_group $group $paths
}
# Physical-time snapshots do not expose individual same-time Active/Inactive/NBA
# iterations. Keep those limits explicit; capture both sides and +1ps boundaries.
set times {0 1 1000 2857142 2857143 2858143 15842857934 15842857935 15842858935 23265715448 23265715449 23265716449 26185715594 26185715595 26185716595 26191429880 26191429881 26191430881 26197144166 26197144167 26197145167 26202858452 26202858453 26202859453 31380001568 31380001569 31380002569 31385715854 31385715855 31385716855 31391430140 31391430141 31391431141 41865716378 41865716379 41865717379 49288573892 49288573893 49288574893 52208574038 52208574039 52208575039 52214288324 52214288325 52214289325 52220002610 52220002611 52220003611 52225716896 52225716897 52225717897 57402860012 57402860013 57402861013 57408574298 57408574299 57408575299 57414288584 57414288585 57414289585 3373877311550 3373877311551 3373877312550 3373877312551}
set values 0
set status [catch {
  open_wave_database $wave
  foreach time $times {
    foreach group {arithmetic observer ownership} {
      set radix [expr {$group eq "observer" ? "bin" : "hex"}]
      foreach object [dict get $paths_by_group $group] {
        set value [get_value_database -radix $radix -time ${time}fs $object]
        if {$value eq "" || $value eq "<Blank>"} { error "UNRECORDED_INTERNAL_HISTORY $time $object" }
        puts "INVERSE_WDB_VALUE\t$group\t$time\t$radix\t$object\t$value"
        incr values
      }
    }
  }
} result options]
set after_status 0
foreach path [list $wave $arithmetic $observer $ownership] {
  set after [exec sha256sum $path]
  puts "READ_ONLY_AFTER\t$after"
  if {$after ne [dict get $before $path]} { set after_status 1 }
}
if {$status} { return -options $options $result }
if {$after_status} { error "READ_ONLY_SOURCE_HASH_CHANGED" }
if {$values != 9472} { error "incomplete recorded history extraction" }
puts "INVERSE_WDB_HISTORY_EXTRACTED arithmetic=115 observer=14 ownership=19 times=64 values=9472 no_advance=1 physical_time_only=1"

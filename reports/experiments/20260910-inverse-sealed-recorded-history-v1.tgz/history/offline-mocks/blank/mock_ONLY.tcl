set argc 0
proc version {args} {return 2022.2}
proc set_param {args} {}
set opens 0
proc open_wave_database {path} {
  if {![string match */inputs/tb_starlink_pss_inverse_sealed_actual_behav.wdb $path]} {error WRONG_COPY_PATH}
  incr ::opens
}
proc run {args} {error FORBIDDEN_SIMULATION_ADVANCE}
proc launch_simulation {args} {error FORBIDDEN_SIMULATION_LAUNCH}
proc restart {args} {error FORBIDDEN_SIMULATION_RESTART}
proc get_value_database {args} {return {<Blank>}}
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-wdb-prepared-v1.0elVwpXY/read_original77697_wdb.tcl}
if {$opens != 1} {error WRONG_OPEN_COUNT}
puts MOCK_ONLY_NOT_RECORDED_HISTORY

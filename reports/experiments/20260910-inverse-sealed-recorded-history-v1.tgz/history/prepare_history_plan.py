"""Offline bounded original77697 history plan; no vendor calls."""
import csv
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).parent
ACTUAL = HERE.parent / 'inverse-actual-prepared-v2.g5UoQ9Ag/inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2'
SIM = ACTUAL / 'project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim'
WDB = SIM / 'tb_starlink_pss_inverse_sealed_actual_behav.wdb'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


expected = {
    WDB.name: '96418352ac9d6b2b9849bcad5a6d0dd3829ede343b0625dccb5d5bb86592171c',
    'simulate.log': '3133e9cf8592be3c8b247df5f8c1302e3a8a6305a8d8e2cbb039eb9a3d8a9b2d',
    'fft_bank_owned_trace.csv': 'b824b9cffa9cd28c7572f5a906efe92e589fa2775d59fef88b5d345274f682b4',
    'bank_arithmetic_events.csv': '777d36224edd47910271b8ac6e1b74171a9ef72e7b3ae8fae615b6bd568bb16f',
    'inverse_sealed_protocol.csv': '7b96ace09355c6f11ba24e4a4717a4d561c9a00f3c5185ecbc7f5311f80fde87',
}
assert {name: sha(SIM / name) for name in expected} == expected
assert sha(ACTUAL / 'results.json') == 'a597c7ed82f419454d86d2840066bc8277191a292b4fa777454ac52c7e042c18'
snapshots = []


def add(label, time):
    snapshots.append({'label': label, 'time_fs': time})


for label, time in [('startup', 0), ('startup_1fs', 1), ('startup_1ps', 1000),
                    ('first_edge_before', 2857142), ('first_edge', 2857143), ('first_edge_plus1ps', 2858143)]:
    add(label, time)
with (SIM / 'inverse_sealed_protocol.csv').open() as stream:
    rows = list(csv.DictReader(stream))
for row in rows:
    if row['epoch'] != '1' or int(row['start']) not in (8590000128, 8590000575):
        continue
    if row['event'] == 'TAKE' and row['position'] != '0':
        continue
    if row['event'] not in ('ADMIT', 'TAKE', 'QUALIFY', 'CERT', 'SEAL', 'PUB', 'ACK', 'REL', 'REUSE'):
        continue
    # Independent literal clock formula from the frozen 1fs/175MHz recorder.
    edge = 2857143 + 5714286 * int(row['fast_cycle'])
    for suffix, offset in (('before', -1), ('edge', 0), ('plus1ps', 1000)):
        add(f"lease{row['lease']}_{row['event']}_{suffix}", edge + offset)
finish = 3373877312551
for label, time in [('final_edge_before', finish - 1001), ('final_edge', finish - 1000),
                    ('final_before_finish', finish - 1), ('original_finish', finish)]:
    add(label, time)
assert len(snapshots) == 64 and len({row['time_fs'] for row in snapshots}) == 64
groups = {}
for group, file, count, radix in (
    ('arithmetic', 'arithmetic_diagnostic_signals.txt', 115, 'hex'),
    ('observer', 'local_guard_diagnostic_signals.txt', 14, 'bin'),
    ('ownership', 'inverse_protocol_diagnostic_signals.txt', 19, 'hex'),
):
    paths = (SIM / file).read_text().splitlines()
    assert len(paths) == len(set(paths)) == count
    groups[group] = {'file': file, 'count': count, 'radix': radix, 'paths': paths, 'sha256': sha(SIM / file)}
roots = {path.split('/', 2)[1] for group in groups.values() for path in group['paths']}
assert roots == {r'\tb_starlink_pss_inverse_sealed_actual(FAST_MHZ=175,B=1,O=1,L=1,E=1) '}
inputs = HERE / 'inputs'
inputs.mkdir(exist_ok=False)
for file in (WDB.name, *(group['file'] for group in groups.values())):
    shutil.copyfile(SIM / file, inputs / file)
    assert sha(inputs / file) == sha(SIM / file)
plan = {'schema': 'inverse77697-recorded-history-preparation-v1', 'vendor_calls': 0,
    'original_actual': str(ACTUAL), 'original_file_sha256': expected,
    'copy_WDB_sha256': sha(inputs / WDB.name), 'groups': groups,
    'snapshots': snapshots, 'values_expected': 64 * 148,
    'time_scope': 'Physical timestamp histories only; no intra-timestamp region ordering inferred.',
    'comparison_scope': 'Full155-bit original/default/actual views; qualifier-aware119-bit arithmetic boundaries; all19ownership values.'}
with (HERE / 'history_plan.json').open('x') as stream:
    stream.write(json.dumps(plan, indent=2, sort_keys=True) + '\n')
print(json.dumps({'snapshots': 64, 'paths': 148, 'values_expected': 9472,
                  'plan_sha256': sha(HERE / 'history_plan.json'), 'vendor_calls': 0}, indent=2))

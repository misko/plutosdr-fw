"""Package bounded recorded histories; reference the already archived WDB once."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

HERE = Path(__file__).parent
SOURCE = HERE.parent / 'inverse-wdb-prepared-v1.0elVwpXY'
NAME = '20260910-inverse-sealed-recorded-history-v1'
ARCHIVE = HERE / (NAME + '.tgz')
RECEIPT = HERE / (NAME + '.json')
assert not ARCHIVE.exists() and not RECEIPT.exists()
WDB = SOURCE / 'inputs/tb_starlink_pss_inverse_sealed_actual_behav.wdb'
assert WDB.stat().st_size == 133627003
assert hashlib.sha256(WDB.read_bytes()).hexdigest() == '96418352ac9d6b2b9849bcad5a6d0dd3829ede343b0625dccb5d5bb86592171c'
files = {}
for path in SOURCE.rglob('*'):
    assert not path.is_symlink()
    if path.is_file() and path != WDB:
        files['history/' + path.relative_to(SOURCE).as_posix()] = path
files['owner/' + Path(__file__).name] = Path(__file__)
hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
external = {'excluded_identical_copy': str(WDB.relative_to(SOURCE)), 'bytes': WDB.stat().st_size,
    'sha256': hashlib.sha256(WDB.read_bytes()).hexdigest(),
    'archive': '20260910-inverse-sealed-actual-v2.tgz',
    'archive_sha256': '236cedcd7f2c7fb29fb3f17e4f3e974b375335e13b6849380d3b6b5dc96ce11e',
    'member': 'original/inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2/project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim/tb_starlink_pss_inverse_sealed_actual_behav.wdb'}
inventory = json.dumps({'files': hashes, 'external_already_archived_payload': external,
    'scope': 'One readonly loader35055 and offline interpretation; no simulation advance or physical qualification.'},
    indent=2, sort_keys=True).encode()
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, path in sorted(files.items()):
                data = path.read_bytes()
                assert hashlib.sha256(data).hexdigest() == hashes[name]
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o444
                tar.addfile(info, io.BytesIO(data))
            info = tarfile.TarInfo('inventory.json'); info.size = len(inventory); info.mode = 0o444
            tar.addfile(info, io.BytesIO(inventory))
assert hashes == {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
verified = {}
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    for item in tar:
        path = PurePosixPath(item.name)
        assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in verified
        verified[item.name] = hashlib.sha256(tar.extractfile(item).read()).hexdigest()
assert verified.pop('inventory.json') == hashlib.sha256(inventory).hexdigest() and verified == hashes
receipt = {'archive': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size,
    'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(), 'regular_members': len(hashes) + 1,
    'inventory_sha256': hashlib.sha256(inventory).hexdigest(), 'files': hashes,
    'external_already_archived_payload': external, 'all_member_hashes_verified': True, 'inputs_unchanged': True}
with RECEIPT.open('x') as stream:
    stream.write(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('files', 'external_already_archived_payload')}, indent=2))

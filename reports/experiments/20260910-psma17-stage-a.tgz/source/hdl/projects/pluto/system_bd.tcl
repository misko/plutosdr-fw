# create board design

# Independent admission also protects callers that source the BD directly.
source [file join [file dirname [info script]] starlink_pss_build_options.tcl]
set starlink_pss_options [pss_resolve_build_options [array get ::env]]
set starlink_pss_rate_msps [dict get $starlink_pss_options rate_msps]
set starlink_pss_profile [dict get $starlink_pss_options profile]
set starlink_pss_shared_xfft [dict get $starlink_pss_options shared_xfft]
set starlink_pss_realtime_xfft [dict get $starlink_pss_options realtime_xfft]
set starlink_pss_boundary_stop [dict get $starlink_pss_options boundary_stop]

# Add custom repo
set quantulum_ip_repo_path [file normalize [file join [file dirname [info script]] "../../../hdl-quantulum"]]
set ip_repo_list [get_property IP_REPO_PATHS [current_fileset]]
if {[lsearch $ip_repo_list $quantulum_ip_repo_path] == -1} {
	lappend ip_repo_list $quantulum_ip_repo_path
	set_property IP_REPO_PATHS $ip_repo_list [current_fileset]
	update_ip_catalog
	puts "Added IP Repo: $quantulum_ip_repo_path"
}

# default ports

# The result-only detector image dedicates the small Z-7010 fabric to the two
# PSS engines at the selected 15/30/60 MS/s geometry. Its expansion-header AXI
# SPI and IIC controllers are unrelated to the AD9361, which remains controlled
# through PS7 SPI0 below. Keep those optional peripherals in every normal image
# and omit them only from this explicitly selected, non-mainline profile.
set starlink_pss_detector_only [expr {
  [info exists ::env(STARLINK_PSS_PROFILE)] &&
  $::env(STARLINK_PSS_PROFILE) in {detector-only paired-pilot}
}]
set starlink_pilot_enabled [expr {
  [info exists ::env(STARLINK_PSS_PROFILE)] &&
  $::env(STARLINK_PSS_PROFILE) eq "paired-pilot"
}]

create_bd_intf_port -mode Master -vlnv xilinx.com:interface:ddrx_rtl:1.0 ddr
create_bd_intf_port -mode Master -vlnv xilinx.com:display_processing_system7:fixedio_rtl:1.0 fixed_io

create_bd_port -dir O spi0_csn_2_o
create_bd_port -dir O spi0_csn_1_o
create_bd_port -dir O spi0_csn_0_o
create_bd_port -dir I spi0_csn_i
create_bd_port -dir I spi0_clk_i
create_bd_port -dir O spi0_clk_o
create_bd_port -dir I spi0_sdo_i
create_bd_port -dir O spi0_sdo_o
create_bd_port -dir I spi0_sdi_i

create_bd_port -dir I -from 17 -to 0 gpio_i
create_bd_port -dir O -from 17 -to 0 gpio_o
create_bd_port -dir O -from 17 -to 0 gpio_t

if {!$starlink_pss_detector_only} {
  create_bd_port -dir O spi_csn_o
  create_bd_port -dir I spi_csn_i
  create_bd_port -dir I spi_clk_i
  create_bd_port -dir O spi_clk_o
  create_bd_port -dir I spi_sdo_i
  create_bd_port -dir O spi_sdo_o
  create_bd_port -dir I spi_sdi_i
}

# instance: sys_ps7

ad_ip_instance processing_system7 sys_ps7

# ps7 settings

ad_ip_parameter sys_ps7 CONFIG.PCW_PRESET_BANK0_VOLTAGE {LVCMOS 1.8V}
ad_ip_parameter sys_ps7 CONFIG.PCW_PRESET_BANK1_VOLTAGE {LVCMOS 1.8V}
ad_ip_parameter sys_ps7 CONFIG.PCW_PACKAGE_NAME clg225
ad_ip_parameter sys_ps7 CONFIG.PCW_USE_S_AXI_HP1 1
ad_ip_parameter sys_ps7 CONFIG.PCW_USE_S_AXI_HP2 0
ad_ip_parameter sys_ps7 CONFIG.PCW_EN_CLK1_PORT 1
ad_ip_parameter sys_ps7 CONFIG.PCW_EN_RST1_PORT 1
ad_ip_parameter sys_ps7 CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ 100.0
ad_ip_parameter sys_ps7 CONFIG.PCW_FPGA1_PERIPHERAL_FREQMHZ 200.0
ad_ip_parameter sys_ps7 CONFIG.PCW_GPIO_EMIO_GPIO_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_GPIO_EMIO_GPIO_IO 18
ad_ip_parameter sys_ps7 CONFIG.PCW_EN_ENET0 1
ad_ip_parameter sys_ps7 CONFIG.PCW_ENET0_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_ENET0_ENET0_IO {MIO 16 .. 27}
ad_ip_parameter sys_ps7 CONFIG.PCW_ENET0_GRP_MDIO_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_ENET0_GRP_MDIO_IO {MIO 52 .. 53}
ad_ip_parameter sys_ps7 CONFIG.PCW_SPI1_PERIPHERAL_ENABLE 0
ad_ip_parameter sys_ps7 CONFIG.PCW_I2C0_PERIPHERAL_ENABLE 0
ad_ip_parameter sys_ps7 CONFIG.PCW_UART1_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_UART1_UART1_IO {MIO 12 .. 13}
ad_ip_parameter sys_ps7 CONFIG.PCW_I2C1_PERIPHERAL_ENABLE 0
ad_ip_parameter sys_ps7 CONFIG.PCW_QSPI_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_QSPI_GRP_SINGLE_SS_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_SD0_IO "MIO 40 .. 45"
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_GRP_CD_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_GRP_CD_IO "MIO 47"
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_47_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_47_SLEW {slow}
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_GRP_POW_ENABLE    0
ad_ip_parameter sys_ps7 CONFIG.PCW_SD0_GRP_WP_ENABLE     0
ad_ip_parameter sys_ps7 CONFIG.PCW_SPI0_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_SPI0_SPI0_IO EMIO
ad_ip_parameter sys_ps7 CONFIG.PCW_TTC0_PERIPHERAL_ENABLE 0
ad_ip_parameter sys_ps7 CONFIG.PCW_USE_FABRIC_INTERRUPT 1
ad_ip_parameter sys_ps7 CONFIG.PCW_USB0_PERIPHERAL_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_GPIO_MIO_GPIO_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_GPIO_MIO_GPIO_IO MIO
ad_ip_parameter sys_ps7 CONFIG.PCW_USB0_RESET_IO {MIO 46}
ad_ip_parameter sys_ps7 CONFIG.PCW_USB0_RESET_ENABLE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_46_SLEW {slow}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_46_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_IRQ_F2P_INTR 1
ad_ip_parameter sys_ps7 CONFIG.PCW_IRQ_F2P_MODE REVERSE
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_0_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_9_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_10_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_11_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_48_PULLUP {enabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_49_PULLUP {disabled}
ad_ip_parameter sys_ps7 CONFIG.PCW_MIO_53_PULLUP {enabled}

# DDR MT41K256M16 HA-125 (32M, 16bit, 8banks)

ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_PARTNO {MT41K256M16 RE-125}
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_BUS_WIDTH {16 Bit}
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_USE_INTERNAL_VREF 0
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_TRAIN_WRITE_LEVEL 1
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_TRAIN_READ_GATE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_TRAIN_DATA_EYE 1
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_DQS_TO_CLK_DELAY_0 0.048
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_DQS_TO_CLK_DELAY_1 0.050
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_BOARD_DELAY0 0.241
ad_ip_parameter sys_ps7 CONFIG.PCW_UIPARAM_DDR_BOARD_DELAY1 0.240

ad_ip_instance xlconcat sys_concat_intc
ad_ip_parameter sys_concat_intc CONFIG.NUM_PORTS 16

ad_ip_instance proc_sys_reset sys_rstgen
ad_ip_parameter sys_rstgen CONFIG.C_EXT_RST_WIDTH 1

# system reset/clock definitions

# add external spi

if {!$starlink_pss_detector_only} {
  ad_ip_instance axi_quad_spi axi_spi
  ad_ip_parameter axi_spi CONFIG.C_USE_STARTUP 0
  ad_ip_parameter axi_spi CONFIG.C_NUM_SS_BITS 1
  ad_ip_parameter axi_spi CONFIG.C_SCK_RATIO 8
}

ad_connect  sys_cpu_clk sys_ps7/FCLK_CLK0
ad_connect  sys_200m_clk sys_ps7/FCLK_CLK1
ad_connect  sys_cpu_reset sys_rstgen/peripheral_reset
ad_connect  sys_cpu_resetn sys_rstgen/peripheral_aresetn
ad_connect  sys_cpu_clk sys_rstgen/slowest_sync_clk
ad_connect  sys_rstgen/ext_reset_in sys_ps7/FCLK_RESET0_N

# interface connections

ad_connect  ddr sys_ps7/DDR
ad_connect  gpio_i sys_ps7/GPIO_I
ad_connect  gpio_o sys_ps7/GPIO_O
ad_connect  gpio_t sys_ps7/GPIO_T
ad_connect  fixed_io sys_ps7/FIXED_IO

# ps7 spi connections

ad_connect  spi0_csn_2_o sys_ps7/SPI0_SS2_O
ad_connect  spi0_csn_1_o sys_ps7/SPI0_SS1_O
ad_connect  spi0_csn_0_o sys_ps7/SPI0_SS_O
ad_connect  spi0_csn_i sys_ps7/SPI0_SS_I
ad_connect  spi0_clk_i sys_ps7/SPI0_SCLK_I
ad_connect  spi0_clk_o sys_ps7/SPI0_SCLK_O
ad_connect  spi0_sdo_i sys_ps7/SPI0_MOSI_I
ad_connect  spi0_sdo_o sys_ps7/SPI0_MOSI_O
ad_connect  spi0_sdi_i sys_ps7/SPI0_MISO_I

# axi spi connections

if {!$starlink_pss_detector_only} {
  ad_connect  sys_cpu_clk  axi_spi/ext_spi_clk
  ad_connect  spi_csn_i  axi_spi/ss_i
  ad_connect  spi_csn_o  axi_spi/ss_o
  ad_connect  spi_clk_i  axi_spi/sck_i
  ad_connect  spi_clk_o  axi_spi/sck_o
  ad_connect  spi_sdo_i  axi_spi/io0_i
  ad_connect  spi_sdo_o  axi_spi/io0_o
  ad_connect  spi_sdi_i  axi_spi/io1_i
}

# interrupts

ad_connect  sys_concat_intc/dout sys_ps7/IRQ_F2P
ad_connect  sys_concat_intc/In15 GND
ad_connect  sys_concat_intc/In14 GND
ad_connect  sys_concat_intc/In13 GND
ad_connect  sys_concat_intc/In12 GND
ad_connect  sys_concat_intc/In11 GND
ad_connect  sys_concat_intc/In10 GND
ad_connect  sys_concat_intc/In9 GND
ad_connect  sys_concat_intc/In8 GND
ad_connect  sys_concat_intc/In7 GND
ad_connect  sys_concat_intc/In6 GND
ad_connect  sys_concat_intc/In5 GND
ad_connect  sys_concat_intc/In4 GND
ad_connect  sys_concat_intc/In3 GND
ad_connect  sys_concat_intc/In2 GND
ad_connect  sys_concat_intc/In1 GND
ad_connect  sys_concat_intc/In0 GND

# iic

if {!$starlink_pss_detector_only} {
  create_bd_intf_port -mode Master -vlnv xilinx.com:interface:iic_rtl:1.0 iic_main

  ad_ip_instance axi_iic axi_iic_main

  ad_connect  iic_main axi_iic_main/iic
  ad_cpu_interconnect 0x41600000 axi_iic_main
  ad_cpu_interrupt ps-15 mb-15 axi_iic_main/iic2intc_irpt
}

# ad9361

create_bd_port -dir I rx_clk_in
create_bd_port -dir I rx_frame_in
create_bd_port -dir I -from 11 -to 0 rx_data_in

create_bd_port -dir O enable
create_bd_port -dir O txnrx
create_bd_port -dir I up_enable
create_bd_port -dir I up_txnrx

# ad9361 core(s)

ad_ip_instance axi_ad9361 axi_ad9361
ad_ip_parameter axi_ad9361 CONFIG.ID 0
ad_ip_parameter axi_ad9361 CONFIG.CMOS_OR_LVDS_N 1
ad_ip_parameter axi_ad9361 CONFIG.MODE_1R1T 1
ad_ip_parameter axi_ad9361 CONFIG.TDD_DISABLE 1
ad_ip_parameter axi_ad9361 CONFIG.DAC_DATAPATH_DISABLE 1
ad_ip_parameter axi_ad9361 CONFIG.ADC_DCFILTER_DISABLE 1
ad_ip_parameter axi_ad9361 CONFIG.ADC_IQCORRECTION_DISABLE 1
ad_ip_parameter axi_ad9361 CONFIG.ADC_INIT_DELAY 21

set starlink_pss_tracker_enabled [expr {
  $starlink_pss_profile in {full detector-only paired-pilot}
}]
set starlink_pss_rx_dma_enabled [expr {
  $starlink_pss_profile ni {detector-only paired-pilot}
}]
puts "STARLINK_PSS_BUILD_PROFILE rate_msps=$starlink_pss_rate_msps profile=$starlink_pss_profile shared_xfft=$starlink_pss_shared_xfft realtime_xfft=$starlink_pss_realtime_xfft boundary_stop=$starlink_pss_boundary_stop"
set starlink_pss_minimum_lead_samples [expr {
  64 * $starlink_pss_rate_msps / 15
}]

if {$starlink_pss_rx_dma_enabled} {
  ad_ip_instance axi_dmac axi_ad9361_adc_dma
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.DMA_TYPE_SRC 2
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.DMA_TYPE_DEST 0
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.CYCLIC 0
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.AXI_SLICE_SRC 0
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.AXI_SLICE_DEST 0
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.DMA_2D_TRANSFER 0
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.DMA_DATA_WIDTH_SRC 64
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.SYNC_TRANSFER_START {true}
  # Metadata captures add one 64-bit timestamp to the requested IQ payload.
  # A 26-bit length field keeps the largest supported frame in one transfer.
  ad_ip_parameter axi_ad9361_adc_dma CONFIG.DMA_LENGTH_WIDTH 26
  ad_ip_instance util_cpack2 cpack
  ad_ip_instance util_cpack2_timestamp cpack_timestamp
}
if {$starlink_pilot_enabled} {
  # CI16 AXIS only AFTER 15->2.5 MS/s pilot filtering. No raw RX DDR path.
  ad_ip_instance axi_starlink_pilot_capture starlink_pilot_capture
  ad_ip_parameter starlink_pilot_capture CONFIG.INPUT_RATE_MSPS $starlink_pss_rate_msps
  ad_ip_instance axi_dmac starlink_pilot_dma
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_TYPE_SRC 1
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_TYPE_DEST 0
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_DATA_WIDTH_SRC 32
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_DATA_WIDTH_DEST 64
  ad_ip_parameter starlink_pilot_dma CONFIG.CYCLIC 0
  ad_ip_parameter starlink_pilot_dma CONFIG.AXI_SLICE_SRC 0
  ad_ip_parameter starlink_pilot_dma CONFIG.AXI_SLICE_DEST 0
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_2D_TRANSFER 0
  ad_ip_parameter starlink_pilot_dma CONFIG.SYNC_TRANSFER_START false
  ad_ip_parameter starlink_pilot_dma CONFIG.DMA_LENGTH_WIDTH 24
}
ad_ip_instance c_counter_binary counter_timestamp
ad_ip_parameter counter_timestamp CONFIG.Output_Width 64
ad_ip_parameter counter_timestamp CONFIG.CE true

ad_ip_instance axi_starlink_pss_acquisition starlink_pss_acquisition
ad_ip_parameter starlink_pss_acquisition CONFIG.SAMPLE_FIFO_ADDRESS_WIDTH 7
ad_ip_parameter starlink_pss_acquisition CONFIG.INPUT_RATE_MSPS $starlink_pss_rate_msps
ad_ip_parameter starlink_pss_acquisition CONFIG.ENABLE_PILOT_TAP $starlink_pilot_enabled
ad_ip_parameter starlink_pss_acquisition CONFIG.USE_SHARED_XFFT $starlink_pss_shared_xfft
ad_ip_parameter starlink_pss_acquisition CONFIG.USE_REALTIME_XFFT $starlink_pss_realtime_xfft
ad_ip_parameter starlink_pss_acquisition CONFIG.ENABLE_BOUNDARY_STOP $starlink_pss_boundary_stop
# Parameter intent alone is insufficient: fail if the packaged IP ignores it.
set starlink_pss_stop_readback [get_property CONFIG.ENABLE_BOUNDARY_STOP \
  [get_bd_cells starlink_pss_acquisition]]
if {$starlink_pss_stop_readback ne $starlink_pss_boundary_stop} {
  error "boundary-stop IP readback mismatch: requested=$starlink_pss_boundary_stop actual=$starlink_pss_stop_readback"
}
puts "STARLINK_PSS_BOUNDARY_STOP_IP_READBACK actual=$starlink_pss_stop_readback image_unqualified=1"
# FCLK1 already supplies the board's 200 MHz IDELAY reference. The island has
# local async-assert/sync-release reset synchronizers in both clock domains.
ad_connect sys_200m_clk starlink_pss_acquisition/fft_clk
ad_connect sys_cpu_resetn starlink_pss_acquisition/fft_resetn
if {$starlink_pilot_enabled} {
  ad_connect starlink_pilot_capture/pilot_enable starlink_pss_acquisition/pilot_enable
  foreach signal {valid gap flush i q index} {
    ad_connect starlink_pss_acquisition/canonical_$signal starlink_pilot_capture/canonical_$signal
  }
  ad_connect starlink_pilot_capture/m_axis starlink_pilot_dma/s_axis
  ad_connect sys_cpu_clk starlink_pilot_dma/s_axis_aclk
} else {
  ad_connect GND starlink_pss_acquisition/pilot_enable
}
if {$starlink_pss_tracker_enabled} {
  ad_ip_instance axi_starlink_pss_tracker starlink_pss_tracker
  ad_ip_parameter starlink_pss_tracker CONFIG.RATE_MSPS $starlink_pss_rate_msps
  ad_ip_parameter starlink_pss_tracker CONFIG.COMMAND_FIFO_ADDRESS_WIDTH 3
  ad_ip_parameter starlink_pss_tracker CONFIG.MINIMUM_LEAD_SAMPLES $starlink_pss_minimum_lead_samples
  ad_ip_parameter starlink_pss_tracker CONFIG.ENABLE_INJECTION 0
  # The shared paired image has spare DSPs but is slice-packing limited. Reuse
  # the existing exact DSP reducer here; other profiles retain their defaults.
  set starlink_pss_dsp_reducer [expr {
    $starlink_pss_shared_xfft || $starlink_pss_rate_msps == 60
  }]
  ad_ip_parameter starlink_pss_tracker CONFIG.USE_DSP_REDUCER $starlink_pss_dsp_reducer
  set starlink_pss_dsp_readback [get_property CONFIG.USE_DSP_REDUCER \
    [get_bd_cells starlink_pss_tracker]]
  if {$starlink_pss_dsp_readback ne $starlink_pss_dsp_reducer} {
    error "tracker reducer IP readback mismatch: requested=$starlink_pss_dsp_reducer actual=$starlink_pss_dsp_readback"
  }
  puts "STARLINK_PSS_TRACKER_DSP_IP_READBACK actual=$starlink_pss_dsp_readback image_unqualified=1"
  if {$starlink_pss_profile eq "full"} {
    ad_ip_instance util_vector_logic starlink_pss_stream_enable [list \
      C_OPERATION {and} \
      C_SIZE 1]
  }
} elseif {$starlink_pss_profile eq "acquisition-injection"} {
  ad_ip_instance axi_starlink_pss_periodic_injector starlink_pss_periodic_injector
}
if {$starlink_pss_rx_dma_enabled} {
  ad_ip_instance xlslice cpack_timestamp_every_slice
  ad_ip_parameter cpack_timestamp_every_slice CONFIG.DIN_WIDTH 32
  ad_ip_parameter cpack_timestamp_every_slice CONFIG.DIN_FROM 31
  ad_ip_parameter cpack_timestamp_every_slice CONFIG.DIN_TO 1
  ad_ip_instance xlconcat cpack_timestamp_every_concat
  ad_ip_parameter cpack_timestamp_every_concat CONFIG.NUM_PORTS 2
  ad_ip_parameter cpack_timestamp_every_concat CONFIG.IN0_WIDTH 31
  ad_ip_parameter cpack_timestamp_every_concat CONFIG.IN1_WIDTH 1
}

# connections

ad_connect  rx_clk_in axi_ad9361/rx_clk_in
ad_connect  rx_frame_in axi_ad9361/rx_frame_in
ad_connect  rx_data_in axi_ad9361/rx_data_in
ad_connect  enable axi_ad9361/enable
ad_connect  txnrx axi_ad9361/txnrx
ad_connect  up_enable axi_ad9361/up_enable
ad_connect  up_txnrx axi_ad9361/up_txnrx

ad_connect  axi_ad9361/tdd_sync GND
ad_connect  sys_200m_clk axi_ad9361/delay_clk
ad_connect  axi_ad9361/l_clk axi_ad9361/clk

ad_connect axi_ad9361/l_clk counter_timestamp/CLK
ad_connect axi_ad9361/adc_valid_i0 counter_timestamp/CE
if {$starlink_pss_rx_dma_enabled} {
  if {$starlink_pss_tracker_enabled} {
    ad_connect starlink_pss_tracker/selected_sample_timestamp cpack_timestamp/timestamp
  } elseif {$starlink_pss_profile eq "acquisition-injection"} {
    ad_connect starlink_pss_periodic_injector/selected_sample_timestamp cpack_timestamp/timestamp
  } else {
    ad_connect counter_timestamp/Q cpack_timestamp/timestamp
  }
  # cpack_timestamp synchronizes this counter word into sys_cpu_clk before it
  # reaches the ARM-visible ADC GPIO status register (0x800000B8).
  ad_connect cpack_timestamp/timestamp_cpu axi_ad9361/up_adc_gpio_in
} else {
  # Detector-only firmware intentionally has no Linux RX buffer.  Its PSMA
  # and PSST blocks expose coherent source counters through their own MMIO.
  ad_connect GND axi_ad9361/up_adc_gpio_in
}

# Host-scheduled exact TRACK_ONE pipeline. ABI 1.2 adds a fail-closed, future-
# indexed 130-sample deterministic injection mux before the shared tracker/DMA
# fan-out. Outside an explicitly armed window the selected outputs are a two-
# clock pipeline of the unchanged formatted RX0 stream. One result remains
# only the exact normalized winner within one scheduled 61-lag window; it is
# not autonomous search, SSS alignment, cadence qualification, or a Starlink
# claim.
if {$starlink_pss_tracker_enabled} {
  ad_connect axi_ad9361/l_clk starlink_pss_tracker/sample_clk
  ad_connect axi_ad9361/rst starlink_pss_tracker/sample_reset
  ad_connect axi_ad9361/adc_data_i0 starlink_pss_tracker/sample_i
  ad_connect axi_ad9361/adc_data_q0 starlink_pss_tracker/sample_q
  ad_connect axi_ad9361/adc_valid_i0 starlink_pss_tracker/sample_strobe
  if {$starlink_pss_profile eq "full"} {
    ad_connect axi_ad9361/adc_enable_i0 starlink_pss_stream_enable/Op1
    ad_connect axi_ad9361/adc_enable_q0 starlink_pss_stream_enable/Op2
    ad_connect starlink_pss_stream_enable/Res starlink_pss_tracker/sample_enable
  } else {
    # Detector-only operation never opens a Linux DMA buffer, so its tracker
    # must consume every valid RX0 sample independently of the scan mask.
    ad_connect VCC starlink_pss_tracker/sample_enable
  }
  ad_connect counter_timestamp/Q starlink_pss_tracker/sample_index
  ad_connect counter_timestamp/Q starlink_pss_tracker/sample_timestamp
} elseif {$starlink_pss_profile eq "acquisition-injection"} {
  ad_connect axi_ad9361/l_clk starlink_pss_periodic_injector/sample_clk
  ad_connect axi_ad9361/rst starlink_pss_periodic_injector/sample_reset
  ad_connect axi_ad9361/adc_data_i0 starlink_pss_periodic_injector/sample_i
  ad_connect axi_ad9361/adc_data_q0 starlink_pss_periodic_injector/sample_q
  ad_connect axi_ad9361/adc_valid_i0 starlink_pss_periodic_injector/sample_strobe
  ad_connect VCC starlink_pss_periodic_injector/sample_enable
  ad_connect counter_timestamp/Q starlink_pss_periodic_injector/sample_index
  ad_connect counter_timestamp/Q starlink_pss_periodic_injector/sample_timestamp
}

# Continuous acquisition observes the selected stream in full/injection
# profiles or direct RX0 in acquisition-only. It has no ready or backpressure
# output. The associated absolute index is transported with every accepted
# CI16 beat through its loss-detecting FIFO into sys_cpu_clk.
ad_connect axi_ad9361/l_clk starlink_pss_acquisition/sample_clk
ad_connect axi_ad9361/rst starlink_pss_acquisition/sample_reset
if {$starlink_pss_tracker_enabled} {
  ad_connect starlink_pss_tracker/selected_sample_strobe starlink_pss_acquisition/sample_strobe
} elseif {$starlink_pss_profile eq "acquisition-injection"} {
  ad_connect starlink_pss_periodic_injector/selected_sample_strobe starlink_pss_acquisition/sample_strobe
} else {
  ad_connect axi_ad9361/adc_valid_i0 starlink_pss_acquisition/sample_strobe
}
# Acquisition is armed by its own fail-closed MMIO control.  Do not gate the
# observed RX stream with the Linux/DMA scan mask: adc_enable_i0/q0 reset low
# and remain low when the host intentionally runs the PSS engine without an
# IIO buffer.
ad_connect VCC starlink_pss_acquisition/sample_enable
ad_connect GND starlink_pss_acquisition/sample_gap
if {$starlink_pss_tracker_enabled} {
  ad_connect starlink_pss_tracker/selected_sample_i starlink_pss_acquisition/sample_i
  ad_connect starlink_pss_tracker/selected_sample_q starlink_pss_acquisition/sample_q
  ad_connect starlink_pss_tracker/selected_sample_index starlink_pss_acquisition/sample_index
} elseif {$starlink_pss_profile eq "acquisition-injection"} {
  ad_connect starlink_pss_periodic_injector/selected_sample_i starlink_pss_acquisition/sample_i
  ad_connect starlink_pss_periodic_injector/selected_sample_q starlink_pss_acquisition/sample_q
  ad_connect starlink_pss_periodic_injector/selected_sample_index starlink_pss_acquisition/sample_index
} else {
  ad_connect axi_ad9361/adc_data_i0 starlink_pss_acquisition/sample_i
  ad_connect axi_ad9361/adc_data_q0 starlink_pss_acquisition/sample_q
  ad_connect counter_timestamp/Q starlink_pss_acquisition/sample_index
}

if {$starlink_pss_rx_dma_enabled} {
  ad_connect axi_ad9361/up_adc_gpio_out cpack_timestamp_every_slice/Din
  ad_connect cpack_timestamp_every_slice/Dout cpack_timestamp_every_concat/In0
  ad_connect GND cpack_timestamp_every_concat/In1
  ad_connect cpack_timestamp_every_concat/dout cpack_timestamp/timestamp_every

  ad_connect axi_ad9361/l_clk cpack/clk
  ad_connect axi_ad9361/rst cpack/reset
  ad_connect sys_cpu_clk cpack_timestamp/dma_clk
  ad_connect axi_ad9361/l_clk cpack_timestamp/adc_clk
  ad_connect axi_ad9361/rst cpack_timestamp/reset
  ad_connect axi_ad9361/adc_enable_i1 cpack/enable_2
  ad_connect axi_ad9361/adc_data_i1 cpack/fifo_wr_data_2
  ad_connect axi_ad9361/adc_enable_q1 cpack/enable_3
  ad_connect axi_ad9361/adc_data_q1 cpack/fifo_wr_data_3

  if {$starlink_pss_tracker_enabled} {
    ad_connect cpack/enable_0 starlink_pss_tracker/selected_sample_enable
    ad_connect cpack/enable_1 starlink_pss_tracker/selected_sample_enable
    ad_connect cpack/fifo_wr_data_0 starlink_pss_tracker/selected_sample_i
    ad_connect cpack/fifo_wr_data_1 starlink_pss_tracker/selected_sample_q
    ad_connect starlink_pss_tracker/selected_sample_strobe cpack/fifo_wr_en
  } elseif {$starlink_pss_profile eq "acquisition-injection"} {
    # Preserve Linux's independent I/Q scan mask for RX DMA. PSSI is enabled
    # continuously only on the acquisition branch; it must not force DMA.
    ad_connect axi_ad9361/adc_enable_i0 cpack/enable_0
    ad_connect axi_ad9361/adc_enable_q0 cpack/enable_1
    ad_connect cpack/fifo_wr_data_0 starlink_pss_periodic_injector/selected_sample_i
    ad_connect cpack/fifo_wr_data_1 starlink_pss_periodic_injector/selected_sample_q
    ad_connect starlink_pss_periodic_injector/selected_sample_strobe cpack/fifo_wr_en
  } else {
    ad_connect axi_ad9361/adc_enable_i0 cpack/enable_0
    ad_connect axi_ad9361/adc_enable_q0 cpack/enable_1
    ad_connect axi_ad9361/adc_data_i0 cpack/fifo_wr_data_0
    ad_connect axi_ad9361/adc_data_q0 cpack/fifo_wr_data_1
    ad_connect axi_ad9361/adc_valid_i0 cpack/fifo_wr_en
  }

  ad_connect cpack/packed_fifo_wr cpack_timestamp/packed_fifo_wr
  ad_connect cpack_timestamp/packed_timestamped_fifo_wr axi_ad9361_adc_dma/fifo_wr
}
# The transmit datapath is compiled out.  Tie every remaining DAC-facing input
# low so the disabled interface has deterministic, fail-safe values.
ad_connect GND axi_ad9361/dac_data_i0
ad_connect GND axi_ad9361/dac_data_q0
ad_connect GND axi_ad9361/dac_data_i1
ad_connect GND axi_ad9361/dac_data_q1
ad_connect GND axi_ad9361/dac_dunf
ad_connect GND axi_ad9361/up_dac_gpio_in

if {$starlink_pss_rx_dma_enabled} {
  ad_connect sys_cpu_clk axi_ad9361_adc_dma/fifo_wr_clk
  ad_connect cpack/fifo_wr_overflow axi_ad9361/adc_dovf
} else {
  ad_connect GND axi_ad9361/adc_dovf
}

# interconnects

ad_cpu_interconnect 0x79020000 axi_ad9361
if {$starlink_pss_tracker_enabled} {
  ad_cpu_interconnect 0x79030000 starlink_pss_tracker
} elseif {$starlink_pss_profile eq "acquisition-injection"} {
  ad_cpu_interconnect 0x79030000 starlink_pss_periodic_injector
}
ad_cpu_interconnect 0x79040000 starlink_pss_acquisition
if {$starlink_pss_rx_dma_enabled} {
  ad_cpu_interconnect 0x7C400000 axi_ad9361_adc_dma
}
if {$starlink_pilot_enabled} {
  ad_cpu_interconnect 0x79050000 starlink_pilot_capture
  ad_cpu_interconnect 0x7C400000 starlink_pilot_dma
}
if {!$starlink_pss_detector_only} {
  ad_cpu_interconnect 0x7C430000 axi_spi
}

ad_ip_parameter sys_ps7 CONFIG.PCW_USE_S_AXI_HP1 {1}
ad_connect sys_cpu_clk sys_ps7/S_AXI_HP1_ACLK
if {$starlink_pss_rx_dma_enabled} {
  ad_connect axi_ad9361_adc_dma/m_dest_axi sys_ps7/S_AXI_HP1
  create_bd_addr_seg -range 0x20000000 -offset 0x00000000 \
                      [get_bd_addr_spaces axi_ad9361_adc_dma/m_dest_axi] \
                      [get_bd_addr_segs sys_ps7/S_AXI_HP1/HP1_DDR_LOWOCM] \
                      SEG_sys_ps7_HP1_DDR_LOWOCM
  ad_connect sys_cpu_clk axi_ad9361_adc_dma/m_dest_axi_aclk
  ad_connect sys_cpu_resetn axi_ad9361_adc_dma/m_dest_axi_aresetn
}
if {$starlink_pilot_enabled} {
  ad_connect starlink_pilot_dma/m_dest_axi sys_ps7/S_AXI_HP1
  create_bd_addr_seg -range 0x20000000 -offset 0x00000000 \
    [get_bd_addr_spaces starlink_pilot_dma/m_dest_axi] \
    [get_bd_addr_segs sys_ps7/S_AXI_HP1/HP1_DDR_LOWOCM] SEG_pilot_HP1_DDR_LOWOCM
  ad_connect sys_cpu_clk starlink_pilot_dma/m_dest_axi_aclk
  ad_connect sys_cpu_resetn starlink_pilot_dma/m_dest_axi_aresetn
}

# interrupts

if {$starlink_pss_rx_dma_enabled} {
  ad_cpu_interrupt ps-13 mb-13 axi_ad9361_adc_dma/irq
}
if {$starlink_pilot_enabled} {
  ad_cpu_interrupt ps-13 mb-13 starlink_pilot_dma/irq
  ad_cpu_interrupt ps-11 mb-11 starlink_pilot_capture/irq
}
if {$starlink_pss_tracker_enabled} {
  ad_cpu_interrupt ps-12 mb-12 starlink_pss_tracker/irq
}
if {!$starlink_pss_detector_only} {
  ad_cpu_interrupt ps-11 mb-11 axi_spi/ip2intc_irpt
}
ad_cpu_interrupt ps-10 mb-10 starlink_pss_acquisition/irq

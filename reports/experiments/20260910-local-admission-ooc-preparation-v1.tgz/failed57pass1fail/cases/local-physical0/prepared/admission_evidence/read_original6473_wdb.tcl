# READ ONLY saved original6473 WDB. No simulation launch, run, restart or write.
if {[version -short] ne "2022.2" || $argc != 0} { error "requires Vivado2022.2 and no arguments" }
set_param general.maxThreads 2
set sim /tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/local-admission-actual-R1B1O1-L1-175-prepared-v4/project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim
set wave [file join $sim tb_starlink_pss_local_admission_actual_behav.wdb]
set arithmetic [file join $sim arithmetic_diagnostic_signals.txt]
set observer [file join $sim local_guard_diagnostic_signals.txt]
set before {}
foreach path [list $wave $arithmetic $observer] {
  dict set before $path [exec sha256sum $path]
  puts "READ_ONLY_BEFORE\t[dict get $before $path]"
}
if {[lindex [dict get $before $wave] 0] ne "52f4ccf572df859e21cdb6e92a82c3b22459b551874acf241f0ea8acd7539a31"} {
  error "wrong original WDB"
}
set paths_by_group {}
foreach {group path count} [list arithmetic $arithmetic 115 observer $observer 14] {
  set channel [open $path r]; set paths [split [string trimright [read $channel] \n] \n]; close $channel
  if {[llength $paths] != $count || [llength [lsort -unique $paths]] != $count} { error "wrong original path inventory" }
  dict set paths_by_group $group $paths
}
# Physical-time snapshots do not expose individual same-time Active/Inactive/NBA
# iterations. Keep those limits explicit; capture both sides and +1ps boundaries.
set times {0 1 999 1000 1001 2857142 2857143 2858142 2858143 2858144 100000000000 1261765777375 3000000000000 3371803025732 3371803025733 3371803026732 3371803026733}
set values 0
set status [catch {
  open_wave_database $wave
  foreach time $times {
    foreach group {arithmetic observer} {
      set radix [expr {$group eq "observer" ? "bin" : "hex"}]
      foreach object [dict get $paths_by_group $group] {
        set value [get_value_database -radix $radix -time ${time}fs $object]
        if {$value eq "" || $value eq "<Blank>"} { error "UNRECORDED_INTERNAL_HISTORY $time $object" }
        puts "LOCAL_WDB_VALUE\t$group\t$time\t$radix\t$object\t$value"
        incr values
      }
    }
  }
} result options]
set after_status 0
foreach path [list $wave $arithmetic $observer] {
  set after [exec sha256sum $path]
  puts "READ_ONLY_AFTER\t$after"
  if {$after ne [dict get $before $path]} { set after_status 1 }
}
if {$status} { return -options $options $result }
if {$after_status} { error "READ_ONLY_SOURCE_HASH_CHANGED" }
if {$values != 2193} { error "incomplete recorded history extraction" }
puts "LOCAL_WDB_HISTORY_EXTRACTED arithmetic=115 observer=14 times=17 values=2193 no_advance=1 physical_time_only=1"

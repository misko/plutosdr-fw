"""Exactly one saved-WDB loader call; preserve failure and hashes, never retry."""
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ACTUAL = HERE.parent / "local-admission-actual-R1B1O1-L1-175-prepared-v4"
SIM = ACTUAL / "project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim"
SCRIPT = HERE / "read_original6473_wdb.tcl"
INPUTS = [SCRIPT, Path(__file__), *(ACTUAL / name for name in (
    "manifest.json", "results.json", "run_outcome.txt", "generated_ip_before.txt", "generated_ip_after.txt")),
    *(SIM / name for name in ("tb_starlink_pss_local_admission_actual_behav.wdb",
      "arithmetic_diagnostic_signals.txt", "local_guard_diagnostic_signals.txt", "simulate.log"))]


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


before = {str(path): digest(path) for path in INPUTS}
assert before[str(SIM / "tb_starlink_pss_local_admission_actual_behav.wdb")] == "52f4ccf572df859e21cdb6e92a82c3b22459b551874acf241f0ea8acd7539a31"
assert not (HERE / "terminal.json").exists() and not (HERE / "before.json").exists()
command = ["/opt/Xilinx/Vivado/2022.2/bin/vivado", "-mode", "batch", "-source", str(SCRIPT),
           "-log", str(HERE / "vivado.log"), "-journal", str(HERE / "vivado.jou")]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (HERE / "before.json").open("x") as stream:
    json.dump({"started_utc": started, "command": command, "input_sha256": before}, stream, indent=2)
environment = dict(os.environ)
environment["LD_LIBRARY_PATH"] = "/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE"
status = None
error = None
begin = time.monotonic()
try:
    with (HERE / "outer.log").open("x") as stream:
        status = subprocess.run(command, cwd=HERE, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
finally:
    after_error = None
    try:
        after = {str(path): digest(path) for path in INPUTS}
    except Exception as exc:
        after = None
        after_error = repr(exc)
    receipt = {"started_utc": started, "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "elapsed_seconds": time.monotonic()-begin, "original_process_exit": status,
               "launch_error": error, "after_error": after_error, "input_unchanged": before == after,
               "after_sha256": after, "scope": "saved_WDB_readonly_NO_simulation_advance"}
    with (HERE / "terminal.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(status if status not in (None, 0) else (1 if error or after_error or before != after else 0))

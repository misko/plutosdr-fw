"""Fixed source and deliberate lost-capacity-check mutant, preserving both runs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path(__file__).resolve().parent
source=root/'original'
pins={
 'starlink_pss_product_sealed_publication_interface.v':'03c37b96aa77562c9f544b0ff4604e944a7b986677703fc546543caa42718f1f',
 'starlink_pss_epoch_sealed_publication_bank.v':'76d6985aa2148776ee1e834307066575d269878dc2c32cffd2bdbb87f2c5a490',
 'starlink_pss_checked_product_read_interface.v':'b29a700232c9ee0d62dc4cbade48e266bcf6bce4665eff670f9232584194ec3e',
 'starlink_pss_block_mailbox.v':'e85122eb6689ff49b31aa5a0c200e2666786629055b4f45856fe79fb829dbb55'}
for name,pin in pins.items():
    assert hashlib.sha256((source/name).read_bytes()).hexdigest()==pin,name
env={k:v for k,v in os.environ.items() if k not in
     {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
rows=[]
for label in ('fixed','lost_capacity_mutant'):
    directory=root/label
    directory.mkdir()
    for name in pins:
        shutil.copyfile(source/name,directory/name)
    if label!='fixed':
        target=directory/'starlink_pss_product_sealed_publication_interface.v'
        text=target.read_text()
        old='producer_reference && !final_taken && sampled_ready && product_ready'
        assert text.count(old)==1
        target.write_text(text.replace(old,'producer_reference && !final_taken && sampled_ready'))
    command=['iverilog','-g2012','-s','tb','-o',str(directory/'sim.vvp'),str(root/'tb.sv')]
    command += [str(directory/name) for name in pins]
    compile_result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=30)
    (directory/'compile.log').write_text(compile_result.stdout+compile_result.stderr)
    assert compile_result.returncode==0,compile_result.stderr
    result=subprocess.run(['vvp',str(directory/'sim.vvp')],env=env,capture_output=True,text=True,timeout=30)
    log=result.stdout+result.stderr
    (directory/'simulation.log').write_text(log)
    row={'label':label,'compile_command':command,'compile_exit':0,'simulation_exit':result.returncode,
         'log_sha256':hashlib.sha256(log.encode()).hexdigest()}
    (directory/'result.json').write_text(json.dumps(row,indent=2))
    if label=='fixed':
        assert result.returncode==0 and 'PARENT_SAMPLED_READY_CAPACITY_PASS' in log,log
    else:
        assert result.returncode!=0 and 'PARENT_PRIVATE_WRITE_WITHOUT_ADVERTISED_CAPACITY' in log,log
    rows.append(row)
for name,pin in pins.items():
    assert hashlib.sha256((source/name).read_bytes()).hexdigest()==pin,name
with (root/'result.json').open('x') as output:
    json.dump({'scope':'standalone invalid caller; deliberately mutated omission is not original historical run',
               'source_pins':pins,'rows':rows},output,indent=2)
print('PASS fixed sampled-READY/capacity boundary; lost-capacity-check mutant rejected at private write')

// Independent standalone invalid-caller probe; no force or actual-P1 claim.
`timescale 1ns/1ps
module tb;
  reg clk=0,resetn=0;always #5 clk=~clk;
  reg forward_job_accept=0,product_valid=0;
  wire product_ready,reusable,product_take,fault;
  wire [7:0] issuer_reasons,issuer_fault_events_now;
  wire [15:0] bank_reasons;
  starlink_pss_product_sealed_publication_interface #(
    .SEALED_PRODUCT_ADAPTER(1),.SEPARATE_PRODUCT_SEAMS(1)) dut(
    .clk(clk),.resetn(resetn),.peer_resetn(resetn),.engine_reset_held(1'b1),
    .peer_epoch_idle(1'b1),.forward_guard_busy(1'b0),.forward_phase(1'b1),
    .forward_job_accept(forward_job_accept),.forward_descriptor({1'b0,64'd1000,5'b0}),
    .forward_completion(1'b0),.forward_exponent(5'b0),.product_valid(product_valid),
    .product_ready(product_ready),.sampled_product_ready(1'b1),.publication_faults(8'b0),
    .product_data(36'h123456789),.product_position(9'd0),.product_last(1'b0),
    .product_metadata({1'b1,64'd1000,5'b0}),.forward_handoff_ready(1'b0),
    .inverse_job_start(1'b0),.inverse_input_enable(1'b0),.core_ready(1'b0),
    .consumer_complete(1'b0),.current_faults(8'b0),.reusable(reusable),
    .product_take(product_take),.bank_reasons(bank_reasons),.issuer_reasons(issuer_reasons),
    .issuer_fault_events_now(issuer_fault_events_now),.fault(fault));
  task step;begin @(posedge clk);#0.001;@(negedge clk);end endtask
  integer waited=0;
  initial begin
    repeat(2)step;resetn=1;
    while(reusable!==1)begin step;waited=waited+1;if(waited>30)$fatal(1,"SETUP rearm");end
    forward_job_accept=1;step;forward_job_accept=0;
    if(dut.producer_owned!==1||product_ready!==1||fault!==0)$fatal(1,"SETUP real admission");
    // Deliberately invalid qualified second admission, without hierarchy writes.
    // Issuer reason Q arrives one edge before its bank summary reason Q.
    forward_job_accept=1;step;forward_job_accept=0;
    if(issuer_reasons!==8'h01||bank_reasons!==0||dut.bank_input_ready!==1||product_ready!==0)
      $fatal(1,"SETUP missing mixed-reason C0/inner-ready1 interval");
    product_valid=1;#0.001;
    $display("PARENT_SAMPLED_READY A=1 C=%b inner_ready=%b take=%b reasonQ=%h bankQ=%h current=%h",
      product_ready,dut.bank_input_ready,product_take,issuer_reasons,bank_reasons,issuer_fault_events_now);
    if(issuer_fault_events_now[7]!==1)$fatal(1,"MISSING current sampled-READY diagnostic");
    if(product_take!==0)$fatal(1,"PARENT_PRIVATE_WRITE_WITHOUT_ADVERTISED_CAPACITY");
    step;
    if(issuer_reasons!==8'h81||bank_reasons[15]!==1)$fatal(1,"MISSING retained reason");
    $display("PARENT_SAMPLED_READY_CAPACITY_PASS");$finish;
  end
  initial begin #10000;$fatal(1,"bounded parent deadline");end
endmodule

`timescale 1ns/1ps
module tb;
reg [69:0] input_metadata,reference_metadata,retiring_metadata;
reg reference_select;
integer n,b,k,checks=0,seed=32'h45fea174;
function automatic four(input integer n);
case(n%4)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
  (* keep = "true" *) wire match_held = input_metadata == reference_metadata;
  (* keep = "true" *) wire match_retiring = input_metadata == reference_metadata;
  wire identity_good = (reference_select ? match_retiring : match_held) === 1'b1;

task automatic check;
begin
 #1;
 if(identity_good !== ((input_metadata == (reference_select ? retiring_metadata : reference_metadata)) === 1'b1))
   $fatal(1,"parallel reference differs at %0d",checks);
 checks=checks+1;
end
endtask
initial begin
 // Exhaust all two-bit metadata triples and all four-state selectors.
 for(n=0;n<16384;n=n+1)begin
  input_metadata=0;reference_metadata=0;retiring_metadata=0;
  input_metadata[0]=four(n);input_metadata[1]=four(n/4);
  reference_metadata[0]=four(n/16);reference_metadata[1]=four(n/64);
  retiring_metadata[0]=four(n/256);retiring_metadata[1]=four(n/1024);
  reference_select=four(n/4096);check;
 end
 // Exercise every physical bit, equality and X/Z metadata at each selector.
 for(b=0;b<70;b=b+1)for(k=0;k<4;k=k+1)for(n=0;n<4;n=n+1)begin
  input_metadata=0;reference_metadata=0;retiring_metadata=0;reference_select=four(k);
  retiring_metadata[b]=four(n);check;
  reference_metadata[b]=four(n);check;
  input_metadata[b]=four(n);check;
 end
 for(n=0;n<20000;n=n+1)begin
  input_metadata={$random(seed),$random(seed),$random(seed)};
  reference_metadata={$random(seed),$random(seed),$random(seed)};
  retiring_metadata={$random(seed),$random(seed),$random(seed)};reference_select=four(n);
  if(n%3==0)reference_metadata=input_metadata;
  if(n%3==1)retiring_metadata=input_metadata;
  if(n%7==0)begin reference_metadata=input_metadata;retiring_metadata=input_metadata;end
  if(n%8==0)retiring_metadata[n%70]=1'bx;
  if(n%8==1)reference_metadata[n%70]=1'bz;
  if(n%8==2)input_metadata[n%70]=1'bx;
  check;
 end
 $display("PARALLEL_REFERENCE_ALGEBRA_PASS checks=%0d",checks);$finish;
end
endmodule

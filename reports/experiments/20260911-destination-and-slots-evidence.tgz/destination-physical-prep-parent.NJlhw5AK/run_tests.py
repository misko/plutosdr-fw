"""Root source snapshots and bounded physical-policy tests; no vendor call."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent/'destination-actual-worktree-v1'
names = ['tools/prepare_starlink_retained_destination_synthesis.py', 'tools/derive_starlink_destination_physical.py',
         'tests/test_starlink_retained_destination_synthesis.py', 'tests/test_starlink_destination_physical_additive.py']
names += [str(p.relative_to(ROOT)) for p in sorted((ROOT/'tools/retained_destination_synthesis').rglob('*')) if p.is_file()]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before = {n:sha(ROOT/n) for n in names}
for n in names:
    dest = OUT/'source_snapshot'/n
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT/n, dest)
with (OUT/'before.json').open('x') as handle: json.dump(before, handle, indent=2)
(OUT/'tmp').mkdir()
env = {k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
env.update(TMPDIR=str(OUT/'tmp'), PYTHONDONTWRITEBYTECODE='1')
cmd = ['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python', '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
       'tests/test_starlink_retained_destination_synthesis.py', 'tests/test_starlink_destination_physical_additive.py',
       '--basetemp='+str(OUT/'pytest'), '--junitxml='+str(OUT/'results.xml')]
with (OUT/'pytest.log').open('x') as handle:
    run = subprocess.run(cmd, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT, timeout=180)
after = {n:sha(ROOT/n) for n in names}
with (OUT/'after.json').open('x') as handle: json.dump(after, handle, indent=2)
tree = ET.parse(OUT/'results.xml')
counts = {key:sum(int(n.attrib.get(key,0)) for n in tree.iter('testsuite')) for key in ('tests','failures','errors','skipped')}
receipt = dict(exit=run.returncode, counts=counts, source_count=len(names), unchanged=before==after)
with (OUT/'result.json').open('x') as handle: json.dump(receipt, handle, indent=2)
print((OUT/'pytest.log').read_text())
print(json.dumps(receipt))
assert run.returncode == 0 and before == after and counts['failures']==counts['errors']==counts['skipped']==0

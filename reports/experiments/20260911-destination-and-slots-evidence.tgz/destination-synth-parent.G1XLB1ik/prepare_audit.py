"""Derive independent report cross-checks without changing acceptance criteria."""
import hashlib
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parent
old=root.parent/'retained-summary-synth-parent.39BysdkS/audit.py'
original=old.read_text()
edits=[
 ('starlink_pss_fft_bank_owned_retained_output_probe','starlink_pss_fft_bank_owned_retained_destination_probe'),
 ("('/retained_output/' in p or '/retained_output_summary_candidate/' in p) and '/tb/' not in p", "('/retained_output/' in p or '/retained_output_summary_candidate/' in p or '/retained_destination_candidate/' in p) and not p.endswith('/retained_output/starlink_pss_retained_output_owner.v') and '/tb/' not in p"),
 ("sum('/retained_output_summary_candidate/' in p for p in runtime)==4", "sum('/retained_output_summary_candidate/' in p for p in runtime)==2 and sum('/retained_destination_candidate/' in p for p in runtime)==3"),
 ("'CLOSED_INPUT_CUTOVER','INPUT_OFFER_FAULT_SUMMARY')", "'CLOSED_INPUT_CUTOVER','INPUT_OFFER_FAULT_SUMMARY','CONTEXTUAL_DESTINATION_SUMMARY')"),
 ("/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic", str(root.parent/'destination-actual-worktree-v1')),
 ('delta_from_prior_retained_synthesis', 'delta_from_offered_summary_synthesis'),
 ("top['lut']-2242", "top['lut']-2248"),
]
text=original;counts=[]
for before,after in edits:
    assert before in text and after not in text
    counts.append(text.count(before));text=text.replace(before,after)
inverse=text
for (before,after),count in reversed(list(zip(edits,counts))):
    assert inverse.count(after)==count
    inverse=inverse.replace(after,before)
assert inverse==original
with (root/'audit.py').open('x') as handle: handle.write(text)
assert not (root/'preparation-source-pins.json').exists()
shutil.copyfile(root.parent/'destination-physical-prep-parent.NJlhw5AK/before.json',root/'preparation-source-pins.json')
with (root/'audit-derivation.json').open('x') as handle:
    json.dump(dict(original_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),whole_inverse=True,edits=edits,counts=counts),handle,indent=2)
print('Prepared complete original audit plus seven source-specific mapping groups.')

"""Independent mapped source/resource/constraint audit; not physical signoff."""
import collections
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
build=root/'synthesis'
receipt=json.loads((root/'execution.json').read_text())
assert receipt['vendor_exit']==0 and not receipt['timed_out'] and not receipt['changed_prepared_files']
assert receipt['qualified_source_check_exit']==receipt['copied_source_check_exit']==0
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
dcp=build/'retained_output_synth.dcp'
assert sha(dcp)==receipt['dcp_sha256']
assert (build/'dcp_receipt.txt').read_text().strip()=='retained_output_synth.dcp.sha256='+sha(dcp)
assert (build/'generated_ip_before.txt').read_bytes()==(build/'generated_ip_after.txt').read_bytes()
assert (build/'generated_ip_before.txt').read_text().split()[0]=='a3a650654118016012bdfb8553114ee4a89866466d8ca774fa0f281640168a68'
resources=dict(line.split('=',1) for line in (build/'resource_and_paths.txt').read_text().splitlines())
assert {k:resources[k] for k in ('black_boxes','dsp48e1','ramb18e1','ramb36e1')}==dict(black_boxes='0',dsp48e1='21',ramb18e1='15',ramb36e1='0')
hierarchy={}
for line in (build/'hierarchy.rpt').read_text().splitlines():
    columns=[v.strip() for v in line.split('|')[1:-1]]
    if len(columns)==10 and columns[2].isdigit():
        hierarchy[columns[0]]=dict(module=columns[1],lut=int(columns[2]),ff=int(columns[6]),ram36=int(columns[7]),ram18=int(columns[8]),dsp=int(columns[9]))
top=hierarchy['starlink_pss_fft_bank_owned_retained_destination_probe']
util=(build/'utilization.rpt').read_text()
for field,label in [('lut','Slice LUTs*'),('ff','Slice Registers'),('ram18','RAMB18'),('dsp','DSPs')]:
    matches=re.findall(r'^\|\s*'+re.escape(label)+r'\s*\|\s*(\d+)\s*\|',util,re.M)
    assert len(matches)==1 and int(matches[0])==top[field],(field,matches,top)
assert top['ram36']==0 and top['ram18']==15 and top['dsp']==21
assert len([n for n in hierarchy if n=='shared_xfft'])==1
assert hierarchy['shared_xfft']['dsp']==17 and hierarchy['shared_xfft']['ram18']==11
assert hierarchy['product']['dsp']==4
for name in ('source_bank','product_bank','output_bank','joiner'):
    assert hierarchy[name]['ram18']==1 and hierarchy[name]['ram36']==0
assert all('unchanged' not in name for name in hierarchy)
assert all(n in hierarchy for n in ('owners[0].result_guard','owners[1].result_guard','epoch_barrier','retained_owner','cutover'))
manifest=json.loads((build/'inputs/manifest.json').read_text())
runtime=[p for p in manifest['compiled'] if ('/retained_output/' in p or '/retained_output_summary_candidate/' in p or '/retained_destination_candidate/' in p) and not p.endswith('/retained_output/starlink_pss_retained_output_owner.v') and '/tb/' not in p and p.endswith('.v')]
assert len(runtime)==16 and sum('/retained_output_summary_candidate/' in p for p in runtime)==2 and sum('/retained_destination_candidate/' in p for p in runtime)==3
for name in runtime:assert sha(build/'inputs'/name)==manifest['files'][name]['sha256']
profile=(build/'effective_profile.txt').read_text()
for param in ('ENABLE_RETAINED_OUTPUT','REGISTERED_SCHEDULING','BOUNDARY_ROUND_SAT','REGISTER_OPERANDS','LOCAL_FIRST_ADMISSION','PRIVATE_DESCRIPTOR_OFFER','CLOSED_INPUT_CUTOVER','INPUT_OFFER_FAULT_SUMMARY','CONTEXTUAL_DESTINATION_SUMMARY'):
    assert profile.count(param+'=1')==1
assert sha(build/'clocks.xdc')=='bac30eff84cc71d1f273104b716b388b55e51d33be10f9beaf1901232193ba3f'
xdc=(build/'inherited_constraints.xdc').read_text()
commands=[line.strip() for line in xdc.splitlines() if line.strip() and not line.lstrip().startswith('#')]
assert commands==['create_clock -period 10.000 -name source_100 [get_ports clk]',
                 'create_clock -period 5.714 -name island_175 [get_ports fft_clk]','current_instance -quiet'],commands
assert 'No valid timing exceptions found.' in (build/'exceptions.rpt').read_text()
xdc_receipts=[]
for group in (build/'constraint_inputs.txt').read_text().split('path=')[1:]:
    lines=group.splitlines();path=Path(lines[0]);digest=lines[1].split('=',1)[1]
    assert sha(path)==digest
    xdc_receipts.append(dict(path=str(path),sha256=digest,properties=lines[2:]))
assert len(xdc_receipts)==2
for source in ('source_100','island_175'):
    for dest in ('source_100','island_175'):
        for kind in ('min','max'):
            assert resources[f'{source}.{dest}.{kind}.reported_paths']=='20'
            assert len(re.findall(r'^Slack ',(build/f'{source}_{dest}_{kind}.rpt').read_text(),re.M))==20
timing=(build/'check_timing_unqualified.rpt').read_text()
for category in ('no_clock','unconstrained_internal_endpoints','loops','latch_loops'):
    assert f'checking {category} (0)' in timing
assert 'checking no_input_delay (114)' in timing and 'checking no_output_delay (124)' in timing
cdc_rows=re.findall(r'^(CDC-\d+)\s+(Critical|Warning|Info)\s+(\d+)\b',(build/'cdc_unqualified.rpt').read_text(),re.M)
assert cdc_rows
cdc={severity.lower():sum(int(n) for _,s,n in cdc_rows if s==severity) for severity in ('Critical','Warning','Info')}
cdc.update(qualified=False,rules=cdc_rows)
log=(root/'stdout.log').read_text()
assert not re.search(r'^ERROR:',log,re.M)
assert not re.search(r'implicit (?:definition|declaration)|undriven',log,re.I)
warnings=collections.Counter(re.findall(r'^WARNING: \[([^]]+)\]',log,re.M))
pins=json.loads((root/'preparation-source-pins.json').read_text())
tree=Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/destination-actual-worktree-v1')
assert pins=={n:sha(tree/n) for n in pins}
report=dict(dcp_sha256=sha(dcp),source_hierarchy_resources_verified=True,constraints_verified=True,
    scope='isolated synthesis source/resource audit; not physical signoff',resources=top,
    delta_from_offered_summary_synthesis=dict(lut=top['lut']-2248,ff=top['ff']-4759,dsp=top['dsp']-21,ram18=top['ram18']-15),
    runtime_files=runtime,constraint_files=xdc_receipts,warning_counts=dict(warnings),cdc=cdc,
    unconstrained_io=dict(inputs=114,outputs=124),all_eight_clockpair_reports=True,
    preparation_sources_unchanged=True,
    clock_model_warning='Independent rounded primary clocks; not board-derived clock qualification.',
    timing_qualified=False,deployment_eligible=False)
(root/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:report[k] for k in ('dcp_sha256','resources','delta_from_offered_summary_synthesis','cdc','unconstrained_io')}))

"""Bind unchanged-policy synthesis owner to the accepted destination sources."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
recovery=root.parent
source=recovery/'destination-actual-worktree-v1'
prepared=recovery/'destination-synthesis-prepared-parent-v1'
tests=recovery/'destination-physical-prep-parent.NJlhw5AK'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
expected='f528f69000db4552498f013c5a17f7a667fc13cda7c899658cade811753ec764'
assert sha(prepared/'SHA256SUMS')==expected
result=json.loads((tests/'result.json').read_text())
assert result==dict(exit=0, counts=dict(tests=69,failures=0,errors=0,skipped=0),source_count=22,unchanged=True)
pins=json.loads((tests/'before.json').read_text())
assert pins==json.loads((tests/'after.json').read_text())=={n:sha(source/n) for n in pins}
inventory={}
for row in (prepared/'SHA256SUMS').read_text().splitlines():
    digest,name=row.split('  ',1)
    assert name not in inventory and not Path(name).is_absolute() and '..' not in Path(name).parts
    assert not (prepared/name).is_symlink() and sha(prepared/name)==digest
    inventory[name]=digest
assert len(inventory)==149
assert {str(p.relative_to(prepared)) for p in prepared.rglob('*') if p.is_file()}==set(inventory)|{'SHA256SUMS'}
gate=dict(exit=0,unchanged=True,prepared_sha=expected,expected_tests=69,counts=result['counts'],
          runner_sha=sha(prepared/'synthesize_retained_destination.tcl'),copier_sha=sha(prepared/'prepare.py'))
with (root/'preparation-gate.json').open('x') as handle: json.dump(gate,handle,indent=2)
old=recovery/'retained-summary-synth-parent.39BysdkS/owner.py'
assert sha(old)=='c0305cdcfc4cf9e5dd4d6d7987ca68b18826218189884ca9129772e4c0e8f028'
original=old.read_text()
edits=[
 ('b5d112562b7db31164dc4a6ff92404de8e7d7d5d96b1c1b23e1a7dbac9d2c368','183a0ccce954efc48d30f598d4965459695e756e20e8ca32ba47c7ee21bf3363'),
 ('prepare_starlink_retained_summary_actual.py','prepare_starlink_retained_destination_actual.py'),
 ('synthesize_retained_summary.tcl','synthesize_retained_destination.tcl'),
 ('retained-summary-actual-parent.XYAbt6Np','destination-actual-parent.LQnQo9ny'),
 ("def verify(path,logname):", "(root/'tmp').mkdir();env['TMPDIR']=str(root/'tmp')\ndef verify(path,logname):"),
]
text=original;counts=[]
for before,after in edits:
    assert before in text and after not in text
    counts.append(text.count(before));text=text.replace(before,after)
inverse=text
for (before,after),count in reversed(list(zip(edits,counts))):
    assert inverse.count(after)==count
    inverse=inverse.replace(after,before)
assert inverse==original
with (root/'owner.py').open('x') as handle: handle.write(text)
with (root/'owner-derivation.json').open('x') as handle:
    json.dump(dict(original_sha256=sha(old),owner_sha256=sha(root/'owner.py'),whole_inverse=True,edits=edits,counts=counts),handle,indent=2)
print(json.dumps(gate))

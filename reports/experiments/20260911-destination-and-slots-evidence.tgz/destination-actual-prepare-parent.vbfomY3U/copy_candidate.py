"""Recover only source files from independently verified39; no artifact cleanup."""
import hashlib
import json
from pathlib import Path
R=Path(__file__).resolve().parent.parent
old=Path('/tmp/starlink-rom-prefetch.j829ht/fw')
new=R/'destination-actual-worktree-v1'
pins=json.loads((R/'destination-runtime-parent-v2.i7Xlaa2v/before.json').read_text())
copied={}
for raw,expected in pins.items():
 p=Path(raw)
 if not p.is_relative_to(old):continue
 name=p.relative_to(old)
 if not ('retained_destination' in str(name) or 'tb_retained_destination' in str(name) or
         str(name).startswith('hdl/library/starlink_pss_acquisition/retained_destination_candidate/')):continue
 data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==expected
 target=new/name
 if target.exists():assert target.read_bytes()==data
 else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 copied[str(name)]=expected
for name in ('docs/starlink-retained-destination-algebra-contract-20260910.md','docs/starlink-retained-destination-algebra-results-20260910.md','docs/starlink-retained-summary-next-cone-review-20260910.md'):
 target=new/name;assert not target.exists();data=(old/name).read_bytes()
 target.write_bytes(data);copied[name]=hashlib.sha256(data).hexdigest()
(Path(__file__).resolve().parent/'copied-candidate.json').write_text(json.dumps(copied,indent=2)+'\n')
print(json.dumps(copied,sort_keys=True))

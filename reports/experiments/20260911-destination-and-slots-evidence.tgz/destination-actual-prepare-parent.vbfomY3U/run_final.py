"""Freeze sources before evaluation; preserve all failures and compiler temp files."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
ROOT=Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/destination-actual-worktree-v1')
OUT=Path(__file__).resolve().parent/'final'
OUT.mkdir()
sys.path.insert(0,str(ROOT))
from tests.starlink_oracle import retained_destination_actual as b
b.verify_runner();paths=b.sources()
before={n:b.receipt(p) for n,p in paths.items()}
(OUT/'before.json').write_bytes(b.encoded(before))
for n,p in paths.items():
 t=OUT/'source_snapshot'/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
(OUT/'tmp').mkdir()
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
env.update(PYTHONDONTWRITEBYTECODE='1',TMPDIR=str(OUT/'tmp'))
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest','-q','-p','no:cacheprovider',
 '--basetemp',str(OUT/'pytest'),'--junitxml',str(OUT/'results.xml'),
 'tests/test_retained_destination_actual.py','tests/test_retained_destination_candidate.py','tests/test_retained_destination_algebra.py']
(OUT/'command.json').write_text(json.dumps({'cwd':str(ROOT),'argv':cmd,'timeout_seconds':180},indent=2)+'\n')
with (OUT/'pytest.log').open('x') as log:
 r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180,check=False)
after={n:b.receipt(p) for n,p in b.sources().items()}
(OUT/'after.json').write_bytes(b.encoded(after))
ss=ET.parse(OUT/'results.xml').getroot().findall('testsuite')
counts={k:sum(int(s.get(k,'0')) for s in ss) for k in ('tests','failures','errors','skipped')}
result={'exit':r.returncode,'counts':counts,'sources':len(before),'source_before_after_equal':before==after}
(OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
raise SystemExit(r.returncode or int(before!=after))

from pathlib import Path
import hashlib
import json
root=Path(__file__).resolve().parent
old=(root/'run_gate.py').read_text();token="OUT=Path(__file__).resolve().parent/'first'"
assert old.count(token)==1
new=old.replace(token,"OUT=Path(__file__).resolve().parent/'final'")
assert new.replace("OUT=Path(__file__).resolve().parent/'final'",token)==old
(root/'run_final.py').write_text(new)
(root/'final-gate-derivation.json').write_text(json.dumps({'old_sha256':hashlib.sha256(old.encode()).hexdigest(),'new_sha256':hashlib.sha256(new.encode()).hexdigest(),'whole_inverse':True},indent=2)+'\n')

"""Derive exact prior CLI and runner by candidate-specific names only."""
from pathlib import Path
import hashlib
import json
R=Path(__file__).resolve().parent.parent
old=R/'retained-summary-actual-prelaunch-v1/source_snapshot'
new=R/'destination-actual-worktree-v1'
pairs=[('retained_summary_actual simulate_retained_summary_actual.tcl','retained_destination_actual simulate_retained_destination_actual.tcl'),
       ('prepare_starlink_retained_summary_actual.py','prepare_starlink_retained_destination_actual.py'),
       ('RETAINED_SUMMARY_ACTUAL_VERIFIED_SEVEN_CONTEXTS_NO_CONTINUOUS_OR_PHYSICAL_CLAIM','RETAINED_DESTINATION_ACTUAL_VERIFIED_SEVEN_CONTEXTS_NO_CONTINUOUS_OR_PHYSICAL_CLAIM')]
source=old/'hdl/library/starlink_pss_acquisition/retained_summary_actual/simulate_retained_summary_actual.tcl'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='177a1961cdbeca4dc0f68a8994e31fc5b4145690c2f80fc26b916b8fba93f8d1'
text=source.read_text()
for before,after in pairs:
 assert text.count(before)==1;text=text.replace(before,after)
back=text
for before,after in reversed(pairs):assert back.count(after)==1;back=back.replace(after,before)
assert back==source.read_text()
out=new/'hdl/library/starlink_pss_acquisition/retained_destination_actual/simulate_retained_destination_actual.tcl'
out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_text(text)
source=old/'tools/prepare_starlink_retained_summary_actual.py'
text=source.read_text();before='from tests.starlink_oracle import retained_summary_actual_bundle as b';after='from tests.starlink_oracle import retained_destination_actual as b'
assert text.count(before)==1;text=text.replace(before,after);assert text.replace(after,before)==source.read_text()
out=new/'tools/prepare_starlink_retained_destination_actual.py';assert not out.exists();out.write_text(text)
recipe=Path('/tmp/starlink-rom-prefetch.j829ht/fw/docs/starlink-retained-destination-candidate-recipe-20260910.md')
out=new/'docs'/recipe.name;assert not out.exists();out.write_bytes(recipe.read_bytes())
(Path(__file__).resolve().parent/'transport-derivation.json').write_text(json.dumps({'whole_inverses':True,'runner_groups':3,'cli_groups':1},indent=2)+'\n')

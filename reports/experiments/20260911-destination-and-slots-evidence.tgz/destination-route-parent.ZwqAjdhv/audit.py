"""Independent routed report cross-check; never equates vendor exit with timing."""
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
route=root/'route'
execution=json.loads((root/'execution.json').read_text())
assert execution['vendor_exit']==0 and not execution['timed_out']
assert all(execution[k] for k in ('source_dcp_unchanged','original_runner_unchanged','frozen_runner_unchanged'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(route/'retained_output_routed.dcp')==execution['routed_dcp_sha256']
paths=dict(line.split('=',1) for line in (route/'paths.txt').read_text().splitlines())
pairs={}
for source in ('source_100','island_175'):
    for dest in ('source_100','island_175'):
        pair={}
        for kind,label in (('max','setup'),('min','hold')):
            slack=float(paths[f'{source}.{dest}.{kind}.slack'])
            assert paths[f'{source}.{dest}.{kind}.reported_paths']=='20'
            text=(route/f'{source}_{dest}_{kind}.rpt').read_text()
            values=re.findall(r'^Slack \([^\n]*?\)\s*:\s*(-?\d+\.\d+)ns',text,re.M)
            assert len(values)==20 and float(values[0])==slack
            pair[label]=slack
        pairs[source+'->'+dest]=pair
timing=(route/'timing_unqualified.rpt').read_text()
row=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s*$',timing,re.M)
assert row
v=row.groups()
wns,tns,whs,pulse=float(v[0]),float(v[1]),float(v[4]),float(v[8])
setup_fails,hold_fails,pulse_fails=int(v[2]),int(v[6]),int(v[10])
timing_pass=wns>=0 and whs>=0 and pulse>=0 and setup_fails==hold_fails==pulse_fails==0
assert ('Timing constraints are not met.' in timing)==(not timing_pass)
assert wns==min(p['setup'] for p in pairs.values()) and whs==min(p['hold'] for p in pairs.values())
status=(route/'route_status.rpt').read_text()
def route_count(label):
    values=re.findall(re.escape(label)+r'\.+\s*:\s*(\d+)\s*:',status)
    assert len(values)==1
    return int(values[0])
routed=route_count('fully routed nets');errors=route_count('nets with routing errors')
assert routed>0 and errors==0
util=(route/'utilization.rpt').read_text()
def utilization(label):
    values=re.findall(r'^\|\s*'+re.escape(label)+r'\s*\|\s*(\d+)\s*\|',util,re.M)
    expected_count=2 if label=='Slice Registers' else 1
    assert len(values)==expected_count and len(set(values))==1,(label,values)
    return int(values[0])
resources={key:utilization(label) for key,label in [('lut','Slice LUTs'),('ff','Slice Registers'),('dsp','DSPs'),('ramb18','RAMB18'),('control_sets','Unique Control Sets')]}
assert resources['dsp']==21 and resources['ramb18']==15
def commands(path):return [line.strip() for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
synthesis=root.parent/'destination-synth-parent.G1XLB1ik/synthesis'
assert commands(route/'inherited_constraints.xdc')==commands(synthesis/'inherited_constraints.xdc')
assert 'No valid timing exceptions found.' in (route/'exceptions.rpt').read_text()
cdc_rows=re.findall(r'^(CDC-\d+)\s+(Critical|Warning|Info)\s+(\d+)\b',(route/'cdc_unqualified.rpt').read_text(),re.M)
assert cdc_rows
cdc={severity.lower():sum(int(n) for _,s,n in cdc_rows if s==severity) for severity in ('Critical','Warning','Info')}
checks=(route/'check_timing_unqualified.rpt').read_text()
for category in ('no_clock','unconstrained_internal_endpoints','loops','latch_loops'):
    assert f'checking {category} (0)' in checks
assert 'checking no_input_delay (114)' in checks and 'checking no_output_delay (124)' in checks
result=dict(vendor_exit=0,routed_dcp_sha256=execution['routed_dcp_sha256'],route_complete=True,
    fully_routed_nets=routed,routing_errors=errors,timing_pass=timing_pass,wns_ns=wns,tns_ns=tns,
    setup_failing_endpoints=setup_fails,setup_endpoints=int(v[3]),whs_ns=whs,hold_failing_endpoints=hold_fails,
    pulse_width_slack_ns=pulse,pulse_failing_endpoints=pulse_fails,**resources,clockpair_slacks=pairs,
    cdc=cdc,unconstrained_io=dict(inputs=114,outputs=124),constraints_unchanged=True,
    cdc_and_external_io_qualified=False,deployment_eligible=False)
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

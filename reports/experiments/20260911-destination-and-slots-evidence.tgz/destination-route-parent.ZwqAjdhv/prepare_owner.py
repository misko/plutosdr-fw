"""Same diagnostic route and cross-checks, new audited synthesis only."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
oldroot=root.parent/'retained-summary-route-parent.qxOkezJN'
tests=root.parent/'destination-physical-prep-parent.NJlhw5AK'
source=root.parent/'destination-actual-worktree-v1'
runner=source/'tools/retained_destination_synthesis/route_retained_output.tcl'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(runner)=='034d1eaa197757b762644acd0cad9dc267338ae23fd5d757290c8485d0f1ac9a'
result=json.loads((tests/'result.json').read_text())
assert result['exit']==0 and result['unchanged'] and result['counts']==dict(tests=69,failures=0,errors=0,skipped=0)
pins=json.loads((tests/'before.json').read_text())
assert pins=={n:sha(source/n) for n in pins}
gate=dict(exit=0,unchanged=True,runner_sha=sha(runner),expected_tests=69,counts=result['counts'])
with (root/'preparation-gate.json').open('x') as handle: json.dump(gate,handle,indent=2)
assert sha(oldroot/'owner.py')=='fa576de960ad915f184fb9326fd9228d3cc79a860d06cb401bda918219a49d2c'
receipts={}
for name in ('owner.py','audit.py'):
    original=(oldroot/name).read_text()
    edits=[('retained-summary-synth-parent.39BysdkS','destination-synth-parent.G1XLB1ik')]
    if name=='owner.py':
        edits.append(("env['LD_LIBRARY_PATH']=", "(root/'tmp').mkdir();env['TMPDIR']=str(root/'tmp')\nenv['LD_LIBRARY_PATH']="))
    text=original;counts=[]
    for before,after in edits:
        assert before in text and after not in text
        counts.append(text.count(before));text=text.replace(before,after)
    inverse=text
    for (before,after),count in reversed(list(zip(edits,counts))):
        assert inverse.count(after)==count
        inverse=inverse.replace(after,before)
    assert inverse==original
    with (root/name).open('x') as handle: handle.write(text)
    receipts[name]=dict(original_sha256=sha(oldroot/name),sha256=sha(root/name),edits=edits,counts=counts,whole_inverse=True)
with (root/'derivation.json').open('x') as handle: json.dump(receipts,handle,indent=2)
print(json.dumps(gate))

"""Independent full actual-result comparison, not physical qualification."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
old = root.parent/'retained-summary-actual-parent.XYAbt6Np'
csv = 'run/project/retained_output_actual.sim/sim_1/behav/xsim/actual_words.csv'
new_bytes = (root/csv).read_bytes()
assert new_bytes == (old/csv).read_bytes()
digest = hashlib.sha256(new_bytes).hexdigest()
assert digest == '07321b026a637e5922c56a84a955e58549056337198c952a9d73b1245cb4efaa'
result = json.loads((root/'run/results.json').read_text())
destination = result.pop('destination')
assert result == json.loads((old/'run/results.json').read_text())
assert destination == dict(mode=1, pre=89723, post=89723, releases=17, admits=19, publications=19)
assert result['numerical_words'] == 77953
assert [r['service'] for r in result['contexts']] == [3645,3645,4912,3645,3645,3645,3645]
outcome = json.loads((root/'outcome.json').read_text())
assert outcome['functional_accepted'] and outcome['vendor_exit'] == 0
receipt = dict(csv_sha256=digest, numerical_words=77953, entire_previous_result_equal=True,
               destination=destination, physical_qualified=False, deployment_eligible=False)
with (root/'audit.json').open('x') as handle:
    json.dump(receipt, handle, indent=2)
print(json.dumps(receipt))

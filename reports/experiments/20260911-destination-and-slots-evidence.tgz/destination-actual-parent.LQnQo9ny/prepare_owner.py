"""Bind reviewed original vendor owner to independently tested85 destination bundle."""
import hashlib
import json
from pathlib import Path
R=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
bundle=R/'destination-actual-prelaunch-parent-v1'
gate_root=R/'destination-actual-prepare-parent.vbfomY3U'
manifest='183a0ccce954efc48d30f598d4965459695e756e20e8ca32ba47c7ee21bf3363'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(bundle/'manifest.json')==manifest
m=json.loads((bundle/'manifest.json').read_text())
assert len(m['sources'])==132 and len(m['files'])==134
assert set(m['files'])=={str(p.relative_to(bundle)) for p in bundle.rglob('*') if p.is_file()}-{'manifest.json'}
for n,v in m['files'].items():assert sha(bundle/n)==v['sha256'] and (bundle/n).stat().st_size==v['bytes']
tests=json.loads((gate_root/'final/result.json').read_text())
assert tests==dict(exit=0,counts=dict(tests=85,failures=0,errors=0,skipped=0),sources=132,source_before_after_equal=True)
tested=json.loads((gate_root/'final/before.json').read_text())
assert tested==m['sources']
pins={n:v['sha256'] for n,v in tested.items()}
(gate_root/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
audit={'exit':0,'tests':85,'sources_unchanged':True,'prepared_files_unchanged':True,
       'manifest_sha256':manifest,'sources':132,'prepared_files':135}
(gate_root/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
old=R/'retained-summary-actual-parent.XYAbt6Np/owner.py';text=old.read_text()
assert sha(old)=='e60edf3106189468601f4d5def0e0aaefca6cd442ac42c4dc27ea50e3889717f'
pairs=[('67-test gate','85-test gate'),
 ('retained-summary-actual-prelaunch-v1','destination-actual-prelaunch-parent-v1'),
 ('b5d112562b7db31164dc4a6ff92404de8e7d7d5d96b1c1b23e1a7dbac9d2c368',manifest),
 ('retained-summary-actual-prep-parent.ZLxFAi3v','destination-actual-prepare-parent.vbfomY3U'),
 ('retained_summary_actual/simulate_retained_summary_actual.tcl','retained_destination_actual/simulate_retained_destination_actual.tcl'),
 ('tools/prepare_starlink_retained_summary_actual.py','tools/prepare_starlink_retained_destination_actual.py'),
 ('177a1961cdbeca4dc0f68a8994e31fc5b4145690c2f80fc26b916b8fba93f8d1','fd06dae7fe2e212240fef366abc6624028ca865dd92440f4283bcd228ce44fee'),
 ("gate['tests']==67","gate['tests']==85"),('len(pins)==116','len(pins)==132'),
 ("script=json.loads((root.parent/'retained-summary-script-parent.jVE5ixKt/execution.json').read_text())\nassert script['csv_byte_equal'] and script['entire_old_result_equal'] and script['numerical_rows']==77953 and script['source_unchanged']",
  "script=json.loads((parent/'final/result.json').read_text())\nassert script['exit']==0 and script['counts']==dict(tests=85,failures=0,errors=0,skipped=0) and script['source_before_after_equal'] and script['sources']==132"),
 ('Actual retained-summary FFT started','Actual contextual-destination FFT started')]
for before,after in pairs:
 assert text.count(before)==1,before
 text=text.replace(before,after)
back=text
for before,after in reversed(pairs):
 assert back.count(after)==1;back=back.replace(after,before)
assert back==old.read_text()
(OUT/'owner.py').write_text(text)
(OUT/'owner-derivation.json').write_text(json.dumps({'whole_inverse':True,'groups':len(pairs),'owner_sha256':hashlib.sha256(text.encode()).hexdigest(),'pairs':pairs},indent=2)+'\n')
print(json.dumps(audit))

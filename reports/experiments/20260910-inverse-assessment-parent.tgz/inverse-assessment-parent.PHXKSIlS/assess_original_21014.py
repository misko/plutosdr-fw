"""Read-only post-hoc assessment, not repair or PASS of original automation.

Execute the exact frozen results function with one explicitly audited dependency
binding: the offline-tested completed-epoch trace parser. All numerical, clock,
protocol, source/IP, terminal and diagnostic inventory checks are unchanged.
Nothing is written beneath the original run; no vendor tool is invoked.
"""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
from types import FunctionType

HERE = Path(__file__).parent
RECOVERY = HERE.parent
ORIGINAL = RECOVERY / 'inverse-actual-prepared-v1.sUupdgsv'
RUN = ORIGINAL / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v1'
SOURCE = RUN / 'frozen_sources'
OWNER = ORIGINAL / 'inverse-sealed-L1E1-175-actual-owned-v1'
ARCHIVE_RECEIPT = RECOVERY / 'inverse-actual-original-archive-v1.Z7yIZFDF/20260910-inverse-sealed-actual-original21014-failed-v1.json'
MANIFEST = '2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a'
TIMING_SHA = '09061c6d56fab3460536cca74733f2da764ea6f2a2e508a11d4f4d60482f17c6'
RESULT = HERE / 'posthoc_assessment_original_automation_FAIL.json'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    spec = importlib.util.spec_from_file_location('posthoc_' + path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def inventory():
    return {'original/' + path.relative_to(ORIGINAL).as_posix(): sha(path)
            for path in ORIGINAL.rglob('*') if path.is_file() and not path.is_symlink()}


require(not RESULT.exists(), 'post-hoc output must be absent')
receipt = json.loads(ARCHIVE_RECEIPT.read_text())
require(receipt['sha256'] == '07485ace45c94c72bf084de4e0cfbf1529ac6f30b2ae58ac36b72404052b4b63', 'original archive binding')
before = inventory()
require(before == {name: value for name, value in receipt['files'].items() if name.startswith('original/')}, 'all archived original hashes')
require(sha(RUN / 'manifest.json') == MANIFEST, 'original manifest pin')
require(sha(RUN / 'run_outcome.txt') == '316dbfb83f3379b26a77fdf373ad9f8e5ecb9dc7645cd126ee2fa9f820437b47', 'only exact known failed outcome admitted')
require(sha(OWNER / 'terminal.json') == '85e7b43298768d60db7d28dc0ea917bb5fe4664b1f8bd438cf36d92b21929fbe', 'original process failure receipt')
require(not (RUN / 'results.json').exists(), 'original automation must remain without success artifact')
manifest = json.loads((RUN / 'manifest.json').read_text())
timing_path = HERE / 'inverse_sealed_actual_timing.py'
require(sha(timing_path) == TIMING_SHA, 'reviewed replacement parser source')
old_ast = ast.parse((SOURCE / 'inverse_sealed_actual_timing.py').read_text())
new_ast = ast.parse(timing_path.read_text())
old_parser = next(node for node in old_ast.body if isinstance(node, ast.FunctionDef) and node.name == 'parse_trace')
require(sum(isinstance(node, ast.FunctionDef) and node.name == '_completed_epoch' for node in new_ast.body) == 1, 'one new completion predicate')
new_ast.body = [old_parser if isinstance(node, ast.FunctionDef) and node.name == 'parse_trace' else node
                for node in new_ast.body if not (isinstance(node, ast.FunctionDef) and node.name == '_completed_epoch')]
require(ast.dump(new_ast) == ast.dump(old_ast), 'all old numerical/clock/protocol code and constants unchanged')
timing = load(timing_path)
frozen = load(SOURCE / 'inverse_sealed_actual.py')
require(frozen.verify(RUN, MANIFEST) == manifest, 'full frozen source verification')
calls = []


def audited_load(name, expected=None):
    require(name == 'inverse_sealed_actual_timing' and expected == manifest['source_sha256'][name + '.py'],
            'only the declared timing dependency may be rebound')
    calls.append((name, expected))
    return timing


# Same immutable code object, with only the explicitly listed global dependency
# changed. The original module's function/global dictionary stays untouched.
assess = FunctionType(frozen.results.__code__, {**frozen.results.__globals__, 'load': audited_load})
error = None
try:
    functional = assess(RUN, MANIFEST)
    require(len(calls) == 1, 'one exact parser dependency binding')
    transitions = []
    timing.parse_trace(RUN / 'project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim/fft_bank_owned_trace.csv', transitions)
except Exception as caught:
    error = repr(caught)
    raise
finally:
    after = inventory()
    audit = {'original_files_before': before, 'original_files_after': after,
             'unchanged': before == after, 'assessment_error': error}
    with (HERE / 'original_integrity_after.json').open('x') as stream:
        stream.write(json.dumps(audit, indent=2, sort_keys=True) + '\n')
    require(before == after, 'post-hoc assessment changed original inputs')
    require(not (RUN / 'results.json').exists(), 'original success artifact must remain absent')
assessment = {'schema': 'inverse-original21014-posthoc-assessment-v1',
    'original_handle': 21014, 'original_automation': 'FAIL', 'original_process_exit': 1,
    'assessment': 'COMPLETE_FUNCTIONAL_RECEIPTS_REASSESSED_OFFLINE',
    'original_manifest_sha256': MANIFEST, 'parser_source_sha256': TIMING_SHA,
    'original_result_collector_sha256': sha(SOURCE / 'inverse_sealed_actual.py'),
    'known_failure': 'Profile set after complete drain, before next-negedge reset; not an RTL fault.',
    'profile_transition_receipts': transitions, 'original_results_json_remains_absent': True,
    'original_files_verified_before_after': len(before),
    'functional_receipts': functional,
    'no_new_simulation': True, 'WDB_recorded_history_pending': True,
    'receiver_continuous_source_native_pilot_physical_RF_qualification': False}
with RESULT.open('x') as stream:
    stream.write(json.dumps(assessment, indent=2, sort_keys=True) + '\n')
print(json.dumps({'original_automation': 'FAIL', 'posthoc_assessment': str(RESULT),
                  'sha256': sha(RESULT), 'original_files_unchanged': len(before)}, indent=2))

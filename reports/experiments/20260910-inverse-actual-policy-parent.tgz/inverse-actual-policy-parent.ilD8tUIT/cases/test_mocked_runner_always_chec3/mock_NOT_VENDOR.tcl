proc version {args} {return 2022.2}
proc set_param {args} {}
proc create_project {name directory args} {file mkdir $directory}
proc current_project {args} {return mocked}
proc set_property {args} {}
proc get_ips {args} {return {}}
proc create_ip {args} {}
proc add_files {args} {}
proc get_filesets {args} {return sim_1}
proc get_files {args} {return {}}
proc close_sim {args} {}
proc close_project {args} {}
proc generate_target {args} {file mkdir [file dirname $::wrapper]; file copy {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/local-admission-actual-R1B1O1-L1-175-prepared-v4/project/fft_bank_arithmetic_actual.gen/sources_1/ip/starlink_pss_fft512_bfp18_rt_candidate/synth/starlink_pss_fft512_bfp18_rt_candidate.vhd} $::wrapper}
proc launch_simulation {args} {
foreach name {PYTHONHOME PYTHONPATH LD_LIBRARY_PATH} {if {$::env($name) ne {/invalid-vendor}} {error PARENT_ENV_CHANGED}}
error OFFLINE_LAUNCH_STOP
}
set argc 3
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-actual-policy-parent.ilD8tUIT/cases/test_mocked_runner_always_chec3/copy} {/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python} 2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-actual-policy-parent.ilD8tUIT/cases/test_mocked_runner_always_chec3/copy/frozen_sources/simulate_inverse_sealed_actual.tcl}

// Native30 common-source checks. Shared by non-FFT budget probe and future
// paired harness. Every hierarchical reference is an observation, never force.
`define HN_CORE native.i_core
`define HN_RAW native.i_core.i_raw_tracking_core
`define HN_SCHED native.i_core.i_raw_tracking_core.i_candidate_scheduler
  localparam [63:0] NATIVE_CENTER = 64'd17179870192;
  localparam [63:0] NATIVE_CAPTURE_FIRST = NATIVE_CENTER - 64;
  localparam [63:0] NATIVE_DEADLINE = 64'd17179869408;
  localparam [31:0] NATIVE_REQUEST = 32'h30000520;
  localparam [31:0] NATIVE_GENERATION = 32'h30000001;
  wire native_irq, native_injected;
  reg [31:0] native_coefficients [0:131], native_packet [0:25], native_capture [0:259];
  reg [7:0] native_raw_lag [0:128];
  reg [63:0] native_raw_index [0:128];
  reg [47:0] native_raw_real [0:128], native_raw_imag [0:128];
  reg [47:0] native_raw_ex [0:128], native_raw_eh [0:128];
  reg [95:0] native_raw_power [0:128];
  reg [8:0] native_raw_saturation [0:128];
  reg native_raw_qualified [0:128];
  integer native_admissions = 0, native_capture_count = 0, native_raw_count = 0;
  integer native_qualified_count = 0, native_packet_reads = 0, native_readout_transactions = 0;
  integer native_capture_fft_overlap = 0, native_compute_overlap = 0, native_compute_after_stop = 0;
  integer native_capture_end_cycle = -1, native_publish_cycle = -1, native_release_cycle = -1;
  integer native_raw_fd, native_configured = 0;
  reg native_command_issued = 0, native_done = 0;
  reg [63:0] native_admission_index = 0, native_admission_lead = 0;
  reg [95:0] native_square_re, native_square_im;

  axi_starlink_pss_tracker #(.RATE_MSPS(30), .ENABLE_INJECTION(0), .USE_DSP_REDUCER(1)) native (
    .sample_clk(sample_clk), .sample_reset(!resetn), .sample_i(sample_data[15:0]),
    .sample_q(sample_data[31:16]), .sample_strobe(sample_strobe), .sample_enable(source_enable),
    .sample_index(sample_index), .sample_timestamp(sample_index),
    .selected_sample_i(), .selected_sample_q(), .selected_sample_strobe(),
    .selected_sample_enable(), .selected_sample_index(), .selected_sample_timestamp(),
    .selected_sample_injected(native_injected), .irq(native_irq),
    .s_axi_aclk(clk), .s_axi_aresetn(resetn),
    .s_axi_awaddr(awaddr[2]), .s_axi_awvalid(awvalid[2]), .s_axi_awready(awready[2]),
    .s_axi_wdata(wdata[2]), .s_axi_wstrb(4'hf), .s_axi_wvalid(wvalid[2]), .s_axi_wready(wready[2]),
    .s_axi_bvalid(bvalid[2]), .s_axi_bresp(bresp[2]), .s_axi_bready(bready[2]),
    .s_axi_araddr(araddr[2]), .s_axi_arvalid(arvalid[2]), .s_axi_arready(arready[2]),
    .s_axi_rvalid(rvalid[2]), .s_axi_rdata(rdata[2]), .s_axi_rresp(rresp[2]), .s_axi_rready(rready[2]),
    .s_axi_awprot(3'd0), .s_axi_arprot(3'd0)
  );
  `include "bank_native30_late_logic.svh"
  task automatic configure_native;
    integer tap, timeout;
    reg [31:0] readback;
    $readmemh("native_coefficients_q15.mem", native_coefficients);
    $readmemh("native_expected_packet.mem", native_packet);
    $readmemh("native_capture_ci16.mem", native_capture);
    $readmemh("native_raw_lag.mem", native_raw_lag);
    $readmemh("native_raw_index.mem", native_raw_index);
    $readmemh("native_raw_real.mem", native_raw_real); $readmemh("native_raw_imag.mem", native_raw_imag);
    $readmemh("native_raw_ex.mem", native_raw_ex); $readmemh("native_raw_eh.mem", native_raw_eh);
    $readmemh("native_raw_power.mem", native_raw_power);
    $readmemh("native_raw_saturation.mem", native_raw_saturation);
    $readmemh("native_raw_qualified.mem", native_raw_qualified);
    native_raw_fd = $fopen("native30_actual_raw_tuples.txt", "w");
    if (!native_raw_fd) fail("native30 raw tuple log unavailable");
    expect_reg(2, 8'h00, 32'h50535354); expect_reg(2, 8'h04, 32'h00010003);
    expect_reg(2, 8'h08, 30); expect_reg(2, 8'h0c, 32'h0bca0884); expect_reg(2, 8'h10, 32'h1d);
    write_reg(2, 8'h44, 1);
    for (tap = 0; tap < 132; tap = tap + 1)
      write_reg(2, 8'h40, {native_coefficients[tap][15:0], native_coefficients[tap][31:16]});
    write_reg(2, 8'h48, NATIVE_GENERATION); write_reg(2, 8'h44, 2);
    timeout = 0; readback = 0;
    while (readback != NATIVE_GENERATION && timeout < 2000) begin
      read_reg(2, 8'h4c, readback); timeout = timeout + 1;
    end
    if (timeout == 2000) fail("native30 coefficient commit timeout");
    expect_reg(2, 8'h60, 1073746351); expect_reg(2, 8'h64, 0);
    native_configured = 1;
  endtask
  task automatic read_native_packet(input integer pass);
    reg [31:0] actual;
    for (integer word_index = 0; word_index < 26; word_index = word_index + 1) begin
      write_reg(2, 8'h50, word_index); read_reg(2, 8'h54, actual);
      if (actual !== native_packet[word_index]) fail("native30 public packet mismatch");
      $display("NATIVE30_PACKET_WORD pass=%0d word=%0d data=%08x", pass, word_index, actual);
      native_packet_reads = native_packet_reads + 1;
    end
  endtask
`undef HN_CORE
`undef HN_RAW
`undef HN_SCHED

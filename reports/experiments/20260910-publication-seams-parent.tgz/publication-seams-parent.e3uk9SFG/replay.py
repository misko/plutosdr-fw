"""Parent fresh full regression with before/after source identity and raw output."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
tree = Path('/tmp/starlink-rom-prefetch.j829ht/fw')
acq = tree / 'hdl/library/starlink_pss_acquisition'
tests = ['test_product_publication_seams.py', 'test_product_sealed_interface.py',
         'test_product_sealed_adapter.py', 'test_checked_product_read.py']
oracle = tree / 'tests/starlink_oracle'
paths = set(acq.glob('*.v')) | set((acq/'tb').glob('*.sv')) | set((acq/'tb').glob('*.svh'))
paths |= {oracle/n for n in tests + ['product_interface_graph.py']}
for name in ('product_publication_inverse', 'product_interface_inverse'):
    paths |= set((oracle/name).glob('*.patch'))
for relative in ('pyproject.toml','pytest.ini','conftest.py','tests/conftest.py',
                 'tests/starlink_oracle/conftest.py','tests/__init__.py','tests/starlink_oracle/__init__.py'):
    if (tree/relative).is_file(): paths.add(tree/relative)
pins = {str(p.relative_to(tree)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
assert pins['tests/starlink_oracle/test_product_publication_seams.py'] == 'db0d31b2e1b8f200887361bfc4044c04eb0759111fb9f5b4ae286991752d1374'
for relative in pins:
    target = root/'source'/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(tree/relative,target)
(root/'source-pins.json').write_text(json.dumps(pins,indent=2))
commits = {part: subprocess.check_output(['git','-C',str(tree/part),'rev-parse','HEAD'],text=True).strip() for part in ('.','hdl')}
env = {k:v for k,v in os.environ.items() if k not in {'PYTHONOPTIMIZE','PYTHONHOME','PYTHONPATH','LD_LIBRARY_PATH'}}
cmd = [sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',
       *['tests/starlink_oracle/'+n for n in tests],
       '--basetemp',str(root/'cases'),'--junitxml',str(root/'results.xml')]
(root/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(tree),'commits':commits},indent=2))
print('Parent full2752 fresh replay started; sources='+str(len(pins)),flush=True)
result = subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=300)
(root/'pytest.log').write_text(result.stdout+result.stderr)
changed = [p for p,pin in pins.items() if hashlib.sha256((tree/p).read_bytes()).hexdigest()!=pin]
(root/'execution.json').write_text(json.dumps({'exit':result.returncode,'changed_sources':changed,'commits':commits},indent=2))
print('\n'.join((result.stdout+result.stderr).splitlines()[-8:]),flush=True)
assert not changed,changed
assert result.returncode==0,result.returncode

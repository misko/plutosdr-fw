module extra;
starlink_pss_checked_product_read #(.CHECKED_PRODUCT_READ(2)) dut();
endmodule

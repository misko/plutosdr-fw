"""Independent parent receipts, exact reason/read counts and complete graph."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
suite=ET.parse(root/'results.xml').getroot().find('testsuite')
assert all(suite.get(k)==v for k,v in {'tests':'2752','errors':'0','failures':'0','skipped':'0'}.items())
counts=Counter(t.get('classname').split('.')[-1] for t in suite.findall('testcase'))
assert counts=={'test_product_publication_seams':1308,'test_product_sealed_interface':596,
                'test_product_sealed_adapter':520,'test_checked_product_read':328},counts
execution=json.loads((root/'execution.json').read_text())
assert execution['exit']==0 and not execution['changed_sources']
entries=0
for relative,pin in json.loads((root/'source-pins.json').read_text()).items():
    assert hashlib.sha256((root/'source'/relative).read_bytes()).hexdigest()==pin
manifests=list((root/'cases').rglob('sources.json'))
for manifest in manifests:
    for relative,pin in json.loads(manifest.read_text()).items():
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        assert hashlib.sha256((manifest.parent/relative).read_bytes()).hexdigest()==pin
        entries+=1
bank_rows=0
for phase in (0,1,2,4):
    for bit in range(8):
        for value in range(3):
            log=(root/f'cases/bank0/enabled/case-{phase}-bit-{bit}-target-{value}.log').read_text()
            match=re.search(r'^PUBLICATION_BANK_PASS option=1 phase=(\d+) bit=(\d+) value=(\d+) checks=(\d+) reads=(\d+) reasons=([0-9a-f]{4})$',log,re.M)
            assert match and tuple(map(int,match.groups()[:3]))==(phase,bit,value)
            assert int(match[4])>0 and int(match[5])=={0:0,1:0,2:1,4:512}[phase]
            assert int(match[6],16)==1<<(8+bit)
            bank_rows+=1

# Reuse only four reviewed pure definitions, not the old audit's execution.
parser=root/'reviewed_graph_parser.py'
tree=ast.parse(parser.read_text())
nodes=[n for n in tree.body if (isinstance(n,ast.FunctionDef) and n.name in {'parse','first_cycle'}) or
       (isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'TOKEN','ALLOWED'})]
assert len(nodes)==4
space={'re':re}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(parser),'exec'),space)
paths=[root/'cases/interface0/enabled/sim.vvp']
paths+=sorted(p for p in (root/'cases').glob('test_executed_restored_publicat*/backedge/sim.vvp') if not p.parent.parent.is_symlink())
assert len(paths)==4,len(paths)
graph_rows=[]
for index,path in enumerate(paths):
    graph,aliases=space['parse'](path.read_text())
    cycle=space['first_cycle'](graph)
    assert (cycle is None)==(index==0)
    graph_rows.append({'path':str(path.relative_to(root)),'nodes':len(graph),'LS':sum(n.startswith('LS_') for n in graph),'cycle':cycle})
    if index: continue
    source=set().union(*(graph[n] for n,name in aliases.items() if name.endswith('/publication_faults')))
    assert source
    def cone(names):
        seen=set(); pending=list(names)
        while pending:
            n=pending.pop()
            if n not in seen: seen.add(n);pending.extend(graph.get(n,()))
        return seen
    route={}
    for sink in ('bank_live','output_valid','certificate_ready','certificate_take','lease_release_ready','lease_release','product_ready','checked_seal','publish'):
        names=[n for n,name in aliases.items() if name.endswith('/'+sink)]
        assert names,sink
        route[sink]=bool(cone(names)&source)
        assert route[sink]==(sink in ('checked_seal','publish')),(sink,route[sink])

healthy=[]
for directory in ('interface0/enabled','interface1/disabled'):
    log=(root/f'cases/{directory}/case-0-bit-0-target-0.log').read_text()
    jobs=re.findall(r'^PRODUCT_ADAPTER_JOB (.+)$',log,re.M)
    latencies=re.findall(r'^PRODUCT_ADAPTER_LATENCY (.+)$',log,re.M)
    assert len(jobs)==len(latencies)==8
    for j,(job,latency) in enumerate(zip(jobs,latencies)):
        assert dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',job))==dict(job=j,take=512,seal_delta=2,publish_delta=3,completion_to_publish=6,head_delta=10,release_after_core=1,core_span=511,holes=0)
        assert dict((k,int(v)) for k,v in re.findall(r'(\w+)=(\d+)',latency))==dict(job=j,admission_to_release=1555,handoff_to_first_core=2,last_core_to_release=1)
    healthy.append((jobs,latencies))
assert healthy[0]==healthy[1]
result={'scope':'offline primitives and real-guard actor, not P1 controller/vendor/routing',
        'tests':dict(counts),'case_manifests':len(manifests),'case_source_entries':entries,
        'exact_bank_reason_read_rows':bank_rows,'graphs':graph_rows,'publication_routes':route,
        'healthy_enabled_disabled_jobs':8,'admission_to_release_cycles':1555}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

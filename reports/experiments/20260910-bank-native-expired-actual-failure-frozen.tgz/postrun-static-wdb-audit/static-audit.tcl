# Read original saved databases only: no project, launch_simulation or run.
catch {close_sim}
foreach mhz {175 200} {
  set path /tmp/starlink-coarse-alternatives.Y3JzOI/bank-native-paired/hdl/library/starlink_pss_acquisition/build/bank-native-expired-${mhz}-v1/project/bank_native_expired.sim/sim_1/behav/xsim/tb_starlink_bank_native_expired_behav.wdb
  open_wave_database -noautoloadwcfg $path
  puts "STATIC_WDB_BEGIN fast_mhz=$mhz path=$path"
  foreach name {native_injected native_irq native_configured source_enable sample_strobe expired_issued expired_window expired_public_submits expired_wrapper_handshakes expired_fifo_accepts expired_sample_handshakes expired_register_reads canonical_count score_count delivered_count} {
    set obj [lindex [get_objects $name] 0]
    puts "STATIC_WDB_VALUE signal=$name time=9504999ps value=[get_value_database -time 9504999ps -radix hex $obj]"
  }
  foreach name {result_available result_word_read result_release candidate_command_overrun_count coefficient_write_overrun_count queue_overrun_count engine_consumed_count correlator_bound_error_count reducer_processed_job_count reducer_emitted_result_count reducer_invalid_tuple_count reducer_bound_error_count reducer_protocol_error_count result_published_count result_overrun_count result_consumed_count} {
    foreach obj [get_objects -r $name] {
      if {[string match "*/native/$name" $obj]} {
        puts "STATIC_WDB_VALUE signal=native/$name time=9504999ps value=[get_value_database -time 9504999ps -radix hex $obj]"
      }
    }
  }
  set obj [get_objects -r correlator_busy]
  puts "STATIC_WDB_VALUE signal=correlator_busy time=9504999ps value=[get_value_database -time 9504999ps -radix hex $obj]"
  puts "STATIC_WDB_TRANSITIONS signal=correlator_busy values=[get_transitions -startTime 9400ns -endTime 9505ns $obj]"
  puts "STATIC_WDB_END fast_mhz=$mhz internal_blank_is_missing_log_not_zero=1 exact_failing_internal_operand_unavailable=1"
  close_sim
}

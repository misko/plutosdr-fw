"""Read immutable Git archive parts; no extraction, mutation or vendor call."""
import hashlib
import io
import json
from pathlib import PurePosixPath
import subprocess
import tarfile

REPO = '/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic'
COMMIT = 'f6b0a7eefd6729a8c89f73184b8d85efcce84958'
DIRECTORY = 'reports/experiments/'
STEM = '20260910-inverse-sealed-actual-original21014-failed-v1'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def blob(name):
    require(PurePosixPath(name).name == name, 'plain archive filename required')
    return subprocess.check_output(['git', '-C', REPO, 'show', COMMIT + ':' + DIRECTORY + name])


parts = json.loads(blob(STEM + '.parts.json'))
receipt = json.loads(blob(STEM + '.json'))
require(parts['format'] == 'starlink-portable-archive-parts-v1'
        and parts['max_part_bytes'] == 41943040 and len(parts['parts']) == 4, 'part schema')
chunks = []
for index, part in enumerate(parts['parts']):
    require(part['index'] == index and part['name'] == STEM + f'.tgz.part{index:03}', 'part identity/order')
    data = blob(part['name'])
    require(len(data) == part['bytes'] and 0 < len(data) <= 41943040
            and hashlib.sha256(data).hexdigest() == part['sha256'], 'exact part bytes/hash')
    chunks.append(data)
archive_bytes = b''.join(chunks)
digest = hashlib.sha256(archive_bytes).hexdigest()
require(len(archive_bytes) == 140853340 and digest ==
        '07485ace45c94c72bf084de4e0cfbf1529ac6f30b2ae58ac36b72404052b4b63', 'whole failed archive external pin')
require(parts['archive'] == {'bytes': len(archive_bytes), 'sha256': digest, 'name': STEM + '.tgz'},
        'whole archive receipt')
expected = {**receipt['files'], 'inventory.json': receipt['inventory_sha256']}
require('inventory.json' not in receipt['files'], 'inventory must be separately pinned')
actual = {}
with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode='r:gz') as archive:
    for entry in archive:
        path = PurePosixPath(entry.name)
        require(entry.isfile() and not path.is_absolute() and '..' not in path.parts
                and path.as_posix() == entry.name and entry.name not in actual, 'unsafe/duplicate member')
        actual[entry.name] = hashlib.file_digest(archive.extractfile(entry), 'sha256').hexdigest()
require(len(actual) == 213 and actual == expected, 'all committed member hashes')
require(receipt['original_exit'] == 1 and receipt['original_handle'] == 21014, 'failure receipt')
print(json.dumps({'commit': COMMIT, 'parts_verified': 4, 'regular_members_verified': 213,
                  'archive_sha256': digest, 'original_automation': 'FAIL', 'extracted_or_executed': False}))

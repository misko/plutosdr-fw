"""Read-only immutable Git check of the exact prelaunch v2 package."""
import hashlib
import io
import json
from pathlib import PurePosixPath
import subprocess
import tarfile

REPO = '/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic'
COMMIT = 'adfaa08bdb8455877a7bbce0175a2ea640fc64f9'
STEM = 'reports/experiments/20260910-inverse-sealed-actual-preparation-v2'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def blob(suffix):
    return subprocess.check_output(['git', '-C', REPO, 'show', COMMIT + ':' + STEM + suffix])


receipt = json.loads(blob('.json'))
data = blob('.tgz')
digest = hashlib.sha256(data).hexdigest()
require(len(data) == 218653 and digest ==
        'a738e8ef3b0af72ee97cc50357318c1b61faae053486d8658329f217cf2c8063', 'external package pin')
expected = {**receipt['files'], 'inventory.json': receipt['inventory_sha256']}
require('inventory.json' not in receipt['files'], 'separate inventory')
actual = {}
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive:
        path = PurePosixPath(member.name)
        require(member.isfile() and not path.is_absolute() and '..' not in path.parts
                and path.as_posix() == member.name and member.name not in actual, 'unsafe/duplicate member')
        actual[member.name] = hashlib.file_digest(archive.extractfile(member), 'sha256').hexdigest()
require(len(actual) == 73 and actual == expected, 'complete prelaunch inventory')
print(json.dumps({'commit': COMMIT, 'archive_sha256': digest,
                  'regular_members_verified': 73, 'vendor_or_extraction_executed': False}))

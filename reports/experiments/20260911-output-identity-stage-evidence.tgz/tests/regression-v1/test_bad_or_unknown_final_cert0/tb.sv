`timescale 1ns/1ps
module tb;
reg clk=0,resetn=0,valid=0,last=0,certificate=1;
always #5 clk=~clk;
reg [1:0] position=0;
wire ready,fault,current_fault,request,output_valid;
starlink_pss_product_mailbox_staged_identity #(.ADDRESS_WIDTH(2),.RESET_RELEASE_EXTERNAL(1),.EXPLICIT_COMMIT(1)) dut(
 .input_clk(clk),.input_resetn(resetn),.input_valid(valid),.input_ready(ready),
 .input_commit_authorized(current_fault===1'b0),.input_data(36'h123456),.input_position(position),
 .input_last(last),.input_metadata(70'h12345),.input_metadata_certified(certificate),
 .input_fault(fault),.input_framing_fault_now(current_fault),.output_clk(clk),.output_resetn(resetn),
 .output_valid(output_valid),.output_ready(1'b0),.owner_request(request));
integer i;
initial begin
 repeat(3)@(negedge clk);resetn=1;
 for(i=0;i<4;i=i+1)begin
  @(negedge clk);valid=1;position=i;last=i==3;
  if(i==3)certificate=1'b0;
  #1;if(!ready || (i==3 && current_fault!==1))$fatal(1,"final certificate not rejected immediately");
  @(posedge clk);#1;
 end
 @(negedge clk);valid=0;
 repeat(10)@(negedge clk);
 if(!fault || request || output_valid)$fatal(1,"bad final certificate published");
 $display("BAD_FINAL_1'b0_REJECTED");$finish;
end
initial begin #1000;$fatal(1,"deadline");end
endmodule

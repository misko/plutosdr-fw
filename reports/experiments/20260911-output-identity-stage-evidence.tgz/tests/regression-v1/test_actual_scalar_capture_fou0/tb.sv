`timescale 1ns/1ps
module tb;
reg fft_clk=0,fast_running=0,retained_reserved_known=1,preparation_fault_now=0;
reg [31:0] INPUT_OFFER_FAULT_SUMMARY=1,CONTEXTUAL_DESTINATION_SUMMARY=1;
reg [18:0] admission_reject=0;
reg external_fault_now=0,forward_fault_now=0,inverse_fault_now=0;
wire offered_external_fault_now=|admission_reject[7:0];
wire [1:0] guard_offered_local_fault=admission_reject[9:8];
wire output_bank_fault=admission_reject[10];
wire output_bank_framing_fault_now=admission_reject[11];
wire [5:0] summary_preflight_events=admission_reject[17:12];
wire result_fault=admission_reject[18];
  wire original_common_current_fault = external_fault_now || forward_fault_now || inverse_fault_now ||
    output_bank_fault || output_bank_framing_fault_now || preparation_fault_now || result_fault;
  wire offered_common_current_fault = offered_external_fault_now ||
    guard_offered_local_fault[0] || guard_offered_local_fault[1] ||
    output_bank_fault || output_bank_framing_fault_now || preparation_fault_now || result_fault;
  wire destination_original_common = external_fault_now || forward_fault_now || inverse_fault_now ||
    output_bank_fault || output_bank_framing_fault_now || (|summary_preflight_events) || result_fault;
  wire destination_offered_common = offered_external_fault_now ||
    guard_offered_local_fault[0] || guard_offered_local_fault[1] ||
    output_bank_fault || output_bank_framing_fault_now || (|summary_preflight_events) || result_fault;
  wire contextual_destination_common = (fast_running === 1'b1 && retained_reserved_known) ?
    (INPUT_OFFER_FAULT_SUMMARY ? destination_offered_common : destination_original_common) :
    (INPUT_OFFER_FAULT_SUMMARY ? offered_common_current_fault : original_common_current_fault);
wire any_fast_fault=(CONTEXTUAL_DESTINATION_SUMMARY === 0) ?
 (INPUT_OFFER_FAULT_SUMMARY ? offered_common_current_fault : original_common_current_fault) :
 contextual_destination_common;
reg fast_fault;
reg original_fault;
  // BEGIN SCALAR FAULT SOURCES
  // Flatten the checked cause expression BEFORE the original scalar register.
  // Keep its original synchronous reset, capture edge and direct CDC source.
  // Current publication vetoes and unsupported/unknown fallback are unchanged.
  wire [18:0] sticky_fault_sources =
    ((INPUT_OFFER_FAULT_SUMMARY === 1) &&
     (CONTEXTUAL_DESTINATION_SUMMARY === 1) &&
     (retained_reserved_known === 1'b1)) ?
    {admission_reject[18],
     ((fast_running === 1'b1) ? summary_preflight_events : {5'b0,preparation_fault_now}),
     admission_reject[11:0]} : {18'b0,any_fast_fault};
  always @(posedge fft_clk)
    if (!fast_running) fast_fault <= 0;
    else if (|sticky_fault_sources) fast_fault <= 1;
  // END SCALAR FAULT SOURCES

always @(posedge fft_clk)
 if(!fast_running)original_fault<=0;
 else if(any_fast_fault)original_fault<=1;
function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
function [31:0] mode(input integer n);case(n)0:mode=0;1:mode=1;2:mode=32'bx;3:mode=32'bz;endcase endfunction
integer a,b,k,r,p,c,v,n,checks=0,resets=0,sets=0;
task tick;begin
 #1;
 if((|sticky_fault_sources)!==any_fast_fault)$fatal(1,"source partition mismatch checks=%0d",checks);
 fft_clk=1;#1;
 if(fast_fault!==original_fault)$fatal(1,"sticky edge/persistence mismatch checks=%0d",checks);
 if(fast_running===0)resets=resets+1;
 else if(any_fast_fault===1)sets=sets+1;
 checks=checks+1;fft_clk=0;
end endtask
initial begin
 tick;
 for(a=0;a<4;a=a+1)for(b=0;b<4;b=b+1)for(k=0;k<4;k=k+1)
 for(r=0;r<4;r=r+1)for(p=0;p<4;p=p+1)for(c=0;c<19;c=c+1)for(v=0;v<4;v=v+1)begin
   INPUT_OFFER_FAULT_SUMMARY=mode(a);CONTEXTUAL_DESTINATION_SUMMARY=mode(b);
   retained_reserved_known=val(k);preparation_fault_now=val(p);
   external_fault_now=0;forward_fault_now=0;inverse_fault_now=0;
   admission_reject=0;fast_running=0;tick;
   admission_reject[c]=val(v);fast_running=val(r);tick;
   // A known fault must dominate unrelated unknown causes.
   admission_reject[(c+1)%19]=1'b1;admission_reject[(c+2)%19]=1'bx;tick;
   // Fault disappearance may not clear sticky capture.
   admission_reject=0;preparation_fault_now=0;tick;
 end
 for(n=0;n<2000;n=n+1)begin
   INPUT_OFFER_FAULT_SUMMARY=mode($random&3);CONTEXTUAL_DESTINATION_SUMMARY=mode($random&3);
   retained_reserved_known=val($random&3);preparation_fault_now=val($random&3);
   external_fault_now=val($random&3);forward_fault_now=val($random&3);inverse_fault_now=val($random&3);
   fast_running=val($random&3);
   for(c=0;c<19;c=c+1)admission_reject[c]=val($random&3);
   tick;
 end
 $display("DISTRIBUTED_STICKY_CONTRACT_PASS checks=%0d resets=%0d sets=%0d same_edge=1 four_state=1",checks,resets,sets);$finish;
end
endmodule

`timescale 1ns/1ps
module tb;
localparam D=70, T=32, E=T+D+9, W=3*D+5*T+24, N=17;
reg clk=0;
always #5 clk=~clk;
reg resetn=0,abort_epoch=0,allocate_valid=0,commit_valid=0,release_valid=0,lookup_valid=0;
reg [D-1:0] allocate_descriptor=0;
reg [T-1:0] commit_tag=0,release_tag=0,lookup_tag=0;
wire allocate_ready,fault,lookup_found,lookup_committed,tags_exhausted;
wire [T-1:0] allocate_tag;
wire [D-1:0] lookup_descriptor;
wire [1:0] occupied,committed;
starlink_pss_descriptor_slots #(.TAG_WIDTH(T)) dut(.*);
wire [E-1:0] observed={allocate_ready,allocate_tag,fault,occupied,committed,tags_exhausted,lookup_found,lookup_committed,lookup_descriptor};
reg [W-1:0] vectors[0:N-1];
reg [E-1:0] expected_before,expected_after;
integer row;
initial begin
  $readmemh("/dev/shm/starlink-output-identity.zBgwcqOX/regression-v1/test_bad_event_quarantines_wit0/vectors.mem",vectors);
  for(row=0;row<N;row=row+1) begin
    @(negedge clk);
    {resetn,abort_epoch,allocate_valid,allocate_descriptor,commit_valid,commit_tag,release_valid,release_tag,lookup_valid,lookup_tag,expected_before,expected_after}=vectors[row];
    #1;
    if(observed!==expected_before) $fatal(1,"PRE row=%0d actual=%h expected=%h",row,observed,expected_before);
    @(posedge clk);#0.1;
    abort_epoch=0;allocate_valid=0;commit_valid=0;release_valid=0;
    #0.1;
    if(observed!==expected_after) $fatal(1,"POST row=%0d actual=%h expected=%h",row,observed,expected_after);
  end
  $display("SLOTS_PASS rows=%0d",N);$finish(0);
end
endmodule

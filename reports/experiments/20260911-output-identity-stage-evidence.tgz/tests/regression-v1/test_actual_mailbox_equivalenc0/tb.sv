`timescale 1ns/1ps
module tb;
reg clk=0,resetn=0,valid=0,last=0,authorize=0,consume=0,select_replay=0,force_comparison=0;
reg [35:0] data=0;
reg [1:0] position=0;
reg [36:0] live_metadata=37'h123456789,replay_metadata=37'h123456789;
wire [36:0] selected_metadata=select_replay ? replay_metadata : live_metadata;
wire a_ready,a_fault,a_framing,a_valid,a_last,a_request,a_ack,a_writer_idle,a_reader_idle;
wire b_ready,b_fault,b_framing,b_valid,b_last,b_request,b_ack,b_writer_idle,b_reader_idle;
wire [35:0] a_data,b_data;wire [1:0] a_position,b_position;wire [36:0] a_metadata,b_metadata;
starlink_pss_mailbox_owner_view #(.ADDRESS_WIDTH(2),.METADATA_WIDTH(37),.RESET_RELEASE_EXTERNAL(1),.EXPLICIT_COMMIT(1)) original (
 .input_clk(clk),.input_resetn(resetn),.input_valid(valid),.input_commit_authorized(authorize && !a_framing),.input_ready(a_ready),
 .input_data(data),.input_position(position),.input_last(last),.input_metadata(selected_metadata),.input_fault(a_fault),.input_framing_fault_now(a_framing),
 .output_clk(clk),.output_resetn(resetn),.output_valid(a_valid),.output_ready(consume),.output_data(a_data),
 .output_position(a_position),.output_last(a_last),.output_metadata(a_metadata),.owner_request(a_request),
 .owner_ack_sync(a_ack),.writer_reset_idle(a_writer_idle),.reader_reset_idle(a_reader_idle));
starlink_pss_mailbox_split_metadata_view #(.ADDRESS_WIDTH(2),.METADATA_WIDTH(37),.RESET_RELEASE_EXTERNAL(1),.EXPLICIT_COMMIT(1)) candidate (
 .input_clk(clk),.input_resetn(resetn),.input_valid(valid),.input_commit_authorized(authorize && !b_framing),.input_ready(b_ready),
 .input_data(data),.input_position(position),.input_last(last),.input_metadata_live(live_metadata),.input_metadata_replay(replay_metadata),.input_metadata_select(select_replay),.input_fault(b_fault),.input_framing_fault_now(b_framing),
 .output_clk(clk),.output_resetn(resetn),.output_valid(b_valid),.output_ready(consume),.output_data(b_data),
 .output_position(b_position),.output_last(b_last),.output_metadata(b_metadata),.owner_request(b_request),
 .owner_ack_sync(b_ack),.writer_reset_idle(b_writer_idle),.reader_reset_idle(b_reader_idle));
integer checks=0,reads=0,bad_cases=0,n,bitno,kind,side,where;
task compare;begin
 if({a_ready,a_fault,a_framing,a_valid,a_last,a_request,a_ack,a_writer_idle,a_reader_idle} !==
    {b_ready,b_fault,b_framing,b_valid,b_last,b_request,b_ack,b_writer_idle,b_reader_idle})
   $fatal(1,"public mailbox mismatch at %0d",checks);
 if((original.write_position!=0 || force_comparison) &&
    original.metadata_matches!==candidate.metadata_matches)$fatal(1,"current equality mismatch at %0d",checks);
 if(a_valid && {a_data,a_position,a_metadata}!=={b_data,b_position,b_metadata})$fatal(1,"reader payload mismatch");
 checks=checks+1;
end endtask
task tick;begin #1;compare;clk=1;#1;compare;clk=0;#1;end endtask
task restart;begin
 resetn=0;valid=0;consume=0;authorize=0;select_replay=0;
 live_metadata=37'h123456789;replay_metadata=37'h123456789;tick;tick;resetn=1;tick;
end endtask
task word(input integer p);begin valid=1;position=p;last=(p==3);data=p+100;tick;end endtask
task healthy;begin
 restart;for(n=0;n<4;n=n+1)word(n);
 // Unpublished LAST is held and rewritten, then replay chooses the same
 // descriptor and receives actual authorization. Reader must see all words.
 select_replay=1;repeat(4)tick;authorize=1;tick;valid=0;authorize=0;
 repeat(4)tick;consume=1;reads=0;
 repeat(12)begin if(a_valid)begin if(a_data!==a_position+100)$fatal(1,"wrong stored word");reads=reads+1;end tick;end
 if(reads!=4 || !a_ready || a_fault)$fatal(1,"healthy ownership did not recover");
end endtask
initial begin
 restart;healthy;
 // Each of 37 bits, both source branches, nonfinal and final positions,
 // known inversion/X/Z: no corrupted selected descriptor may publish.
 for(side=0;side<2;side=side+1)for(where=1;where<4;where=where+2)
 for(bitno=0;bitno<37;bitno=bitno+1)for(kind=0;kind<3;kind=kind+1)begin
  restart;for(n=0;n<where;n=n+1)word(n);
  select_replay=side;
  if(side==0)case(kind)0:live_metadata[bitno]=~live_metadata[bitno];1:live_metadata[bitno]=1'bx;2:live_metadata[bitno]=1'bz;endcase
  else case(kind)0:replay_metadata[bitno]=~replay_metadata[bitno];1:replay_metadata[bitno]=1'bx;2:replay_metadata[bitno]=1'bz;endcase
  authorize=1;word(where);valid=0;repeat(4)tick;
  if(a_request!==0 || b_request!==0)$fatal(1,"corruption published");bad_cases=bad_cases+1;
 end
 // Nonselected corruption cannot corrupt the currently selected transfer;
 // switching to it must restore the exact original failure predicate.
 restart;word(0);replay_metadata=0;word(1);select_replay=1;word(2);
 // Four-state selector is NOT distributive through equality. In particular
 // live=0/replay=3/held=1 produces X, not the merged equality result 0.
 restart;force_comparison=1;force original.metadata_in_hold=37'd1;force candidate.metadata_in_hold=37'd1;
 for(side=0;side<2;side=side+1)begin
  select_replay=side==0 ? 1'bx : 1'bz;
  live_metadata=0;replay_metadata=3;#1;compare;
  live_metadata=1;replay_metadata=1;#1;compare;
  live_metadata=1;replay_metadata=3;#1;compare;
 end
 release original.metadata_in_hold;release candidate.metadata_in_hold;force_comparison=0;
 healthy;
 // Reset cancels an unpublished final and returns both original ownership
 // views; new selected-first metadata is retained identically.
 restart;select_replay=1;live_metadata=0;for(n=0;n<4;n=n+1)word(n);restart;healthy;
 if(bad_cases!=444 || checks<5000)$fatal(1,"short split metadata campaign");
 $display("SPLIT_METADATA_MAILBOX_PASS checks=%0d corruptions=%0d exact_current=1 four_state=1 ownership=1 fresh_recovery=1",checks,bad_cases);$finish;
end
endmodule

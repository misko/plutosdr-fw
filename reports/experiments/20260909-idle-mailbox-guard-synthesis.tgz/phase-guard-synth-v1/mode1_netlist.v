// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2022.2 (lin64) Build 3671981 Fri Oct 14 04:59:54 MDT 2022
// Date        : Wed Sep  9 23:43:31 2026
// Host        : gauss running 64-bit Ubuntu 26.04 LTS
// Command     : write_verilog -mode funcsim /tmp/starlink-idle-mailbox.N0l1fN/phase-guard-synth-v1/mode1_netlist.v
// Design      : starlink_pss_realtime_result_guard
// Purpose     : This verilog netlist is a functional simulation representation of the design and should not be modified
//               or synthesized. This netlist cannot be used for SDF annotated simulation.
// Device      : xc7z010clg400-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* AGE_WIDTH = "13" *) (* NETLIST_CHECKSUM = "90036743" *) (* USE_IDLE_MAILBOX_FAULT = "0" *) 
(* USE_PHASE_INPUT_FAULT = "1" *) (* WATCHDOG_CYCLES = "8192" *) 
(* NotValidForBitStream *)
module starlink_pss_realtime_result_guard
   (clk,
    resetn,
    job_valid,
    job_ready,
    job_descriptor,
    input_bank_reserved,
    output_bank_reserved,
    certified_input_beat,
    certified_input_complete,
    final_fence_certified,
    external_fault_now,
    phase_input_fault_now,
    core_event_frame_started,
    core_output_tdata,
    core_output_tuser,
    core_output_tvalid,
    core_output_tlast,
    core_status_tdata,
    core_status_tvalid,
    mailbox_input_valid,
    mailbox_private_valid,
    mailbox_commit_valid,
    mailbox_input_ready,
    mailbox_input_fault,
    idle_mailbox_fault_now,
    mailbox_input_data,
    mailbox_input_position,
    mailbox_input_last,
    mailbox_input_metadata,
    busy,
    commit_pulse,
    protocol_fault,
    fault_reasons);
  input clk;
  input resetn;
  input job_valid;
  output job_ready;
  input [69:0]job_descriptor;
  input input_bank_reserved;
  input output_bank_reserved;
  input certified_input_beat;
  input certified_input_complete;
  input final_fence_certified;
  input external_fault_now;
  input phase_input_fault_now;
  input core_event_frame_started;
  input [47:0]core_output_tdata;
  input [23:0]core_output_tuser;
  input core_output_tvalid;
  input core_output_tlast;
  input [7:0]core_status_tdata;
  input core_status_tvalid;
  output mailbox_input_valid;
  output mailbox_private_valid;
  output mailbox_commit_valid;
  input mailbox_input_ready;
  input mailbox_input_fault;
  input idle_mailbox_fault_now;
  output [35:0]mailbox_input_data;
  output [8:0]mailbox_input_position;
  output mailbox_input_last;
  output [74:0]mailbox_input_metadata;
  output busy;
  output commit_pulse;
  output protocol_fault;
  output [7:0]fault_reasons;

  wire active_private_i_1_n_0;
  wire active_private_reg_n_0;
  wire [12:0]age_reg;
  wire \age_reg[0]_i_1_n_0 ;
  wire \age_reg[0]_i_1_n_4 ;
  wire \age_reg[0]_i_1_n_5 ;
  wire \age_reg[0]_i_1_n_6 ;
  wire \age_reg[0]_i_1_n_7 ;
  wire \age_reg[12]_i_1_n_7 ;
  wire \age_reg[4]_i_1_n_0 ;
  wire \age_reg[4]_i_1_n_4 ;
  wire \age_reg[4]_i_1_n_5 ;
  wire \age_reg[4]_i_1_n_6 ;
  wire \age_reg[4]_i_1_n_7 ;
  wire \age_reg[8]_i_1_n_0 ;
  wire \age_reg[8]_i_1_n_4 ;
  wire \age_reg[8]_i_1_n_5 ;
  wire \age_reg[8]_i_1_n_6 ;
  wire \age_reg[8]_i_1_n_7 ;
  wire awaiting_ack;
  wire awaiting_ack_i_1_n_0;
  wire busy;
  wire certified_input_beat;
  wire certified_input_complete;
  wire clk;
  wire commit_pulse;
  wire core_event_frame_started;
  wire [47:0]core_output_tdata;
  wire core_output_tlast;
  wire [23:0]core_output_tuser;
  wire core_output_tvalid;
  wire [7:0]core_status_tdata;
  wire core_status_tvalid;
  wire exponent_seen;
  wire exponent_seen_i_1_n_0;
  wire external_fault_now;
  wire [7:0]fault_reasons;
  wire \fault_reasons[0]_i_1_n_0 ;
  wire \fault_reasons[1]_i_1_n_0 ;
  wire \fault_reasons[2]_i_1_n_0 ;
  wire \fault_reasons[3]_i_1_n_0 ;
  wire \fault_reasons[4]_i_1_n_0 ;
  wire \fault_reasons[5]_i_1_n_0 ;
  wire \fault_reasons[6]_i_1_n_0 ;
  wire \fault_reasons[7]_i_1_n_0 ;
  wire final_fence_certified;
  wire frame_seen_i_1_n_0;
  wire frame_seen_reg_n_0;
  wire input_bank_reserved;
  wire input_complete_seen_i_1_n_0;
  wire input_complete_seen_reg_n_0;
  wire [9:0]input_count;
  wire \input_count[6]_i_1_n_0 ;
  wire \input_count[7]_i_1_n_0 ;
  wire \input_count[8]_i_1_n_0 ;
  wire \input_count[9]_i_1_n_0 ;
  wire [69:0]job_descriptor;
  wire job_ready;
  wire job_valid;
  wire [35:0]mailbox_input_data;
  wire mailbox_input_fault;
  wire mailbox_input_last;
  wire [74:0]mailbox_input_metadata;
  wire [8:0]mailbox_input_position;
  wire mailbox_input_ready;
  wire mailbox_input_valid;
  wire mailbox_private_valid;
  wire output_bank_reserved;
  wire [9:0]output_count;
  wire \output_count[0]_i_1_n_0 ;
  wire \output_count[1]_i_1_n_0 ;
  wire \output_count[2]_i_1_n_0 ;
  wire \output_count[3]_i_1_n_0 ;
  wire \output_count[4]_i_1_n_0 ;
  wire \output_count[5]_i_1_n_0 ;
  wire \output_count[6]_i_1_n_0 ;
  wire \output_count[7]_i_1_n_0 ;
  wire \output_count[8]_i_1_n_0 ;
  wire \output_count[9]_i_1_n_0 ;
  wire \output_count[9]_i_2_n_0 ;
  wire output_error5;
  wire output_exponent;
  wire \output_exponent_reg_n_0_[0] ;
  wire \output_exponent_reg_n_0_[1] ;
  wire \output_exponent_reg_n_0_[2] ;
  wire \output_exponent_reg_n_0_[3] ;
  wire \output_exponent_reg_n_0_[4] ;
  wire [9:0]p_1_in;
  wire phase_input_fault_now;
  wire protocol_fault;
  wire resetn;
  wire \return_data[35]_i_2_n_0 ;
  wire return_occupied_i_1_n_0;
  wire return_occupied_reg_n_0;
  wire starlink_pss_re_net;
  wire starlink_pss_re_net_10;
  wire starlink_pss_re_net_11;
  wire starlink_pss_re_net_12;
  wire starlink_pss_re_net_13;
  wire starlink_pss_re_net_14;
  wire starlink_pss_re_net_15;
  wire starlink_pss_re_net_16;
  wire starlink_pss_re_net_17;
  wire starlink_pss_re_net_18;
  wire starlink_pss_re_net_19;
  wire starlink_pss_re_net_2;
  wire starlink_pss_re_net_20;
  wire starlink_pss_re_net_21;
  wire starlink_pss_re_net_22;
  wire starlink_pss_re_net_23;
  wire starlink_pss_re_net_24;
  wire starlink_pss_re_net_25;
  wire starlink_pss_re_net_26;
  wire starlink_pss_re_net_27;
  wire starlink_pss_re_net_28;
  wire starlink_pss_re_net_29;
  wire starlink_pss_re_net_3;
  wire starlink_pss_re_net_30;
  wire starlink_pss_re_net_31;
  wire starlink_pss_re_net_32;
  wire starlink_pss_re_net_33;
  wire starlink_pss_re_net_34;
  wire starlink_pss_re_net_35;
  wire starlink_pss_re_net_36;
  wire starlink_pss_re_net_37;
  wire starlink_pss_re_net_38;
  wire starlink_pss_re_net_39;
  wire starlink_pss_re_net_4;
  wire starlink_pss_re_net_40;
  wire starlink_pss_re_net_41;
  wire starlink_pss_re_net_42;
  wire starlink_pss_re_net_43;
  wire starlink_pss_re_net_44;
  wire starlink_pss_re_net_45;
  wire starlink_pss_re_net_46;
  wire starlink_pss_re_net_47;
  wire starlink_pss_re_net_48;
  wire starlink_pss_re_net_49;
  wire starlink_pss_re_net_5;
  wire starlink_pss_re_net_50;
  wire starlink_pss_re_net_51;
  wire starlink_pss_re_net_52;
  wire starlink_pss_re_net_53;
  wire starlink_pss_re_net_54;
  wire starlink_pss_re_net_55;
  wire starlink_pss_re_net_56;
  wire starlink_pss_re_net_57;
  wire starlink_pss_re_net_58;
  wire starlink_pss_re_net_59;
  wire starlink_pss_re_net_6;
  wire starlink_pss_re_net_60;
  wire starlink_pss_re_net_61;
  wire starlink_pss_re_net_62;
  wire starlink_pss_re_net_63;
  wire starlink_pss_re_net_64;
  wire starlink_pss_re_net_65;
  wire starlink_pss_re_net_66;
  wire starlink_pss_re_net_67;
  wire starlink_pss_re_net_68;
  wire starlink_pss_re_net_69;
  wire starlink_pss_re_net_7;
  wire starlink_pss_re_net_8;
  wire starlink_pss_re_net_9;
  wire \status_exponent_reg_n_0_[0] ;
  wire \status_exponent_reg_n_0_[1] ;
  wire \status_exponent_reg_n_0_[2] ;
  wire \status_exponent_reg_n_0_[3] ;
  wire \status_exponent_reg_n_0_[4] ;
  wire status_seen_i_1_n_0;
  wire status_seen_reg_n_0;
  wire [2:0]\NLW_age_reg[0]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_age_reg[12]_i_1_CO_UNCONNECTED ;
  wire [3:1]\NLW_age_reg[12]_i_1_O_UNCONNECTED ;
  wire [2:0]\NLW_age_reg[4]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_age_reg[8]_i_1_CO_UNCONNECTED ;
  wire [3:0]NLW_mailbox_input_valid_INST_0_i_23_CO_UNCONNECTED;
  wire [3:0]NLW_mailbox_input_valid_INST_0_i_23_O_UNCONNECTED;

  assign mailbox_commit_valid = starlink_pss_re_net_41;
  FDCE active_private_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(active_private_i_1_n_0),
        .Q(active_private_reg_n_0));
  FDCE \age_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[0]_i_1_n_7 ),
        .Q(age_reg[0]));
  (* ADDER_THRESHOLD = "11" *) 
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 \age_reg[0]_i_1 
       (.CI(1'b0),
        .CO({\age_reg[0]_i_1_n_0 ,\NLW_age_reg[0]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,starlink_pss_re_net_2}),
        .O({\age_reg[0]_i_1_n_4 ,\age_reg[0]_i_1_n_5 ,\age_reg[0]_i_1_n_6 ,\age_reg[0]_i_1_n_7 }),
        .S({starlink_pss_re_net_60,starlink_pss_re_net_59,starlink_pss_re_net_58,starlink_pss_re_net_57}));
  FDCE \age_reg[10] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[8]_i_1_n_5 ),
        .Q(age_reg[10]));
  FDCE \age_reg[11] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[8]_i_1_n_4 ),
        .Q(age_reg[11]));
  FDCE \age_reg[12] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[12]_i_1_n_7 ),
        .Q(age_reg[12]));
  (* ADDER_THRESHOLD = "11" *) 
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 \age_reg[12]_i_1 
       (.CI(\age_reg[8]_i_1_n_0 ),
        .CO(\NLW_age_reg[12]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\NLW_age_reg[12]_i_1_O_UNCONNECTED [3:1],\age_reg[12]_i_1_n_7 }),
        .S({1'b0,1'b0,1'b0,starlink_pss_re_net_69}));
  FDCE \age_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[0]_i_1_n_6 ),
        .Q(age_reg[1]));
  FDCE \age_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[0]_i_1_n_5 ),
        .Q(age_reg[2]));
  FDCE \age_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[0]_i_1_n_4 ),
        .Q(age_reg[3]));
  FDCE \age_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[4]_i_1_n_7 ),
        .Q(age_reg[4]));
  (* ADDER_THRESHOLD = "11" *) 
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 \age_reg[4]_i_1 
       (.CI(\age_reg[0]_i_1_n_0 ),
        .CO({\age_reg[4]_i_1_n_0 ,\NLW_age_reg[4]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\age_reg[4]_i_1_n_4 ,\age_reg[4]_i_1_n_5 ,\age_reg[4]_i_1_n_6 ,\age_reg[4]_i_1_n_7 }),
        .S({starlink_pss_re_net_64,starlink_pss_re_net_63,starlink_pss_re_net_62,starlink_pss_re_net_61}));
  FDCE \age_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[4]_i_1_n_6 ),
        .Q(age_reg[5]));
  FDCE \age_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[4]_i_1_n_5 ),
        .Q(age_reg[6]));
  FDCE \age_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[4]_i_1_n_4 ),
        .Q(age_reg[7]));
  FDCE \age_reg[8] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[8]_i_1_n_7 ),
        .Q(age_reg[8]));
  (* ADDER_THRESHOLD = "11" *) 
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 \age_reg[8]_i_1 
       (.CI(\age_reg[4]_i_1_n_0 ),
        .CO({\age_reg[8]_i_1_n_0 ,\NLW_age_reg[8]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\age_reg[8]_i_1_n_4 ,\age_reg[8]_i_1_n_5 ,\age_reg[8]_i_1_n_6 ,\age_reg[8]_i_1_n_7 }),
        .S({starlink_pss_re_net_68,starlink_pss_re_net_67,starlink_pss_re_net_66,starlink_pss_re_net_65}));
  FDCE \age_reg[9] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\age_reg[8]_i_1_n_6 ),
        .Q(age_reg[9]));
  FDCE awaiting_ack_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(awaiting_ack_i_1_n_0),
        .Q(awaiting_ack));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE commit_pulse_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(starlink_pss_re_net_48),
        .Q(commit_pulse));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[0] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[0]),
        .Q(mailbox_input_metadata[5]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[10] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[10]),
        .Q(mailbox_input_metadata[15]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[11] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[11]),
        .Q(mailbox_input_metadata[16]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[12] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[12]),
        .Q(mailbox_input_metadata[17]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[13] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[13]),
        .Q(mailbox_input_metadata[18]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[14] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[14]),
        .Q(mailbox_input_metadata[19]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[15] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[15]),
        .Q(mailbox_input_metadata[20]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[16] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[16]),
        .Q(mailbox_input_metadata[21]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[17] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[17]),
        .Q(mailbox_input_metadata[22]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[18] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[18]),
        .Q(mailbox_input_metadata[23]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[19] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[19]),
        .Q(mailbox_input_metadata[24]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[1] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[1]),
        .Q(mailbox_input_metadata[6]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[20] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[20]),
        .Q(mailbox_input_metadata[25]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[21] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[21]),
        .Q(mailbox_input_metadata[26]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[22] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[22]),
        .Q(mailbox_input_metadata[27]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[23] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[23]),
        .Q(mailbox_input_metadata[28]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[24] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[24]),
        .Q(mailbox_input_metadata[29]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[25] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[25]),
        .Q(mailbox_input_metadata[30]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[26] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[26]),
        .Q(mailbox_input_metadata[31]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[27] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[27]),
        .Q(mailbox_input_metadata[32]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[28] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[28]),
        .Q(mailbox_input_metadata[33]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[29] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[29]),
        .Q(mailbox_input_metadata[34]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[2] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[2]),
        .Q(mailbox_input_metadata[7]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[30] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[30]),
        .Q(mailbox_input_metadata[35]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[31] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[31]),
        .Q(mailbox_input_metadata[36]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[32] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[32]),
        .Q(mailbox_input_metadata[37]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[33] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[33]),
        .Q(mailbox_input_metadata[38]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[34] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[34]),
        .Q(mailbox_input_metadata[39]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[35] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[35]),
        .Q(mailbox_input_metadata[40]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[36] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[36]),
        .Q(mailbox_input_metadata[41]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[37] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[37]),
        .Q(mailbox_input_metadata[42]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[38] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[38]),
        .Q(mailbox_input_metadata[43]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[39] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[39]),
        .Q(mailbox_input_metadata[44]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[3] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[3]),
        .Q(mailbox_input_metadata[8]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[40] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[40]),
        .Q(mailbox_input_metadata[45]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[41] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[41]),
        .Q(mailbox_input_metadata[46]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[42] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[42]),
        .Q(mailbox_input_metadata[47]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[43] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[43]),
        .Q(mailbox_input_metadata[48]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[44] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[44]),
        .Q(mailbox_input_metadata[49]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[45] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[45]),
        .Q(mailbox_input_metadata[50]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[46] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[46]),
        .Q(mailbox_input_metadata[51]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[47] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[47]),
        .Q(mailbox_input_metadata[52]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[48] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[48]),
        .Q(mailbox_input_metadata[53]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[49] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[49]),
        .Q(mailbox_input_metadata[54]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[4] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[4]),
        .Q(mailbox_input_metadata[9]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[50] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[50]),
        .Q(mailbox_input_metadata[55]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[51] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[51]),
        .Q(mailbox_input_metadata[56]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[52] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[52]),
        .Q(mailbox_input_metadata[57]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[53] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[53]),
        .Q(mailbox_input_metadata[58]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[54] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[54]),
        .Q(mailbox_input_metadata[59]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[55] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[55]),
        .Q(mailbox_input_metadata[60]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[56] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[56]),
        .Q(mailbox_input_metadata[61]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[57] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[57]),
        .Q(mailbox_input_metadata[62]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[58] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[58]),
        .Q(mailbox_input_metadata[63]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[59] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[59]),
        .Q(mailbox_input_metadata[64]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[5] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[5]),
        .Q(mailbox_input_metadata[10]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[60] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[60]),
        .Q(mailbox_input_metadata[65]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[61] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[61]),
        .Q(mailbox_input_metadata[66]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[62] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[62]),
        .Q(mailbox_input_metadata[67]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[63] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[63]),
        .Q(mailbox_input_metadata[68]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[64] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[64]),
        .Q(mailbox_input_metadata[69]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[65] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[65]),
        .Q(mailbox_input_metadata[70]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[66] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[66]),
        .Q(mailbox_input_metadata[71]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[67] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[67]),
        .Q(mailbox_input_metadata[72]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[68] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[68]),
        .Q(mailbox_input_metadata[73]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[69] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[69]),
        .Q(mailbox_input_metadata[74]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[6] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[6]),
        .Q(mailbox_input_metadata[11]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[7] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[7]),
        .Q(mailbox_input_metadata[12]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[8] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[8]),
        .Q(mailbox_input_metadata[13]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \descriptor_reg[9] 
       (.C(clk),
        .CE(starlink_pss_re_net_47),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(job_descriptor[9]),
        .Q(mailbox_input_metadata[14]));
  FDCE exponent_seen_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(exponent_seen_i_1_n_0),
        .Q(exponent_seen));
  FDCE \fault_reasons_reg[0] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[0]_i_1_n_0 ),
        .Q(fault_reasons[0]));
  FDCE \fault_reasons_reg[1] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[1]_i_1_n_0 ),
        .Q(fault_reasons[1]));
  FDCE \fault_reasons_reg[2] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[2]_i_1_n_0 ),
        .Q(fault_reasons[2]));
  FDCE \fault_reasons_reg[3] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[3]_i_1_n_0 ),
        .Q(fault_reasons[3]));
  FDCE \fault_reasons_reg[4] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[4]_i_1_n_0 ),
        .Q(fault_reasons[4]));
  FDCE \fault_reasons_reg[5] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[5]_i_1_n_0 ),
        .Q(fault_reasons[5]));
  FDCE \fault_reasons_reg[6] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[6]_i_1_n_0 ),
        .Q(fault_reasons[6]));
  FDCE \fault_reasons_reg[7] 
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\fault_reasons[7]_i_1_n_0 ),
        .Q(fault_reasons[7]));
  FDCE frame_seen_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(frame_seen_i_1_n_0),
        .Q(frame_seen_reg_n_0));
  FDCE input_complete_seen_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(input_complete_seen_i_1_n_0),
        .Q(input_complete_seen_reg_n_0));
  FDCE \input_count_reg[0] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[0]),
        .Q(input_count[0]));
  FDCE \input_count_reg[1] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[1]),
        .Q(input_count[1]));
  FDCE \input_count_reg[2] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[2]),
        .Q(input_count[2]));
  FDCE \input_count_reg[3] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[3]),
        .Q(input_count[3]));
  FDCE \input_count_reg[4] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[4]),
        .Q(input_count[4]));
  FDCE \input_count_reg[5] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[5]),
        .Q(input_count[5]));
  FDCE \input_count_reg[6] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\input_count[6]_i_1_n_0 ),
        .Q(input_count[6]));
  FDCE \input_count_reg[7] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\input_count[7]_i_1_n_0 ),
        .Q(input_count[7]));
  FDCE \input_count_reg[8] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\input_count[8]_i_1_n_0 ),
        .Q(input_count[8]));
  FDCE \input_count_reg[9] 
       (.C(clk),
        .CE(\input_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(p_1_in[9]),
        .Q(input_count[9]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  CARRY4 mailbox_input_valid_INST_0_i_23
       (.CI(1'b0),
        .CO({NLW_mailbox_input_valid_INST_0_i_23_CO_UNCONNECTED[3],output_error5,NLW_mailbox_input_valid_INST_0_i_23_CO_UNCONNECTED[1:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b1,1'b1,1'b1}),
        .O(NLW_mailbox_input_valid_INST_0_i_23_O_UNCONNECTED[3:0]),
        .S({1'b0,starlink_pss_re_net_56,starlink_pss_re_net_55,starlink_pss_re_net_54}));
  FDCE \output_count_reg[0] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[0]_i_1_n_0 ),
        .Q(output_count[0]));
  FDCE \output_count_reg[1] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[1]_i_1_n_0 ),
        .Q(output_count[1]));
  FDCE \output_count_reg[2] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[2]_i_1_n_0 ),
        .Q(output_count[2]));
  FDCE \output_count_reg[3] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[3]_i_1_n_0 ),
        .Q(output_count[3]));
  FDCE \output_count_reg[4] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[4]_i_1_n_0 ),
        .Q(output_count[4]));
  FDCE \output_count_reg[5] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[5]_i_1_n_0 ),
        .Q(output_count[5]));
  FDCE \output_count_reg[6] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[6]_i_1_n_0 ),
        .Q(output_count[6]));
  FDCE \output_count_reg[7] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[7]_i_1_n_0 ),
        .Q(output_count[7]));
  FDCE \output_count_reg[8] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[8]_i_1_n_0 ),
        .Q(output_count[8]));
  FDCE \output_count_reg[9] 
       (.C(clk),
        .CE(\output_count[9]_i_1_n_0 ),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(\output_count[9]_i_2_n_0 ),
        .Q(output_count[9]));
  FDCE \output_exponent_reg[0] 
       (.C(clk),
        .CE(output_exponent),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[16]),
        .Q(\output_exponent_reg_n_0_[0] ));
  FDCE \output_exponent_reg[1] 
       (.C(clk),
        .CE(output_exponent),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[17]),
        .Q(\output_exponent_reg_n_0_[1] ));
  FDCE \output_exponent_reg[2] 
       (.C(clk),
        .CE(output_exponent),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[18]),
        .Q(\output_exponent_reg_n_0_[2] ));
  FDCE \output_exponent_reg[3] 
       (.C(clk),
        .CE(output_exponent),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[19]),
        .Q(\output_exponent_reg_n_0_[3] ));
  FDCE \output_exponent_reg[4] 
       (.C(clk),
        .CE(output_exponent),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[20]),
        .Q(\output_exponent_reg_n_0_[4] ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[0] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[0]),
        .Q(mailbox_input_data[0]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[10] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[10]),
        .Q(mailbox_input_data[10]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[11] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[11]),
        .Q(mailbox_input_data[11]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[12] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[12]),
        .Q(mailbox_input_data[12]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[13] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[13]),
        .Q(mailbox_input_data[13]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[14] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[14]),
        .Q(mailbox_input_data[14]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[15] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[15]),
        .Q(mailbox_input_data[15]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[16] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[16]),
        .Q(mailbox_input_data[16]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[17] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[17]),
        .Q(mailbox_input_data[17]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[18] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[24]),
        .Q(mailbox_input_data[18]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[19] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[25]),
        .Q(mailbox_input_data[19]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[1] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[1]),
        .Q(mailbox_input_data[1]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[20] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[26]),
        .Q(mailbox_input_data[20]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[21] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[27]),
        .Q(mailbox_input_data[21]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[22] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[28]),
        .Q(mailbox_input_data[22]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[23] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[29]),
        .Q(mailbox_input_data[23]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[24] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[30]),
        .Q(mailbox_input_data[24]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[25] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[31]),
        .Q(mailbox_input_data[25]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[26] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[32]),
        .Q(mailbox_input_data[26]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[27] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[33]),
        .Q(mailbox_input_data[27]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[28] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[34]),
        .Q(mailbox_input_data[28]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[29] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[35]),
        .Q(mailbox_input_data[29]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[2] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[2]),
        .Q(mailbox_input_data[2]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[30] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[36]),
        .Q(mailbox_input_data[30]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[31] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[37]),
        .Q(mailbox_input_data[31]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[32] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[38]),
        .Q(mailbox_input_data[32]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[33] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[39]),
        .Q(mailbox_input_data[33]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[34] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[40]),
        .Q(mailbox_input_data[34]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[35] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[41]),
        .Q(mailbox_input_data[35]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[3] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[3]),
        .Q(mailbox_input_data[3]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[4] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[4]),
        .Q(mailbox_input_data[4]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[5] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[5]),
        .Q(mailbox_input_data[5]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[6] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[6]),
        .Q(mailbox_input_data[6]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[7] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[7]),
        .Q(mailbox_input_data[7]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[8] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[8]),
        .Q(mailbox_input_data[8]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_data_reg[9] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tdata[9]),
        .Q(mailbox_input_data[9]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_exponent_reg[0] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[16]),
        .Q(mailbox_input_metadata[0]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_exponent_reg[1] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[17]),
        .Q(mailbox_input_metadata[1]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_exponent_reg[2] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[18]),
        .Q(mailbox_input_metadata[2]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_exponent_reg[3] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[19]),
        .Q(mailbox_input_metadata[3]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_exponent_reg[4] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[20]),
        .Q(mailbox_input_metadata[4]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE return_last_reg
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tlast),
        .Q(mailbox_input_last));
  FDCE return_occupied_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(return_occupied_i_1_n_0),
        .Q(return_occupied_reg_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[0] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[0]),
        .Q(mailbox_input_position[0]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[1] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[1]),
        .Q(mailbox_input_position[1]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[2] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[2]),
        .Q(mailbox_input_position[2]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[3] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[3]),
        .Q(mailbox_input_position[3]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[4] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[4]),
        .Q(mailbox_input_position[4]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[5] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[5]),
        .Q(mailbox_input_position[5]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[6] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[6]),
        .Q(mailbox_input_position[6]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[7] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[7]),
        .Q(mailbox_input_position[7]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \return_position_reg[8] 
       (.C(clk),
        .CE(starlink_pss_re_net_50),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_output_tuser[8]),
        .Q(mailbox_input_position[8]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT1 #(
    .INIT(2'h1)) 
    starlink_pss_re_LUT1_21
       (.I0(resetn),
        .O(\return_data[35]_i_2_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h2)) 
    starlink_pss_re_LUT2
       (.I0(active_private_reg_n_0),
        .I1(protocol_fault),
        .O(starlink_pss_re_net_2));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_1
       (.I0(awaiting_ack),
        .I1(starlink_pss_re_net_2),
        .O(busy));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_10
       (.I0(age_reg[3]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_60));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_11
       (.I0(age_reg[4]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_61));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_12
       (.I0(age_reg[5]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_62));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_13
       (.I0(age_reg[6]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_63));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_14
       (.I0(age_reg[7]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_64));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_15
       (.I0(age_reg[8]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_65));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_16
       (.I0(age_reg[9]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_66));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_17
       (.I0(age_reg[10]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_67));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_18
       (.I0(age_reg[11]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_68));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_19
       (.I0(age_reg[12]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_69));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h1)) 
    starlink_pss_re_LUT2_2
       (.I0(active_private_reg_n_0),
        .I1(protocol_fault),
        .O(starlink_pss_re_net_3));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_20
       (.I0(core_output_tvalid),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_50));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hB)) 
    starlink_pss_re_LUT2_21
       (.I0(fault_reasons[2]),
        .I1(starlink_pss_re_net_45),
        .O(\fault_reasons[2]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_22
       (.I0(fault_reasons[3]),
        .I1(starlink_pss_re_net_37),
        .O(\fault_reasons[3]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_23
       (.I0(fault_reasons[4]),
        .I1(starlink_pss_re_net_46),
        .O(\fault_reasons[4]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_24
       (.I0(fault_reasons[5]),
        .I1(starlink_pss_re_net_42),
        .O(\fault_reasons[5]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_25
       (.I0(certified_input_beat),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_51));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_26
       (.I0(starlink_pss_re_net_3),
        .I1(starlink_pss_re_net_51),
        .O(\input_count[9]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h4)) 
    starlink_pss_re_LUT2_27
       (.I0(output_count[0]),
        .I1(starlink_pss_re_net_52),
        .O(\output_count[0]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'hE)) 
    starlink_pss_re_LUT2_28
       (.I0(starlink_pss_re_net_3),
        .I1(starlink_pss_re_net_52),
        .O(\output_count[9]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h4)) 
    starlink_pss_re_LUT2_29
       (.I0(exponent_seen),
        .I1(starlink_pss_re_net_50),
        .O(output_exponent));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_3
       (.I0(output_count[9]),
        .I1(starlink_pss_re_net_6),
        .O(starlink_pss_re_net_15));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h4)) 
    starlink_pss_re_LUT2_30
       (.I0(input_count[0]),
        .I1(starlink_pss_re_net_51),
        .O(p_1_in[0]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_31
       (.I0(core_status_tvalid),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_53));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_4
       (.I0(input_count[3]),
        .I1(input_count[4]),
        .O(starlink_pss_re_net_26));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_5
       (.I0(output_count[3]),
        .I1(output_count[4]),
        .O(starlink_pss_re_net_31));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_6
       (.I0(mailbox_input_ready),
        .I1(starlink_pss_re_net_41),
        .O(starlink_pss_re_net_48));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h4)) 
    starlink_pss_re_LUT2_7
       (.I0(age_reg[0]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_57));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_8
       (.I0(age_reg[1]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_58));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT2 #(
    .INIT(4'h8)) 
    starlink_pss_re_LUT2_9
       (.I0(age_reg[2]),
        .I1(starlink_pss_re_net_2),
        .O(starlink_pss_re_net_59));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h80)) 
    starlink_pss_re_LUT3
       (.I0(age_reg[1]),
        .I1(age_reg[5]),
        .I2(age_reg[8]),
        .O(starlink_pss_re_net_8));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h2A)) 
    starlink_pss_re_LUT3_1
       (.I0(core_status_tvalid),
        .I1(starlink_pss_re_net_2),
        .I2(starlink_pss_re_net_40),
        .O(starlink_pss_re_net_46));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h60)) 
    starlink_pss_re_LUT3_10
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(starlink_pss_re_net_52),
        .O(\output_count[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h60)) 
    starlink_pss_re_LUT3_11
       (.I0(output_count[6]),
        .I1(starlink_pss_re_net_32),
        .I2(starlink_pss_re_net_52),
        .O(\output_count[6]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h60)) 
    starlink_pss_re_LUT3_12
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(starlink_pss_re_net_51),
        .O(p_1_in[1]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'hF2)) 
    starlink_pss_re_LUT3_13
       (.I0(status_seen_reg_n_0),
        .I1(starlink_pss_re_net_3),
        .I2(starlink_pss_re_net_53),
        .O(status_seen_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h80)) 
    starlink_pss_re_LUT3_2
       (.I0(resetn),
        .I1(return_occupied_reg_n_0),
        .I2(starlink_pss_re_net_2),
        .O(mailbox_private_valid));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h20)) 
    starlink_pss_re_LUT3_3
       (.I0(job_valid),
        .I1(awaiting_ack),
        .I2(starlink_pss_re_net_3),
        .O(starlink_pss_re_net_47));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h80)) 
    starlink_pss_re_LUT3_4
       (.I0(output_bank_reserved),
        .I1(starlink_pss_re_net_4),
        .I2(starlink_pss_re_net_47),
        .O(starlink_pss_re_net_49));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h32)) 
    starlink_pss_re_LUT3_5
       (.I0(exponent_seen),
        .I1(starlink_pss_re_net_3),
        .I2(starlink_pss_re_net_50),
        .O(exponent_seen_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'hFE)) 
    starlink_pss_re_LUT3_6
       (.I0(external_fault_now),
        .I1(mailbox_input_fault),
        .I2(fault_reasons[0]),
        .O(\fault_reasons[0]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'hEA)) 
    starlink_pss_re_LUT3_7
       (.I0(fault_reasons[7]),
        .I1(starlink_pss_re_net_2),
        .I2(starlink_pss_re_net_10),
        .O(\fault_reasons[7]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'h60)) 
    starlink_pss_re_LUT3_8
       (.I0(input_count[6]),
        .I1(starlink_pss_re_net_27),
        .I2(starlink_pss_re_net_51),
        .O(\input_count[6]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT3 #(
    .INIT(8'hD0)) 
    starlink_pss_re_LUT3_9
       (.I0(output_count[9]),
        .I1(starlink_pss_re_net_6),
        .I2(starlink_pss_re_net_50),
        .O(starlink_pss_re_net_52));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    starlink_pss_re_LUT4
       (.I0(fault_reasons[0]),
        .I1(fault_reasons[1]),
        .I2(fault_reasons[2]),
        .I3(fault_reasons[3]),
        .O(starlink_pss_re_net));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h0080)) 
    starlink_pss_re_LUT4_1
       (.I0(resetn),
        .I1(return_occupied_reg_n_0),
        .I2(starlink_pss_re_net_2),
        .I3(starlink_pss_re_net_10),
        .O(starlink_pss_re_net_11));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h7800)) 
    starlink_pss_re_LUT4_10
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(starlink_pss_re_net_52),
        .O(\output_count[2]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h6C00)) 
    starlink_pss_re_LUT4_11
       (.I0(output_count[6]),
        .I1(output_count[7]),
        .I2(starlink_pss_re_net_32),
        .I3(starlink_pss_re_net_52),
        .O(\output_count[7]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h7800)) 
    starlink_pss_re_LUT4_12
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[2]),
        .I3(starlink_pss_re_net_51),
        .O(p_1_in[2]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h8421)) 
    starlink_pss_re_LUT4_2
       (.I0(core_output_tuser[18]),
        .I1(core_output_tuser[19]),
        .I2(core_status_tdata[2]),
        .I3(core_status_tdata[3]),
        .O(starlink_pss_re_net_18));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    starlink_pss_re_LUT4_3
       (.I0(core_output_tuser[11]),
        .I1(core_output_tuser[13]),
        .I2(core_output_tuser[14]),
        .I3(starlink_pss_re_net_25),
        .O(starlink_pss_re_net_29));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h0100)) 
    starlink_pss_re_LUT4_4
       (.I0(external_fault_now),
        .I1(mailbox_input_fault),
        .I2(mailbox_input_last),
        .I3(starlink_pss_re_net_11),
        .O(starlink_pss_re_net_35));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'hAA8A)) 
    starlink_pss_re_LUT4_5
       (.I0(core_event_frame_started),
        .I1(frame_seen_reg_n_0),
        .I2(starlink_pss_re_net_2),
        .I3(starlink_pss_re_net_36),
        .O(starlink_pss_re_net_37));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'hFF8A)) 
    starlink_pss_re_LUT4_6
       (.I0(awaiting_ack),
        .I1(protocol_fault),
        .I2(starlink_pss_re_net_4),
        .I3(starlink_pss_re_net_48),
        .O(awaiting_ack_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'hA0EC)) 
    starlink_pss_re_LUT4_7
       (.I0(core_event_frame_started),
        .I1(frame_seen_reg_n_0),
        .I2(starlink_pss_re_net_2),
        .I3(starlink_pss_re_net_3),
        .O(frame_seen_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'hA0EC)) 
    starlink_pss_re_LUT4_8
       (.I0(certified_input_complete),
        .I1(input_complete_seen_reg_n_0),
        .I2(starlink_pss_re_net_2),
        .I3(starlink_pss_re_net_3),
        .O(input_complete_seen_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT4 #(
    .INIT(16'h6C00)) 
    starlink_pss_re_LUT4_9
       (.I0(input_count[6]),
        .I1(input_count[7]),
        .I2(starlink_pss_re_net_27),
        .I3(starlink_pss_re_net_51),
        .O(\input_count[7]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hFFFEFFFF)) 
    starlink_pss_re_LUT5
       (.I0(fault_reasons[4]),
        .I1(fault_reasons[5]),
        .I2(fault_reasons[6]),
        .I3(fault_reasons[7]),
        .I4(starlink_pss_re_net),
        .O(protocol_fault));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h00000001)) 
    starlink_pss_re_LUT5_1
       (.I0(output_count[3]),
        .I1(output_count[4]),
        .I2(output_count[5]),
        .I3(output_count[7]),
        .I4(output_count[8]),
        .O(starlink_pss_re_net_5));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h84210000)) 
    starlink_pss_re_LUT5_10
       (.I0(core_status_tdata[3]),
        .I1(core_status_tdata[4]),
        .I2(\output_exponent_reg_n_0_[3] ),
        .I3(\output_exponent_reg_n_0_[4] ),
        .I4(starlink_pss_re_net_38),
        .O(starlink_pss_re_net_39));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h88F800F0)) 
    starlink_pss_re_LUT5_11
       (.I0(input_bank_reserved),
        .I1(resetn),
        .I2(starlink_pss_re_net_2),
        .I3(starlink_pss_re_net_48),
        .I4(starlink_pss_re_net_49),
        .O(active_private_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hF3F7F0F0)) 
    starlink_pss_re_LUT5_12
       (.I0(input_bank_reserved),
        .I1(output_bank_reserved),
        .I2(fault_reasons[1]),
        .I3(input_complete_seen_reg_n_0),
        .I4(starlink_pss_re_net_2),
        .O(\fault_reasons[1]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h78F00000)) 
    starlink_pss_re_LUT5_13
       (.I0(input_count[6]),
        .I1(input_count[7]),
        .I2(input_count[8]),
        .I3(starlink_pss_re_net_27),
        .I4(starlink_pss_re_net_51),
        .O(\input_count[8]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h7F800000)) 
    starlink_pss_re_LUT5_14
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(output_count[3]),
        .I4(starlink_pss_re_net_52),
        .O(\output_count[3]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h78F00000)) 
    starlink_pss_re_LUT5_15
       (.I0(output_count[6]),
        .I1(output_count[7]),
        .I2(output_count[8]),
        .I3(starlink_pss_re_net_32),
        .I4(starlink_pss_re_net_52),
        .O(\output_count[8]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h7F800000)) 
    starlink_pss_re_LUT5_16
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[2]),
        .I3(input_count[3]),
        .I4(starlink_pss_re_net_51),
        .O(p_1_in[3]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hFBAA0000)) 
    starlink_pss_re_LUT5_17
       (.I0(core_output_tvalid),
        .I1(mailbox_input_ready),
        .I2(mailbox_input_last),
        .I3(return_occupied_reg_n_0),
        .I4(starlink_pss_re_net_2),
        .O(return_occupied_i_1_n_0));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h00010000)) 
    starlink_pss_re_LUT5_2
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(output_count[6]),
        .I4(starlink_pss_re_net_5),
        .O(starlink_pss_re_net_6));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h01000000)) 
    starlink_pss_re_LUT5_3
       (.I0(input_count[2]),
        .I1(input_count[4]),
        .I2(input_count[6]),
        .I3(input_count[9]),
        .I4(starlink_pss_re_net_7),
        .O(starlink_pss_re_net_16));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h80000080)) 
    starlink_pss_re_LUT5_4
       (.I0(output_bank_reserved),
        .I1(exponent_seen),
        .I2(input_complete_seen_reg_n_0),
        .I3(\output_exponent_reg_n_0_[0] ),
        .I4(\status_exponent_reg_n_0_[0] ),
        .O(starlink_pss_re_net_14));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h84210000)) 
    starlink_pss_re_LUT5_5
       (.I0(core_output_tuser[16]),
        .I1(core_output_tuser[20]),
        .I2(core_status_tdata[0]),
        .I3(core_status_tdata[4]),
        .I4(starlink_pss_re_net_18),
        .O(starlink_pss_re_net_21));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    starlink_pss_re_LUT5_6
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[2]),
        .I3(input_count[5]),
        .I4(starlink_pss_re_net_26),
        .O(starlink_pss_re_net_27));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'h80000000)) 
    starlink_pss_re_LUT5_7
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(output_count[5]),
        .I4(starlink_pss_re_net_31),
        .O(starlink_pss_re_net_32));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hAAAAA2AA)) 
    starlink_pss_re_LUT5_8
       (.I0(core_output_tvalid),
        .I1(starlink_pss_re_net_2),
        .I2(starlink_pss_re_net_15),
        .I3(starlink_pss_re_net_33),
        .I4(starlink_pss_re_net_34),
        .O(starlink_pss_re_net_42));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT5 #(
    .INIT(32'hC8FF0000)) 
    starlink_pss_re_LUT5_9
       (.I0(input_bank_reserved),
        .I1(output_bank_reserved),
        .I2(input_complete_seen_reg_n_0),
        .I3(starlink_pss_re_net_2),
        .I4(starlink_pss_re_net_35),
        .O(starlink_pss_re_net_43));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000000010000)) 
    starlink_pss_re_LUT6
       (.I0(core_event_frame_started),
        .I1(core_output_tvalid),
        .I2(core_status_tvalid),
        .I3(mailbox_input_fault),
        .I4(mailbox_input_ready),
        .I5(phase_input_fault_now),
        .O(starlink_pss_re_net_4));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0080000000000000)) 
    starlink_pss_re_LUT6_1
       (.I0(input_bank_reserved),
        .I1(output_bank_reserved),
        .I2(resetn),
        .I3(awaiting_ack),
        .I4(starlink_pss_re_net_3),
        .I5(starlink_pss_re_net_4),
        .O(job_ready));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_10
       (.I0(core_output_tuser[3]),
        .I1(core_output_tuser[4]),
        .I2(core_output_tuser[5]),
        .I3(output_count[3]),
        .I4(output_count[4]),
        .I5(output_count[5]),
        .O(starlink_pss_re_net_55));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_11
       (.I0(core_output_tuser[6]),
        .I1(core_output_tuser[7]),
        .I2(core_output_tuser[8]),
        .I3(output_count[6]),
        .I4(output_count[7]),
        .I5(output_count[8]),
        .O(starlink_pss_re_net_56));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_12
       (.I0(core_output_tuser[16]),
        .I1(core_output_tuser[17]),
        .I2(core_output_tuser[18]),
        .I3(\status_exponent_reg_n_0_[0] ),
        .I4(\status_exponent_reg_n_0_[1] ),
        .I5(\status_exponent_reg_n_0_[2] ),
        .O(starlink_pss_re_net_19));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7BDE0000FFFF0000)) 
    starlink_pss_re_LUT6_13
       (.I0(core_output_tuser[19]),
        .I1(core_output_tuser[20]),
        .I2(\status_exponent_reg_n_0_[3] ),
        .I3(\status_exponent_reg_n_0_[4] ),
        .I4(status_seen_reg_n_0),
        .I5(starlink_pss_re_net_19),
        .O(starlink_pss_re_net_22));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_14
       (.I0(core_output_tuser[16]),
        .I1(core_output_tuser[19]),
        .I2(core_output_tuser[20]),
        .I3(\output_exponent_reg_n_0_[0] ),
        .I4(\output_exponent_reg_n_0_[3] ),
        .I5(\output_exponent_reg_n_0_[4] ),
        .O(starlink_pss_re_net_20));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h70B0D0E0F0F0F0F0)) 
    starlink_pss_re_LUT6_15
       (.I0(core_output_tuser[17]),
        .I1(core_output_tuser[18]),
        .I2(exponent_seen),
        .I3(\output_exponent_reg_n_0_[1] ),
        .I4(\output_exponent_reg_n_0_[2] ),
        .I5(starlink_pss_re_net_20),
        .O(starlink_pss_re_net_23));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000000009F0F)) 
    starlink_pss_re_LUT6_16
       (.I0(core_output_tuser[17]),
        .I1(core_status_tdata[1]),
        .I2(core_status_tvalid),
        .I3(starlink_pss_re_net_21),
        .I4(starlink_pss_re_net_22),
        .I5(starlink_pss_re_net_23),
        .O(starlink_pss_re_net_28));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h000F000C000A0008)) 
    starlink_pss_re_LUT6_17
       (.I0(certified_input_complete),
        .I1(core_event_frame_started),
        .I2(core_output_tuser[15]),
        .I3(core_output_tuser[9]),
        .I4(frame_seen_reg_n_0),
        .I5(input_complete_seen_reg_n_0),
        .O(starlink_pss_re_net_24));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000100000000)) 
    starlink_pss_re_LUT6_18
       (.I0(core_output_tuser[10]),
        .I1(core_output_tuser[12]),
        .I2(core_output_tuser[21]),
        .I3(core_output_tuser[22]),
        .I4(core_output_tuser[23]),
        .I5(starlink_pss_re_net_24),
        .O(starlink_pss_re_net_25));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000800000000000)) 
    starlink_pss_re_LUT6_19
       (.I0(certified_input_beat),
        .I1(input_count[6]),
        .I2(input_count[7]),
        .I3(input_count[8]),
        .I4(input_count[9]),
        .I5(starlink_pss_re_net_27),
        .O(starlink_pss_re_net_30));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000000000001)) 
    starlink_pss_re_LUT6_2
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[3]),
        .I3(input_count[5]),
        .I4(input_count[7]),
        .I5(input_count[8]),
        .O(starlink_pss_re_net_7));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0F00000004000000)) 
    starlink_pss_re_LUT6_20
       (.I0(certified_input_beat),
        .I1(starlink_pss_re_net_16),
        .I2(output_error5),
        .I3(starlink_pss_re_net_28),
        .I4(starlink_pss_re_net_29),
        .I5(starlink_pss_re_net_30),
        .O(starlink_pss_re_net_33));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hAAAA6AAAAAAAAAAA)) 
    starlink_pss_re_LUT6_21
       (.I0(core_output_tlast),
        .I1(output_count[6]),
        .I2(output_count[7]),
        .I3(output_count[8]),
        .I4(output_count[9]),
        .I5(starlink_pss_re_net_32),
        .O(starlink_pss_re_net_34));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000000100000000)) 
    starlink_pss_re_LUT6_22
       (.I0(certified_input_beat),
        .I1(input_count[2]),
        .I2(input_count[4]),
        .I3(input_count[6]),
        .I4(input_count[9]),
        .I5(starlink_pss_re_net_7),
        .O(starlink_pss_re_net_36));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h000000005CFFFFFF)) 
    starlink_pss_re_LUT6_23
       (.I0(core_output_tvalid),
        .I1(mailbox_input_ready),
        .I2(mailbox_input_last),
        .I3(return_occupied_reg_n_0),
        .I4(starlink_pss_re_net_2),
        .I5(starlink_pss_re_net_37),
        .O(starlink_pss_re_net_44));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h15111F1115111311)) 
    starlink_pss_re_LUT6_24
       (.I0(certified_input_beat),
        .I1(certified_input_complete),
        .I2(input_complete_seen_reg_n_0),
        .I3(starlink_pss_re_net_2),
        .I4(starlink_pss_re_net_16),
        .I5(starlink_pss_re_net_30),
        .O(starlink_pss_re_net_45));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_25
       (.I0(core_status_tdata[0]),
        .I1(core_status_tdata[1]),
        .I2(core_status_tdata[2]),
        .I3(\output_exponent_reg_n_0_[0] ),
        .I4(\output_exponent_reg_n_0_[1] ),
        .I5(\output_exponent_reg_n_0_[2] ),
        .O(starlink_pss_re_net_38));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0000010100000001)) 
    starlink_pss_re_LUT6_26
       (.I0(core_status_tdata[5]),
        .I1(core_status_tdata[6]),
        .I2(core_status_tdata[7]),
        .I3(exponent_seen),
        .I4(status_seen_reg_n_0),
        .I5(starlink_pss_re_net_39),
        .O(starlink_pss_re_net_40));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hAAAAAAAABAAAAAAA)) 
    starlink_pss_re_LUT6_27
       (.I0(starlink_pss_re_net_41),
        .I1(starlink_pss_re_net_42),
        .I2(starlink_pss_re_net_43),
        .I3(starlink_pss_re_net_44),
        .I4(starlink_pss_re_net_45),
        .I5(starlink_pss_re_net_46),
        .O(mailbox_input_valid));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hFAF3F0F0F0F0F0F0)) 
    starlink_pss_re_LUT6_28
       (.I0(core_output_tvalid),
        .I1(mailbox_input_ready),
        .I2(fault_reasons[6]),
        .I3(mailbox_input_last),
        .I4(return_occupied_reg_n_0),
        .I5(starlink_pss_re_net_2),
        .O(\fault_reasons[6]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7FFF800000000000)) 
    starlink_pss_re_LUT6_29
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(output_count[3]),
        .I4(output_count[4]),
        .I5(starlink_pss_re_net_52),
        .O(\output_count[4]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    starlink_pss_re_LUT6_3
       (.I0(age_reg[0]),
        .I1(age_reg[2]),
        .I2(age_reg[3]),
        .I3(age_reg[6]),
        .I4(age_reg[7]),
        .I5(starlink_pss_re_net_8),
        .O(starlink_pss_re_net_9));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7F80FF0000000000)) 
    starlink_pss_re_LUT6_30
       (.I0(output_count[0]),
        .I1(output_count[1]),
        .I2(output_count[2]),
        .I3(output_count[5]),
        .I4(starlink_pss_re_net_31),
        .I5(starlink_pss_re_net_52),
        .O(\output_count[5]_i_1_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'hFF80FF0000000000)) 
    starlink_pss_re_LUT6_31
       (.I0(output_count[6]),
        .I1(output_count[7]),
        .I2(output_count[8]),
        .I3(output_count[9]),
        .I4(starlink_pss_re_net_32),
        .I5(starlink_pss_re_net_52),
        .O(\output_count[9]_i_2_n_0 ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7FFF800000000000)) 
    starlink_pss_re_LUT6_32
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[2]),
        .I3(input_count[3]),
        .I4(input_count[4]),
        .I5(starlink_pss_re_net_51),
        .O(p_1_in[4]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7F80FF0000000000)) 
    starlink_pss_re_LUT6_33
       (.I0(input_count[0]),
        .I1(input_count[1]),
        .I2(input_count[2]),
        .I3(input_count[5]),
        .I4(starlink_pss_re_net_26),
        .I5(starlink_pss_re_net_51),
        .O(p_1_in[5]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h7F80FF0000000000)) 
    starlink_pss_re_LUT6_34
       (.I0(input_count[6]),
        .I1(input_count[7]),
        .I2(input_count[8]),
        .I3(input_count[9]),
        .I4(starlink_pss_re_net_27),
        .I5(starlink_pss_re_net_51),
        .O(p_1_in[9]));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8000000000000000)) 
    starlink_pss_re_LUT6_4
       (.I0(age_reg[10]),
        .I1(age_reg[11]),
        .I2(age_reg[12]),
        .I3(age_reg[4]),
        .I4(age_reg[9]),
        .I5(starlink_pss_re_net_9),
        .O(starlink_pss_re_net_10));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8000008000000000)) 
    starlink_pss_re_LUT6_5
       (.I0(final_fence_certified),
        .I1(frame_seen_reg_n_0),
        .I2(mailbox_input_last),
        .I3(\output_exponent_reg_n_0_[4] ),
        .I4(\status_exponent_reg_n_0_[4] ),
        .I5(status_seen_reg_n_0),
        .O(starlink_pss_re_net_12));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h1000010000100001)) 
    starlink_pss_re_LUT6_6
       (.I0(mailbox_input_fault),
        .I1(phase_input_fault_now),
        .I2(\output_exponent_reg_n_0_[1] ),
        .I3(\output_exponent_reg_n_0_[2] ),
        .I4(\status_exponent_reg_n_0_[1] ),
        .I5(\status_exponent_reg_n_0_[2] ),
        .O(starlink_pss_re_net_13));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h9000000000000000)) 
    starlink_pss_re_LUT6_7
       (.I0(\output_exponent_reg_n_0_[3] ),
        .I1(\status_exponent_reg_n_0_[3] ),
        .I2(starlink_pss_re_net_11),
        .I3(starlink_pss_re_net_12),
        .I4(starlink_pss_re_net_13),
        .I5(starlink_pss_re_net_14),
        .O(starlink_pss_re_net_17));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h0100000000000000)) 
    starlink_pss_re_LUT6_8
       (.I0(core_event_frame_started),
        .I1(core_output_tvalid),
        .I2(core_status_tvalid),
        .I3(starlink_pss_re_net_15),
        .I4(starlink_pss_re_net_16),
        .I5(starlink_pss_re_net_17),
        .O(starlink_pss_re_net_41));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  LUT6 #(
    .INIT(64'h8040201008040201)) 
    starlink_pss_re_LUT6_9
       (.I0(core_output_tuser[0]),
        .I1(core_output_tuser[1]),
        .I2(core_output_tuser[2]),
        .I3(output_count[0]),
        .I4(output_count[1]),
        .I5(output_count[2]),
        .O(starlink_pss_re_net_54));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \status_exponent_reg[0] 
       (.C(clk),
        .CE(starlink_pss_re_net_53),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_status_tdata[0]),
        .Q(\status_exponent_reg_n_0_[0] ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \status_exponent_reg[1] 
       (.C(clk),
        .CE(starlink_pss_re_net_53),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_status_tdata[1]),
        .Q(\status_exponent_reg_n_0_[1] ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \status_exponent_reg[2] 
       (.C(clk),
        .CE(starlink_pss_re_net_53),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_status_tdata[2]),
        .Q(\status_exponent_reg_n_0_[2] ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \status_exponent_reg[3] 
       (.C(clk),
        .CE(starlink_pss_re_net_53),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_status_tdata[3]),
        .Q(\status_exponent_reg_n_0_[3] ));
  (* OPT_MODIFIED = "RESYNTH_AREA" *) 
  FDCE \status_exponent_reg[4] 
       (.C(clk),
        .CE(starlink_pss_re_net_53),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(core_status_tdata[4]),
        .Q(\status_exponent_reg_n_0_[4] ));
  FDCE status_seen_reg
       (.C(clk),
        .CE(1'b1),
        .CLR(\return_data[35]_i_2_n_0 ),
        .D(status_seen_i_1_n_0),
        .Q(status_seen_reg_n_0));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif

"""One parent-owned real FFT run; immutable inputs, bounded process group, no retry."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

root=Path(__file__).resolve().parent
bundle=Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-output-actual-prelaunch-declaration-v3')
expected='cb3bfc9af54809f67c95e20fd642019c1b953f3a51f40bf3a75e3a502eabd583'
python='/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11'
runner=bundle/'source_snapshot/hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl'
cli=bundle/'source_snapshot/tools/prepare_starlink_retained_output_actual.py'
output=root/'run'
assert not output.exists()
assert hashlib.sha256((bundle/'manifest.json').read_bytes()).hexdigest()==expected
assert hashlib.sha256(Path(python).read_bytes()).hexdigest()=='2874a0b9344d06b7767aebb1e6e25a759ffcbdb544e99400ecc74dc6092d1174'
# Independent parent155 source-to-bundle and unchanged campaign audit.
import xml.etree.ElementTree as ET
parent=root.parent/'retained-declaration-parent.nu4VLvyG'
test_result=json.loads((parent/'execution.json').read_text())
assert test_result=={'exit':0,'changed':[],'source_count':73}
xml=ET.parse(parent/'results.xml').getroot()
cases=xml.findall('.//testcase')
assert len(cases)==155 and not xml.findall('.//failure') and not xml.findall('.//error') and not xml.findall('.//skipped')
pins=json.loads((parent/'source-pins.json').read_text())
manifest=json.loads((bundle/'manifest.json').read_text())
assert {name:hashlib.sha256((bundle/'source_snapshot'/name).read_bytes()).hexdigest() for name in pins}==pins
previous=root.parent/'retained-output-actual-prelaunch-language-v2'
old_manifest=json.loads((previous/'manifest.json').read_text())
assert manifest['compiled']==old_manifest['compiled'] and manifest['vectors']==old_manifest['vectors']
for name in ['bench.sv','profile.tcl',*manifest['vectors']]:
    assert (bundle/name).read_bytes()==(previous/name).read_bytes(),name
(root/'parent155-audit.json').write_text(json.dumps({'tests':155,'source_pins':73,'unchanged_bench_profile_vectors':True,'unchanged_compiled_list':True},indent=2))
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
before=subprocess.run([python,'-B',str(cli),'verify',str(bundle),'--expected',expected,'--live'],cwd='/',env=env,capture_output=True,text=True,timeout=30)
(root/'before.log').write_text(before.stdout+before.stderr)
assert before.returncode==0,before.stderr
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
cmd=['/opt/Xilinx/Vivado/2022.2/bin/vivado','-mode','batch','-notrace',
     '-log',str(root/'vivado.log'),'-journal',str(root/'vivado.jou'),'-source',str(runner),
     '-tclargs',str(bundle),python,expected,str(output)]
(root/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'wall_limit_seconds':900,
 'sources_fw':'946ea9fa747097a5a2730acca93ae39b656cf232','sources_hdl':'c02fb48b72c4abcb43bc2aab4f7b0d0511ef1b52',
 'manifest_sha256':expected,'kind':'ACTUAL_VENDOR_FFT_SEVEN_CONTEXTS_NOT_PHYSICAL_RX'},indent=2))
start=time.monotonic();timed_out=False
with (root/'stdout.log').open('x') as log:
    process=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (root/'process.json').write_text(json.dumps({'pid':process.pid,'process_group':process.pid}))
    print('Parent actual FFT process started; pid='+str(process.pid),flush=True)
    try:
        code=process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGTERM)
        try: code=process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=15)
env.pop('LD_LIBRARY_PATH',None)
after=subprocess.run([python,'-B',str(cli),'verify',str(bundle),'--expected',expected,'--live'],cwd='/',env=env,capture_output=True,text=True,timeout=30)
(root/'after.log').write_text(after.stdout+after.stderr)
copied=None
if (output/'inputs/manifest.json').is_file():
    copied=subprocess.run([python,'-B',str(cli),'verify',str(output/'inputs'),'--expected',expected,'--live'],cwd='/',env=env,capture_output=True,text=True,timeout=30)
    (root/'copied-after.log').write_text(copied.stdout+copied.stderr)
result={'vendor_exit':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,
        'original_source_check_exit':after.returncode,'copied_source_check_exit':None if copied is None else copied.returncode,
        'result_file_exists':(output/'results.json').is_file()}
(root/'execution.json').write_text(json.dumps(result,indent=2))
print('\n'.join((root/'stdout.log').read_text().splitlines()[-25:]),flush=True)
print(json.dumps(result),flush=True)
assert code==0 and not timed_out and after.returncode==0 and copied is not None and copied.returncode==0 and result['result_file_exists'],result


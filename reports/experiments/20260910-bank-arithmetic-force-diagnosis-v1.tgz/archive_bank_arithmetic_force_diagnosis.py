"""Archive observed force-boundary diagnosis without rewriting failed runs."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import tarfile

BUILD = Path(__file__).resolve().parent
FW = BUILD.parents[3]
REPORTS = FW / "reports/experiments"
DIAG = BUILD / "bank-arithmetic-force-diagnosis.AbVRjg"
XSIM = BUILD / "bank-arithmetic-force-xsim-v1.x51G4v"
OUTPUT = REPORTS / "20260910-bank-arithmetic-force-diagnosis-v1.tgz"
RECEIPT = OUTPUT.with_suffix(".json")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def observations(path: Path, option: int) -> list[dict[str, str]]:
    text = path.read_text()
    assert not re.search(r"(?m)^(?:Fatal:|FATAL:|ERROR:)", text)
    marker = f"FORCE_OBSERVATION_COMPLETE O={option} cases=3 no_actual_FFT=1 no_cause_assertion=1"
    assert text.count(marker) == 1
    rows = [dict(re.findall(r"(\w+)=(\S+)", line)) for line in text.splitlines()
            if line.startswith("FORCE_OBSERVATION O=")]
    assert [int(row["kind"]) for row in rows] == [0, 1, 2]
    assert all(int(row["O"]) == option for row in rows)
    return rows


def main() -> None:
    assert not OUTPUT.exists() and not RECEIPT.exists()
    original = REPORTS / "20260910-bank-arithmetic-actual175-failures-v1.json"
    failures = json.loads(original.read_text())
    assert sha(REPORTS / failures["archive"]) == "22cdaa34c00226790ed1759a459eab4a28425111d53e169bfab93c73fb514b8e"
    unchanged = {}
    saved_values = {}
    for run in failures["runs"]:
        directory = Path(run["directory"])
        frozen = directory / "frozen_sources"
        assert {p.name for p in frozen.iterdir()} == set(run["source_sha256"])
        assert {p.name: sha(p) for p in frozen.iterdir()} == run["source_sha256"]
        sim = directory / "project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim"
        wave_sha = sha(sim / "tb_starlink_pss_bank_arithmetic_actual_behav.wdb")
        assert wave_sha == run["waveform_sha256"]
        assert sha(sim / "simulate.log") == run["log_sha256"]
        assert not (directory / "results.json").exists()
        unchanged[run["arm"]] = {"frozen_sources": len(run["source_sha256"]), "wdb_sha256": wave_sha}
        log = (DIAG / f'read_saved_values_v6_{run["arm"]}.outer.log').read_text()
        values = [line.split("\t") for line in log.splitlines() if line.startswith("SAVED_VALUE\t")]
        assert values and all(row[3] == "0" for row in values)
        epoch = [row for row in values if row[4].endswith(" /epoch")]
        kind = [row for row in values if row[4].endswith(" /test_kind")]
        internal = [row for row in values if not re.search(r" /(epoch|fft_clk|resetn|test_kind)$", row[4])]
        assert len(epoch) == len(kind) == 4
        assert all(row[5] == "0000000e" for row in epoch)
        assert all(row[5] == "00000000" for row in kind)
        assert internal and all(row[5] == "<Blank>" for row in internal)
        saved_values[run["arm"]] = {"epoch": 14, "test_kind": 0, "internal_histories": "not_recorded"}
    prelaunch = json.loads((XSIM / "prelaunch.json").read_text())
    assert prelaunch["sources"] == {name: sha(XSIM / name) for name in prelaunch["sources"]}
    observed = {}
    for option in (0, 1):
        xsim = observations(XSIM / f"option-{option}/simulate.log", option)
        icarus = observations(XSIM / f"icarus-same-v3-option-{option}/simulate.log", option)
        outcome = json.loads((XSIM / f"option-{option}/outcome.json").read_text())
        assert outcome["source_integrity"] and all(row["returncode"] == 0 for row in outcome["results"])
        for kind, (xrow, irow) in enumerate(zip(xsim, icarus, strict=True)):
            expected = (2, 0x53 << 72, (0x2000e0000 ^ 0xdeadbeef) << 2)[kind]
            assert int(xrow["wrapper_xor"], 16) == expected
            assert int(xrow["old_xor"], 16) == int(xrow["inner_xor"], 16) == 0
            assert all(int(irow[key], 16) == expected for key in ("old_xor", "wrapper_xor", "inner_xor"))
        observed[str(option)] = {"xsim": xsim, "icarus_identical_source": icarus}
    members = {}
    for directory in (DIAG, XSIM):
        for path in sorted(directory.rglob("*")):
            if path.is_file() and not path.is_symlink():
                name = directory.name + "/" + path.relative_to(directory).as_posix()
                members[name] = path
    members["archive_bank_arithmetic_force_diagnosis.py"] = Path(__file__).resolve()
    member_hashes = {name: sha(path) for name, path in members.items()}
    with tarfile.open(OUTPUT, "x:gz") as archive:
        for name, path in sorted(members.items()):
            archive.add(path, arcname=name, recursive=False)
    with tarfile.open(OUTPUT, "r:gz") as archive:
        rows = archive.getmembers()
        assert len(rows) == len({row.name for row in rows}) == len(members)
        for row in rows:
            assert row.isfile() and not row.name.startswith("/") and ".." not in Path(row.name).parts
            assert hashlib.sha256(archive.extractfile(row).read()).hexdigest() == member_hashes[row.name]
    receipt = {
        "schema": "bank-arithmetic-force-diagnosis-v1",
        "all_actual_runs_remain_failed": True,
        "actual_retry_or_runtime_edit": False,
        "actual_bank_internal_vector_available": False,
        "diagnosis_scope": "standalone Xsim proves force-boundary mechanism; attribution to actual failure remains source-based inference",
        "original_failure_archive_sha256": failures["archive_sha256"],
        "original_inputs_still_unchanged": unchanged,
        "saved_wave_observation": saved_values,
        "standalone_original_handles": {"0": 4397, "1": 90953},
        "standalone_sources": prelaunch["sources"],
        "observed_vectors": observed,
        "preserved_attempts": ["Icarus v1 hypothesis assertion FAIL", "Icarus v2 six observations", "WDB unsupported close command", "WDB live-only current_time rejection", "WDB argv-order rejection", "WDB internal histories Blank", "Xsim standalone both options terminal0", "Icarus identical-v3-source both options terminal0"],
        "archive": OUTPUT.name,
        "archive_sha256": sha(OUTPUT),
        "archive_bytes": OUTPUT.stat().st_size,
        "archive_safe_unique_files": len(members),
        "archive_file_sha256": member_hashes,
    }
    RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("archive", "archive_sha256", "archive_bytes", "archive_safe_unique_files")}, indent=2))


if __name__ == "__main__":
    main()

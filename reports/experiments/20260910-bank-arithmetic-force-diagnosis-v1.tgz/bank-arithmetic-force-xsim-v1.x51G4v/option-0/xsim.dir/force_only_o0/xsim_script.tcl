xsim {force_only_o0} -autoloadwcfg -runall

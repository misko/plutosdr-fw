xsim {force_only_o1} -autoloadwcfg -runall

"""Source-frozen standalone Xsim diagnosis: no FFT/IP/bank/project generation."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TOOLS = Path("/opt/Xilinx/Vivado/2022.2/bin")
SOURCE_NAMES = (
    "tb_force_observation_v3.sv",
    "starlink_pss_spectrum_product_7ee87258_golden.v",
    "starlink_pss_spectrum_product_bank_arithmetic.v",
    "starlink_pss_spectrum_product_operand_register.v",
    "run_saved_force_only.py",
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def commands(option: int) -> list[list[str]]:
    return [
        [str(TOOLS / "xvlog"), "--sv", *(str(ROOT / name) for name in SOURCE_NAMES[:4])],
        [str(TOOLS / "xelab"), "--mt", "2", "--debug", "all", "--generic_top",
         f"O={option}", "--snapshot", f"force_only_o{option}", "tb_force_observation_v3"],
        [str(TOOLS / "xsim"), f"force_only_o{option}", "--runall"],
    ]


def main() -> None:
    mode = sys.argv[1]
    if mode == "prepare":
        receipt = {
            "scope": "standalone diagnosis only: no FFT/IP/bank simulation",
            "sources": {name: digest(ROOT / name) for name in SOURCE_NAMES},
            "commands": {str(option): commands(option) for option in (0, 1)},
            "vendor_env": {"LD_LIBRARY_PATH": "/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE"},
        }
        with (ROOT / "prelaunch.json").open("x") as stream:
            json.dump(receipt, stream, indent=2)
            stream.write("\n")
        print(json.dumps(receipt, indent=2))
        return
    if mode not in ("0", "1"):
        raise SystemExit("require prepare, 0, or 1")
    option = int(mode)
    receipt = json.loads((ROOT / "prelaunch.json").read_text())
    verify = lambda: receipt["sources"] == {name: digest(ROOT / name) for name in SOURCE_NAMES}
    assert verify(), "before source mismatch"
    output = ROOT / f"option-{option}"
    output.mkdir(exist_ok=False)
    env = os.environ.copy()
    env.update(receipt["vendor_env"])
    results = []
    try:
        for phase, command in zip(("compile", "elaborate", "simulate"), commands(option), strict=True):
            with (output / f"{phase}.log").open("x") as log:
                result = subprocess.run(command, cwd=output, env=env, stdout=log, stderr=subprocess.STDOUT)
            results.append({"phase": phase, "command": command, "returncode": result.returncode})
            print(f"FORCE_ONLY_PHASE O={option} phase={phase} exit={result.returncode}", flush=True)
            if result.returncode:
                raise RuntimeError(f"{phase} failed: {result.returncode}")
    finally:
        after = verify()
        (output / "outcome.json").write_text(json.dumps({"results": results, "source_integrity": after}, indent=2) + "\n")
        if not after:
            raise RuntimeError("after source mismatch")


if __name__ == "__main__":
    main()

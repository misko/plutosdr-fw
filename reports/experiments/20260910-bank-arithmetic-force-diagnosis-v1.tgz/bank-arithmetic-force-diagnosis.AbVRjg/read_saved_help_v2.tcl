# READ ONLY saved waveform API discovery: no simulation launch or time advance.
if {[version -short] ne "2022.2"} { error "wrong Vivado" }
set_param general.maxThreads 2
set wave /tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-baseline175-prepared-v2/project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim/tb_starlink_pss_bank_arithmetic_actual_behav.wdb
puts "READ_ONLY_BEFORE_SHA [exec sha256sum $wave]"
open_wave_database $wave
foreach command {get_value get_objects current_time current_scope} {
  puts "READ_ONLY_HELP $command"
  puts [help $command]
}
foreach pattern {*product_outputs *p_overflow *product_overflow *output_overflow *epoch} {
  foreach object [get_objects -r $pattern] {
    puts "READ_ONLY_OBJECT <$object>"
    set status [catch {get_value -radix hex $object} value]
    puts "READ_ONLY_VALUE status=$status value=<$value>"
  }
}
puts "READ_ONLY_AFTER_SHA [exec sha256sum $wave]"
puts READ_ONLY_API_DISCOVERY_DONE

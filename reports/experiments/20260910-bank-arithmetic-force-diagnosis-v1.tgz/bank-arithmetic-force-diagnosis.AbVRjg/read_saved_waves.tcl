# READ ONLY: open saved WDBs. Never create project, launch simulation or run time.
if {[version -short] ne "2022.2"} { error "wrong Vivado" }
set_param general.maxThreads 2
puts "READ_ONLY_WAVE_HELP_BEGIN"
help open_wave_database
help get_value
help get_objects
set base /tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build
foreach arm {baseline candidate} {
  set path [file join $base bank-arithmetic-actual-${arm}175-prepared-v2 project fft_bank_arithmetic_actual.sim sim_1 behav xsim tb_starlink_pss_bank_arithmetic_actual_behav.wdb]
  puts "READ_ONLY_WAVE_OPEN arm=$arm sha256=[lindex [exec sha256sum $path] 0]"
  open_wave_database $path
  puts "READ_ONLY_SCOPES [get_scopes -r *]"
  puts "READ_ONLY_MATCHING_OBJECTS [get_objects -r *product*]"
  close_wave_database
}
puts "READ_ONLY_WAVE_INSPECTION_DONE"

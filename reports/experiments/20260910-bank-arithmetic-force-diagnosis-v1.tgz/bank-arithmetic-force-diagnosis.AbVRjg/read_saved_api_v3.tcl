# READ ONLY command/property discovery on an existing saved waveform.
set_param general.maxThreads 2
set wave /tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-baseline175-prepared-v2/project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim/tb_starlink_pss_bank_arithmetic_actual_behav.wdb
puts "READ_ONLY_BEFORE_SHA [exec sha256sum $wave]"
open_wave_database $wave
puts "READ_ONLY_WAVE_COMMANDS [lsort [info commands *wave*]]"
puts "READ_ONLY_CURSOR_COMMANDS [lsort [info commands *cursor*]]"
puts "READ_ONLY_VCD_COMMANDS [lsort [info commands *vcd*]]"
puts "READ_ONLY_VALUE_COMMANDS [lsort [info commands *value*]]"
puts "READ_ONLY_TIME [current_time]"
foreach command {get_wave_config get_wave_objects report_values set_property} {
  puts "READ_ONLY_HELP $command [help $command]"
}
set object [lindex [get_objects -r *product_overflow] 0]
puts "READ_ONLY_PROPERTIES <$object> [list_property $object]"
report_property $object
puts "READ_ONLY_AFTER_SHA [exec sha256sum $wave]"
puts READ_ONLY_API_DISCOVERY_DONE

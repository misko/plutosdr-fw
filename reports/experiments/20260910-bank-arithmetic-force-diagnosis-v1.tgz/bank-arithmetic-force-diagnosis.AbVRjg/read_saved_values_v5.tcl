# READ ONLY: inspect original saved failure WDB; never launch/advance simulation.
if {[llength $argv] != 1 || [lindex $argv 0] ni {baseline candidate}} { error "arm required" }
set arm [lindex $argv 0]
set_param general.maxThreads 2
set base /tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build
set wave [file join $base bank-arithmetic-actual-${arm}175-prepared-v2 project fft_bank_arithmetic_actual.sim sim_1 behav xsim tb_starlink_pss_bank_arithmetic_actual_behav.wdb]
set fatal [expr {$arm eq "baseline" ? 1261662920227 : 1261765777375}]
puts "READ_ONLY_BEFORE_SHA [exec sha256sum $wave]"
open_wave_database $wave
set selected {}
foreach object [get_objects -r *] {
  if {[regexp {/(epoch|fft_clk|resetn|test_kind|product_outputs|p_ready|p_valid|p_i|p_q|p_position|p_exponent|p_last|p_start|p_overflow|p_overflow_pulse|available|occupied|product_overflow|product_position|product_start|product_valid|output_i|output_q|output_valid|output_bin_index|output_block_exponent|output_last|output_block_start_index|output_overflow|overflow_pulse|flush|product_enable|input_ready)$} $object]
      && ([string match */dut/product/* $object] || [string match */dut/product_* $object]
          || [string match */forward_chain_shadow/* $object] || [string match */payload_shadow/* $object]
          || [regexp {/(epoch|fft_clk|resetn|test_kind)$} $object])} {
    lappend selected $object
  }
}
foreach offset {-11428572 -5714286 -1 0} {
  set time "[expr {$fatal + $offset}]fs"
  foreach object $selected {
    set status [catch {get_value_database -radix hex -time $time $object} value]
    puts "SAVED_VALUE\t$arm\t$time\t$status\t$object\t$value"
  }
}
puts "READ_ONLY_AFTER_SHA [exec sha256sum $wave]"
puts READ_ONLY_SAVED_VALUES_DONE

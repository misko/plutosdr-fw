// Minimal OFFLINE diagnosis. No FFT, bank scheduler, waiver or modified core.
`timescale 1ns/1ps
module tb_force_propagation;
  parameter integer O=0;
  reg clk=0; always #5 clk=!clk;
  reg resetn=0,flush=0,input_valid=0;
  reg signed [17:0] input_i=30000,input_q=-40000,kernel_i=70000,kernel_q=90000;
  reg [8:0] input_bin_index=64;
  reg [4:0] input_block_exponent=5;
  reg input_last=0;
  reg [63:0] input_block_start_index=64'h2000e0000;
  wire old_ready,old_valid,old_last,old_overflow,old_pulse;
  wire new_ready,new_valid,new_last,new_overflow,new_pulse;
  wire [17:0] old_i,old_q,new_i,new_q;
  wire [8:0] old_position,new_position;
  wire [4:0] old_exponent,new_exponent;
  wire [63:0] old_start,new_start;
  starlink_pss_spectrum_product #(.DATA_WIDTH(18),.PRIVATE_PAYLOAD_BUBBLES(1)) old (
    .clk(clk),.resetn(resetn),.flush(flush),.input_valid(input_valid),.input_ready(old_ready),
    .input_i(input_i),.input_q(input_q),.kernel_i(kernel_i),.kernel_q(kernel_q),
    .input_bin_index(input_bin_index),.input_block_exponent(input_block_exponent),
    .input_last(input_last),.input_block_start_index(input_block_start_index),
    .output_valid(old_valid),.output_ready(1'b0),.output_i(old_i),.output_q(old_q),
    .output_bin_index(old_position),.output_block_exponent(old_exponent),.output_last(old_last),
    .output_block_start_index(old_start),.output_overflow(old_overflow),.overflow_pulse(old_pulse));
  starlink_pss_spectrum_product_operand_register #(.DATA_WIDTH(18),.PRIVATE_PAYLOAD_BUBBLES(1),
    .BOUNDARY_ROUND_SAT(O),.REGISTER_OPERANDS(O)) wrapped (
    .clk(clk),.resetn(resetn),.flush(flush),.input_valid(input_valid),.input_ready(new_ready),
    .input_i(input_i),.input_q(input_q),.kernel_i(kernel_i),.kernel_q(kernel_q),
    .input_bin_index(input_bin_index),.input_block_exponent(input_block_exponent),
    .input_last(input_last),.input_block_start_index(input_block_start_index),
    .output_valid(new_valid),.output_ready(1'b0),.output_i(new_i),.output_q(new_q),
    .output_bin_index(new_position),.output_block_exponent(new_exponent),.output_last(new_last),
    .output_block_start_index(new_start),.output_overflow(new_overflow),.overflow_pulse(new_pulse));
  wire [118:0] old_monitor={old.input_ready,old.output_valid,old.output_i,old.output_q,
    old.output_bin_index,old.output_block_exponent,old.output_last,old.output_block_start_index,
    old.output_overflow,old.overflow_pulse};
  wire [118:0] wrapper_monitor={wrapped.input_ready,wrapped.output_valid,wrapped.output_i,wrapped.output_q,
    wrapped.output_bin_index,wrapped.output_block_exponent,wrapped.output_last,wrapped.output_block_start_index,
    wrapped.output_overflow,wrapped.overflow_pulse};
  wire [117:0] inner_payload={wrapped.arithmetic.output_valid,wrapped.arithmetic.output_i,wrapped.arithmetic.output_q,
    wrapped.arithmetic.output_bin_index,wrapped.arithmetic.output_block_exponent,wrapped.arithmetic.output_last,
    wrapped.arithmetic.output_block_start_index,wrapped.arithmetic.output_overflow,wrapped.arithmetic.overflow_pulse};
  reg [118:0] before_old,before_wrapper,expected_delta;
  reg [117:0] before_inner;
  integer kind;
  initial begin
    repeat(2) @(negedge clk); resetn=1; input_valid=1;
    @(negedge clk); input_valid=0;
    repeat(8) @(negedge clk);
    if(!old_valid || !new_valid || old_monitor !== wrapper_monitor || old_overflow || new_overflow || old_pulse || new_pulse)
      $fatal(1,"FORCE_DIAG_HEALTHY_PRECONDITION");
    before_old=old_monitor;before_wrapper=wrapper_monitor;before_inner=inner_payload;
    for(kind=0;kind<3;kind=kind+1) begin
      @(negedge clk);
      case(kind)
        0: begin force old_overflow=1;force new_overflow=1;expected_delta=119'b1<<1;end
        1: begin force old_position=9'd19;force new_position=9'd19;expected_delta=119'h53<<72;end
        2: begin force old_start=64'hdeadbeef;force new_start=64'hdeadbeef;
          expected_delta=119'(64'h2000e0000^64'hdeadbeef)<<2;end
      endcase
      #1;
      $display("FORCE_PROPAGATION O=%0d kind=%0d old_monitor=%030h wrapper_monitor=%030h xor=%030h expected_xor=%030h inner_payload=%030h old_top_overflow=%0b old_reg_overflow=%0b wrapper_port_overflow=%0b inner_reg_overflow=%0b old_top_position=%0d old_reg_position=%0d wrapper_port_position=%0d inner_reg_position=%0d old_top_start=%016h old_reg_start=%016h wrapper_port_start=%016h inner_reg_start=%016h",
        O,kind,old_monitor,wrapper_monitor,wrapper_monitor^before_wrapper,expected_delta,inner_payload,
        old_overflow,old.output_overflow,wrapped.output_overflow,wrapped.arithmetic.output_overflow,
        old_position,old.output_bin_index,wrapped.output_bin_index,wrapped.arithmetic.output_bin_index,
        old_start,old.output_block_start_index,wrapped.output_block_start_index,wrapped.arithmetic.output_block_start_index);
      if(old_monitor !== before_old || inner_payload !== before_inner || (wrapper_monitor^before_wrapper) !== expected_delta)
        $fatal(1,"FORCE_DIAG_PROPAGATION_NOT_AS_HYPOTHESIZED");
      release old_overflow;release new_overflow;release old_position;release new_position;release old_start;release new_start;
      #1;
      if(old_monitor !== before_old || wrapper_monitor !== before_wrapper || inner_payload !== before_inner)
        $fatal(1,"FORCE_DIAG_RELEASE_DID_NOT_RESTORE");
    end
    $display("FORCE_PROPAGATION_REPRODUCED O=%0d cases=3 arithmetic_unchanged=1 no_actual_FFT=1",O);
    $finish;
  end
  initial begin #1000;$fatal(1,"FORCE_DIAG_WATCHDOG");end
endmodule

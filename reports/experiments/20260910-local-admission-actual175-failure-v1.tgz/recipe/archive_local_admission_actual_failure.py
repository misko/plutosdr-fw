"""Freeze original failed attempt, including complete project, without replay."""
import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path("/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic")
BUILD = ROOT / "hdl/library/starlink_pss_acquisition/build"
PREPARED = BUILD / "local-admission-actual-R1B1O1-L1-175-prepared-v2"
OWNER = BUILD / "local-admission-L1-175-actual-owned-v1"
REPORT = ROOT / "docs/starlink-local-admission-actual175-failure-20260910.md"
ARCHIVE = ROOT / "reports/experiments/20260910-local-admission-actual175-failure-v1.tgz"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


terminal = json.loads((OWNER / "terminal.json").read_text())
assert terminal["original_process_exit"] == 1 and terminal["source_unchanged"] is True
assert not (PREPARED / "results.json").exists()
for name, expected in terminal["after_source_sha256"].items():
    assert sha(PREPARED / name) == expected
assert (PREPARED / "generated_ip_before.txt").read_bytes() == (PREPARED / "generated_ip_after.txt").read_bytes()
sim = PREPARED / "project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim"
assert (sim / "simulate.log").read_text() == "Time resolution is 1 fs\n"
assert "LOCAL_GUARD_WAVE_PATH_MISSING actual_view" in (OWNER / "outer.log").read_text()
files = {}
for label, directory in (("original_attempt", PREPARED), ("owner", OWNER)):
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise ValueError("unexpected original archive symlink " + str(path))
        if path.is_file():
            files[label + "/" + path.relative_to(directory).as_posix()] = path
files["report/" + REPORT.name] = REPORT
files["recipe/" + Path(__file__).name] = Path(__file__)
owner_script = BUILD / "own_local_admission_L1_actual_v1.py"
files["recipe/" + owner_script.name] = owner_script
inventory = {name: {"bytes": path.stat().st_size, "sha256": sha(path)} for name, path in files.items()}
with ARCHIVE.open("xb") as raw:
    with tarfile.open(fileobj=raw, mode="w:gz") as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
with tarfile.open(ARCHIVE, "r:gz") as archive:
    members = archive.getmembers()
    assert len(members) == len({member.name for member in members}) == len(inventory)
    for member in members:
        assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
        with archive.extractfile(member) as stream:
            digest = hashlib.file_digest(stream, "sha256").hexdigest()
        assert inventory[member.name] == {"bytes": member.size, "sha256": digest}
assert all(sha(files[name]) == row["sha256"] for name, row in inventory.items())
receipt = {"schema": "local-admission-actual-failure-v1", "original_handle": 22656,
           "scope": "FAIL_diagnostic_lookup_before_run_all_NO_guard_or_arithmetic_execution",
           "original_process_exit": 1, "source_unchanged": True, "results_json_present": False,
           "archive": ARCHIVE.name, "archive_bytes": ARCHIVE.stat().st_size, "archive_sha256": sha(ARCHIVE),
           "safe_unique_regular_files": len(inventory), "members": inventory}
with ARCHIVE.with_suffix(".json").open("x") as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True)
print(json.dumps({k: v for k, v in receipt.items() if k != "members"}, indent=2))

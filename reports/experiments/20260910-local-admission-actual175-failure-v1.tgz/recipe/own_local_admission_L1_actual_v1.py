"""One authorized frozen Vivado call; exclusive owner receipts, no retry."""
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

BUILD = Path("/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build")
PREPARED = BUILD / "local-admission-actual-R1B1O1-L1-175-prepared-v2"
OWNER = BUILD / "local-admission-L1-175-actual-owned-v1"
EXPECTED = "a84e723cb3de7b2c3382dbc88b89b6edc533d7493856540d1871d4ecd31831d5"
RUNNER_SHA = "f76090eba45113c44eff258fa1482198b663747787b76b14ce24a39bee7ebb98"
PYTHON = "/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python"
VIVADO = "/opt/Xilinx/Vivado/2022.2/bin/vivado"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    paths = [PREPARED / "manifest.json", *sorted((PREPARED / "frozen_sources").iterdir())]
    assert all(p.is_file() and not p.is_symlink() for p in paths)
    return {p.relative_to(PREPARED).as_posix(): sha(p) for p in paths}


assert sha(PREPARED / "manifest.json") == EXPECTED
runner = PREPARED / "frozen_sources/simulate_local_admission_actual.tcl"
assert sha(runner) == RUNNER_SHA
assert not (PREPARED / "project").exists() and not (PREPARED / "launch_started.txt").exists()
OWNER.mkdir(exist_ok=False)
before = inventory()
manifest = json.loads((PREPARED / "manifest.json").read_text())
assert len(manifest["source_sha256"]) == 45
assert {"frozen_sources/" + name: value for name, value in manifest["source_sha256"].items()} == {name: value for name, value in before.items() if name.startswith("frozen_sources/")}
command = [VIVADO, "-mode", "batch", "-source", str(runner), "-log", str(OWNER / "vivado.log"),
           "-journal", str(OWNER / "vivado.jou"), "-tclargs", str(PREPARED), PYTHON, EXPECTED]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OWNER / "before.json").open("x") as stream:
    json.dump({"started_utc": started, "command": command, "source_sha256": before}, stream, indent=2)
environment = dict(os.environ)
environment["LD_LIBRARY_PATH"] = "/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE"
begin = time.monotonic()
status = None
error = None
try:
    with (OWNER / "outer.log").open("x") as log:
        status = subprocess.run(command, cwd=OWNER, env=environment, stdout=log,
                                stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
finally:
    after_error = None
    try:
        after = inventory()
    except Exception as exc:
        after = None
        after_error = repr(exc)
    receipt = {"started_utc": started, "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "elapsed_seconds": time.monotonic()-begin, "original_process_exit": status,
               "launch_error": error, "after_integrity_error": after_error,
               "source_unchanged": before == after, "after_source_sha256": after}
    with (OWNER / "terminal.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(status if status not in (None, 0) else (1 if error or after_error or before != after else 0))

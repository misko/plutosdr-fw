"""Offline real-RAM/issuer traces, independent public model and killed mutants."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

import pytest

HERE = Path(__file__).parent
FW = HERE.parents[1]
ACQ = FW / "hdl/library/starlink_pss_acquisition"
RTL = ACQ / "starlink_pss_epoch_sealed_bank.v"
BENCH = ACQ / "tb_epoch_sealed_bank.sv"
MAILBOX = ACQ / "starlink_pss_block_mailbox.v"
SPEC = importlib.util.spec_from_file_location("sealed_reference", HERE / "epoch_sealed_bank.py")
MODEL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODEL)


def child_env():
    env = dict(os.environ)
    for key in ("LD_LIBRARY_PATH", "PYTHONHOME", "PYTHONPATH"):
        env.pop(key, None)
    return env


def compile_case(path, mutation=None):
    path.mkdir()
    for source in (RTL, BENCH, MAILBOX, Path(__file__), HERE / "epoch_sealed_bank.py"):
        shutil.copyfile(source, path / source.name)
    source = path / RTL.name
    if mutation:
        old, new = mutation
        text = source.read_text()
        assert text.count(old) == 1
        source.write_text(text.replace(old, new))
    inventory = {item.name: hashlib.sha256(item.read_bytes()).hexdigest()
                 for item in path.iterdir() if item.is_file()}
    (path / "sources.json").write_text(json.dumps(inventory, indent=2))
    command = ["iverilog", "-g2012", "-s", "tb_epoch_sealed_bank", "-o", "simv",
               RTL.name, BENCH.name, MAILBOX.name]
    process = subprocess.run(command, cwd=path, env=child_env(), text=True,
                             capture_output=True, check=False)
    (path / "compile.log").write_text(process.stdout + process.stderr)
    (path / "compile_command.json").write_text(json.dumps({"command": command, "exit": process.returncode}))
    assert process.returncode == 0, process.stdout + process.stderr
    return path


@pytest.fixture(scope="module")
def compiled(tmp_path_factory):
    parent = tmp_path_factory.mktemp("sealed_sources")
    return compile_case(parent / "original")


def execute(path, case, bit=0, phase=0):
    command = ["vvp", "simv", f"+CASE={case}", f"+BIT={bit}", f"+PHASE={phase}"]
    process = subprocess.run(command, cwd=path, env=child_env(), text=True,
                             capture_output=True, check=False, timeout=30)
    name = f"case-{case}-bit-{bit}-phase-{phase}"
    with (path / f"{name}.log").open("x") as stream:
        stream.write(process.stdout + process.stderr)
    (path / f"{name}.json").write_text(json.dumps({"command": command, "exit": process.returncode}))
    assert process.returncode == 0, (process.stdout + process.stderr)[-3000:]
    return MODEL.verify_events(process.stdout + process.stderr, case, bit, phase)


@pytest.mark.parametrize("case,bit,phase", [(0, 0, 0), (4, 0, 0), (5, 0, 0), (7, 0, 0),
                                           (8, 0, 0), (9, 0, 0), (10, 0, 0), (10, 0, 1),
                                           (12, 0, 0), (13, 0, 0)])
def test_ownership_issuers_and_current_faults(compiled, case, bit, phase):
    execute(compiled, case, bit, phase)


@pytest.mark.parametrize("bit", range(75))
@pytest.mark.parametrize("phase", range(3))
def test_every_metadata_bit_first_interior_final(compiled, bit, phase):
    execute(compiled, 1, bit, phase)


@pytest.mark.parametrize("bit", range(75))
def test_every_certificate_bit_after_seal(compiled, bit):
    execute(compiled, 2, bit, 1)


@pytest.mark.parametrize("bit", range(8))
@pytest.mark.parametrize("phase", range(4))
def test_live_cause_at_each_final_boundary(compiled, bit, phase):
    execute(compiled, 3, bit, phase)


@pytest.mark.parametrize("side", range(2))
@pytest.mark.parametrize("phase", range(5))
def test_one_sided_reset_join_and_explicit_finite_peer_drain(compiled, side, phase):
    execute(compiled, 6, side, phase)


@pytest.mark.parametrize("kind", range(6))
def test_unknown_current_interface_is_simulation_fail_closed(compiled, kind):
    execute(compiled, 11, kind)


MUTANTS = [
    ("seal_q && full && certificate_seen && pipe_empty", "seal_q && full && 1'b1 && pipe_empty", 0),
    ("full && !seal_q &&\n      check_valid[1]", "full && !seal_q &&\n      check_valid[0]", 13),
    ("wire publication_current_clean = live_clean", "wire publication_current_clean = 1'b1", 3),
    (" && !closed_input_offer && !duplicate_certificate_offer", " && 1'b1 && !duplicate_certificate_offer", 7),
    (" && !duplicate_certificate_offer && !uncertain_interface", " && 1'b1 && !uncertain_interface", 8),
    ("!(&equal_groups)", "!(&equal_groups[3:0])", 1),
    ("old_certificate_drained && old_input_drained", "certificate_valid === 1'b0 && input_valid === 1'b0", 9),
    ("certificate_lease !== lease ||", "1'b0 ||", 2),
    ("lease_release_tag !== lease", "1'b0", 5),
    ("reasons <= reasons | errors_now;", "reasons <= errors_now;", 10),
    ("if (rearm_valid === 1'b1 && rearm_ready) armed <= 1;", "if (!armed) armed <= 1;", 6),
    ("if (private_take) payload_memory[write_position] <= input_data;", "if (private_take) payload_memory[write_position] <= input_data ^ 36'b1;", 13),
]


@pytest.mark.parametrize("index", [0, 1, 2, 3, 4, 6, 8, 9, 10, 11])
def test_semantic_mutants_reject(tmp_path, index):
    old, new, case = MUTANTS[index]
    path = compile_case(tmp_path / "mutant", (old, new))
    with pytest.raises((AssertionError, ValueError)):
        execute(path, case)


def test_state_and_literal_legacy_binding():
    assert hashlib.sha256(MAILBOX.read_bytes()).hexdigest() == "e85122eb6689ff49b31aa5a0c200e2666786629055b4f45856fe79fb829dbb55"
    text = RTL.read_text()
    assert "parameter integer SEALED_PUBLICATION = 0" in text
    assert "if (SEALED_PUBLICATION !== 0 && SEALED_PUBLICATION !== 1)" in text
    assert ".METADATA_WIDTH(75), .EXPLICIT_COMMIT(1)" in text
    assert text.count("payload_memory [0:511]") == 1
    state = MODEL.logical_state(text)
    assert state["memory"] == {"payload_memory": 512 * 36}
    assert state["reused_bank_bits"] == 222
    assert state["registers"]["equal_leaves"] == 25
    assert state["registers"]["equal_groups"] == 5
    assert state["registers"]["check_position0"] == state["registers"]["check_position1"] == 9
    assert "input_metadata !== metadata_in_hold" not in text.split("wire framing_bad", 1)[1].split(";", 1)[0]
    fence = text.split("wire publication_current_clean =", 1)[1].split(";", 1)[0]
    assert not re.search("framing|certificate_bad|pipeline_bad|local_current_clean", fence)


@pytest.mark.parametrize("suffix", ["\nFATAL: late failure", "\nERROR late", "\nSEALED_BANK_PASS case=0 bit=0 phase=0 cycles=2", "\nunknown_receipt"])
def test_terminal_and_late_failure_are_strict(suffix):
    with pytest.raises(ValueError):
        MODEL.verify_events("SEALED_BANK_PASS case=0 bit=0 phase=0 cycles=1" + suffix, 0)

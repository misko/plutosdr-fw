"""Independent transaction/event checks for the offline sealed-bank prototype."""
import re


def golden_metadata(job):
    return (1 << 74) | ((0x200000001 + job * 447) << 10) | (7 << 5) | 9


def golden_word(job, position):
    return (((job + 1) * 0x123450001 + position * 0x10203) ^ (position << 19)) & ((1 << 36) - 1)


def verify_events(log, case, bit=0, phase=0):
    """No candidate predicates/state are used as the expected token or deadline."""
    if re.search(r"(?i)\b(fatal|error|fail)\b", log):
        raise ValueError("failed simulation")
    terminals = re.findall(r"^SEALED_BANK_PASS case=(\d+) bit=(\d+) phase=(\d+) cycles=(\d+)$", log, re.MULTILINE)
    if len(terminals) != 1 or tuple(map(int, terminals[0][:3])) != (case, bit, phase):
        raise ValueError("missing/duplicate/wrong terminal")
    bank = None
    completed = 0
    published = 0
    words = 0
    seals = 0
    lease_history = []
    previous_cycle = -1
    for line in log.splitlines():
        parts = line.split()
        if not parts:
            continue
        kind = parts[0]
        if kind in ("RESET", "JOB", "TAKE", "CERT", "SEAL", "PUB", "OUT", "REL", "FAULT"):
            if int(parts[1]) < previous_cycle:
                raise ValueError("event cycle moved backwards")
            previous_cycle = int(parts[1])
        if kind == "RESET":
            bank = None
        elif kind == "JOB":
            _, cycle, epoch, lease, job, metadata = parts
            if bank is not None:
                raise ValueError("bank overwritten before release/reset")
            bank = {"epoch": int(epoch), "lease": int(lease), "job": int(job),
                    "take": [], "read": 0, "certificate": False, "sealed": False,
                    "published": False, "poison": False, "fault": False,
                    "local_bad": False, "first_metadata": None, "first_bad_token": None}
            if int(metadata, 16) != golden_metadata(int(job)):
                raise ValueError("source descriptor is not independent golden")
            lease_history.append(int(lease))
        elif kind == "TAKE":
            _, cycle, epoch, lease, position, data, metadata, last = parts
            if bank is None or bank["published"] or len(bank["take"]) >= 512:
                raise ValueError("duplicate/unowned private take")
            ordinal = len(bank["take"])
            if int(epoch) != bank["epoch"]:
                raise ValueError("take changed epoch")
            if int(data, 16) != golden_word(bank["job"], ordinal):
                raise ValueError("private data differs from independent source")
            legal = (int(position) == ordinal and int(last) == (ordinal == 511)
                     and int(metadata, 16) == golden_metadata(bank["job"]))
            if bank["first_metadata"] is None:
                bank["first_metadata"] = int(metadata, 16)
            locally_bad = (int(position) != ordinal or int(last) != (ordinal == 511)
                           or int(metadata, 16) != bank["first_metadata"] or int(lease) != bank["lease"])
            bank["local_bad"] |= locally_bad
            if locally_bad and bank["first_bad_token"] is None:
                bank["first_bad_token"] = (int(cycle), int(position), int(lease))
            bank["poison"] |= not legal
            bank["take"].append(int(cycle))
        elif kind == "CERT":
            _, cycle, epoch, lease, metadata, good = parts
            if bank is None or bank["certificate"]:
                raise ValueError("unowned or duplicate consumed certificate")
            legal = (int(epoch) == bank["epoch"] and int(lease) == bank["lease"]
                     and int(metadata, 16) == golden_metadata(bank["job"]) and int(good) == 1)
            bank["certificate"] = legal
            bank["certificate_cycle"] = int(cycle)
            bank["poison"] |= not legal
        elif kind == "SEAL":
            if bank is None or bank["sealed"] or len(bank["take"]) != 512:
                raise ValueError("seal before complete exactly-once payload")
            if int(parts[1]) != bank["take"][-1] + 2 or bank["local_bad"] or bank["fault"]:
                raise ValueError("wrong drain latency or invalid seal")
            if (int(parts[2]), int(parts[3])) != (bank["epoch"], bank["lease"]):
                raise ValueError("seal ownership mismatch")
            bank["sealed"] = True
            bank["seal_cycle"] = int(parts[1])
            seals += 1
        elif kind == "PUB":
            if (bank is None or not bank["sealed"] or not bank["certificate"]
                    or bank["published"] or bank["poison"] or bank["fault"]):
                raise ValueError("uncertified/duplicate publication")
            if (int(parts[1]) < bank["take"][-1] + 3 or int(parts[1]) <= bank["seal_cycle"]
                    or int(parts[1]) <= bank["certificate_cycle"]):
                raise ValueError("publication before drain")
            if (int(parts[2]), int(parts[3])) != (bank["epoch"], bank["lease"]):
                raise ValueError("publication ownership mismatch")
            bank["published"] = True
            published += 1
        elif kind == "OUT":
            _, cycle, epoch, lease, position, data, metadata, last = parts
            if bank is None or not bank["published"] or bank["fault"]:
                raise ValueError("unpublished/faulted output")
            ordinal = bank["read"]
            if ((int(epoch), int(lease), int(position), int(last)) !=
                    (bank["epoch"], bank["lease"], ordinal, int(ordinal == 511))
                    or int(data, 16) != golden_word(bank["job"], ordinal)
                    or int(metadata, 16) != golden_metadata(bank["job"])):
                raise ValueError("output numerical/metadata/ownership mismatch")
            bank["read"] += 1
            bank["last_read_cycle"] = int(cycle)
            words += 1
        elif kind == "REL":
            if bank is None or not bank["published"] or bank["read"] != 512 or bank["fault"]:
                raise ValueError("release before complete valid read")
            if (int(parts[2]), int(parts[3])) != (bank["epoch"], bank["lease"]):
                raise ValueError("release ownership mismatch")
            if int(parts[1]) < bank["last_read_cycle"] + 3:
                raise ValueError("release before ACK synchronization")
            completed += 1
            bank = None
        elif kind == "FAULT":
            if bank is not None and int(parts[3], 16):
                bank["fault"] = True
        elif kind == "TWO_EDGE_FAULT":
            match = re.fullmatch(r"TWO_EDGE_FAULT cycle=(\d+) pos=(\d+) lease=(\d+)", line)
            if match is None or bank is None or bank["first_bad_token"] is None:
                raise ValueError("unowned delayed fault receipt")
            clock, position, lease = map(int, match.groups())
            origin, expected_position, expected_lease = bank["first_bad_token"]
            if (clock, position, lease) != (origin + 2, expected_position, expected_lease):
                raise ValueError("delayed fault lost original token identity")
        elif kind not in ("SEALED_BANK_PASS", "ISSUER_TIMEOUT"):
            raise ValueError(f"unknown receipt: {line}")
    expected_completed = {0: 8, 6: 1, 9: 2, 13: 1}.get(case, 0)
    if completed != expected_completed:
        raise ValueError("incomplete expected healthy inventory")
    if case == 0 and lease_history != [0, 1, 2, 3, 0, 1, 2, 3]:
        raise ValueError("missing drained lease-wrap coverage")
    if case in (1, 2, 3, 4, 7, 8, 11, 12, 14, 15, 16) and published:
        raise ValueError("negative profile published")
    if case == 12 and not re.search(r"^ISSUER_TIMEOUT age=8\d{3}$", log, re.MULTILINE):
        raise ValueError("missing independent bounded issuer timeout")
    return {"completed": completed, "published": published, "words": words,
            "seals": seals, "lease_history": lease_history}


def logical_state(rtl):
    """Count declared logical registers, not a mapped resource estimate."""
    staged = rtl.split("end else begin : staged", 1)[1]
    staged = re.sub(r"//[^\n]*", "", staged)
    registers = {}
    memory = {}
    for match in re.finditer(r"\breg\s*(?:\[(\d+):0\])?\s+([^;]+);", staged):
        width = int(match[1]) + 1 if match[1] else 1
        for name in match[2].split(","):
            name = name.strip()
            array = re.fullmatch(r"(\w+)\s*\[0:(\d+)\]", name)
            if array:
                memory[array[1]] = width * (int(array[2]) + 1)
            elif re.fullmatch(r"\w+", name):
                if name in registers:
                    raise ValueError("duplicate declared state")
                registers[name] = width
            else:
                raise ValueError(f"unknown state declaration: {name}")
    reused = {"metadata_in_hold", "metadata_out_hold", "write_position", "request_toggle",
              "acknowledge_toggle", "request_sync", "acknowledge_sync", "reading",
              "read_all_loaded", "read_valid", "read_address", "read_output_position", "read_payload"}
    return {"registers": registers, "memory": memory,
            "all_register_bits": sum(registers.values()),
            "reused_bank_bits": sum(registers[name] for name in reused),
            "new_control_bits": sum(value for name, value in registers.items() if name not in reused)}

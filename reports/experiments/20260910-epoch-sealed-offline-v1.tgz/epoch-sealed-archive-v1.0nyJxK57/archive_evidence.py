"""One-shot read-only source/log audit and portable archive; no simulator launch."""
import ast
import hashlib
import importlib.util
import json
import os
import re
import subprocess
import tarfile
from pathlib import Path

OWNER = Path(__file__).parent
RECOVERY = OWNER.parent
FW = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic')
ACQ = FW / 'hdl/library/starlink_pss_acquisition'
ROOTS = [RECOVERY / name for name in (
    'epoch-sealed-smoke-v1.jjp4L9z7', 'epoch-sealed-tests-v1.X3u1HOqu',
    'epoch-sealed-tests-v2.4AMJtgtA', 'epoch-sealed-tests-v3.I3lszlLF',
    'epoch-sealed-tests-v4.ANpePoWN', 'epoch-sealed-tests-v5.LvArdYld',
    'epoch-sealed-tests-v6.92Nhpa0l')]
FINAL = ROOTS[-1]
SOURCES = [ACQ / name for name in ('starlink_pss_epoch_sealed_bank.v',
    'tb_epoch_sealed_bank.sv', 'tb_epoch_sealed_legacy.sv', 'starlink_pss_block_mailbox.v')]
SOURCES += [FW / 'tests/starlink_oracle' / name for name in
            ('epoch_sealed_bank.py', 'test_epoch_sealed_bank.py')]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')

def command(argv, cwd=FW):
    process = subprocess.run(argv, cwd=cwd, env={key: value for key, value in os.environ.items()
        if key not in ('LD_LIBRARY_PATH', 'PYTHONHOME', 'PYTHONPATH')}, capture_output=True, text=True)
    return {'argv': argv, 'exit': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr}

assert command(['git', 'rev-parse', 'HEAD'])['stdout'].strip() == 'f8754e23afc136870d1dd68228bdecb197a6e6c7'
assert command(['git', 'rev-parse', 'HEAD'], FW / 'hdl')['stdout'].strip() == '2c2460ad55981ed0833eeadfef60463f1d1bca10'
source_hashes = {str(path.relative_to(FW)): digest(path) for path in SOURCES}
original = FINAL / 'cases/sealed_sources0/original'
for path in SOURCES:
    assert digest(original / path.name) == digest(path), path
freeze_count = 0
for inventory in FINAL.rglob('sources.json'):
    for name, expected in json.loads(inventory.read_text()).items():
        assert Path(name).name == name
        assert digest(inventory.parent / name) == expected, inventory
    freeze_count += 1

spec = importlib.util.spec_from_file_location('frozen_sealed_model', original / 'epoch_sealed_bank.py')
model = importlib.util.module_from_spec(spec)
spec.loader.exec_module(model)
profiles = {}
for path in sorted(original.glob('case-*.log')):
    case, bit, phase = map(int, re.fullmatch(r'case-(\d+)-bit-(\d+)-phase-(\d+)\.log', path.name).groups())
    profiles[path.name] = model.verify_events(path.read_text(), case, bit, phase)
    assert json.loads(path.with_suffix('.json').read_text())['exit'] == 0

tree = ast.parse((original / 'test_epoch_sealed_bank.py').read_text())
mutations = next(ast.literal_eval(node.value) for node in tree.body
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'MUTANTS'
        for target in node.targets))
mutants = {}
base_rtl = (original / 'starlink_pss_epoch_sealed_bank.v').read_text()
for directory in FINAL.glob('cases/test_semantic_mutants_reject*/mutant'):
    if directory.parent.is_symlink():
        continue
    actual = (directory / 'starlink_pss_epoch_sealed_bank.v').read_text()
    indices = [index for index, (old, new, _) in enumerate(mutations)
               if base_rtl.count(old) == 1 and actual == base_rtl.replace(old, new)]
    assert len(indices) == 1 and indices[0] not in mutants
    logs = list(directory.glob('case-*.log'))
    assert len(logs) == 1
    receipt = json.loads(logs[0].with_suffix('.json').read_text())
    failures = re.findall(r'^FATAL: .+$', logs[0].read_text(), re.MULTILINE)
    assert receipt['exit'] != 0 and failures, directory
    mutants[indices[0]] = {'log': str(logs[0].relative_to(RECOVERY)),
        'exit': receipt['exit'], 'fatal': failures, 'sha256': digest(logs[0])}
assert len(mutants) == len(mutations) == 15
assert '526 passed in 8.14s' in (FINAL / 'pytest.log').read_text()

versions = {'observation_scope': 'post-run tool inventory, not a pre-run binary freeze',
    'python': command(['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python', '-B', '--version']),
    'iverilog': command(['iverilog', '-V']), 'vvp': command(['vvp', '-V']),
    'ruff': command(['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/ruff', 'check',
        'tests/starlink_oracle/epoch_sealed_bank.py', 'tests/starlink_oracle/test_epoch_sealed_bank.py'])}
assert all(item['exit'] == 0 for item in versions.values() if isinstance(item, dict))
write_new(OWNER / 'postrun_tools.json', versions)

files = {}
excluded_links = []
for root in ROOTS:
    for path in sorted(root.rglob('*')):
        name = str(path.relative_to(RECOVERY))
        if path.is_symlink():
            excluded_links.append({'name': name, 'target': os.readlink(path)})
        elif path.is_file():
            files[name] = path
for path in SOURCES:
    files['current_source/' + str(path.relative_to(FW))] = path
for name in ('starlink-epoch-sealed-bank-offline-20260910.md', 'starlink-epoch-owned-pipeline-proposal-20260910.md'):
    files['current_source/docs/' + name] = FW / 'docs' / name
files['archive_evidence.py'] = Path(__file__)
files['postrun_tools.json'] = OWNER / 'postrun_tools.json'
summary = {'scope': 'offline standalone only; prior attempts preserve original outcomes',
    'fw_source_commit': 'f8754e23afc136870d1dd68228bdecb197a6e6c7',
    'hdl_source_commit': '2c2460ad55981ed0833eeadfef60463f1d1bca10',
    'original_final_handle': 92094, 'final_exit': 0, 'tests_passed': 526, 'seconds': 8.14,
    'final_source_hashes_before_after': source_hashes, 'verified_compile_freezes': freeze_count,
    'state': model.logical_state(base_rtl), 'independently_reparsed_profiles': profiles,
    'executed_rejected_mutants': mutants, 'excluded_pytest_navigation_symlinks': excluded_links,
    'manual_smoke_compile_stderr': 'Tool-output-only; not reconstructed as a raw file.',
    'member_hashes': {name: digest(path) for name, path in files.items()}}
write_new(OWNER / 'assessment.json', summary)
files['assessment.json'] = OWNER / 'assessment.json'
inventory = {name: digest(path) for name, path in files.items()}
archive = OWNER / 'epoch-sealed-offline-v1.tgz'
assert not archive.exists()
with tarfile.open(archive, 'x:gz') as stream:
    for name, path in sorted(files.items()):
        stream.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as stream:
    members = stream.getmembers()
    assert len(members) == len(inventory) == len({member.name for member in members})
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        assert hashlib.sha256(stream.extractfile(member).read()).hexdigest() == inventory[member.name]
for name, path in files.items():
    assert digest(path) == inventory[name], name
receipt = {'archive_sha256': digest(archive), 'archive_bytes': archive.stat().st_size,
    'regular_unique_verified_members': len(inventory), 'member_hashes': inventory,
    'assessment_sha256': digest(OWNER / 'assessment.json'), 'source_pins':
    [summary['fw_source_commit'], summary['hdl_source_commit']], 'tests_passed': 526}
write_new(OWNER / 'archive_receipt.json', receipt)
print(json.dumps({key: value for key, value in receipt.items() if key != 'member_hashes'}, indent=2))

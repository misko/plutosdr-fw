"""Package the single negative diagnostic route without rerunning any tool."""

import hashlib
import json
import re
import tarfile
from pathlib import Path

FW = Path(__file__).resolve().parents[4]
RUN = Path("/tmp/starlink-arithmetic-route-v1.VNX5gK")
ROUTE = RUN / "route"
OUTPUT = FW / "reports/experiments/20260910-bank-arithmetic-ooc-route-v1.tgz"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


assert (RUN / "inputs-before.sha256").read_bytes() == (RUN / "inputs-after.sha256").read_bytes()
inputs = {}
for line in (RUN / "inputs-before.sha256").read_text().splitlines():
    expected, name = line.split("  ", 1)
    assert sha(Path(name)) == expected
    inputs[Path(name)] = expected
assert set(inputs.values()) == {
    "de5b7ca6849c8111ccfce29ca39bbf8899276c0dea309abb576e70546daf06bf",
    "0873675fcec384f676a80b75b746460fbff2ecc3ee162f6111705ead2fad6d4a"}
assert sha(ROUTE / "probe.tcl") == "0873675fcec384f676a80b75b746460fbff2ecc3ee162f6111705ead2fad6d4a"
log = (RUN / "outer.log").read_text()
marker = "COMPLETED_INPUT_DIAGNOSTIC_RECORDED_NOT_A_PHYSICAL_RELEASE_PASS"
assert log.splitlines().count(marker) == 1
assert not re.search(r"^(ERROR|FATAL):", log, re.MULTILINE)
assert re.findall(r"^\s*Exit status: (\d+)$", (RUN / "process-time.txt").read_text(), re.MULTILINE) == ["0"]
assert "Timing constraints are not met." in (ROUTE / "timing_unqualified.rpt").read_text()
assert sha(ROUTE / "completed_input_diagnostic_routed.dcp") == "e8a6336eb4079d8d27ac9596cd6fcb7322da656d0f8f04d6ac67e619ed5a7413"
receipt = dict(line.split("=", 1) for line in (ROUTE / "receipt.txt").read_text().splitlines())
assert [receipt[k] for k in ("source_100.max.slack", "source_100.min.slack", "island_175.max.slack", "island_175.min.slack")] == ["2.454", "0.138", "-1.341", "0.038"]
files = {"owner/" + str(path.relative_to(RUN)): path for path in sorted(RUN.rglob("*")) if path.is_file()}
assert not any(path.is_symlink() for path in RUN.rglob("*"))
for path in inputs:
    files["input/" + path.name] = path
for name in ("starlink-bank-arithmetic-ooc-route-20260910.md", "starlink-bank-arithmetic-ooc-synthesis-20260910.md"):
    files["docs/" + name] = FW / "docs" / name
files["archive_arithmetic_ooc_route.py"] = Path(__file__).resolve()
hashes = {name: sha(path) for name, path in files.items()}
with OUTPUT.open("xb") as raw:
    with tarfile.open(fileobj=raw, mode="w:gz") as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
with tarfile.open(OUTPUT, "r:gz") as archive:
    members = archive.getmembers()
    assert len(members) == len(files) == len({member.name for member in members})
    for member in members:
        assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
        assert hashlib.sha256(archive.extractfile(member).read()).hexdigest() == hashes[member.name]
assert hashes == {name: sha(path) for name, path in files.items()}
result = {"scope": "single_diagnostic_OOC_route_TIMING_FAIL_NOT_receiver_release",
          "original_handle": 42281, "process_exit": 0, "elapsed_seconds": 58.32,
          "route_completion": "all_6762_routable_nets_routed_zero_errors", "timing_status": "FAIL",
          "global_WNS_ns": -1.341, "global_TNS_ns": -386.804, "global_setup_failing_endpoints": 497,
          "global_WHS_ns": 0.038, "global_hold_failing_endpoints": 0,
          "same_domain_receipt": receipt, "original_source_pre_post_equal": True,
          "archive": OUTPUT.name, "archive_bytes": OUTPUT.stat().st_size, "archive_sha256": sha(OUTPUT),
          "safe_unique_regular_files": len(files), "file_sha256": hashes,
          "no_retry_source_edit_exception_receiver_RF_or_timing_pass": True}
with OUTPUT.with_suffix(".json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in result.items() if key != "file_sha256"}, indent=2))

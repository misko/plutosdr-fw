# Actual healthy30-upper bank175/native132/PIL1 result

PASS: original execution handle57213 terminated with exit0. Actual Vivado2022.2
simulation, strict result parser, and post-run frozen-source verification all
passed. One environment-corrected run; no retry, tail extension, source edit,
alternate profile, physical build, receiver change or radio operation.

Frozen FW6a99d1d538889c79630758ac86c4493ea254640d and
HDL446a8617adbabcce5122705e528dc997ff06d263. Both worktrees remain clean.
95-source signature413f9cd065da934d258750b30075d5e9c75ff16efd9484a51222ca0b3043cb31;
bundleSHA2d410bc8a7984425751a527725e8f43c8406596b23f610e904199d1524863da5.
The full358-input inventory remained unchanged. Runner enforced maxThreads2.

## Actual exact observations

| Stream or stage | Exact checked count |
|---|---:|
| Original-source/CDC including two prime and4096 tail |12303/12303 |
| Enabled conditioner raw/canonical |7250/3618 |
| Actual175-clock forward input/output/product |1536/1536/1536 |
| Actual175-clock inverse input / slow returned inverse output |1536/1024 |
| Sample-energy and normalized69-bit numerator/denominator |894/894 |
| Visible/admitted scores |894/894 |
| Complete public map words |447 |
| Native original-raw capture |260 |
| Native raw/qualified tuples |129/121 |
| Native26-word public packet, retained and read twice |52 reads |
| Pilot accepted/mixed/half/all outputs |3617/3617/1808/602 |
| Pilot selected/AXIS delivered |512/512 (2048 bytes) |

The third inverse job's input was actually consumed; no third slow inverse
output was observed. Every observed prefix in the frozen checker was exact.
This is not a claim that all seven stored oracle blocks executed or that the
third job completed. No score tail entered the map.

Actual native admission:index17179869201, capture_start17179870128, lead926,
deadline17179869408. Public PSMA1.7/caps0x7ff/30-upper conditioner identity and
native132/PIL1 identity checks passed. No reported health failure, saturation,
source discontinuity, invalid tuple, missing strobe, buffer loss or timeout.

STOP occurred with source4946, canonical2464, pilot319, capture260 and native
correlator busy. The map remained owned through full map read and native
publication/read/release at source8991. Independent map release completed at
source9000; source continued to12303. Conditioner auto-stop cancelled only the
unpromised pipeline; its independent ledger matched the entire3618-output prefix.

Actual overlap witnesses:273 native-capture/FFT-consumption fast-clock beats;
6433 native-compute/coarse+pilot clocks;13219 native-compute clocks after STOP.
43723 fast-clock observations proved bank-local quiescence after teardown.

Native timing: capture_end_cycle13182, publication33092, release33882.
Publication19910 cycles; complete public read/release20700; maximum AXI8.
The original24000/28000-cycle bounds and fixed4096-source tail were unchanged.
The one-cycle publication difference from the native-only Icarus observation
is reported, not rounded away or used to change any bound.

Simulated endpoint453870ns; xsim reported18.960s simulation CPU and186440KB
peak simulation memory. These are gauss/x86_64 host observations, not ARM,
Zynq timing closure, RF accuracy, driver throughput, DMA/IIO,120ms dwell,
production20k×64 capacity, causal candidate scheduling,60MS/s or lower-edge evidence.

## Exact working invocation

Working directory:
`/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate-paired/hdl/library/starlink_pss_acquisition`

```sh
env LD_LIBRARY_PATH=/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE \
  /opt/Xilinx/Vivado/2022.2/bin/vivado -mode batch \
  -source /tmp/starlink-coarse-alternatives.Y3JzOI/high-rate-paired/hdl/library/starlink_pss_acquisition/simulate_high_rate_bank_native_paired.tcl \
  -log /tmp/starlink-bank-route.I50MDJ/main-high-rate30-bank175-447-v2.vivado.log \
  -journal /tmp/starlink-bank-route.I50MDJ/main-high-rate30-bank175-447-v2.vivado.jou \
  -tclargs /tmp/starlink-bank-route.I50MDJ/main-high-rate30-bank175-447-v2 \
  /tmp/starlink-coarse-alternatives.Y3JzOI/high-rate-paired/build/high-rate-harness-prelaunch-v1 \
  /home/mouse9911/gits/pluto-plus-utils/.venv/bin/python
```

The earlier v1 attempt with LD_LIBRARY_PATH unset stopped in the vendor loader
before Tcl/project creation (missing libtinfo.so.5). Despite launcher exit0 it
is classified as failure, never PASS. Exact command/stderr is retained at
`../main-high-rate30-bank175-447-v1.initialization-failure.json`,
SHA223087f01f9fb9b68c75451fddeba62939c0b0adc44293e543baa119f26a59eb.
The installed real SuSE/libtinfo.so.5 supplied the missing dependency; no source
or system-library modification was required.

## Receipts and raw evidence

`prelaunch_receipt.txt`, `after_integrity.txt`, `run_status.txt` and
`terminal_receipt.json` retain independent pre/post integrity and terminal status.
Actual output directory is `project/high_rate_bank_native_paired.sim/sim_1/behav/xsim`.
There, `simulate.log` contains all512 pilot words,52 native packet reads and
the unique complete receipts. `native30_actual_raw_tuples.txt` contains all129
actual raw tuples; `paired_pilot_actual.ci16` contains the exact2048 AXIS bytes.

SHA256s:

- simulate.log:3fcb4f1b86a102421b8fd0f42b1e0885023782b4325303d599091942f67b47db
- raw tuples:1d16a0259f13a5a4ee914896c20449c9028bb79edd6a55253ae273496f908f8c
- pilot bytes:f461fa6399c6163d462835310bb18aeb431cec4153225c385cd4e7b79c5282ca
- generated actual FFT wrapper:a3a650654118016012bdfb8553114ee4a89866466d8ca774fa0f281640168a68

All generated project, IP, simulation and waveform artifacts remain in place;
the full directory is47MB, including a4.6MB default waveform. No artifact was
deleted. `artifact-inventory.sha256` inventories all regular run files except
itself; `external-launch-artifacts.sha256` covers the outer logs and v1 failure.

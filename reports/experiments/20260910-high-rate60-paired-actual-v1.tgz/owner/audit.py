"""Post-run read/hash audit only; never starts a simulator or edits its inputs."""

import hashlib
import json
import re
from pathlib import Path

OWNER=Path(__file__).resolve().parent
RUN=OWNER.with_name("main-high-rate60-bank175-447-v1")
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
EXTERNAL=WORK/"build/high-rate60-harness-prelaunch-v1"
SIM=RUN/"project/high_rate60_bank_native_paired.sim/sim_1/behav/xsim"
EXPECTED="b5f7d48a96217691d7a034634d3bdc7006e489066e571d93b00ce2ed5f741714"


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        while chunk:=f.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()


def main():
    out=OWNER/"post-audit.json"
    assert not out.exists()
    assert sha(EXTERNAL/"bundle.json")==sha(RUN/"inputs/bundle.json")==EXPECTED
    r=json.loads((RUN/"inputs/bundle.json").read_bytes())
    live={name:sha(WORK/name) for name in r["source_sha256"]}
    assert live==r["source_sha256"] and len(live)==108
    for prefix in [EXTERNAL,RUN/"inputs"]:
        assert all(sha(prefix/name)==digest for name,digest in r["files"].items())
    # Same original69 in both copies; every simulator-exported memory byte is
    # matched to its frozen vectors or immutable pilot/kernel source.
    memories={}
    for p in sorted((RUN/"inputs/vectors").glob("*.mem")):
        assert sha(SIM/p.name)==sha(p)
        memories[p.name]=sha(p)
    for name in ["pilot_mixer_q16.mem","pilot_halfband2_q17.mem","pilot_fir3_q17.mem"]:
        p=RUN/"inputs/source_snapshot/hdl/library/starlink_pss_acquisition"/name
        assert sha(SIM/name)==sha(p)
        memories[name]=sha(p)
    name="upper_edge_pss60_x4_ddc_kernel_q17.mem"
    p=RUN/"inputs/source_snapshot/hdl/library/starlink_pss_acquisition/tb"/name
    assert sha(SIM/name)==sha(p)
    memories[name]=sha(p)
    generated_before,wrapper=(RUN/"generated_ip.txt").read_text().strip().split(maxsplit=1)
    generated_after=sha(Path(wrapper))
    assert generated_before==generated_after
    assert (RUN/"run_status.txt").read_text().splitlines()[0]=="run_tcl_exit=0 integrity_exit=0"
    terminal=json.loads((RUN/"terminal_receipt.json").read_bytes())
    assert terminal==json.loads((OWNER/"independent-result.json").read_bytes())
    assert terminal["result"]=="HIGH_RATE60_SIMULATION_VERIFIED"
    log=(SIM/"simulate.log").read_text()
    assert not re.search(r"warning|fatal|error|fail",log,re.I)
    assert len(re.findall(r"^HIGH_RATE60_",log,re.M))==521
    assert len(re.findall(r"^NATIVE60_",log,re.M))==60
    files=sorted(p for p in RUN.rglob("*") if p.is_file())
    assert not any(p.is_symlink() for p in RUN.rglob("*"))
    assert len(files)<=700 and sum(p.stat().st_size for p in files)<100_000_000
    assert all(p.stat().st_size<32_000_000 for p in files)
    artifacts={p.relative_to(RUN).as_posix():{"sha256":sha(p),"bytes":p.stat().st_size} for p in files}
    external_logs={p.name:{"sha256":sha(p),"bytes":p.stat().st_size}
                   for p in [RUN.with_suffix(".vivado.log"),RUN.with_suffix(".vivado.jou")]}
    assert all(sha(RUN/name)==entry["sha256"] for name,entry in artifacts.items())
    result={"result":"POST_RUN_AUDIT_PASS","original_handle":5432,"original_exit":0,
        "bundle_before_and_after_sha256":EXPECTED,"source_signature":r["source_signature"],"live_source_sha256":live,
        "both_external_and_run_input_files_verified":len(r["files"]),"actual_simulator_memories_verified":memories,
        "generated_wrapper_before_sha256":generated_before,"generated_wrapper_after_sha256":generated_after,
        "generated_wrapper":wrapper,"full_run_files":len(artifacts),"full_run_bytes":sum(v["bytes"] for v in artifacts.values()),
        "full_run_artifacts":artifacts,"external_logs":external_logs,"terminal":terminal,
        "audit_script_sha256":sha(Path(__file__)),"source_runtime_golden_budget_changes":False,"retries":0}
    out.write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ["result","full_run_files","full_run_bytes","generated_wrapper_after_sha256","bundle_before_and_after_sha256"]},sort_keys=True))


if __name__=="__main__":
    main()

"""Compact actual-run proof archive; raw544-file run remains untouched."""

import io
import json
import tarfile
from pathlib import Path

from audit import EXTERNAL, OWNER, RUN, SIM, WORK, sha


def main():
    archive=WORK/"reports/experiments/20260910-high-rate60-paired-actual-v1.tgz"
    adjacent=archive.with_suffix(".json")
    assert not archive.exists() and not adjacent.exists()
    audit=json.loads((OWNER/"post-audit.json").read_bytes())
    assert audit["result"]=="POST_RUN_AUDIT_PASS" and audit["full_run_files"]==544
    inputs=json.loads((RUN/"inputs/bundle.json").read_bytes())
    paths={"inputs/"+name:RUN/"inputs"/name for name in [*inputs["files"],"bundle.json"]}
    for name in ["before_integrity.txt","after_integrity.txt","generated_ip.txt","run_status.txt","terminal_receipt.json"]:
        paths["run/"+name]=RUN/name
    for p in SIM.iterdir():
        # Keep original receipts and simulator commands/logs, not the large WDB,
        # compiled kernels or duplicate exported golden memories.
        if p.is_file() and p.suffix in {".log",".txt",".ci16",".prj",".tcl",".sh",".ini"}:
            paths["simulation/"+p.name]=p
    wrapper=Path(audit["generated_wrapper"])
    assert sha(wrapper)==audit["generated_wrapper_before_sha256"]
    paths["generated/"+wrapper.name]=wrapper
    xcifiles=list((RUN/"project").rglob("*.xci"))
    assert len(xcifiles)==1
    paths["generated/"+xcifiles[0].name]=xcifiles[0]
    for name in ["owner.json","audit.py","package.py","post-audit.json","independent-result.json","external-after.json"]:
        paths["owner/"+name]=OWNER/name
    for suffix in [".vivado.log",".vivado.jou"]:
        p=RUN.with_suffix(suffix)
        assert sha(p)==audit["external_logs"][p.name]["sha256"]
        paths["vendor/"+p.name]=p
    paths["report.md"]=WORK/"docs/starlink-high-rate60-paired-result-20260910.md"
    assert len(paths)<400 and all(not p.is_symlink() for p in paths.values())
    assert sum(p.stat().st_size for p in paths.values())<12_000_000
    payloads={name:p.read_bytes() for name,p in sorted(paths.items())}
    for name in payloads:
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
    receipts={name:{"bytes":len(data),"sha256":__import__("hashlib").sha256(data).hexdigest()}
              for name,data in payloads.items()}
    payloads["receipts.json"]=(json.dumps(receipts,sort_keys=True,indent=2)+"\n").encode()
    with tarfile.open(archive,"w:gz") as t:
        for name,data in sorted(payloads.items()):
            m=tarfile.TarInfo(name); m.size=len(data); m.mtime=0; m.mode=0o644
            t.addfile(m,io.BytesIO(data))
    with tarfile.open(archive,"r:gz") as t:
        members=t.getmembers()
        assert len(members)==len(payloads) and all(m.isfile() for m in members)
        assert {m.name:t.extractfile(m).read() for m in members}==payloads
    # Recheck the complete original run, not merely selected portable members.
    assert all(sha(RUN/name)==v["sha256"] for name,v in audit["full_run_artifacts"].items())
    assert sha(EXTERNAL/"bundle.json")==audit["bundle_before_and_after_sha256"]
    assert all(sha(WORK/name)==digest for name,digest in audit["live_source_sha256"].items())
    summary={"archive":archive.name,"sha256":sha(archive),"bytes":archive.stat().st_size,
        "members":len(payloads),"receipt_files":len(receipts),"files":receipts,
        "original_run":str(RUN),"original_run_files_retained":544,"original_run_bytes":audit["full_run_bytes"],
        "generated_project_binaries_and_waveform_not_duplicated":True,"original_exit":0,"retries":0,
        "bundle_sha256":audit["bundle_before_and_after_sha256"],"source_signature":audit["source_signature"]}
    adjacent.write_text(json.dumps(summary,sort_keys=True,indent=2)+"\n")
    print(json.dumps({k:v for k,v in summary.items() if k!="files"},sort_keys=True))


if __name__=="__main__":
    main()

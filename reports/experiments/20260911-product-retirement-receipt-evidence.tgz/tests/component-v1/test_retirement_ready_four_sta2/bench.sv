`timescale 1ns/1ps
module tb;
reg product_owner_request,product_owner_ack_sync,fast_fault,staged_product_last,product_bank_ready;
integer n,checks=0;
function automatic four(input integer n);
case(n%4)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
  wire product_published_receipt = (product_owner_request ^ product_owner_ack_sync) === 1'b1;
  wire product_retire_ready = (fast_fault === 1'b0) &&
    (((staged_product_last === 1'b0) && (product_bank_ready === 1'b1)) ||
     ((staged_product_last === 1'b1) && 1'b1));

reg expected;
initial begin
 for(n=0;n<1024;n=n+1)begin
  product_owner_request=four(n);product_owner_ack_sync=four(n/4);fast_fault=four(n/16);
  staged_product_last=four(n/64);product_bank_ready=four(n/256);
  expected=0;
  if(fast_fault===0)begin
   if(staged_product_last===0)expected=product_bank_ready===1;
   if(staged_product_last===1)expected=(product_owner_request===0 && product_owner_ack_sync===1) ||
     (product_owner_request===1 && product_owner_ack_sync===0);
  end
  #1;if(product_retire_ready!==expected)$fatal(1,"retirement authority mismatch");checks=checks+1;
 end
 $display("RETIREMENT_FOUR_STATE_PASS checks=%0d",checks);$finish;
end
endmodule

`timescale 1ns/1ps
module tb;
reg clk=0,resetn=0,abort_epoch=0,reserve_valid=0,capture_valid=0,seal_valid=0,output_ready=1;
reg [69:0] reserve_descriptor=0,capture_descriptor=0;
reg [35:0] capture_data=0;
reg [8:0] capture_position=0;
reg capture_last=0;
reg [4:0] capture_exponent=7;
wire reserve_ready,capture_ready,output_valid,output_last,done_pulse,busy,fault,private_fault;
wire [35:0] output_data;
wire [8:0] output_position;
wire [4:0] output_exponent;
wire [69:0] output_descriptor;
starlink_pss_forward_return_private_descriptor #(.ADDRESS_WIDTH(2)) dut(.*);
integer n,k,tries,reads=0,recovered=0;
function automatic four(input integer n);
case(n%4)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
task tick;begin #1;clk=1;#1;clk=0;#1;end endtask
task restart;begin
 resetn=0;abort_epoch=0;reserve_valid=0;capture_valid=0;seal_valid=0;output_ready=1;tick;
 reads=0;resetn=1;tick;
end endtask
always @(posedge clk)if(resetn && output_valid && output_ready)begin
 if(output_data!==36'(100+reads) || output_position!==9'(reads) || output_last!==(reads==3) ||
    output_descriptor!==70'h12345 || output_exponent!==7)$fatal(1,"fresh replay mismatch");
 reads=reads+1;
end
initial begin
 for(n=0;n<768;n=n+1)begin
  restart;
  reserve_descriptor=n<256?70'habcdef:n<512?{70{1'bx}}:{70{1'bz}};
  reserve_valid=four(n);capture_valid=four(n/4);seal_valid=four(n/16);abort_epoch=four(n/64);
  tick;
  if(fault===1)begin
    abort_epoch=0;reserve_valid=1;capture_valid=1;seal_valid=1;
    repeat(4)tick;
    if(reserve_ready || capture_ready || output_valid)$fatal(1,"quarantined reservation reused");
  end
  restart;reserve_descriptor=70'h12345;capture_descriptor=70'h12345;
  reserve_valid=1;tick;reserve_valid=0;
  for(k=0;k<4;k=k+1)begin capture_valid=1;capture_position=k;capture_last=k==3;capture_data=100+k;tick;end
  capture_valid=0;capture_last=0;seal_valid=1;tick;seal_valid=0;
  for(tries=0;tries<12 && reads<4;tries=tries+1)tick;
  if(reads!=4 || fault)$fatal(1,"fresh recovery missing");
  recovered=recovered+1;tick;
 end
 if(private_differences==0)$fatal(1,"private descriptor delta not exercised");
 $display("PRIVATE_DESCRIPTOR_GRID_PASS cases=%0d fresh_reads=%0d private_differences=%0d",recovered,recovered*4,private_differences);$finish;
end

  wire old_reserve_ready,old_capture_ready,old_output_valid,old_output_last,old_done_pulse,old_busy,old_fault;
  wire [35:0] old_output_data;
  wire [8:0] old_output_position;
  wire [4:0] old_output_exponent;
  wire [69:0] old_output_descriptor;
  bank_reference #(.ADDRESS_WIDTH(2)) original(
    .clk(clk),.resetn(resetn),.abort_epoch(abort_epoch),.reserve_valid(reserve_valid),
    .reserve_ready(old_reserve_ready),.reserve_descriptor(reserve_descriptor),
    .capture_valid(capture_valid),.capture_ready(old_capture_ready),.capture_data(capture_data),
    .capture_position(capture_position),.capture_last(capture_last),.capture_exponent(capture_exponent),
    .capture_descriptor(capture_descriptor),.seal_valid(seal_valid),.output_ready(output_ready),
    .output_valid(old_output_valid),.output_data(old_output_data),.output_position(old_output_position),
    .output_last(old_output_last),.output_exponent(old_output_exponent),.output_descriptor(old_output_descriptor),
    .done_pulse(old_done_pulse),.busy(old_busy),.fault(old_fault));
  integer equivalence_checks=0,private_differences=0;
  task automatic compare;
    begin
      if({reserve_ready,capture_ready,output_valid,done_pulse,busy,fault} !==
         {old_reserve_ready,old_capture_ready,old_output_valid,old_done_pulse,old_busy,old_fault})
        $fatal(1,"private progress changed current control/fault contract");
      if(output_valid && {output_data,output_position,output_last,output_exponent,output_descriptor} !==
         {old_output_data,old_output_position,old_output_last,old_output_exponent,old_output_descriptor})
        $fatal(1,"private progress changed valid replay");
      if(dut.descriptor!==original.descriptor)begin
        if(!fault || output_valid || reserve_ready || capture_ready)
          $fatal(1,"private difference escaped quarantine");
        private_differences=private_differences+1;
      end
      if({dut.state,dut.fault_q,dut.write_count,dut.read_count,dut.exponent,dut.replay_valid,dut.output_position} !==
         {original.state,original.fault_q,original.write_count,original.read_count,original.exponent,original.replay_valid,original.output_position})
        $fatal(1,"descriptor load changed other bank state");
      equivalence_checks=equivalence_checks+1;
    end
  endtask
  always @(posedge clk)begin compare;#0.1;compare;end
  final $display("PRIVATE_FORWARD_CAPTURE_EQ checks=%0d private_differences=%0d current_exact=1 valid_payload_exact=1",equivalence_checks,private_differences);

endmodule

"""Additive arithmetic port, independent token math and offline bank ownership."""
import hashlib
import itertools
import random
import re
import subprocess
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
HDL = ROOT / "hdl"
ACQ = HDL / "library/starlink_pss_acquisition"
BASE = "dec20d6371f2d77b6e09c4bcdda2f3d7f8715776"
ROUND_BASE = "f7345ab655a21374f46d2bda89854f40295fca24"
CORE = "starlink_pss_spectrum_product_bank_arithmetic"
WRAPPER = "starlink_pss_spectrum_product_operand_register"
TOP = "starlink_pss_fft_bank_owned_arithmetic_probe"
LEGACY = "starlink_pss_spectrum_product"


def frozen(name, pin=BASE):
    return subprocess.run(["git", "-C", str(HDL), "show", f"{pin}:library/starlink_pss_acquisition/{name}"],
                          capture_output=True, text=True, check=True, timeout=15).stdout


def once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new, 1)


def round_blocks():
    source = frozen(f"{LEGACY}.v", ROUND_BASE)
    return [source[source.index(f"  // BEGIN {name}"):source.index(f"  // END {name}") + len(f"  // END {name}")]
            for name in ("BOUNDARY_ROUND_SAT", "BOUNDARY_ROUND_FUNCTION")]


def test_exact_additive_round_port_retains_entire_dec20_sequential_behavior():
    source = (ACQ / f"{CORE}.v").read_text()
    source = once(source, f"module {CORE} #(", f"module {LEGACY} #(")
    source = once(source, "  parameter integer PRIVATE_PAYLOAD_BUBBLES = 0,\n  parameter integer BOUNDARY_ROUND_SAT = 0",
                  "  parameter integer PRIVATE_PAYLOAD_BUBBLES = 0")
    selection, function = round_blocks()
    source = once(source, selection, "  assign rounded_real = round_and_saturate(sum_real);\n  assign rounded_imag = round_and_saturate(sum_imag);")
    source = once(source, function + "\n\n", "")
    assert source == frozen(f"{LEGACY}.v")


def test_original_bank_core_bench_and_all_control_modules_byte_unchanged():
    for name in ("starlink_pss_fft_bank_owned_slice", LEGACY, "starlink_pss_realtime_input_guard",
                 "starlink_pss_realtime_result_guard", "starlink_pss_block_mailbox",
                 "starlink_pss_forward_kernel_join", "starlink_pss_kernel_rom"):
        assert (ACQ / f"{name}.v").read_text() == frozen(f"{name}.v")
    name = "tb/tb_starlink_pss_fft_bank_owned_slice.sv"
    assert (ACQ / name).read_text() == frozen(name)


def test_exact_derived_top_inverse_and_held_fault_bindings():
    source = (ACQ / f"{TOP}.v").read_text()
    source = once(source, f"module {TOP} #(", "module starlink_pss_fft_bank_owned_slice #(")
    source = once(source, "  parameter integer REGISTERED_SCHEDULING = 0,\n  parameter integer BOUNDARY_ROUND_SAT = 0,\n  parameter integer REGISTER_OPERANDS = 0",
                  "  parameter integer REGISTERED_SCHEDULING = 0")
    source = once(source, f"  {WRAPPER} #(.DATA_WIDTH(18),\n    .BOUNDARY_ROUND_SAT(BOUNDARY_ROUND_SAT), .REGISTER_OPERANDS(REGISTER_OPERANDS),\n    .PRIVATE_PAYLOAD_BUBBLES(REGISTERED_SCHEDULING)) product (",
                  f"  {LEGACY} #(.DATA_WIDTH(18),\n    .PRIVATE_PAYLOAD_BUBBLES(REGISTERED_SCHEDULING)) product (")
    assert source == frozen("starlink_pss_fft_bank_owned_slice.v")
    assert ".output_overflow(product_overflow), .overflow_pulse()" in source
    assert source.count("product_overflow || product_bank_fault") == 2
    wrapper = (ACQ / f"{WRAPPER}.v").read_text()
    assert f"  {CORE} #(" in wrapper
    assert ".PRIVATE_PAYLOAD_BUBBLES(PRIVATE_PAYLOAD_BUBBLES)" in wrapper


def rounded(value, width):
    magnitude, rem = divmod(abs(value), 1 << width)
    half = 1 << (width - 1)
    magnitude += rem > half or (rem == half and magnitude % 2)
    result = -magnitude if value < 0 else magnitude
    clipped = max(-half, min(half - 1, result))
    return clipped, int(clipped != result)


def vectors(width):
    rng = random.Random(0xB0A0 + width)
    half = 1 << (width - 1)
    rows = []
    for token in range(1024):
        operands = [rng.randrange(-half, half) for _ in range(4)]
        if token % 17 == 0:
            operands = [-half] * 4
        a, b, c, d = operands
        real, ro = rounded(a * c - b * d, width)
        imag, io = rounded(a * d + b * c, width)
        fields = ([(word, width) for word in operands] + [(token & 511, 9), (token % 32, 5),
                  (int(token % 17 == 0), 1), (0xABCDE00000000000 | (token << 19) | rng.randrange(1 << 19), 64)] +
                  [(real, width), (imag, width), (ro | io, 1)])
        packed = 0
        for word, bits in fields:
            packed = (packed << bits) | (word & ((1 << bits) - 1))
        rows.append(f"{packed:0{(6*width+83)//4}x}\n")
    return "".join(rows)


def run_sv(directory, top, files, parameters=(), extra=None):
    payloads = {path.name: path.read_bytes() for path in files}
    assert len(payloads) == len(files)
    payloads["frozen_test.py"] = Path(__file__).read_bytes()
    payloads["round_reference.v.txt"] = frozen(f"{LEGACY}.v", ROUND_BASE).encode()
    if extra:
        assert not payloads.keys() & extra.keys()
        payloads.update({name: value.encode() for name, value in extra.items()})
    for name, payload in payloads.items():
        (directory / name).write_bytes(payload)
    hashes = {name: hashlib.sha256(payload).hexdigest() for name, payload in payloads.items()}
    (directory / "sources.sha256").write_text("".join(f"{digest}  {name}\n" for name, digest in sorted(hashes.items())))
    compiled = subprocess.run(["env", "-u", "LD_LIBRARY_PATH", "iverilog", "-g2012", "-Wall", "-s", top,
        *[f"-P{top}.{p}" for p in parameters], "-o", "test.vvp", *[path.name for path in files]],
        cwd=directory, capture_output=True, text=True, check=False, timeout=30)
    (directory / "compile.log").write_text(compiled.stdout + compiled.stderr)
    assert compiled.returncode == 0, compiled.stdout + compiled.stderr
    result = subprocess.run(["env", "-u", "LD_LIBRARY_PATH", "vvp", "test.vvp", "+VECTORS=vectors.mem"],
        cwd=directory, capture_output=True, text=True, check=False, timeout=60)
    (directory / "simulate.log").write_text(result.stdout + result.stderr)
    actual = {p.name for p in directory.iterdir()} - {"sources.sha256", "compile.log", "simulate.log", "test.vvp"}
    assert actual == hashes.keys()
    assert hashes == {name: hashlib.sha256((directory / name).read_bytes()).hexdigest() for name in hashes}
    return result


@pytest.mark.parametrize("boundary,private", list(itertools.product((0, 1), repeat=2)))
@pytest.mark.parametrize("width", [2, 18, 24])
def test_all_eight_options_exact_math_latency_bubbles_stalls_reset_flush(tmp_path, boundary, private, width):
    files = [ACQ / f"{name}.v" for name in (LEGACY, CORE, WRAPPER)] + [ACQ / "tb/tb_starlink_bank_operand_register.sv"]
    result = run_sv(tmp_path, "tb_starlink_bank_operand_register", files,
                    [f"D={width}", f"B={boundary}", f"P={private}"], {"vectors.mem": vectors(width)})
    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stdout.count("OPERAND_BOUNDARY_PASS") == 1
    assert result.stdout.count("OPERAND_MODE_PASS") == 2
    assert f"OPERAND_PRIVATE_BUBBLES_PASS enabled={private}" in result.stdout
    assert "registered=0 no_stall_elapsed_clocks=2" in result.stdout
    assert "registered=1 no_stall_elapsed_clocks=3" in result.stdout
    assert not re.search(r"FAIL|MISMATCH|Fatal|ERROR", result.stdout)

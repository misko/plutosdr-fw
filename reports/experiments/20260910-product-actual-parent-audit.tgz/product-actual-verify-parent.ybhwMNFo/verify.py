"""Independent post-terminal audit; no vendor launch or radio operations."""
import hashlib
import json
from pathlib import Path
import runpy

ROOT = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz')
prepared = ROOT / 'product-final-actual-prepared-v1'
owner = ROOT / 'product-final-actual-owner-v1'
source = prepared / 'frozen_sources'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pins = {
    prepared / 'SHA256SUMS': '7adf2efa0a242b89ccfbb387b00210e76841ba544cbae4cef97efc861acf59b2',
    source / 'simulate_exact_control_prepared.tcl': '2d3b5008f0d087614000ae518421cd9d800aadeb98a747f47fce01d8e76cc6e3',
    source / 'prepare_product_final_fence_actual.py': '39141329e600b15c2ff9357d952d3cd148d6db3126fff2c394108073db49b853',
    owner / 'owner.sh': '62e4fa75b645f200b9c6bbccc0a43cf6e7cda0c2f58d04245128f5da9b24cb68',
}
for path, expected in pins.items():
    assert digest(path) == expected, path
files = {}
for line in (prepared / 'SHA256SUMS').read_text().splitlines():
    expected, name = line.split(maxsplit=1)
    name = name.lstrip('*')
    path = prepared / name
    assert not Path(name).is_absolute() and '..' not in Path(name).parts
    assert name not in files and digest(path) == expected, name
    files[name] = expected
assert len(files) == 65
for name in ['process-exit.txt', 'after-integrity-exit.txt', 'after-ip-exit.txt', 'receipt-exit.txt']:
    assert (owner / name).read_bytes() == b'0\n', name
assert (owner / 'before.sha256').read_bytes() == (owner / 'after.sha256').read_bytes()
api = runpy.run_path(str(source / 'prepare_product_final_fence_actual.py'))
settings = api['verify_prepared'](prepared)
log = prepared / 'project/exact_control_actual.sim/sim_1/behav/xsim/simulate.log'
status = api['verify_result'](log, 1, source)
assert (owner / 'launch.log').read_text().splitlines().count('EXACT_CONTROL_ACTUAL_FROZEN_PAIR_VERIFIED_NO_PHYSICAL_OR_RF_CLAIM') == 1
expected_csv = {
    'fft_bank_owned_trace.csv': '25ab9d06ca0e03f280540cda625a7826b3c4cbaa6322ce3266c59e1fbad94122',
    'exact_control_reference_trace.csv': '25ab9d06ca0e03f280540cda625a7826b3c4cbaa6322ce3266c59e1fbad94122',
    'exact_control_extra_trace.csv': 'b965d12603a64111fa9c6ea36cb0f12189945ad4d9be7cf4fbd883980c4ec4a0',
    'exact_control_reference_extra_trace.csv': 'b965d12603a64111fa9c6ea36cb0f12189945ad4d9be7cf4fbd883980c4ec4a0',
}
for name, expected in expected_csv.items():
    assert digest(log.parent / name) == expected, name
project = prepared / 'project'
inventory = json.loads((owner / 'after-ip.json').read_text())['files']
actual_paths = {p.relative_to(project).as_posix() for p in project.rglob('*') if p.is_file() and p.suffix in ('.xci', '.vhd')}
assert actual_paths == set(inventory)
for name, entry in inventory.items():
    path = project / name
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'], name
print(json.dumps({'passed': True, 'scope': 'functional_actual_FFT_only_not_physical_or_RF',
    'sources': len(files), 'generated_IP_files_after_only': len(inventory),
    'settings': settings, 'qualified_status': status, 'complete_csv_hashes': expected_csv,
    'terminal_receipts': [line for line in log.read_text().splitlines() if line.startswith(('PRODUCT_FINAL_FENCE_ACTUAL_PASS ', 'ROM_READ_AHEAD_ACTUAL_PASS ', 'EXACT_CONTROL_ACTUAL_PASS ', 'FAULT_CDC_ACTUAL_PASS '))]}, indent=2))

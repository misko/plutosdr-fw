`timescale 1ns/1ps
module guard_view(input wire ENABLE_OFFERED_FAULT_SUMMARY,input wire [7:0] summary_faults_now,
 output wire offered_local_fault_now,output wire [7:0] offered_local_faults_now);
 wire summary_fault_now=|summary_faults_now;
  assign offered_local_fault_now = ENABLE_OFFERED_FAULT_SUMMARY ? summary_fault_now : 1'b0;
  assign offered_local_faults_now = ENABLE_OFFERED_FAULT_SUMMARY ? (summary_faults_now & 8'h7f) : 8'b0;
endmodule

module tb;
 reg enable=0;reg [7:0] facts0=0,facts1=0;
 wire [1:0] guard_offered_local_fault;
 wire [7:0] guard_offered_local_faults[0:1];
 guard_view d0(enable,facts0,guard_offered_local_fault[0],guard_offered_local_faults[0]);
 guard_view d1(enable,facts1,guard_offered_local_fault[1],guard_offered_local_faults[1]);
 reg [18:0] other=0;
 wire [18:0] admission_reject={other[18:10],guard_offered_local_fault[1],guard_offered_local_fault[0],other[7:0]};
 reg next_inverse=1,inverse_descriptor_live=1,cutover_admission_capacity=1;
 reg [1:0] guard_capacity=3;
 reg [8:0] completion_prefix=9'h1ff;
 wire [27:0] completion_good={completion_prefix,~admission_reject};
 wire [21:0] old_admission={!next_inverse || inverse_descriptor_live,cutover_admission_capacity,guard_capacity[next_inverse],~admission_reject};
  wire [32:0] admission_reject_expanded = {admission_reject[18:10],
    guard_offered_local_faults[1],guard_offered_local_faults[0],admission_reject[7:0]};
  wire [35:0] admission_checks = {!next_inverse || inverse_descriptor_live,
    cutover_admission_capacity,guard_capacity[next_inverse],~admission_reject_expanded};
  wire [41:0] completion_checks = {completion_good[27:19],~admission_reject_expanded};
 function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
 function [7:0] quad(input integer n);integer b;begin for(b=0;b<8;b=b+1)quad[b]=val((n>>(2*b))&3);end endfunction
 integer mode,side,n,context_kind,bitno,cases=0;
 task check;
 begin
   #1;
   if((|admission_reject_expanded)!==(|admission_reject) ||
      (&admission_checks)!==(&old_admission) || (&completion_checks)!==(&completion_good))
     $fatal(1,"expanded predicate differs");
   cases=cases+1;
 end
 endtask
 initial begin
   for(mode=0;mode<2;mode=mode+1)for(side=0;side<2;side=side+1)
    for(context_kind=0;context_kind<4;context_kind=context_kind+1)for(n=0;n<65536;n=n+1)begin
     enable=mode;facts0=side ? {8{val(context_kind)}} : quad(n);
     facts1=side ? quad(n) : {8{val(context_kind)}};check;
   end
   enable=1;facts0=0;facts1=0;
   for(bitno=0;bitno<19;bitno=bitno+1)if(bitno!=8 && bitno!=9)
    for(n=0;n<4;n=n+1)begin other=0;other[bitno]=val(n);check;end
   other=0;
   for(n=0;n<4;n=n+1)begin
     inverse_descriptor_live=val(n);check;inverse_descriptor_live=1;
     cutover_admission_capacity=val(n);check;cutover_admission_capacity=1;
     guard_capacity[1]=val(n);check;guard_capacity=3;
     for(bitno=0;bitno<9;bitno=bitno+1)begin
       completion_prefix=9'h1ff;completion_prefix[bitno]=val(n);check;
     end
   end
   $display("GUARD_FACTS_PASS cases=%0d exact_four_state=1 disabled_exact=1",cases);$finish;
 end
endmodule

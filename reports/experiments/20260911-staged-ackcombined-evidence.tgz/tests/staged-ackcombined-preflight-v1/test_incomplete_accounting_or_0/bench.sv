`timescale 1ns/1ps
module tb;
reg  clk='0;
reg  resetn='0;
reg  job_valid='0;
reg  private_descriptor_offer='0;
reg [69:0] job_descriptor='0;
reg  input_bank_reserved='0;
reg  output_bank_reserved='0;
reg  certified_input_beat='0;
reg  certified_input_complete='0;
reg  offered_input_beat='0;
reg  offered_input_complete='0;
reg  final_fence_certified='0;
reg  external_fault_now='0;
reg  phase_input_fault_now='0;
reg  completed_input_certified='0;
reg  completed_input_fault_now='0;
reg  preflight_fault_evidence_now='0;
reg  core_event_frame_started='0;
reg [47:0] core_output_tdata='0;
reg [23:0] core_output_tuser='0;
reg  core_output_tvalid='0;
reg  core_output_tlast='0;
reg [7:0] core_status_tdata='0;
reg  core_status_tvalid='0;
reg  mailbox_input_ready='0;
reg  mailbox_input_fault='0;
reg  inverse_phase='0;
reg  forward_mailbox_fault='0;
starlink_pss_result_guard_owner_view #(.PRIVATE_ACK_RETIREMENT(1)) dut(.clk(clk),.resetn(resetn),.job_valid(job_valid),.private_descriptor_offer(private_descriptor_offer),.job_descriptor(job_descriptor),.input_bank_reserved(input_bank_reserved),.output_bank_reserved(output_bank_reserved),.certified_input_beat(certified_input_beat),.certified_input_complete(certified_input_complete),.offered_input_beat(offered_input_beat),.offered_input_complete(offered_input_complete),.final_fence_certified(final_fence_certified),.external_fault_now(external_fault_now),.phase_input_fault_now(phase_input_fault_now),.completed_input_certified(completed_input_certified),.completed_input_fault_now(completed_input_fault_now),.preflight_fault_evidence_now(preflight_fault_evidence_now),.core_event_frame_started(core_event_frame_started),.core_output_tdata(core_output_tdata),.core_output_tuser(core_output_tuser),.core_output_tvalid(core_output_tvalid),.core_output_tlast(core_output_tlast),.core_status_tdata(core_status_tdata),.core_status_tvalid(core_status_tvalid),.mailbox_input_ready(mailbox_input_ready),.mailbox_input_fault(mailbox_input_fault),.inverse_phase(inverse_phase),.forward_mailbox_fault(forward_mailbox_fault));

function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
integer n;
initial begin
 resetn=1;#1;resetn=0;#1;resetn=1;
 input_bank_reserved=1;output_bank_reserved=1;mailbox_input_ready=1;
 for(n=0;n<16384;n=n+1)begin
external_fault_now=val((n>>0)&3);
mailbox_input_fault=val((n>>2)&3);
certified_input_beat=val((n>>4)&3);
certified_input_complete=val((n>>6)&3);
core_event_frame_started=val((n>>8)&3);
core_status_tvalid=val((n>>10)&3);
core_output_tvalid=val((n>>12)&3);
   #1;
   if(dut.active!==0 || dut.protocol_fault!==0 || dut.idle_fault_now!==dut.fault_now)
     $fatal(1,"inactive idle fault omitted from sticky accounting");
 end
 $display("PRIVATE_ACK_ACCOUNTING_PASS cases=16384 four_state_exact=1");$finish;
end
endmodule


`timescale 1ns/1ps
module tb;
 reg fft_clk=0,fast_running=0,registered_quarantine=0,selected_valid=0,destination_reserved=0;
 reg [3:0] state=0;
 localparam WAIT_BANK=4'd2;
 reg [69:0] selected_metadata=0,engine_metadata,original;
 integer f,s,q,v,d,m,checks=0,private_differences=0;
 reg old_accept;
    // BEGIN PRIVATE ENGINE DESCRIPTOR
    // This payload grants nothing in WAIT_BANK. Follow the selected bank while
    // waiting, then freeze on the unchanged capacity/admission transition.
    // Quarantine may cancel a private capture, never authorize a core start.
    always @(posedge fft_clk) begin
      if (!fast_running) engine_metadata <= 0;
      else if (state == 4'd9) engine_metadata <= selected_metadata;
    end
    // END PRIVATE ENGINE DESCRIPTOR

 always @(posedge fft_clk)begin
   if(!fast_running)original<=0;
   else if(registered_quarantine)begin end
   else case(state)WAIT_BANK:if(selected_valid && destination_reserved)original<=selected_metadata;endcase
 end
 function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
 task edge_tick;begin #1;fft_clk=1;#1;fft_clk=0;#1;end endtask
 initial begin
 for(f=0;f<4;f=f+1)for(s=0;s<4;s=s+1)for(q=0;q<4;q=q+1)
 for(v=0;v<4;v=v+1)for(d=0;d<4;d=d+1)for(m=0;m<4;m=m+1)begin
   fast_running=0;edge_tick;
   if(engine_metadata!==70'b0)$fatal(1,"reset lost");
   fast_running=val(f);registered_quarantine=val(q);selected_valid=val(v);destination_reserved=val(d);
   case(s)0:state=WAIT_BANK;1:state=4'd6;2:state=4'bxxxx;3:state=4'bzzzz;endcase
   case(m)0:selected_metadata=70'h123456;1:selected_metadata=70'h3abcde;
     2:selected_metadata=70'bx;3:selected_metadata=70'bz;endcase
   // Literal original if/case semantics, including X controls (not !q && ...).
   old_accept=0;
   if(!fast_running)begin end else if(registered_quarantine)begin end
   else case(state)WAIT_BANK:if(selected_valid && destination_reserved)old_accept=1;endcase
   edge_tick;checks=checks+1;
   if(old_accept && engine_metadata!==original)$fatal(1,"owned descriptor mismatch");
   if(s!=0 && engine_metadata!==original)$fatal(1,"capture outside private wait");
   if(engine_metadata!==original)private_differences=private_differences+1;
   if(old_accept)begin
     // Once accepted, private data must freeze through active processing.
     fast_running=1;state=4'd6;selected_metadata=~selected_metadata;edge_tick;
     if(engine_metadata!==original)$fatal(1,"owned payload changed");
   end
 end
 if(private_differences==0)$fatal(1,"private-only captures unexercised");
 $display("ENGINE_CAPTURE_PASS checks=%0d private_differences=%0d transfer_exact=1 freeze=1",checks,private_differences);
 $finish;
 end
endmodule

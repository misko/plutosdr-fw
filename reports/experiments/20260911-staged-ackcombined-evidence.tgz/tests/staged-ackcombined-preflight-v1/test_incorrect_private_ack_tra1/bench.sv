`timescale 1ns/1ps
module tb;
reg PRIVATE_ACK_RETIREMENT,awaiting_ack,mailbox_input_ready,protocol_fault,idle_fault_now,final_commit;
  wire private_ack_clear_allowed = 1'b1 ?
    (idle_fault_now === 1'b0 || idle_fault_now === 1'b1) : !idle_fault_now;
function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
integer m,a,r,p,f,c,cases=0,differences=0;
reg candidate,original;
initial begin
 for(m=0;m<2;m=m+1)for(a=0;a<2;a=a+1)for(r=0;r<2;r=r+1)
 for(p=0;p<2;p=p+1)for(f=0;f<4;f=f+1)for(c=0;c<2;c=c+1)begin
   PRIVATE_ACK_RETIREMENT=m;awaiting_ack=a;mailbox_input_ready=r;
   protocol_fault=p;idle_fault_now=val(f);final_commit=c;#1;
   candidate=awaiting_ack;original=awaiting_ack;
   if(awaiting_ack && mailbox_input_ready && !protocol_fault && private_ack_clear_allowed)candidate=0;
   if(awaiting_ack && mailbox_input_ready && !protocol_fault && !idle_fault_now)original=0;
   if(final_commit)begin candidate=1;original=1;end
   if(m && a && r && !p && f==1 && !c)begin
     if(candidate!==0 || original!==1)$fatal(1,"missing intentional known-fault private retirement");
     differences=differences+1;
   end else if(candidate!==original)$fatal(1,"unpermitted private ACK transition difference");
   cases=cases+1;
 end
 $display("PRIVATE_ACK_TRANSITION_PASS cases=%0d differences=%0d unknown_exact=1 fallback_exact=1",cases,differences);$finish;
end
endmodule

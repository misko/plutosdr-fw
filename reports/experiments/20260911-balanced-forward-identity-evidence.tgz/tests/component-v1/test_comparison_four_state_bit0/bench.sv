`timescale 1ns/1ps
module tb;
reg [69:0] descriptor,capture_descriptor;
integer bit_index,n,seed=32'h526913ab,checks=0;
  (* keep = "true" *) wire [23:0] capture_descriptor_groups_equal;
  generate for (genvar group_index=0; group_index<23; group_index=group_index+1) begin : descriptor_groups
    assign capture_descriptor_groups_equal[group_index] =
      capture_descriptor[group_index*3 +: 3] == descriptor[group_index*3 +: 3];
  end endgenerate
  assign capture_descriptor_groups_equal[23] = capture_descriptor[69] == descriptor[69];
  (* keep = "true" *) wire [3:0] capture_descriptor_tiles_equal;
  generate for (genvar tile_index=0; tile_index<4; tile_index=tile_index+1) begin : descriptor_tiles
    assign capture_descriptor_tiles_equal[tile_index] = &capture_descriptor_groups_equal[tile_index*6 +: 6];
  end endgenerate
  wire capture_descriptor_equal = &capture_descriptor_tiles_equal;

task automatic compare;
begin
  #1;
  if(capture_descriptor_equal !== (capture_descriptor==descriptor))$fatal(1,"four-state comparison differs");
  if((capture_descriptor_equal!==1'b1) !== ((capture_descriptor==descriptor)!==1'b1))$fatal(1,"fault authority differs");
  checks=checks+1;
end
endtask
initial begin
  descriptor=0;capture_descriptor=0;compare;
  for(bit_index=0;bit_index<70;bit_index=bit_index+1)begin
    descriptor=0;capture_descriptor=70'b1<<bit_index;compare;
    capture_descriptor[bit_index]=1'bx;compare;
    capture_descriptor[bit_index]=1'bz;compare;
    descriptor[bit_index]=1'bz;compare;
    capture_descriptor=~descriptor;compare;
  end
  for(n=0;n<20000;n=n+1)begin
    descriptor={$random(seed),$random(seed),$random(seed)};
    capture_descriptor={$random(seed),$random(seed),$random(seed)};
    if(n%4==0)capture_descriptor=descriptor;
    if(n%8==1)capture_descriptor[n%70]=1'bx;
    if(n%8==2)capture_descriptor[n%70]=1'bz;
    if(n%8==3)begin descriptor[n%70]=1'bx;capture_descriptor=descriptor;end
    compare;
  end
  $display("BALANCED_COMPARISON_PASS checks=%0d",checks);$finish;
end
endmodule

"""Independent saved-script parser probes; no HDL or vendor execution."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys

root = Path(__file__).resolve().parent
tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
saved = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-preparation-v1/script-v2')
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_output_actual_result as parser
from tests.starlink_oracle import retained_output_actual as helper
from tests.starlink_oracle import retained_output_prototype as baseline

paths = [Path(m.__file__) for m in (parser, helper, baseline)]
pins = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
source = root / 'source'
source.mkdir()
for p in paths:
    shutil.copyfile(p, source / p.name)
for name in ('simulation.log', 'actual_words.csv'):
    shutil.copyfile(saved / name, root / name)
with (root / 'actual_words.csv').open(newline='') as f:
    reader = csv.DictReader(f)
    columns = reader.fieldnames
    original = list(reader)

receipts = []
for label in ('unchanged', 'raw_first_wrong_cycle', 'wrong_slow_counter'):
    rows = [dict(row) for row in original]
    index = next(i for i, row in enumerate(rows) if row['stream'] == 'rawF' and row['position'] == '0')
    if label == 'raw_first_wrong_cycle':
        rows[index]['fast'] = str(int(rows[index]['fast']) + 1)
        rows[index]['time_fs'] = str(int(rows[index]['time_fs']) + 5714286)
    elif label == 'wrong_slow_counter':
        rows[index]['slow'] = str(int(rows[index]['slow']) + 1000000)
    output = root / (label + '.csv')
    with output.open('x', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
    try:
        result = parser.verify_result(root / 'simulation.log', output, kind='OFFLINE_SCRIPT_NOT_FFT')
        receipt = {'label': label, 'accepted': True, 'words': result['numerical_words']}
    except ValueError as error:
        receipt = {'label': label, 'accepted': False, 'error': str(error)}
    receipt['modified_row'] = None if label == 'unchanged' else index
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)

assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == pin for p, pin in pins.items()), 'source changed during probe'
(root / 'result.json').write_text(json.dumps({'scope': 'saved offline script parser, no execution proof', 'source_pins': pins, 'receipts': receipts}, indent=2))
assert receipts[0]['accepted'], 'baseline parser failed'
assert receipts[1]['accepted'] is False and receipts[1]['error'] == 'raw row/job ordinal time join', receipts[1]
assert receipts[2]['accepted'] is False and receipts[2]['error'] == 'independent slow edge coordinate', receipts[2]

"""Offline inverse-only composition; no vendor FFT or physical qualification."""

import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

import pytest

HERE = Path(__file__).parent
FW = HERE.parents[1]
ACQ = FW / "hdl/library/starlink_pss_acquisition"
SPEC = importlib.util.spec_from_file_location(
    "inverse_sealed_recipe", HERE / "inverse_sealed.py"
)
RECIPE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RECIPE)
TOP = "starlink_pss_fft_bank_owned_inverse_sealed_probe"
BENCH = "tb_starlink_inverse_sealed_ownership"
NAMES = [
    TOP,
    "starlink_pss_epoch_sealed_bank_cdc",
    "starlink_pss_inverse_sealed_issuer",
    "starlink_pss_spectrum_product_bank_arithmetic",
    "starlink_pss_spectrum_product_operand_register",
    "starlink_pss_realtime_input_guard_local_admission",
    "starlink_pss_realtime_result_guard",
    "starlink_pss_block_mailbox",
    "starlink_pss_forward_kernel_join",
    "starlink_pss_kernel_rom",
]
SOURCES = [ACQ / (name + ".v") for name in NAMES] + [
    ACQ / "tb" / (name + ".sv")
    for name in [
        BENCH,
        "starlink_pss_offline_xfft_interface",
        "starlink_pss_forward_retirement_shadow",
    ]
]
SOURCES += [ACQ / "tb/starlink_pss_realtime_result_guard_ce6a885e_golden.v"]
KERNEL = (
    ACQ
    / "evidence/forward-retirement-v1/actual/frozen_sources/upper_edge_pss_kernel_q17.mem"
)


def env():
    return {
        key: value
        for key, value in os.environ.items()
        if key not in ("LD_LIBRARY_PATH", "PYTHONHOME", "PYTHONPATH")
    }


def test_literal_old_source_restoration():
    for old, new, derive, restore in [
        (
            "starlink_pss_epoch_sealed_bank.v",
            "starlink_pss_epoch_sealed_bank_cdc.v",
            RECIPE.derive_cdc,
            RECIPE.restore_cdc,
        ),
        (
            "starlink_pss_fft_bank_owned_local_admission_probe.v",
            TOP + ".v",
            RECIPE.derive_top,
            RECIPE.restore_top,
        ),
        (
            "tb/tb_starlink_bank_arithmetic_ownership.sv",
            "tb/" + BENCH + ".sv",
            RECIPE.derive_bench,
            RECIPE.restore_bench,
        ),
    ]:
        before, after = (ACQ / old).read_text(), (ACQ / new).read_text()
        assert derive(before) == after and restore(after) == before


def run_top(path, enabled, case, scheduling=1):
    path.mkdir()
    paths = SOURCES + [KERNEL, HERE / "inverse_sealed.py", Path(__file__)]
    for source in paths:
        shutil.copyfile(source, path / source.name)
    hashes = {
        source.name: hashlib.sha256(source.read_bytes()).hexdigest() for source in paths
    }
    (path / "sources.json").write_text(json.dumps(hashes, indent=2, sort_keys=True))
    commands = [
        [
            "iverilog",
            "-g2012",
            "-s",
            BENCH,
            f"-P{BENCH}.E={enabled}",
            f"-P{BENCH}.CASE={case}",
            f"-P{BENCH}.S={scheduling}",
            "-o",
            "top.simv",
            *[source.name for source in SOURCES],
        ],
        ["vvp", "top.simv"],
    ]
    receipts = []
    for index, command in enumerate(commands):
        result = subprocess.run(
            command,
            cwd=path,
            env=env(),
            capture_output=True,
            text=True,
            timeout=30,
            check=False,
        )
        (path / f"phase{index}.log").write_text(result.stdout + result.stderr)
        receipts.append({"command": command, "exit": result.returncode})
        (path / "commands.json").write_text(json.dumps(receipts, indent=2))
        assert hashes == {
            name: hashlib.sha256((path / name).read_bytes()).hexdigest()
            for name in hashes
        }
        assert result.returncode == 0, (result.stdout + result.stderr)[-3000:]
    assert not re.search(r"\b(?:FATAL|ERROR|FAIL)\b", result.stdout, re.IGNORECASE)
    assert result.stdout.count("BANK_ARITHMETIC_OWNERSHIP_PASS") == 1
    assert f"outputs={1024 if case == 0 else 512}" in result.stdout
    assert "synthetic_interface_not_fft=1 no_capacity_claim=1" in result.stdout


@pytest.mark.parametrize("enabled", [0, 1])
@pytest.mark.parametrize("scheduling", [0, 1])
def test_original_two_block_ownership_with_explicit_default_and_enabled(
    tmp_path, enabled, scheduling
):
    run_top(tmp_path / "run", enabled, 0, scheduling)


@pytest.mark.parametrize("case", range(1, 12))
def test_all_original_current_late_fault_and_reset_checks_preserved(tmp_path, case):
    run_top(tmp_path / "run", 1, case)

"""Parent audit of fresh1444 replay: source integrity, receipts and complete graph."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
suite = ET.parse(root / 'results.xml').getroot().find('testsuite')
assert suite is not None
assert all(suite.get(k) == v for k,v in
           {'tests':'1444','errors':'0','failures':'0','skipped':'0'}.items())
classes = Counter(t.get('classname') for t in suite.findall('testcase'))
assert classes['tests.starlink_oracle.test_product_sealed_interface'] == 596
assert sum(v for k,v in classes.items() if k != 'tests.starlink_oracle.test_product_sealed_interface') == 848
manifests = sorted((root / 'cases').rglob('sources.json'))
files_checked = 0
for manifest in manifests:
    for relative, pin in json.loads(manifest.read_text()).items():
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        source = manifest.parent / relative
        assert hashlib.sha256(source.read_bytes()).hexdigest() == pin, source
        files_checked += 1

# Load only the already-reviewed parser constants and two pure functions.
parser = root / 'reviewed_graph_parser.py'
tree = ast.parse(parser.read_text())
selected = [n for n in tree.body if
            (isinstance(n, ast.FunctionDef) and n.name in {'parse','first_cycle'}) or
            (isinstance(n, ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0], ast.Name)
             and n.targets[0].id in {'TOKEN','ALLOWED'})]
assert len(selected)==4
namespace = {'re':re}
exec(compile(ast.Module(body=selected,type_ignores=[]),str(parser),'exec'),namespace)
paths = [root / 'cases/interface0/original/sim.vvp']
paths += [root / f'cases/test_graph_rejects_individual_{i}/backedge/sim.vvp' for i in range(6)]
graph_results = []
for index, path in enumerate(paths):
    source = path.read_bytes()
    graph, aliases = namespace['parse'](source.decode())
    cycle = namespace['first_cycle'](graph)
    assert (cycle is None) == (index == 0), path
    if index == 0:
        assert len(graph)==3302 and sum(n.startswith('LS_') for n in graph)==36
    graph_results.append({'file':str(path.relative_to(root)),
                          'sha256':hashlib.sha256(source).hexdigest(),
                          'nodes':len(graph),'cycle':cycle})
log = (root / 'cases/interface0/original/kind-0-bit-0-target-37.log').read_text()
assert 'PRODUCT_INTERFACE_ORDER_COUNTS admissions=8 completions=8' in log
assert not re.search(r'(?im)^(?:ERROR|FATAL|FAIL)(?::|\b)',log)
jobs = re.findall(r'^PRODUCT_ADAPTER_JOB (.+)$',log,re.M)
latencies = re.findall(r'^PRODUCT_ADAPTER_LATENCY (.+)$',log,re.M)
assert len(jobs)==len(latencies)==8
for index, (job, latency) in enumerate(zip(jobs,latencies)):
    values = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',job)}
    assert values == {'job':index,'take':512,'seal_delta':2,'publish_delta':3,
                      'completion_to_publish':6,'head_delta':10,'release_after_core':1,
                      'core_span':511,'holes':0}
    values = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',latency)}
    assert values == {'job':index,'admission_to_release':1555,
                      'handoff_to_first_core':2,'last_core_to_release':1}
result = {'scope':'OFFLINE_PRIMITIVES_AND_ACTOR_COMPOSITION_NOT_ACTUAL_CONTROLLER_OR_PHYSICAL_TIMING',
          'fw_commit':'ce25a80b37faee37ae841cea117a34977c0f1542',
          'hdl_commit':'c4befff9a74bbf3743c3ce00eec2bbedbb09fd77',
          'tests_by_class':dict(classes),'source_manifests':len(manifests),
          'source_files_verified':files_checked,'graphs':graph_results,
          'healthy_jobs':8,'words_per_job':512,'input_holes':0,
          'xml_sha256':hashlib.sha256((root/'results.xml').read_bytes()).hexdigest()}
with (root/'parent-audit.json').open('x') as stream:
    json.dump(result,stream,indent=2)
    stream.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='graphs'},indent=2))

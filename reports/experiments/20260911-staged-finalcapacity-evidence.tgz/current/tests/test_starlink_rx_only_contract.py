import hashlib
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


def _sha256(relative: str) -> str:
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def _git_sha256(repository: str, revision: str, relative: str) -> str:
    blob = subprocess.run(
        ["git", "-C", str(ROOT / repository), "show", f"{revision}:{relative}"],
        check=True,
        capture_output=True,
    ).stdout
    return hashlib.sha256(blob).hexdigest()


def test_experiment_is_marked_do_not_merge_and_ram_only() -> None:
    stop = _read("STARLINK_RX_ONLY_EXPERIMENT_DO_NOT_MERGE.md")
    plan = _read("STARLINK_PSS_15_30_60_PLAN.md")

    assert "DO NOT MERGE" in stop
    assert "codex/starlink-rx-only-do-not-merge" in stop
    assert "persistently flashed" in stop
    assert "DO NOT MERGE INTO FIRMWARE MAIN" in plan
    assert "RAM-only" in plan

    merge_guard = _read(".github/workflows/starlink-rx-only-do-not-merge.yml")
    assert "github.head_ref == 'codex/starlink-rx-only-do-not-merge'" in merge_guard
    assert "exit 1" in merge_guard


def test_source_graph_and_builder_are_locked_to_the_experiment() -> None:
    modules = _read(".gitmodules")
    manifest = _read("manifests/starlink-rx-only-dnm-v1-source.yaml")
    workflow = _read(".github/workflows/firmware-main.yml")
    builder = _read("scripts/ci/build_main_firmware.sh")

    assert "branch = codex/starlink-rx-only-buildroot-do-not-merge" in modules
    assert modules.count("branch = codex/starlink-rx-only-do-not-merge") == 2
    assert "release_state: candidate" in manifest
    assert manifest.count("refs/tags/starlink-rx-only-dnm-v1-source/") == 3
    assert "codex/starlink-rx-only-do-not-merge" in workflow
    assert "v0.49-plutoplus-starlink-rx-only-dnm-v1" in workflow
    assert "starlink-rx-only-dnm-v1-source.yaml" in builder
    assert "for rate in 15 30 60" in builder
    assert "bash hdl-starlink/run_tests.sh" in builder


def test_rx_only_packaging_requires_fifo_and_monitor_mailbox_crossings() -> None:
    packager = _read("scripts/ci/package_main_firmware.sh")
    validator = _read("scripts/ci/validate_starlink_rx_only_route_reports.py")

    assert "REQUIRED_BUS_SKEW_CONSTRAINTS=4" in packager
    assert "STARLINK_RX_ONLY_BUILD=false" in packager
    assert 'realpath -- "$MANIFEST"' in packager
    assert "HEAD:manifests/starlink-rx-only-dnm-v1-source.yaml" in packager
    assert "RX-only manifest differs from its committed HEAD blob" in packager
    assert "STARLINK_RX_ONLY_BUILD=true" in packager
    assert "REQUIRED_BUS_SKEW_CONSTRAINTS=3" in packager
    assert '-ge "$REQUIRED_BUS_SKEW_CONSTRAINTS"' in packager
    assert "Slack (VIOLATED)" in packager
    assert "validate_starlink_rx_only_route_reports.py" in packager
    assert "EXPECTED_BUS_SKEW_MET = 3" in validator
    assert "EXPECTED_MONITOR_PAYLOAD_ROWS = 293" in validator
    assert "EXPECTED_MONITOR_TOGGLE_ROWS = 2" in validator
    assert "diagnostic monitor contributes Critical routed CDC rows" in validator
    assert "cpack_timestamp/inst/overflow_sync/" in validator
    assert "cpack_timestamp/inst/timestamp_cpu_sync/" in validator


def test_block_design_is_compile_time_single_rx_without_tx_engines() -> None:
    design = _read("hdl/projects/pluto/system_bd.tcl")
    transceiver = _read("hdl/library/axi_ad9361/axi_ad9361.v")
    tx_null = _read("hdl/library/axi_ad9361/axi_ad9361_tx_null.v")

    assert "CONFIG.MODE_1R1T 1" in design
    assert "CONFIG.TDD_DISABLE 1" in design
    assert "CONFIG.DAC_DATAPATH_DISABLE 1" in design
    assert "CONFIG.PCW_USE_S_AXI_HP2 0" in design
    # Raw RX uses timestamp-synchronized FIFO DMA; paired-pilot has a separate
    # AXIS DMA that must not wait for that raw-RX transfer-start signal.
    sync_starts = re.findall(
        r"(?m)^\s*ad_ip_parameter (\S+) CONFIG\.SYNC_TRANSFER_START (\S+)\s*$",
        design,
    )
    assert sorted((instance, value.strip("{}")) for instance, value in sync_starts) == [
        ("axi_ad9361_adc_dma", "true"), ("starlink_pilot_dma", "false"),
    ]

    forbidden = (
        "axi_ad9361_dac_dma",
        "tx_fir_interpolator",
        "tx_upack",
        "axi_tdd_0",
        "i_tandem_agc",
    )
    for name in forbidden:
        assert name not in design

    assert "axi_ad9361_tx_null" in transceiver
    assert "assign up_rack_tx_s = up_rreq_s;" not in transceiver
    assert "assign up_wack_tx_s = up_wreq_s;" not in transceiver
    assert "up_raddr[13:7] == {6'h10, 1'b0}" in tx_null
    assert "up_raddr[13:8] == 6'h11" in tx_null
    assert "up_raddr[13:8] == 6'h00" not in tx_null


def test_dma_instances_are_selected_by_the_actual_profile_gates() -> None:
    """Execute only the real profile/DMA configuration snippets with Tcl mocks."""
    design = _read("hdl/projects/pluto/system_bd.tcl")
    snippets = []
    for variable in ("starlink_pilot_enabled", "starlink_pss_rx_dma_enabled"):
        expression = re.search(
            rf"(?ms)^set {variable} \[expr \{{\n.*?^\}}\]", design,
        )
        assert expression, variable
        snippets.append(expression.group(0))
    for condition, instance in (
        ("starlink_pss_rx_dma_enabled", "axi_ad9361_adc_dma"),
        ("starlink_pilot_enabled", "starlink_pilot_dma"),
    ):
        blocks = re.findall(rf"(?ms)^if \{{\${condition}\}} \{{\n.*?^\}}", design)
        selected = [block for block in blocks if f"ad_ip_instance axi_dmac {instance}" in block]
        assert len(selected) == 1, instance
        snippets.append(selected[0])
    script = r"""
proc ad_ip_instance {kind instance args} {
  if {$kind eq "axi_dmac"} { lappend ::dma_instances $instance }
}
proc ad_ip_parameter {instance key value} {
  if {$key eq "CONFIG.SYNC_TRANSFER_START"} {
    lappend ::dma_sync "$instance:$value"
  }
}
foreach profile {default full detector-only paired-pilot acquisition-only acquisition-injection} {
  unset -nocomplain ::env(STARLINK_PSS_PROFILE)
  set starlink_pss_profile full
  if {$profile ne "default"} {
    set ::env(STARLINK_PSS_PROFILE) $profile
    set starlink_pss_profile $profile
  }
  set starlink_pss_rate_msps 15
  set dma_instances {}
  set dma_sync {}
""" + "\n".join(snippets) + r"""
  puts [list PROFILE $profile $dma_instances $dma_sync]
}
"""
    result = subprocess.run(["tclsh"], input=script, text=True, capture_output=True,
                            check=True, timeout=10)
    assert not result.stderr, result.stderr
    assert result.stdout.splitlines() == [
        "PROFILE default axi_ad9361_adc_dma axi_ad9361_adc_dma:true",
        "PROFILE full axi_ad9361_adc_dma axi_ad9361_adc_dma:true",
        "PROFILE detector-only {} {}",
        "PROFILE paired-pilot starlink_pilot_dma starlink_pilot_dma:false",
        "PROFILE acquisition-only axi_ad9361_adc_dma axi_ad9361_adc_dma:true",
        "PROFILE acquisition-injection axi_ad9361_adc_dma axi_ad9361_adc_dma:true",
    ]


def test_abi12_injection_is_the_shared_tracker_and_dma_boundary() -> None:
    design = _read("hdl/projects/pluto/system_bd.tcl")
    manifest = _read(
        "manifests/starlink-pss15-injection-abi12-dnm-v1-source.yaml"
    )
    wrapper = _read(
        "hdl/library/axi_starlink_pss_tracker/axi_starlink_pss_tracker.v"
    )
    mux = _read(
        "hdl/library/axi_starlink_pss_tracker/starlink_pss_injection_mux.v"
    )
    provenance = _read(
        "hdl/library/axi_starlink_pss_tracker/"
        "tb/real_071200_wrapper_replay_provenance.json"
    )

    assert "localparam [31:0] VERSION = (RATE_MSPS == 15) ?" in wrapper
    assert "32'h0001_0002 : 32'h0001_0003;" in wrapper
    assert "localparam [31:0] CAPABILITIES = ENABLE_INJECTION ?" in wrapper
    assert "32'h0000_003d : 32'h0000_001d;" in wrapper
    assert "starlink_pss_injection_mux" in wrapper
    for signal in ("i", "q", "enable", "index", "timestamp"):
        assert f".i_sample_{signal}" in wrapper
        assert f"selected_sample_{signal}" in wrapper
    assert ".i_sample_valid" in wrapper
    assert "selected_sample_strobe" in wrapper

    for connection in (
        "starlink_pss_tracker/selected_sample_i",
        "starlink_pss_tracker/selected_sample_q",
        "starlink_pss_tracker/selected_sample_strobe",
        "starlink_pss_tracker/selected_sample_enable",
        "starlink_pss_tracker/selected_sample_timestamp",
    ):
        assert connection in design
    assert "rx_fir_decimator/data_out_0 cpack/fifo_wr_data_0" not in design
    assert "rx_fir_decimator/valid_out_0 cpack/fifo_wr_en" not in design

    assert "selected_sample_i <= selection_injected_stage" in mux
    assert "selected_sample_strobe <= source_sample_strobe_stage" in mux
    assert "selected_sample_index <= source_sample_index_stage" in mux
    assert "sample_mismatch_toggle <= ~sample_mismatch_toggle" in mux
    assert '(* ram_style = "block" *)' in mux
    assert 'ram_style = "distributed"' not in mux
    assert "real_071200_window0_samples_ci16.mem" in provenance

    assert "do_not_merge: true" in manifest
    assert "persistent_flash_eligible: false" in manifest
    assert "tracker_version: 0x00010002" in manifest
    assert "tracker_capabilities: 0x0000003d" in manifest
    assert "injection_shared_consumers: tracker-and-rx-dma-cpack" in manifest
    assert "hardware_injection_qualified: false" in manifest
    assert "over_the_air_starlink_pss_detected: false" in manifest


def test_continuous_pss_acquisition_is_independent_of_dma_scan_enable() -> None:
    design = _read("hdl/projects/pluto/system_bd.tcl")

    assert "ad_connect VCC starlink_pss_acquisition/sample_enable" in design
    assert (
        "ad_connect starlink_pss_tracker/selected_sample_enable "
        "starlink_pss_acquisition/sample_enable"
    ) not in design
    assert "adc_enable_i0/q0 reset low" in design
    assert "Acquisition is armed by its own fail-closed MMIO control" in design


def test_abi12_batch_and_clock_contract_is_frozen_without_rtl_changes() -> None:
    manifest = _read("manifests/starlink-pss15-batch-clock-dnm-v1-source.yaml")
    header = _read("tools/starlink_pssctl/starlink_pss_hw.h")
    library = _read("tools/starlink_pssctl/starlink_pss_hw.c")
    controller = _read("tools/starlink_pssctl/starlink_pssctl.c")
    selftest = _read("tools/starlink_pssctl/test_starlink_pss_hw.c")

    assert "do_not_merge: true" in manifest
    assert "persistent_flash_eligible: false" in manifest
    assert "qualification_utility_branch: main" in manifest
    assert "qualification_utility_main_commit: 4ca3451" in manifest
    assert "tracker_version: 0x00010002" in manifest
    assert "tracker_rtl_changed: false" in manifest
    assert "tracker_xsa_reused: true" in manifest
    assert "batch_primary_count: 45000" in manifest
    assert "batch_period_samples: 20000" in manifest
    assert "batch_queue_target: 7" in manifest
    assert "clock_observation_repeats_each_path: 5" in manifest
    assert "stage15_rf_bandwidth_requested_hz: 15000000" in manifest
    assert "mandatory_final_setup_target: ad9361-2r2t" in manifest
    assert "live_multiframe_pss_qualified: false" in manifest

    assert "PSS_COMMAND_FIFO_USABLE 7U" in header
    # This manifest records the original Stage-15 source, not the subsequently
    # generalized compile-time header. Keep that historical byte binding and
    # lead claim; current evaluated 15/30/60 contracts are tested separately.
    assert "batch_minimum_post_submit_lead_samples: 65536" in manifest
    assert "host_header_sha256: " + _git_sha256(
        ".", "d83f898bb3f18fce73db75545598df03243c9629",
        "tools/starlink_pssctl/starlink_pss_hw.h",
    ) in manifest
    assert "pss_track_batch" in header
    assert "pss_calculate_clock_slope" in header
    assert "validate_batch_counter_capacity" in library
    assert "validate_batch_deltas" in library
    assert '"track-batch"' in controller
    assert '"clock-slope"' in controller
    assert "batch_fifo=7 batch_refill=1" in selftest
    assert "clock_slope=1" in selftest


def test_current_host_header_has_explicit_compile_time_rate_contracts() -> None:
    header = ROOT / "tools/starlink_pssctl/starlink_pss_hw.h"
    # Default retains the historical 15 MS/s values checked below. These
    # compile checks are not qualification of hardware or host scheduling.
    for selected, rate, version, geometry, capabilities, multiplier, lead in (
        (None, 15, 0x10002, 0x003D8242, 0x3D, 1, 65536),
        (15, 15, 0x10002, 0x003D8242, 0x3D, 1, 65536),
        (30, 30, 0x10003, 0x0BCA0884, 0x1D, 2, 131072),
        (60, 60, 0x10003, 0x0F8C1108, 0x1D, 4, 262144),
    ):
        expected = {
            "PSS_RATE_MSPS": rate, "PSS_VERSION": version, "PSS_GEOMETRY": geometry,
            "PSS_CAPABILITIES": capabilities, "PSS_RATE_MULTIPLIER": multiplier,
            "PSS_MINIMUM_HOST_LEAD": lead, "PSS_DEFAULT_LEAD_SAMPLES": 1000000 * multiplier,
            "PSS_COMMAND_FIFO_USABLE": 7, "PSS_DEFAULT_QUEUE_TARGET": 7,
            "PSS_FRAME_PERIOD_SAMPLES": 20000 * multiplier,
            "PSS_COEFFICIENT_COUNT": 66 * multiplier,
            "PSS_CAPTURE_SAMPLES": 130 * multiplier,
            "PSS_QUALIFIED_LAG_COUNT": 60 * multiplier + 1,
            "PSS_RESULT_WORDS": 26, "PSS_HAS_INJECTION": int(rate == 15),
        }
        source = f'#include "{header}"\n' + "\n".join(
            f'_Static_assert({name} == UINT64_C({value}), "{name}");'
            for name, value in expected.items()
        )
        flags = [] if selected is None else [f"-DPSS_BUILD_RATE_MSPS={selected}"]
        result = subprocess.run(
            ["gcc", "-std=c11", "-Wall", "-Wextra", "-Werror", *flags, "-x", "c", "-fsyntax-only", "-"],
            input=source, text=True, capture_output=True, check=False, timeout=10,
        )
        assert result.returncode == 0, result.stdout + result.stderr
    for rate in (0, 25, 120):
        result = subprocess.run(
            ["gcc", "-std=c11", f"-DPSS_BUILD_RATE_MSPS={rate}", "-x", "c", "-fsyntax-only", "-"],
            input=f'#include "{header}"\n', text=True, capture_output=True, check=False, timeout=10,
        )
        assert result.returncode != 0
        assert "PSS_BUILD_RATE_MSPS must be exactly 15, 30, or 60" in result.stderr


def test_abi12_batch_hardware_evidence_keeps_rt_and_live_signal_boundaries() -> None:
    evidence = _read(
        "manifests/starlink-pss15-batch-clock-dnm-v2-hardware.yaml"
    )
    plan = _read("STARLINK_PSS_15_30_60_PLAN.md")

    assert "do_not_merge: true" in evidence
    assert "persistent_flash_eligible: false" in evidence
    assert "stage_30_authorized: false" in evidence
    assert "passing_scheduler_policy: SCHED_FIFO" in evidence
    assert "passing_scheduler_priority: 80" in evidence
    assert "passing_primary_request_count: 45000" in evidence
    assert "passing_primary_maximum_inflight: 7" in evidence
    assert "passing_primary_all_error_counter_deltas_zero: true" in evidence
    assert "ordinary_scheduler_qualified: false" in evidence
    assert "queue_depth_conditionally_qualified: true" in evidence
    assert "live_multiframe_pss_qualified: false" in evidence
    assert "over_the_air_starlink_pss_detected: false" in evidence
    assert "final_setup_target: ad9361-2r2t" in evidence
    assert "final_route_absent: true" in evidence
    assert "final_control_daemon_stopped: true" in evidence

    assert "SCHED_FIFO` priority 80" in plan
    assert "ordinary best-effort Linux scheduling is explicitly unqualified" in plan
    assert "does not authorize Stage 30" in plan


def test_acquisition_oracle_checkpoint_is_offline_and_fail_closed() -> None:
    manifest = _read("manifests/starlink-pss-acquisition-oracle-v1-source.yaml")
    plan = _read("STARLINK_PSS_15_30_60_PLAN.md")
    report = _read("reports/STARLINK_PSS_ACQUISITION_ORACLE_V1.md")
    oracle = _read("tests/starlink_oracle/acquisition.py")

    assert "do_not_merge: true" in manifest
    assert "persistent_flash_eligible: false" in manifest
    assert "radio_eligible: false" in manifest
    assert "radio_contacted_by_this_revision: false" in manifest
    assert "qualification_utility_branch: main" in manifest
    assert "qualification_utility_changed: false" in manifest
    assert "acquisition_score_bits: 8" in manifest
    assert "acquisition_phase_bin_samples: 1" in manifest
    assert "acquisition_phase_bins: 20000" in manifest
    assert "acquisition_tile_frames: 64" in manifest
    assert "acquisition_phase_map_word_bits: 16" in manifest
    assert "independent_positive_verdict: PASS" in manifest
    assert "independent_negative_verdict: REJECT" in manifest
    assert "rtl_fft_implemented: false" in manifest
    assert "hardware_qualified: false" in manifest
    assert "production_false_alarm_policy_frozen: false" in manifest

    bound_files = {
        "acquisition_oracle_source_sha256": "tests/starlink_oracle/acquisition.py",
        "acquisition_oracle_test_sha256": "tests/starlink_oracle/test_acquisition.py",
        "acquisition_study_cli_test_sha256": (
            "tests/test_starlink_pss_acquisition_study.py"
        ),
        "acquisition_study_tool_sha256": "tools/starlink_pss_acquisition_study.py",
        "acquisition_report_sha256": (
            "reports/STARLINK_PSS_ACQUISITION_ORACLE_V1.md"
        ),
        "primary_positive_report_sha256": (
            "reports/starlink-pss-acquisition-oracle-v1.json"
        ),
        "independent_positive_report_sha256": (
            "reports/starlink-pss-acquisition-oracle-v1-independent-positive.json"
        ),
        "independent_negative_report_sha256": (
            "reports/starlink-pss-acquisition-oracle-v1-independent-negative.json"
        ),
    }
    for field, relative in bound_files.items():
        assert f"{field}: {_sha256(relative)}" in manifest

    assert "coarse phase bins are rejected" in plan
    assert "one-sample phase resolution" in plan
    assert "FPGA-facing reduction" in oracle
    assert "not live-PSS or hardware evidence" in report


def test_continuous_phase_map_checkpoint_is_isolated_and_source_locked() -> None:
    manifest = _read("manifests/starlink-pss15-phase-map-dnm-v1-source.yaml")
    report = _read("reports/STARLINK_PSS15_PHASE_MAP_V1.md")
    summary = _read("reports/starlink-pss15-phase-map-v1-ooc-summary.txt")
    plan = _read("STARLINK_PSS_15_30_60_PLAN.md")
    rtl = _read("hdl/library/starlink_pss_acquisition/starlink_pss_phase_map.v")

    assert "do_not_merge: true" in manifest
    assert "persistent_flash_eligible: false" in manifest
    assert "build_eligible: false" in manifest
    assert "radio_eligible: false" in manifest
    assert "radio_contacted_by_this_revision: false" in manifest
    assert "qualification_utility_changed: false" in manifest
    assert "submodule_hdl: d291871923c6dc6cc2f30745d2e9d8a6abd3188f" in manifest
    assert "superseded_submodule_hdl_v1: 1e36384bbf54798a7778b22cd1a54bfb6828dc53" in manifest
    assert "superseded_submodule_hdl_v2: 77aefb265a88f1d1b746b7d6df4e45d0a3f10627" in manifest
    assert "firmware_main_gitlink_guard_pr: https://github.com/misko/plutosdr-fw/pull/82" in manifest
    assert "firmware_main_gitlink_guard_merge_commit: ae9be3ec411eeebe0ee396b93c0f59e2d9d1940b" in manifest
    assert "acquisition_phase_bins: 20000" in manifest
    assert "acquisition_tile_frames: 64" in manifest
    assert "phase_map_memory_segments_per_bank: 10" in manifest
    assert "phase_map_publish_complete_tiles_only: true" in manifest
    assert "phase_map_backpressures_rx_dma: false" in manifest
    assert "rtl_phase_map_implemented: true" in manifest
    assert "rtl_score_frontend_implemented: false" in manifest
    assert "rtl_fft_implemented: false" in manifest
    assert "rtl_detector_integrated: false" in manifest
    assert "hardware_qualified: false" in manifest
    assert "stage_30_authorized: false" in manifest
    assert "stage_60_authorized: false" in manifest

    hdl_bound_files = {
        "phase_map_rtl_sha256": (
            "hdl/library/starlink_pss_acquisition/starlink_pss_phase_map.v"
        ),
        "phase_map_bank_rtl_sha256": (
            "hdl/library/starlink_pss_acquisition/starlink_pss_phase_map_bank.v"
        ),
        "phase_map_testbench_sha256": (
            "hdl/library/starlink_pss_acquisition/tb/"
            "tb_starlink_pss_phase_map.sv"
        ),
        "phase_map_ooc_runner_sha256": (
            "hdl/library/starlink_pss_acquisition/run_phase_map_ooc.sh"
        ),
        "phase_map_ooc_xdc_sha256": (
            "hdl/library/starlink_pss_acquisition/"
            "starlink_pss_phase_map_ooc.xdc"
        ),
        "phase_map_ooc_tcl_sha256": (
            "hdl/library/starlink_pss_acquisition/"
            "synthesize_phase_map_ooc.tcl"
        ),
        "phase_map_ooc_summary_sha256": (
            "reports/starlink-pss15-phase-map-v1-ooc-summary.txt"
        ),
        "phase_map_report_sha256": "reports/STARLINK_PSS15_PHASE_MAP_V1.md",
    }
    for field, relative in hdl_bound_files.items():
        if relative.startswith("hdl/"):
            digest = _git_sha256(
                "hdl",
                "d291871923c6dc6cc2f30745d2e9d8a6abd3188f",
                relative.removeprefix("hdl/"),
            )
        else:
            digest = _sha256(relative)
        assert f"{field}: {digest}" in manifest

    # The shared runner grows as later independently tested slices are added.
    # Keep the phase-map checkpoint bound to its historical runner digest
    # rather than silently rewriting the immutable v1 manifest.
    assert (
        "phase_map_test_runner_sha256: "
        "f3dea923744c5d1c7ca1d549bfe788240b2b240952c0e1b5c1e4b006a9b8852b"
        in manifest
    )

    assert "parameter integer PHASE_BINS = 20000" in rtl
    assert "parameter integer TILE_FRAMES = 64" in rtl
    assert "parameter integer MAP_SEGMENT_COUNT = 10" in rtl
    assert "state != STATE_DRAIN" in rtl
    assert "map_release_bank == map_read_bank" in rtl
    assert "setup_wns_ns=1.190" in summary
    assert "ramb36e1=20" in summary
    assert "dsp48e1=0" in summary
    assert "It does not yet" in report
    assert "generate those scores from IQ samples" in report
    assert "there is no FFT/scorer" in plan


def test_top_level_holds_digital_tx_bus_static() -> None:
    top = _read("hdl/projects/pluto/system_top.v")

    assert "assign tx_clk_out = 1'b0;" in top
    assert "assign tx_frame_out = 1'b0;" in top
    assert "assign tx_data_out = 12'b0;" in top
    assert "assign phaser_enable = 1'b0;" in top
    assert "assign phaser_enable = gpio_o[14];" not in top
    assert ".tx_clk_out (tx_clk_out)" not in top
    assert ".tx_frame_out (tx_frame_out)" not in top
    assert ".tx_data_out (tx_data_out)" not in top
    assert "gpio_o[14]" not in top


def test_linux_matches_removed_hardware_and_single_rx_geometry() -> None:
    common = _read("linux/arch/arm/boot/dts/zynq-pluto-sdr.dtsi")
    revc = _read("linux/arch/arm/boot/dts/zynq-pluto-sdr-revc.dts")

    for node in (
        "tandem-agc@7c450000",
        "dma@7c420000",
        "cf-ad9361-dds-core-lpc@79024000",
    ):
        start = common.index(node)
        assert 'status = "disabled";' in common[start : start + 500]

    assert "digital-interface-tune-skip-mode = <1>" in common
    assert "misko,rx-only-fpga;" in common
    assert "adi,source-bus-width = <64>;" in common
    assert "adi,frequency-division-duplex-mode-enable;" not in common
    assert "adi,2rx-2tx-mode-enable;" not in revc

    phaser = revc.index("one-bit-adc-dac@0")
    assert 'status = "disabled";' in revc[phaser : phaser + 500]

    for node in ("axi-tdd-0@7C440000", "iio_axi_tdd_0@0"):
        start = revc.index(node)
        assert 'status = "disabled";' in revc[start : start + 500]


def test_removed_hdl_libraries_are_not_build_dependencies() -> None:
    makefile = _read("hdl/projects/pluto/Makefile")

    assert "LIB_DEPS += axi_tdd" not in makefile
    assert "LIB_DEPS += util_pack/util_upack2" not in makefile
    assert "library/axi_tdd/scripts/axi_tdd.tcl" not in makefile


def test_boot_guard_requires_rx_only_dt_proof_and_powers_down_tx_lo() -> None:
    guard = _read("buildroot/board/pluto/pluto-mute-tx")

    assert "DT_ROOT=${PLUTO_DT_ROOT:-/sys/firmware/devicetree/base}" in guard
    assert '"$DT_ROOT/misko,rx-only-fpga"' in guard
    assert "cf-ad9361-dds-core-lpc@79024000/status" in guard
    assert '"disabled"' in guard
    assert "out_altvoltage*_TX_LO_powerdown" in guard
    assert "printf '1\\n' > \"$control\"" in guard

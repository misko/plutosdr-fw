`timescale 1ns/1ps
module tb;
reg clk=0,resetn=0,abort_epoch=0,input_valid=0,input_last=0,output_ready=0;
reg [35:0] input_data=0;
reg [8:0] input_position=0;
reg [69:0] input_metadata=70'h12345,reference_metadata=70'h12345;
wire input_ready,output_valid,output_last,output_identity_good,idle,fault;
wire [35:0] output_data;wire [8:0] output_position;wire [69:0] output_metadata;
starlink_pss_product_identity_stage dut(.*);
integer n,retired=0;
task tick;begin #1;clk=1;#1;clk=0;#1;end endtask
initial begin
 tick;resetn=1;input_valid=1;input_data=36'h111;input_position=0;tick;
 // A nonfinal word refills on the same edge, with exact data/certificate.
 output_ready=1;input_data=36'h222;input_position=511;input_last=1;#1;
 if(!input_ready || !output_valid)$fatal(1,"nonfinal refill lost");tick;
 if(output_data!==36'h222 || !output_last || !output_identity_good)$fatal(1,"final capture mismatch");
 // A queued future offer must not displace a held LAST, regardless of whether
 // publication is blocked, known allowed, or unknown. The consumer is still
 // the only authority to retire it. Input capacity cannot follow that decision.
 input_data=36'h333;input_position=0;input_last=0;
 for(n=0;n<4;n=n+1)begin
  case(n)0:output_ready=0;1:output_ready=1'bx;2:output_ready=1'bz;3:output_ready=1;endcase
  #1;
  if(input_ready!==0)$fatal(1,"held final capacity depends on publication");
 end
 output_ready=0;
 repeat(10)begin tick;if(!output_valid || output_data!==36'h222)$fatal(1,"unpublished LAST dropped");end
 output_ready=1;tick;
 if(output_valid || !idle || !input_ready)$fatal(1,"retired slot not empty/reopened");
 // The queued offer can be taken on the FOLLOWING edge, not on LAST's edge.
 tick;
 if(!output_valid || output_data!==36'h333 || output_last)$fatal(1,"queued next word lost");
 input_valid=0;tick;
 resetn=0;tick;resetn=1;input_valid=1;input_last=1;output_ready=0;tick;
 abort_epoch=1;#1;if(!fault || input_ready || output_valid)$fatal(1,"current abort no longer fences slot");tick;
 abort_epoch=0;#1;if(!fault || input_ready || output_valid)$fatal(1,"abort quarantine lost");
 resetn=0;tick;resetn=1;#1;if(fault || !input_ready || output_valid)$fatal(1,"reset did not recover");
 $display("FINAL_CAPACITY_PASS nonfinal_refill=1 held_final_isolated=1 next_edge_reopen=1 publication_unchanged=1");$finish;
end
endmodule

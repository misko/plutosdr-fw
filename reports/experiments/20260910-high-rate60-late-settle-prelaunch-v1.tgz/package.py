"""Non-/tmp portable settling preparation; no simulation/test/source edits."""

import hashlib
import io
import json
import tarfile
from pathlib import Path

BASE=Path(__file__).resolve().parent
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
BUNDLE=BASE/"frozen-bundle"
EXPECTED="79febd5abe231065f9fc77abd7c587104e4608ffd8eae40ebd5b4f20a6ac1043"
ARCHIVE=BASE/"20260910-high-rate60-late-settle-prelaunch-v1.tgz"
RUN=BASE/"main-high-rate60-bank175-late447-settle-v1"
OWNER=BASE/"main-high-rate60-bank175-late447-settle-v1-owner"
REPORT="docs/starlink-high-rate60-late-settle-prelaunch-20260910.md"


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    assert str(BASE).startswith("/home/") and not ARCHIVE.exists()
    r=json.loads((BUNDLE/"bundle.json").read_bytes())
    assert sha((BUNDLE/"bundle.json").read_bytes())==EXPECTED
    before={n:sha((WORK/n).read_bytes()) for n in r["source_sha256"]}
    assert before==r["source_sha256"] and len(before)==119
    assert all(sha((BUNDLE/n).read_bytes())==v for n,v in r["files"].items())
    prospective=[RUN,OWNER,RUN.with_suffix(".vivado.log"),RUN.with_suffix(".vivado.jou")]
    assert all(not p.exists() and not p.is_symlink() for p in prospective)
    proposal={"classification":"PROPOSED_ONLY_NO_ACTUAL_LAUNCH_AUTHORITY",
        "tested_fw":"bca3b8e1478bef46dfc953758daded2ec49c7e4b",
        "tested_hdl":"ecbb3712965ff39b144b5adf84a2a262c6c53dff",
        "bundle_sha256":EXPECTED,"source_signature":r["source_signature"],
        "runner_sha256":"1ca8c38a649bcfc299afb608977ac6487acb68eb16fe0a00d0a4324591e67e2c",
        "absent_targets":[str(p) for p in prospective],"working_owner":str(OWNER),
        "command":["env","TMPDIR="+str(OWNER/"tmp"),"LD_LIBRARY_PATH=/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE",
                   "/opt/Xilinx/Vivado/2022.2/bin/vivado","-mode","batch","-source",
                   str(BUNDLE/"case/simulate_high_rate60_bank_native_late.tcl"),
                   "-log",str(RUN.with_suffix(".vivado.log")),"-journal",str(RUN.with_suffix(".vivado.jou")),
                   "-tclargs",str(RUN),str(BUNDLE),"/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python",EXPECTED],
        "threads":2,"requires_new_authorization":True,"retries_authorized":0,
        "all_new_temp_build_archive_outputs_non_tmp":True}
    (BASE/"successor-proposal.json").write_text(json.dumps(proposal,sort_keys=True,indent=2)+"\n")
    payload={}
    def add(name,path):
        assert name not in payload and not path.is_symlink() and path.is_file() and path.stat().st_size<10_000_000
        payload[name]=path.read_bytes()
    for p in sorted(BUNDLE.rglob("*")):
        assert not p.is_symlink()
        if p.is_file(): add("frozen-bundle/"+p.relative_to(BUNDLE).as_posix(),p)
    for name in ["package.py","successor-proposal.json","report-partial-quota-failure.md"]: add(name,BASE/name)
    add("report.md",WORK/REPORT)
    for name in ["log","xml"]:
        add("offline/final694."+name,WORK/f"build/high-rate60-late-settle-offline-v1.{name}")
        add("offline/initial_clock4."+name,WORK/f"build/high-rate60-late-settle-unit-v1.{name}")
    final=Path("/tmp/starlink-highrate60-late-settle-offline-v1")
    for dirname in ["test_actual_stimulus_clock_onl0","test_actual_stimulus_clock_onl1",
                    "test_late_whole_composition_co0","test_entire_composition_compil0"]:
        for p in sorted((final/dirname).iterdir()):
            if p.is_file() and p.suffix in [".json",".log",".sv"]: add("offline/"+dirname+"/"+p.name,p)
    diagnostic=Path("/tmp/starlink-bank-route.I50MDJ/main-high-rate60-bank175-late447-v1-owner")
    for name in ["diagnostic_predicates.py","diagnostic-predicates.json"]: add("diagnostic_only/"+name,diagnostic/name)
    parent=Path("/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/late-settle-parent.26zBTKKN")
    for name in ["pytest.log","results.xml"]: add("parent694/"+name,parent/name)
    after={n:sha((WORK/n).read_bytes()) for n in r["source_sha256"]}
    assert before==after
    assert all(sha((BUNDLE/n).read_bytes())==v for n,v in r["files"].items())
    binding={"classification":"OFFLINE_PACKAGING_INTEGRITY_NOT_NEW_ACTUAL",
        "source_before":before,"source_after":after,"source_signature":r["source_signature"],
        "bundle_sha256":EXPECTED,"source_count":119,"bundle_payload_count":376,
        "original_failed_actual_handle":88460,"original_actual_status":"FAIL",
        "original_failure_archive_sha256":"b731571cbd8ed78af1224d585d483db98b8bcd53a6764f734edf7a255ed55c33",
        "partial_report_bytes":4096,"partial_report_sha256":sha((BASE/"report-partial-quota-failure.md").read_bytes())}
    payload["source-binding.json"]=(json.dumps(binding,sort_keys=True,indent=2)+"\n").encode()
    (BASE/"source-binding.json").write_bytes(payload["source-binding.json"])
    assert len(payload)<450 and sum(map(len,payload.values()))<15_000_000
    files={n:{"sha256":sha(data),"bytes":len(data)} for n,data in sorted(payload.items())}
    payload["receipt.json"]=(json.dumps({"classification":"OFFLINE_PREPARATION_ONLY", "files":files},sort_keys=True,indent=2)+"\n").encode()
    with tarfile.open(ARCHIVE,"w:gz") as tar:
        for name,data in sorted(payload.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    with tarfile.open(ARCHIVE,"r:gz") as tar:
        members=tar.getmembers()
        assert len(members)==len(payload) and len({m.name for m in members})==len(members)
        for m in members:
            assert m.isfile() and not m.name.startswith("/") and ".." not in Path(m.name).parts
            assert tar.extractfile(m).read()==payload[m.name]
    result={"archive":str(ARCHIVE),"sha256":sha(ARCHIVE.read_bytes()),"bytes":ARCHIVE.stat().st_size,
        "safe_regular_members":len(payload),"hash_length_receipts":len(files),
        "source_signature":r["source_signature"],"bundle_sha256":EXPECTED,"actual_executed":False,
        "archive_outside_worktree_to_avoid_tmp_quota":True}
    (BASE/"archive-receipt.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__": main()

`timescale 1ns/1fs
module settle_unit;
  reg clk=0; always #5 clk=!clk;
  integer cycles=0,late_handshake_cycle=0,source_off_cycle=0;
  integer tested=0,old7=0,old8=0;
  always @(posedge clk) cycles=cycles+1;
  task automatic probe(input integer phase_fs);
    integer anchor_cycle,old_cycle,new_cycle;
    begin
      @(negedge clk); #(phase_fs/1000000.0);
      anchor_cycle=cycles; late_handshake_cycle=cycles; source_off_cycle=cycles;
      fork
        begin repeat(8) @(negedge clk); old_cycle=cycles; end
        begin repeat(8) @(negedge clk);
          while(cycles-late_handshake_cycle<8) @(negedge clk);
          new_cycle=cycles;
        end
      join
      if(old_cycle-anchor_cycle==7) old7=old7+1;
      else if(old_cycle-anchor_cycle==8) old8=old8+1;
      else $fatal(1,"old phase relation");
      if(new_cycle-anchor_cycle!=8 || new_cycle<old_cycle || new_cycle-old_cycle>1)
        $fatal(1,"corrected schedule violates unchanged8 deadline");
      tested=tested+1;
      $display("SETTLE_PHASE phase_fs=%0d old_labels=%0d new_labels=%0d",phase_fs,old_cycle-anchor_cycle,new_cycle-anchor_cycle);
    end
  endtask
  initial begin
    probe(1);
    probe(4999999);
    probe(5000001);
    probe(9999999);
    probe(433333);
    probe(7099999);
    probe(3766665);
    probe(8766666);
    probe(5433332);
    probe(2099998);
    probe(7094577);
    probe(2087034);
    if(tested!=12 || !old7 || !old8) $fatal(1,"phase coverage");
    $display("SETTLE_UNIT_PASS cases=12 NO_DUT_NATIVE_OR_FFT"); $finish;
  end
endmodule

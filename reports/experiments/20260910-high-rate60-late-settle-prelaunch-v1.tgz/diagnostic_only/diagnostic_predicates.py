"""READ-ONLY predicate inventory, NOT the frozen verifier or a PASS override.

Clone functions with a recording require solely to list additional failed
predicates after the original fatal predicate. No module globals, files, original
logs or accepted outcomes are changed. Discard the functions' result objects.
"""

import json
import sys
import types
from pathlib import Path

OWNER=Path(__file__).resolve().parent
RUN=OWNER.with_name("main-high-rate60-bank175-late447-v1")
BUNDLE=RUN/"inputs"
sys.path.insert(0,str(BUNDLE/"source_snapshot"))
from tests.starlink_oracle.high_rate60_late_result import verify_native_component

failures=[]
observed=[]


def diagnostic_require(condition,message):
    observed.append(message)
    if not condition: failures.append(message)


def main():
    target=OWNER/"diagnostic-predicates.json"
    assert not target.exists()
    scope={"__package__":"tests.starlink_oracle"}
    exec(compile((BUNDLE/"case/high_rate60_late_context.py").read_text(),"<diagnostic original context>","exec"),scope)
    cloned_globals=dict(verify_native_component.__globals__)
    cloned_globals["require"]=diagnostic_require
    clone=types.FunctionType(verify_native_component.__code__,cloned_globals)
    scope["verify_native_component"]=clone
    scope["require"]=diagnostic_require
    scope["verify_results"](RUN/"project/high_rate60_bank_native_late.sim/sim_1/behav/xsim",BUNDLE/"healthy/cohort")
    result={"classification":"DIAGNOSTIC_ONLY_ORIGINAL_RUN_REMAINS_FAILED", "original_process_exit":1,
        "original_handle":88460,"predicates_observed":len(observed),"failed_predicates":failures,
        "no_source_or_log_edits":True,"no_runtime_module_global_mutation":True,"no_actual_rerun":True}
    target.write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__": main()

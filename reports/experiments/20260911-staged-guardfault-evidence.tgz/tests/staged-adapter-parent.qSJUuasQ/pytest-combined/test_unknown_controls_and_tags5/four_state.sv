`timescale 1ns/1ps
module tb;
localparam D=70,T=32,E=T+D+12,W=3*D+4*T+31,N=2;
reg clk=0;always #5 clk=~clk;
reg resetn=0,abort_epoch=0,command_valid=0,response_ready=1,lookup_valid=0;
reg [1:0] command_opcode=0;
reg [T-1:0] command_tag=0,lookup_tag=0;
reg [D-1:0] command_descriptor=0;
wire command_ready,response_valid,lookup_found,lookup_committed,tags_exhausted,fault;
wire [1:0] response_opcode,occupied,committed;
wire [T-1:0] response_tag;
wire [D-1:0] lookup_descriptor;
starlink_pss_descriptor_commands #(.TAG_WIDTH(T)) dut(.*);
wire [E-1:0] observed={command_ready,response_valid,response_opcode,response_tag,fault,occupied,committed,tags_exhausted,lookup_found,lookup_committed,lookup_descriptor};
reg [W-1:0] vectors[0:N-1];reg [E-1:0] expected_before,expected_after;integer row;
task send(input [1:0] opcode);
begin
  @(negedge clk);command_valid=1;command_opcode=opcode;command_tag=0;command_descriptor=70'h123456;
  #1;if(command_ready!==1) $fatal(1,"setup not ready");
  @(posedge clk);#0.1;command_valid=0;
  @(posedge clk);#0.1;if(response_valid!==1) $fatal(1,"setup response missing");
  @(posedge clk);#0.1;if(response_valid!==0) $fatal(1,"setup response not consumed");
end
endtask
initial begin
  @(negedge clk);resetn=0;
  @(negedge clk);resetn=1;
  send(0);
  
  @(negedge clk);lookup_valid=1;lookup_tag=0;
  abort_epoch='z;
  #1;
  if(fault!==1 || command_ready!==0 || response_valid!==0 || lookup_found!==0)
      $fatal(1,"unknown scalar did not immediately fence");
  @(posedge clk);#0.1;
  command_valid=0;response_ready=1;abort_epoch=0;command_opcode=0;command_tag=0;
  @(posedge clk);#0.1;
  if(fault!==1 || response_valid!==0) $fatal(1,"bad command escaped quarantine");

  $display("COMMANDS_FOUR_STATE_PASS");$finish(0);
end
endmodule

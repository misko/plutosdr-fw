`timescale 1ns/1ps
module tb;
reg clk=0,fast_running=0,CERTIFIED_ADMISSION=1,next_inverse=0;
reg return_commit_valid=0,result_destination_ready=0,admit=0;
reg product_bank_valid=0,kernel_ready=1,product_bank_ready=1;
reg raw_last=0,current_fault=0,sticky_fault=0;
reg [1:0] guard_commit=0;
reg forward_committed=0,original=0;
integer mode,n,checks=0,pending=0;
  wire forward_receipt_wait = forward_committed || (CERTIFIED_ADMISSION && guard_commit[0]);
wire actual_ready=forward_receipt_wait ? product_bank_valid : kernel_ready && product_bank_ready;
wire old_ready=original ? product_bank_valid : kernel_ready && product_bank_ready;
wire publish=forward_committed && !current_fault && !sticky_fault;
always @(posedge clk) begin
  if(!fast_running) begin forward_committed<=0; original<=0;guard_commit<=0;end
  else begin
    guard_commit[0]<=return_commit_valid && result_destination_ready && !next_inverse;
    if(return_commit_valid && result_destination_ready && !next_inverse)original<=1;
        if (CERTIFIED_ADMISSION ? (guard_commit[0] && !next_inverse) :
            (return_commit_valid && result_destination_ready && !next_inverse))
          forward_committed <= 1;
    if(admit)begin original<=0;forward_committed<=0;end
  end
end
task tick;begin #1;clk=1;#1;clk=0;#1;
 if(fast_running)begin
   checks=checks+1;
   if(forward_receipt_wait!==original || actual_ready!==old_ready)$fatal(1,"ACK wait changed");
   if(publish && (!original || current_fault || sticky_fault))$fatal(1,"unauthorized publication");
   if(forward_committed!==original)begin
     if(!CERTIFIED_ADMISSION || forward_committed!==0 || original!==1 || guard_commit[0]!==1)
       $fatal(1,"unqualified completion difference");
     pending=pending+1;
   end
 end
end endtask
function val(input integer n);case(n)0:val=0;1:val=1;2:val=1'bx;3:val=1'bz;endcase endfunction
initial begin
 for(mode=0;mode<2;mode=mode+1)for(n=0;n<32;n=n+1)begin
   CERTIFIED_ADMISSION=mode;fast_running=0;admit=0;tick;fast_running=1;
   // Malformed/unqualified LAST must never be receipt authority.
   return_commit_valid=0;result_destination_ready=1;raw_last=1;
   product_bank_valid=0;current_fault=0;sticky_fault=0;tick;
   raw_last=0;
   // Known qualified completion, followed by known/X/Z downstream readiness.
   return_commit_valid=n&1;result_destination_ready=1;
   tick;return_commit_valid=0;
   current_fault=(n>>1)&1;sticky_fault=current_fault;tick;
   product_bank_valid=val((n>>2)&3);tick;
   current_fault=0;tick;product_bank_valid=1;tick;
   admit=1;tick;admit=0;tick;
   fast_running=0;tick;
 end
 if(pending!=16)$fatal(1,"pending coverage count %0d",pending);
 $display("FORWARD_RECEIPT_TRANSITIONS_PASS checks=%0d pending=%0d ack_exact=1 publication_subset=1",checks,pending);$finish;
end
endmodule

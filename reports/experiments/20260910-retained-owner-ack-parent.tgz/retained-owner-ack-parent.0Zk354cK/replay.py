"""Retain all original-owner counterexamples; never relabel a failed simulation."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
source = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-composition17-v2/source/hdl/library/starlink_pss_acquisition/retained_output/starlink_pss_retained_output_owner.v')
pin = 'f9f51f6889c505215aa591c78ad3157314b9ac21aff651a7b7a9e653b5683904'
assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
env = {k: v for k, v in os.environ.items() if k not in
       {'PYTHONHOME', 'PYTHONPATH', 'PYTHONOPTIMIZE', 'LD_LIBRARY_PATH'}}
rows = []
for kind in range(9):
    directory = root / f'original-kind{kind}'
    directory.mkdir()
    command = ['iverilog', '-g2012', '-s', 'tb', f'-Ptb.KIND={kind}',
               '-o', str(directory / 'sim.vvp'), str(root / 'tb.sv'), str(source)]
    compiled = subprocess.run(command, env=env, capture_output=True, text=True, timeout=30)
    (directory / 'compile.log').write_text(compiled.stdout + compiled.stderr)
    assert compiled.returncode == 0, compiled.stderr
    run = subprocess.run(['vvp', str(directory / 'sim.vvp')], env=env,
                         capture_output=True, text=True, timeout=30)
    log = run.stdout + run.stderr
    (directory / 'simulation.log').write_text(log)
    row = {'kind': kind, 'compile_exit': compiled.returncode, 'simulation_exit': run.returncode,
           'compile_command': command, 'log_sha256': hashlib.sha256(log.encode()).hexdigest()}
    (directory / 'result.json').write_text(json.dumps(row, indent=2))
    if kind == 0:
        assert run.returncode == 0 and 'PARENT_HEALTHY_ACK_PASS' in log, log
    else:
        assert run.returncode != 0 and 'PARENT_UNSAFE_SAME_EDGE_RELEASE' in log, log
    rows.append(row)
assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
with (root / 'result.json').open('x') as output:
    json.dump({'scope': 'standalone owner controls, NOT demonstrated top-level reachability',
               'original_source_sha256': pin, 'healthy_cases': 1,
               'expected_original_simulation_failures': 8, 'rows': rows}, output, indent=2)
print('REPRODUCED: healthy ACK passes; eight original owner boundary simulations fail with unsafe release')

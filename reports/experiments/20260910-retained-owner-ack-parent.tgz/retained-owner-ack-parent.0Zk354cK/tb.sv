// Parent standalone boundary probe. No FFT, mailbox actor or top-level claim.
`timescale 1ns/1ps
module tb;
  parameter integer KIND=0;
  reg clk=0,resetn=0; always #5 clk=~clk;
  reg inverse_admit=0,inverse_publication=0,inverse_guard_ack=0,transfer_consumed=0;
  reg bank_ready=1,bank_request=0,bank_ack_sync=0,common_current_fault=0;
  wire reusable,reservation,retained,fault_now,transfer_receipt,reader_release;
  wire [7:0] fault_reasons;
  wire [1:0] current_lease,admitted_lease;
  starlink_pss_retained_output_owner dut(.*);
  task step; begin @(posedge clk); #0.001; @(negedge clk); end endtask
  initial begin
    repeat(2)step; resetn=1; step;
    if(reusable!==1)$fatal(1,"SETUP not reusable");
    inverse_admit=1; step; inverse_admit=0;
    inverse_publication=1;
    @(posedge clk); #0.001; bank_request=1; bank_ready=0;
    @(negedge clk); inverse_publication=0;
    repeat(3)step;
    if(retained!==1||transfer_receipt!==1||fault_reasons!==0)
      $fatal(1,"SETUP publication/busy witness");
    transfer_consumed=1; step; transfer_consumed=0;
    if(transfer_receipt!==0||retained!==1||reusable!==0)
      $fatal(1,"SETUP receipt not real ACK");
    // Every negative case has the same otherwise valid real ACK evidence.
    bank_ack_sync=1; bank_ready=1; inverse_guard_ack=1;
    case(KIND)
      1: inverse_publication=1;
      2: inverse_publication=1'bx;
      3: transfer_consumed=1;
      4: transfer_consumed=1'bx;
      5: inverse_admit=1;
      6: inverse_admit=1'bx;
      7: inverse_guard_ack=1'bx;
      8: inverse_publication=1'bz;
    endcase
    #0.001;
    $display("PARENT_ACK_BOUNDARY kind=%0d release=%b retained=%b lease=%0d reasons=%h",
      KIND,reader_release,retained,current_lease,fault_reasons);
    if(KIND==0)begin
      if(reader_release!==1)$fatal(1,"HEALTHY real ACK blocked");
      step; inverse_guard_ack=0;
      if(retained!==0||current_lease!==1||fault_reasons!==0)
        $fatal(1,"HEALTHY release state");
      $display("PARENT_HEALTHY_ACK_PASS");
    end else begin
      if(reader_release!==0)$fatal(1,"PARENT_UNSAFE_SAME_EDGE_RELEASE kind=%0d",KIND);
      step;
      if(retained!==1||current_lease!==0||fault_reasons===0)
        $fatal(1,"PARENT_MISSING_RETAINED_QUARANTINE kind=%0d",KIND);
      $display("PARENT_REJECTED_ACK_PASS kind=%0d",KIND);
    end
    $finish;
  end
  initial begin #10000;$fatal(1,"PARENT bounded timeout");end
endmodule

// A valid caller may retire a pending transfer receipt with its real read ACK.
`timescale 1ns/1ps
module tb;
  reg clk=0,resetn=0; always #5 clk=~clk;
  reg inverse_admit=0,inverse_publication=0,inverse_guard_ack=0,transfer_consumed=0;
  reg bank_ready=1,bank_request=0,bank_ack_sync=0,common_current_fault=0;
  wire reusable,reservation,retained,fault_now,transfer_receipt,reader_release;
  wire [7:0] fault_reasons;
  wire [1:0] current_lease,admitted_lease;
  starlink_pss_retained_output_owner dut(.*);
  task step; begin @(posedge clk); #0.001; @(negedge clk); end endtask
  initial begin
    repeat(2)step; resetn=1; step;
    if(reusable!==1)$fatal(1,"SETUP not reusable");
    inverse_admit=1; step; inverse_admit=0;
    inverse_publication=1;
    @(posedge clk); #0.001; bank_request=1; bank_ready=0;
    @(negedge clk); inverse_publication=0;
    repeat(3)step;
    if(retained!==1||transfer_receipt!==1||fault_reasons!==0)
      $fatal(1,"SETUP pending receipt and busy witness");
    // Unlike the negative probe, no earlier transfer consumed this receipt.
    bank_ack_sync=1; bank_ready=1; inverse_guard_ack=1; transfer_consumed=1;
    #0.001;
    $display("PARENT_VALID_COINCIDENCE release=%b receipt=%b reasons=%h",
      reader_release,transfer_receipt,fault_reasons);
    if(reader_release!==1)$fatal(1,"PARENT_VALID_RECEIPT_ACK_BLOCKED");
    step; inverse_guard_ack=0; transfer_consumed=0;
    if(retained!==0||current_lease!==1||transfer_receipt!==0||fault_reasons!==0)
      $fatal(1,"PARENT_VALID_RECEIPT_ACK_STATE");
    $display("PARENT_VALID_RECEIPT_ACK_PASS"); $finish;
  end
  initial begin #10000;$fatal(1,"PARENT bounded timeout");end
endmodule

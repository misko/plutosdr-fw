"""Identical independent probes applied to the final, receipt-qualified fence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
source = root / 'owner-final-fence.v'
pin = 'b6280f6a894ec120f0e57415d5cc6da7b9e193a65f42b1d7f9789cbdbaa5d648'
assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
env = {k:v for k,v in os.environ.items() if k not in
       {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
cases = [(f'final-kind{k}', 'tb.sv', k, 'PARENT_HEALTHY_ACK_PASS' if k == 0
          else 'PARENT_REJECTED_ACK_PASS') for k in range(9)]
cases += [('final-valid-coincidence', 'tb_valid_transfer_ack.sv', None, 'PARENT_VALID_RECEIPT_ACK_PASS')]
rows = []
for name, bench, kind, marker in cases:
    directory = root / name
    directory.mkdir()
    command = ['iverilog', '-g2012', '-s', 'tb', '-o', str(directory / 'sim.vvp')]
    if kind is not None:
        command.append(f'-Ptb.KIND={kind}')
    command += [str(root / bench), str(source)]
    compiled = subprocess.run(command, env=env, capture_output=True, text=True, timeout=30)
    (directory / 'compile.log').write_text(compiled.stdout + compiled.stderr)
    assert compiled.returncode == 0, compiled.stderr
    run = subprocess.run(['vvp', str(directory / 'sim.vvp')], env=env,
                         capture_output=True, text=True, timeout=30)
    log = run.stdout + run.stderr
    (directory / 'simulation.log').write_text(log)
    row = {'name': name, 'compile_command': command, 'compile_exit': compiled.returncode,
           'simulation_exit': run.returncode, 'log_sha256': hashlib.sha256(log.encode()).hexdigest()}
    (directory / 'result.json').write_text(json.dumps(row, indent=2))
    assert run.returncode == 0 and marker in log, log
    rows.append(row)
assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
with (root / 'final-result.json').open('x') as output:
    json.dump({'scope': 'standalone owner controls; no full top reachability or physical claim',
               'source_sha256': pin, 'passed': 10, 'rows': rows}, output, indent=2)
print('PASS: final owner, eight invalid-control rejections, ordinary ACK, valid pending-receipt/ACK coincidence')

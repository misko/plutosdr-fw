"""Check first fence regressions and retain its too-strict healthy counterexample."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
original = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-composition17-v2/source/hdl/library/starlink_pss_acquisition/retained_output/starlink_pss_retained_output_owner.v')
first = root / 'owner-first-fence.v'
pins = {original: 'f9f51f6889c505215aa591c78ad3157314b9ac21aff651a7b7a9e653b5683904',
        first: '49b671d0f79e16c11ffd25fddda56b3ce166380cf5c94ae281a1ca1229c66b8d'}
env = {k:v for k,v in os.environ.items() if k not in
       {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
for source, pin in pins.items():
    assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
cases = [(f'first-kind{k}', first, 'tb.sv', k, 'PARENT_HEALTHY_ACK_PASS' if k == 0
          else 'PARENT_REJECTED_ACK_PASS', False) for k in range(9)]
cases += [('original-valid-coincidence', original, 'tb_valid_transfer_ack.sv', None,
           'PARENT_VALID_RECEIPT_ACK_PASS', False),
          ('first-valid-coincidence', first, 'tb_valid_transfer_ack.sv', None,
           'PARENT_VALID_RECEIPT_ACK_BLOCKED', True)]
rows = []
for name, source, bench, kind, marker, expected_failure in cases:
    directory = root / name
    directory.mkdir()
    command = ['iverilog', '-g2012', '-s', 'tb', '-o', str(directory / 'sim.vvp')]
    if kind is not None:
        command.append(f'-Ptb.KIND={kind}')
    command += [str(root / bench), str(source)]
    compiled = subprocess.run(command, env=env, capture_output=True, text=True, timeout=30)
    (directory / 'compile.log').write_text(compiled.stdout + compiled.stderr)
    assert compiled.returncode == 0, compiled.stderr
    run = subprocess.run(['vvp', str(directory / 'sim.vvp')], env=env,
                         capture_output=True, text=True, timeout=30)
    log = run.stdout + run.stderr
    (directory / 'simulation.log').write_text(log)
    row = {'name': name, 'source_sha256': pins[source], 'compile_command': command,
           'compile_exit': compiled.returncode, 'simulation_exit': run.returncode,
           'expected_failure': expected_failure, 'log_sha256': hashlib.sha256(log.encode()).hexdigest()}
    (directory / 'result.json').write_text(json.dumps(row, indent=2))
    assert (run.returncode != 0) == expected_failure and marker in log, log
    rows.append(row)
for source, pin in pins.items():
    assert hashlib.sha256(source.read_bytes()).hexdigest() == pin
with (root / 'first-fence-result.json').open('x') as output:
    json.dump({'scope': 'standalone boundary only', 'rows': rows}, output, indent=2)
print('First fence rejects eight bad controls and passes ordinary ACK; valid pending-receipt+ACK fails. Original valid coincidence passes.')

# Read-only resource inventory of the immutable complete receiver reference.
# No constraints, synthesis, placement, routing or checkpoint writes.
if {$argc != 3} { error "expected CHECKPOINT SHA256 NEW_OUTPUT" }
if {[version -short] ne "2022.2"} { error "requires Vivado 2022.2" }
set checkpoint [file normalize [lindex $argv 0]]
set expected_hash [lindex $argv 1]
set output [file normalize [lindex $argv 2]]
if {![regexp {^[0-9a-f]{64}$} $expected_hash]} { error "full checkpoint hash required" }
if {![file isfile $checkpoint] || [lindex [exec sha256sum $checkpoint] 0] ne $expected_hash} {
  error "checkpoint identity mismatch"
}
if {[file exists $output]} { error "output must be new" }
file mkdir $output
file copy [info script] [file join $output measurement_source.tcl]
open_checkpoint $checkpoint
if {[get_property PART [current_design]] ne "xc7z010clg400-1"} { error "wrong receiver part" }
set report [open [file join $output scope.txt] w]
puts $report "scope=read_only_complete_receiver_reference_resource_inventory_not_new_design_qualification"
puts $report "checkpoint=$checkpoint"
puts $report "checkpoint_sha256=$expected_hash"
puts $report "nested_subtrees_overlap_do_not_sum=true"
puts $report "primitive_LUT_count_is_not_combined_slice_LUT_occupancy=true"
report_utilization -hierarchical -hierarchical_depth 8 -file [file join $output hierarchy.rpt]
foreach {label pattern} {
  acquisition {.*starlink_pss_acquisition/inst$}
  fine {.*starlink_pss_tracker/inst$}
  pilot {.*starlink_pilot_capture/inst$}
  pilot_dma {.*starlink_pilot_dma/inst$}
  transform_service {.*transform_service$}
  FFT {.*transform_service/shared_xfft$}
} {
  set cells [get_cells -quiet -hier -regexp $pattern]
  if {[llength $cells] != 1} { error "expected exact $label subtree, got [llength $cells]" }
  set name [get_property NAME $cells]
  puts $report "$label=$name"
  report_utilization -cells $cells -hierarchical -hierarchical_depth 4 \
    -file [file join $output ${label}.rpt]
  set primitives [get_cells -quiet -hier -filter "IS_PRIMITIVE && NAME =~ ${name}/*"]
  foreach {kind match} {LUT LUT* FF FD* DSP DSP48E1 RAM18 RAMB18E1 RAM36 RAMB36E1} {
    puts $report "${label}_${kind}=[llength [filter $primitives [format {REF_NAME =~ %s} $match]]]"
  }
}
if {[lindex [exec sha256sum $checkpoint] 0] ne $expected_hash} { error "checkpoint changed" }
puts $report "COMPLETE_RECEIVER_REFERENCE_RESOURCE_INVENTORY_FINISHED hardware_qualified=false"
close $report
close_design
puts "COMPLETE_RECEIVER_REFERENCE_RESOURCE_INVENTORY_FINISHED hardware_qualified=false"

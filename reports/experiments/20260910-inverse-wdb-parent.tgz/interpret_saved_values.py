"""Independent bounded interpretation of saved values, no vendor/tool execution."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-wdb-prepared-v1.0elVwpXY')
PLAN = ROOT / 'history_plan.json'
LOG = ROOT / 'query-owned-v1/outer.log'


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


require(sha(PLAN) == '4aaeaa9d7a20a2a9da4f3721dea5189909467ee9c7726666f38f69cb1ae4a605', 'plan pin')
require(sha(LOG) == 'c008f94833dafd436af5e2088647d5ea03d568fc26bc1e12de76a66aff6888fb', 'original loader log pin')
plan = json.loads(PLAN.read_text())
terminal = json.loads((ROOT / 'query-owned-v1/terminal.json').read_text())
before = json.loads((ROOT / 'query-owned-v1/before.json').read_text())
require(terminal['original_process_exit'] == 0 and terminal['launch_error'] is None
        and terminal['after_error'] is None and terminal['input_unchanged']
        and terminal['original_names_unchanged'], 'loader owner outcome')
require(before['input_sha256'] == terminal['after_sha256'], 'loader before/after inventory')
require({name: sha(Path(name)) for name in before['input_sha256']} == before['input_sha256'], 'live original/copy integrity')
text = LOG.read_text()
require(not re.search(r'^\s*(?:ERROR|FATAL):', text, re.MULTILINE), 'loader terminal error')
marker = 'INVERSE_WDB_HISTORY_EXTRACTED arithmetic=115 observer=14 ownership=19 times=64 values=9472 no_advance=1 physical_time_only=1'
require(text.splitlines().count(marker) == 1, 'unique loader completion')
values = {}
for line in text.splitlines():
    if not line.startswith('INVERSE_WDB_VALUE\t'):
        continue
    tag, group, when, radix, path, value = line.split('\t')
    key = int(when), group, path
    require(key not in values and value not in ('', '<Blank>'), 'duplicate/absent history')
    require(radix == plan['groups'][group]['radix'], 'changed radix')
    values[key] = value.lower()
expected = {(row['time_fs'], group, path) for row in plan['snapshots']
            for group, item in plan['groups'].items() for path in item['paths']}
require(set(values) == expected and len(values) == 9472, 'complete exact recorded path/time inventory')
top = plan['groups']['ownership']['paths'][0].rsplit('/', 1)[0]


def get(row, group, leaf):
    return values[row['time_fs'], group, top + '/' + leaf]


def integer(row, group, leaf):
    raw = get(row, group, leaf)
    require(re.fullmatch('[0-9a-f]+' if group != 'observer' else '[01]+', raw) is not None, 'unknown qualified value: ' + leaf)
    return int(raw, 2 if group == 'observer' else 16)


def signed(row, leaf):
    value = integer(row, 'ownership', leaf)
    return value - (1 << 32) if value & (1 << 31) else value


guard_rows, arithmetic_checks = [], 0
for row in plan['snapshots']:
    actual, original, default = [get(row, 'observer', 'local_guard_observer/' + name)
                                 for name in ('actual_view', 'original_view', 'default_view')]
    require(len(actual) == 155 and actual == original == default, 'full155-bit unconditional snapshot mismatch')
    guard_rows.append({'label': row['label'], 'time_fs': row['time_fs'],
        'pre': integer(row, 'observer', 'local_guard_observer/pre_checks'),
        'post': integer(row, 'observer', 'local_guard_observer/post_checks')})
    for prefix in ('payload_shadow', 'forward_chain_shadow'):
        ref = prefix + '/\\extra_token_reference.reference /'
        resetn, flush = [get(row, 'arithmetic', ref + name) for name in ('resetn', 'flush')]
        if resetn != '1' or flush != '0':
            continue
        # Literal unchanged119-bit checker tuple, including all public values
        # even when p_valid=0. Only its original reset/flush qualifier applies.
        fields = [('available', 1), ('p_valid', 1), ('p_i', 18), ('p_q', 18),
                  ('p_position', 9), ('p_exponent', 5), ('p_last', 1), ('p_start', 64),
                  ('p_overflow', 1), ('p_overflow_pulse', 1)]
        packed, width = 0, 0
        for leaf, bits in fields:
            field = integer(row, 'arithmetic', ref + leaf)
            require(field < 1 << bits, 'reference width')
            packed = (packed << bits) | field
            width += bits
        require(width == 119 and packed == integer(row, 'arithmetic', ref + 'product_outputs'),
                'full119-bit arithmetic snapshot mismatch')
        arithmetic_checks += 1
require(arithmetic_checks > 0, 'no qualified arithmetic snapshots')
ownership = []
signals = {'TAKE': 'inverse_take', 'CERT': 'inverse_certificate', 'SEAL': 'inverse_seal',
           'PUB': 'inverse_publication', 'ACK': 'inverse_reader_ack', 'REL': 'inverse_release'}
for row in plan['snapshots']:
    match = re.fullmatch(r'lease([01])_(ADMIT|TAKE|QUALIFY|CERT|SEAL|PUB|ACK|REL|REUSE)_(before|edge|plus1ps)', row['label'])
    if not match:
        continue
    lease, event, side = int(match[1]), match[2], match[3]
    if side == 'before' and event in signals:
        require(integer(row, 'ownership', signals[event]) == 1, 'missing pre-edge actual handshake: ' + row['label'])
    if side != 'plus1ps':
        continue
    require(integer(row, 'ownership', 'inverse_protocol_lease') == lease
            and integer(row, 'ownership', 'inverse_lease') == lease
            and integer(row, 'ownership', 'inverse_protocol_start') == 8590000128 + lease * 447,
            'post-edge admitted full identity/independent lease')
    require(integer(row, 'ownership', 'inverse_protocol_owned') == int(event != 'REUSE'), 'owned lifetime state')
    if event in ('ADMIT', 'TAKE', 'QUALIFY'):
        expected_words = {'ADMIT': 0, 'TAKE': 1, 'QUALIFY': 512}[event]
        require(integer(row, 'ownership', 'inverse_protocol_words') == expected_words, 'accepted token count')
    if event in ('QUALIFY', 'PUB', 'ACK', 'REL'):
        leaf = {'QUALIFY': 'qualified', 'PUB': 'pub', 'ACK': 'ack', 'REL': 'release'}[event]
        edge = row['time_fs'] - 1000
        require(signed(row, 'inverse_protocol_' + leaf) == (edge - 2857143) // 5714286,
                'exact monitor event timestamp')
    if event == 'REUSE':
        require(integer(row, 'ownership', 'inverse_protocol_reuse_seen') == 1, 'reusable receipt')
    ownership.append({'lease': lease, 'event': event, 'time_fs': row['time_fs']})
require(len(ownership) == 18, 'two complete sampled ownership lifetimes')
output = {'scope': 'BOUNDED_RECORDED_PHYSICAL_TIMESTAMP_HISTORY_NOT_INTRATIMESTAMP_SCHEDULING_PROOF',
    'loader_original_handle': 35055, 'log_sha256': sha(LOG), 'values': len(values),
    'full155_equal_snapshots': 64, 'qualified_full119_comparisons': arithmetic_checks,
    'ownership_postedge_events': ownership, 'guard_counters': guard_rows,
    'all215_owner_inputs_unchanged': True, 'simulation_advance': False, 'physical_qualified': False}
with (Path(__file__).parent / 'interpreted_recorded_history.json').open('x') as stream:
    stream.write(json.dumps(output, indent=2, sort_keys=True) + '\n')
print(json.dumps({'values': 9472, 'full155_equal_snapshots': 64,
    'qualified_full119_comparisons': arithmetic_checks, 'ownership_events': 18,
    'interpretation_sha256': sha(Path(__file__).parent / 'interpreted_recorded_history.json')}, indent=2))

"""Read-only independent connectivity correction on original87683's netlist.

Continuous dependency graph only; procedural variables/RAM are state cuts.
Structural cycles are not a claim of observed oscillation or physical timing.
"""
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
NETLIST = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/product-sealed-parent.qo5EiWU4/cases/product_adapter0/original/sim.vvp')
PIN = '034eebc7bf351336e7bae74b7ff7424ac67a04c35914b441b5cc635582e1d270'
TOKEN = re.compile(r'\b(?:LS?_0x|v0x)[0-9a-f]+(?:_\d+)*\b')
ALLOWED = {'net', 'net/2u', 'net/2s', 'net/s', 'arith/sum', 'array/port',
           'cmp/eeq', 'cmp/eq', 'cmp/gt', 'cmp/ne', 'cmp/nee', 'concat', 'concat8',
           'functor', 'part', 'part/v', 'reduce/and', 'reduce/nor', 'reduce/or',
           'reduce/xor', 'shift/l', 'ufunc/vec4'}


def parse(source, legacy=False):
    graph, definitions, aliases, scopes = {}, set(), {}, {}
    current = ''
    for line in source.splitlines():
        match = re.fullmatch(r'(\w+) \.(\S+) (.*);', line)
        if not match:
            continue
        label, operation, body = match.groups()
        definitions.add(label)
        if operation == 'scope':
            name = re.search(r'"([^"]*)"', body).group(1)
            parent = re.search(r', (S_0x[0-9a-f]+)$', body)
            current = (scopes[parent[1]] + '/' if parent else '') + name
            scopes[label] = current
        if operation.startswith('net') or label.startswith(('L_', 'LS_')):
            if operation not in ALLOWED:
                raise ValueError('UNKNOWN_OPERATION ' + operation)
            if operation.startswith('ufunc') and 'product.round_and_saturate' not in body:
                raise ValueError('UNREVIEWED_FUNCTION')
            if not legacy or not label.startswith('LS_'):
                token = r'(?:L_0x|v0x)[0-9a-f]+(?:_\d+)?' if legacy else TOKEN
                graph[label] = set(re.findall(token, body))
            if operation.startswith('net'):
                name = re.search(r'"([^"]*)"', body).group(1)
                aliases[label] = current + '/' + name
    if not legacy:
        references = set().union(*graph.values())
        missing = references - definitions
        if missing:
            raise ValueError('UNRESOLVED_REFERENCES ' + repr(sorted(missing)))
    return graph, aliases


def first_cycle(graph):
    colors, stack = {}, []

    def walk(node):
        if colors.get(node) == 1:
            return stack[stack.index(node):] + [node]
        if colors.get(node) == 2:
            return None
        colors[node] = 1
        stack.append(node)
        for child in sorted(graph.get(node, ())):
            found = walk(child)
            if found:
                return found
        stack.pop()
        colors[node] = 2
        return None

    for node in sorted(graph):
        found = walk(node)
        if found:
            return found
    return None


# Minimal cycle exists only through an LS node with two suffix coordinates.
sample = '''L_0xa .functor OR 1, LS_0xb_0_4, C4<0>, C4<0>, C4<0>;
LS_0xb_0_4 .concat [ 1 0 0 0], L_0xa;
'''
assert first_cycle(parse(sample)[0])
assert first_cycle(parse(sample, legacy=True)[0]) is None
assert first_cycle(parse('L_0xa .functor BUF 1, C4<0>;\n')[0]) is None
try:
    parse('L_0xa .functor BUF 1, LS_0xb_0_4;\n')
except ValueError as exc:
    assert 'UNRESOLVED_REFERENCES' in str(exc)
else:
    raise AssertionError('missing node accepted')

source = NETLIST.read_bytes()
assert hashlib.sha256(source).hexdigest() == PIN
graph, aliases = parse(source.decode())
legacy, _ = parse(source.decode(), legacy=True)
assert len(legacy) == 3123 and first_cycle(legacy) is None
cycle = first_cycle(graph)
assert cycle is not None
drivers = {}
for node, name in aliases.items():
    for driver in graph[node]:
        drivers.setdefault(driver, []).append(name)
result = {
    'scope': 'CONTINUOUS_STRUCTURAL_GRAPH_NOT_PHYSICAL_TIMING',
    'original_netlist_sha256': PIN, 'legacy_nodes': len(legacy),
    'complete_nodes': len(graph), 'LS_nodes': sum(n.startswith('LS_') for n in graph),
    'legacy_false_negative_reproduced': True, 'structural_cycle_found': True,
    'cycle': [{'label': node, 'net': aliases.get(node), 'driver_aliases': drivers.get(node, [])} for node in cycle],
    'original_behavioral_848_result_changed': False,
    'self_tests': ['LS_cycle', 'legacy_miss', 'acyclic', 'unresolved_reference_rejected'],
}
assert hashlib.sha256(NETLIST.read_bytes()).hexdigest() == PIN
with (HERE / 'verification.json').open('x') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2))

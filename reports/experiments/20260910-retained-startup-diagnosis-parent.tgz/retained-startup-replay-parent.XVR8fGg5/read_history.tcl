# Read only the targeted diagnostic WDB; never advance simulation.
set_param general.maxThreads 2
set wave /home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-startup-replay-parent.XVR8fGg5/startup.wdb
set before [exec sha256sum $wave]
if {[lindex $before 0] ne "709e3c030edb874d544a3ad66320bcd5488ff21b0145f5c8109338377191b088"} {error "wrong diagnostic WDB"}
open_wave_database $wave
set selected {}
foreach object [get_objects -r *] {
  if {[regexp {/(fft_clk|fast_running|state|completion_accept|completion_receipt|cutover_reasons|known|producer_closed|job_accept|config_accept|resetn|fault_reasons|raw_vendor_faults|raw_frame|raw_output|raw_status)$} $object]} {lappend selected $object}
}
set times {0 1000 1000000}
for {set cycle 1} {$cycle <= 31} {incr cycle} {
  set edge [expr {2857143 + ($cycle-1)*5714286}]
  lappend times [expr {$edge-1}] $edge
  if {$cycle < 31} {lappend times [expr {$edge+1000}]}
}
set recorded 0
set missing 0
foreach time $times {
  foreach object $selected {
    set value [get_value_database -radix bin -time ${time}fs $object]
    if {$value eq "" || $value eq "<Blank>"} {incr missing} else {incr recorded}
    puts "HISTORY\t$time\t$object\t$value"
  }
}
if {$before ne [exec sha256sum $wave]} {error "changed WDB"}
puts "READ_ONLY_HISTORY objects=[llength $selected] times=[llength $times] recorded=$recorded missing=$missing no_advance=1"

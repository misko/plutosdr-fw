"""Independent checks of diagnostic receipts and recorded startup history."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
execution = json.loads((root/'execution.json').read_text())
assert execution['original_unchanged'] and execution['source_verify_exit']==0
assert execution['original_cycle31_reproduced'] and not execution['timed_out']
assert execution['copied_changed_files']==['xsim.dir/tb_behav/xsimkernel.log']
assert hashlib.sha256((root/'startup.wdb').read_bytes()).hexdigest()=='709e3c030edb874d544a3ad66320bcd5488ff21b0145f5c8109338377191b088'
rows={}
for line in (root/'history.log').read_text().splitlines():
    if not line.startswith('HISTORY\t'): continue
    _, stamp, name, value = line.split('\t')
    key=(int(stamp),name)
    assert key not in rows
    rows[key]=value
assert len(rows)==5985
assert sum(value!='<Blank>' for value in rows.values())==2470
base='/tb/dut/\\retained.island /'
times=sorted({stamp for stamp,name in rows})
assert len(times)==95
for stamp in times:
    assert rows[stamp,base+'completion_accept']=='Z'
    assert rows[stamp,base+'cutover/producer_closed']=='Z'
for stamp in (162857150,162857151,162858151,168571436,168571437,168572437,174285722,174285723):
    assert rows[stamp,base+'cutover/known']=='1'
    for name in ('job_accept','config_accept','raw_frame','raw_output','raw_status'):
        assert rows[stamp,base+'cutover/'+name]=='0'
    assert rows[stamp,base+'cutover/raw_vendor_faults']=='000'
assert rows[162857150,base+'fast_running']=='0'
assert rows[162857151,base+'fast_running']=='1'
assert rows[168571436,base+'cutover_reasons']=='00000000'
assert rows[168571437,base+'cutover_reasons']=='00000001'
values={}
for line in (root/'run/startup_values.tsv').read_text().splitlines()[1:]:
    phase,name,value=line.split('\t')
    values[phase,name]=value
assert len(values)==132
assert int(values['after','/tb/actual_jobs'],2)==0
assert int(values['after','/tb/actual_commits'],2)==0
assert int(values['after','/tb/payload_checks'],2)==2
assert int(values['after','/tb/forward_checks'],2)==61
report={'scope':'diagnosis_not_qualification','recorded_rows':2470,'unlogged_rows':3515,
        'undriven_control_sample_times':95,'fast_release_fs':162857151,
        'fault_latch_fs':168571437,'fatal_fs':174285723,'jobs':0,'commits':0,
        'control':'completion_accept / cutover.producer_closed',
        'sampled_value':'Z','suspected_mechanism':'implicit net before later initialized wire declaration; corrected compilation still required',
        'no_assertion_or_runtime_edits':True}
(root/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))

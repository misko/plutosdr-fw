"""One copied-snapshot startup diagnostic. No RTL modification or qualification."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

root = Path(__file__).resolve().parent
original = root.parent / 'retained-actual-sv-parent.cKDdhubU'
sim = original / 'run/project/retained_output_actual.sim/sim_1/behav/xsim'
script = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired/tools/diagnostics/retained_output_startup.tcl')
bundle = root.parent / 'retained-output-actual-prelaunch-language-v2'
python = '/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11'
cli = bundle / 'source_snapshot/tools/prepare_starlink_retained_output_actual.py'
expected = '3a0eb7872722b65764178c813ec96946e61ce0ac226c0202ea0a70d24e559eeb'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(base):
    return {str(p.relative_to(base)): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(base.rglob('*')) if p.is_file() and not p.is_symlink()}
def record(name, data):
    with (root / name).open('x') as stream:
        json.dump(data, stream, indent=2)
assert sha(script) == '4365a58bc809b6a2049c47f2513c6275bd2481a30b8f888a7f46d0b5c080a7d6'
assert sha(sim / 'tb_behav.wdb') == '78543a4b8b3073f6080c8bd05f2b7819ee4de6bd8b974fd3a87b548d2e80b0de'
env = {k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
verify = [python, '-B', str(cli), 'verify', str(bundle), '--expected', expected, '--live']
check = subprocess.run(verify, cwd='/', env=env, capture_output=True, text=True, timeout=30)
record('before-source.json', {'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})
assert check.returncode == 0
before = inventory(original)
record('original-before.json', before)
work = root / 'run'
work.mkdir()
(work / 'xsim.dir').mkdir()
for directory in ('tb_behav','xil_defaultlib'):
    shutil.copytree(sim/'xsim.dir'/directory, work/'xsim.dir'/directory)
files = ('xsim.ini','forward_exponents.mem','forward_q17.mem','inverse_exponents.mem',
         'inverse_q17.mem','product_q17.mem','samples_ci16.mem','scores_u8.mem','upper_edge_pss_kernel_q17.mem')
for name in files:
    shutil.copy2(sim/name, work/name)
shutil.copy2(script, root/'startup.tcl')
copied = inventory(work)
for name, receipt in copied.items():
    assert receipt == before[str((sim/name).relative_to(original))], name
record('copied-before.json', copied)
command = ['/opt/Xilinx/Vivado/2022.2/bin/xsim','tb_behav','-key','Behavioral:sim_1:Functional:tb',
           '-tclbatch',str(root/'startup.tcl'),'-log',str(root/'startup.log'),'-wdb',str(root/'startup.wdb')]
record('command.json', {'command':command,'cwd':str(work),'wall_limit_seconds':120,
       'scope':'DIAGNOSTIC_COPIED_ORIGINAL_SNAPSHOT_NOT_NUMERICAL_QUALIFICATION'})
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
start=time.monotonic()
timed_out=False
with (root/'stdout.log').open('x') as log:
    process=subprocess.Popen(command,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    record('process.json',{'pid':process.pid})
    print('Started copied-snapshot diagnostic pid='+str(process.pid),flush=True)
    try:
        code=process.wait(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGTERM)
        try: code=process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL)
            code=process.wait(timeout=10)
after=inventory(original)
record('original-after.json',after)
copied_after=inventory(work)
record('copied-after.json',copied_after)
env.pop('LD_LIBRARY_PATH')
check=subprocess.run(verify,cwd='/',env=env,capture_output=True,text=True,timeout=30)
record('after-source.json',{'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})
log=(root/'stdout.log').read_text()
receipt={'exit':code,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-start,
         'original_unchanged':before==after,'source_verify_exit':check.returncode,
         'copied_changed_files':[name for name,data in copied.items() if copied_after.get(name)!=data],
         'original_cycle31_reproduced':'Fatal: composition health cycle=31 state=1 fault=1 cut=01 owner=00 f=01 i=01' in log,
         'numerical_qualification':False}
record('execution.json',receipt)
print(log[-6000:],flush=True)
print(json.dumps(receipt),flush=True)
assert before==after and check.returncode==0 and not timed_out

"""Preserve the exclusive v2 preparation; no vendor execution."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

HERE = Path(__file__).parent
RECOVERY = HERE.parent
FW = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic')
NAME = '20260910-inverse-sealed-actual-preparation-v2'
ARCHIVE = HERE / (NAME + '.tgz')
RECEIPT = HERE / (NAME + '.json')
assert not ARCHIVE.exists() and not RECEIPT.exists()
files, links = {}, {}
for dirname in ('inverse-actual-prepared-v2.g5UoQ9Ag',):
    root = RECOVERY / dirname
    for directory, dirs, names in os.walk(root, followlinks=False):
        directory = Path(directory)
        for name in dirs + names:
            path = directory / name
            if path.is_symlink():
                links[dirname + '/' + path.relative_to(root).as_posix()] = os.readlink(path)
        dirs[:] = sorted(name for name in dirs if not (directory / name).is_symlink())
        for name in sorted(names):
            path = directory / name
            if not path.is_symlink():
                assert path.is_file()
                files[dirname + '/' + path.relative_to(root).as_posix()] = path
for name in ('inverse_sealed_actual_timing.py', 'test_inverse_sealed_transition_policy.py',
             'test_inverse_sealed_actual_policy.py'):
    files['source/' + name] = FW / 'tests/starlink_oracle' / name
files['owner/' + Path(__file__).name] = Path(__file__)
hashes = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
inventory = json.dumps({'files': hashes, 'omitted_symlinks_not_followed': links,
    'source_FW': 'fb186470204f314681a37c7fe2962d024e876e04', 'HDL_unchanged': 'b26f56dd32106c8e91290d075255ac4a6b9ff72d',
    'scope': 'Exclusive64-file v2 preparation, owner, four-anchor inverse and three negative controls; original21014 remains FAIL; no vendor execution.'},
    indent=2, sort_keys=True).encode()
with ARCHIVE.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, path in sorted(files.items()):
                data = path.read_bytes()
                assert hashlib.sha256(data).hexdigest() == hashes[name]
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o444
                tar.addfile(info, io.BytesIO(data))
            info = tarfile.TarInfo('inventory.json'); info.size = len(inventory); info.mode = 0o444
            tar.addfile(info, io.BytesIO(inventory))
assert hashes == {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in files.items()}
verified = {}
with tarfile.open(ARCHIVE, 'r:gz') as tar:
    for item in tar:
        path = PurePosixPath(item.name)
        assert item.isfile() and not path.is_absolute() and '..' not in path.parts and item.name not in verified
        verified[item.name] = hashlib.sha256(tar.extractfile(item).read()).hexdigest()
assert verified.pop('inventory.json') == hashlib.sha256(inventory).hexdigest() and verified == hashes
receipt = {'archive': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size,
    'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(), 'regular_members': len(hashes) + 1,
    'inventory_sha256': hashlib.sha256(inventory).hexdigest(), 'files': hashes,
    'omitted_symlinks_not_followed': links, 'all_member_hashes_verified': True, 'inputs_unchanged': True}
with RECEIPT.open('x') as stream:
    stream.write(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key not in ('files', 'omitted_symlinks_not_followed')}, indent=2))

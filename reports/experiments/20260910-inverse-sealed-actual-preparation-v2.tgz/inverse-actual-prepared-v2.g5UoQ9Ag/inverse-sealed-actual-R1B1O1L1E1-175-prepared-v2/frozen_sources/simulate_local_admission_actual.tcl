# Source-frozen actual vendor FFT launch. Preparation is a separate offline step.
if {$argc != 3} { error "expected PREPARED_OUTPUT ABSOLUTE_PYTHON EXPECTED_MANIFEST_SHA" }
set expected_manifest [lindex $argv 2]
# Reject lexical aliases BEFORE Tcl normalization can hide them from Python.
foreach requested_path [list [lindex $argv 0] [info script]] {
  set lexical_path $requested_path
  if {[file pathtype $lexical_path] eq "relative"} { set lexical_path [file join [pwd] $lexical_path] }
  while {1} {
    if {![catch {file type $lexical_path} lexical_type] && $lexical_type eq "link"} {
      error "symlink actual output/runner path forbidden: $lexical_path"
    }
    set parent_path [file dirname $lexical_path]
    if {$parent_path eq $lexical_path} { break }
    set lexical_path $parent_path
  }
}
set output_dir [file normalize [lindex $argv 0]]
set python [file normalize [lindex $argv 1]]
set source_dir [file dirname [file normalize [info script]]]
if {$source_dir ne [file join $output_dir frozen_sources]} { error "launch only the frozen runner" }
if {![file executable $python]} { error "explicit repository Python required" }
if {[version -short] ne "2022.2"} { error "requires Vivado 2022.2" }
set_param general.maxThreads 2
set project_dir [file join $output_dir project]
if {[file exists $project_dir] || [file exists [file join $output_dir launch_started.txt]]} {
  error "refusing actual launch restart or overwrite"
}
# Uses the frozen standalone helper: no mutable repository/package import.
set python_command [list env -u PYTHONHOME -u PYTHONPATH -u LD_LIBRARY_PATH $python -B \
  [file join $source_dir local_admission_actual.py]]
exec {*}$python_command verify $output_dir --expected $expected_manifest > [file join $output_dir preflight.json]
source [file join $source_dir profile.tcl]
if {$R != 1 || $B != 1 || $O != 1 || $L ni {0 1} || $fast_mhz != 175} { error "undeclared local-admission matrix" }
set source_hashes_before [exec sha256sum {*}[lsort [glob [file join $source_dir *]]] [file join $output_dir manifest.json]]
set run_status [catch {
set channel [open [file join $output_dir launch_started.txt] {WRONLY CREAT EXCL}]
puts $channel "actual_fft=true R=$R B=$B O=$O frequency=$fast_mhz L=$L no_restart=true"; close $channel
set project_name fft_bank_arithmetic_actual
create_project $project_name $project_dir -part xc7z010clg400-1
set_property target_language Verilog [current_project]
set_property simulator_language Mixed [current_project]
source [file join $source_dir create_shared_realtime_xfft_ip.tcl]
set wrapper [file join $project_dir ${project_name}.gen sources_1 ip \
  starlink_pss_fft512_bfp18_rt_candidate synth starlink_pss_fft512_bfp18_rt_candidate.vhd]
pss_create_shared_realtime_xfft_ip $wrapper
set wrapper_hash [lindex [exec sha256sum $wrapper] 0]
set channel [open [file join $output_dir generated_ip_before.txt] w]
puts $channel [exec sha256sum $wrapper]; close $channel
foreach name $compiled_names { add_files -fileset sim_1 -norecurse [file join $source_dir $name] }
foreach name $vector_names { add_files -fileset sim_1 -norecurse [file join $source_dir $name] }
set_property include_dirs [list $source_dir] [get_filesets sim_1]
set_property file_type {Memory Initialization Files} [get_files -of_objects [get_filesets sim_1] *.mem]
set_property top tb_starlink_pss_local_admission_actual [get_filesets sim_1]
set_property generic [list FAST_MHZ=$fast_mhz R=$R B=$B O=$O L=$L] [get_filesets sim_1]
set_property xsim.simulate.runtime all [get_filesets sim_1]
set_property xsim.simulate.custom_tcl [file join $source_dir simulate_local_admission_diagnostics.tcl] [get_filesets sim_1]
launch_simulation -simset sim_1 -mode behavioral
close_sim
if {[lindex [exec sha256sum $wrapper] 0] ne $wrapper_hash} { error "generated FFT wrapper changed during run" }
set channel [open [file join $output_dir generated_ip_after.txt] w]
puts $channel [exec sha256sum $wrapper]; close $channel
set result_json [exec {*}$python_command results $output_dir --expected $expected_manifest]
close_project
} run_result run_options]
# Always independently verify after the run body, including project/IP/launch,
# result parsing and close errors. Do not let either error hide the other.
set after_status [catch {
  set source_hashes_after [exec sha256sum {*}[lsort [glob [file join $source_dir *]]] [file join $output_dir manifest.json]]
  if {$source_hashes_before ne $source_hashes_after} { error "after-run frozen inventory/source/manifest changed" }
  exec {*}$python_command verify $output_dir --expected $expected_manifest > [file join $output_dir postflight.json]
} after_result after_options]
set channel [open [file join $output_dir run_outcome.txt] w]
puts $channel "run_status=$run_status\nrun_result=$run_result\nrun_options=$run_options"
puts $channel "after_status=$after_status\nafter_result=$after_result\nafter_options=$after_options"
close $channel
if {$run_status} { return -options $run_options $run_result }
if {$after_status} { return -options $after_options $after_result }
set channel [open [file join $output_dir results.json] {WRONLY CREAT EXCL}]
puts $channel $result_json; close $channel
puts "LOCAL_ADMISSION_ACTUAL_CORE_VERIFIED_NO_SCORER_RTL_PHYSICAL_OR_RF_CLAIM"

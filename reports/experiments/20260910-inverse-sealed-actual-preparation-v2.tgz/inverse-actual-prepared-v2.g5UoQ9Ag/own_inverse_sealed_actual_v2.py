"""Prepared for ONE separately authorized frozen Vivado call; do not run before review."""
import datetime
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path

BUILD = Path("/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-actual-prepared-v2.g5UoQ9Ag")
PREPARED = BUILD / "inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2"
OWNER = BUILD / "inverse-sealed-L1E1-175-actual-owned-v2"
EXPECTED = "39b1c731eb6f001983d5e842b1861d059c6f1f7a9ad986c26cde2a341ed74853"
RUNNER_SHA = "23e9e9b989e35f013113bd6356288952bf05d58c57d7803c8baa1d74b8239972"
PYTHON = "/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python"
VIVADO = "/opt/Xilinx/Vivado/2022.2/bin/vivado"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inventory():
    paths = [PREPARED / "manifest.json", *sorted((PREPARED / "frozen_sources").iterdir())]
    assert all(p.is_file() and not p.is_symlink() for p in paths)
    return {p.relative_to(PREPARED).as_posix(): sha(p) for p in paths}


assert sha(PREPARED / "manifest.json") == EXPECTED
runner = PREPARED / "frozen_sources/simulate_inverse_sealed_actual.tcl"
assert sha(runner) == RUNNER_SHA
assert not (PREPARED / "project").exists() and not (PREPARED / "launch_started.txt").exists()
OWNER.mkdir(exist_ok=False)
before = inventory()
manifest = json.loads((PREPARED / "manifest.json").read_text())
assert len(manifest["source_sha256"]) == 64
assert {"frozen_sources/" + name: value for name, value in manifest["source_sha256"].items()} == {name: value for name, value in before.items() if name.startswith("frozen_sources/")}
command = [VIVADO, "-mode", "batch", "-source", str(runner), "-log", str(OWNER / "vivado.log"),
           "-journal", str(OWNER / "vivado.jou"), "-tclargs", str(PREPARED), PYTHON, EXPECTED]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OWNER / "before.json").open("x") as stream:
    json.dump({"started_utc": started, "command": command, "source_sha256": before}, stream, indent=2)
environment = dict(os.environ)
environment["LD_LIBRARY_PATH"] = "/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE"
(OWNER / "tmp").mkdir(exist_ok=False)
environment["TMPDIR"] = str(OWNER / "tmp")
begin = time.monotonic()
status = None
error = None
try:
    with (OWNER / "outer.log").open("x") as log:
        status = subprocess.run(command, cwd=OWNER, env=environment, stdout=log,
                                stderr=subprocess.STDOUT, check=False).returncode
except Exception as exc:
    error = repr(exc)
finally:
    after_error = None
    try:
        after = inventory()
    except Exception as exc:
        after = None
        after_error = repr(exc)
    receipt = {"started_utc": started, "ended_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "elapsed_seconds": time.monotonic()-begin, "original_process_exit": status,
               "launch_error": error, "after_integrity_error": after_error,
               "source_unchanged": before == after, "after_source_sha256": after}
    with (OWNER / "terminal.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
    print(json.dumps(receipt, indent=2), flush=True)
raise SystemExit(status if status not in (None, 0) else (1 if error or after_error or before != after else 0))

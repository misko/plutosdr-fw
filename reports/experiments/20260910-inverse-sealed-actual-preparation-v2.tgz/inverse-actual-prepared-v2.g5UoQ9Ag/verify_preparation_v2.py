"""Offline source/owner inverse: NEVER imports or executes the vendor owner."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).parent
OLD = ROOT.parent / 'inverse-actual-prepared-v1.sUupdgsv'
OLD_RUN = OLD / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v1'
NEW_RUN = ROOT / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2'
MANIFEST = '39b1c731eb6f001983d5e842b1861d059c6f1f7a9ad986c26cde2a341ed74853'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(OLD_RUN / 'manifest.json') == '2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a'
assert sha(NEW_RUN / 'manifest.json') == MANIFEST
old = json.loads((OLD_RUN / 'manifest.json').read_text())
new = json.loads((NEW_RUN / 'manifest.json').read_text())
assert len(old['source_sha256']) == len(new['source_sha256']) == 64
assert old.keys() == new.keys()
assert {key: value for key, value in old.items() if key != 'source_sha256'} == {key: value for key, value in new.items() if key != 'source_sha256'}
assert old['source_sha256'].keys() == new['source_sha256'].keys()
changed = [name for name in old['source_sha256'] if old['source_sha256'][name] != new['source_sha256'][name]]
assert changed == ['inverse_sealed_actual_timing.py']
for run, manifest in ((OLD_RUN, old), (NEW_RUN, new)):
    entries = list((run / 'frozen_sources').iterdir())
    assert all(path.is_file() and not path.is_symlink() for path in entries)
    assert {path.name: sha(path) for path in entries} == manifest['source_sha256']
original = (OLD / 'own_inverse_sealed_actual_v1.py').read_text()
assert hashlib.sha256(original.encode()).hexdigest() == 'c77a1a119df74e7e3a93281e59f03a0050bb9e29f03354253618152a6ab1d96f'
candidate_path = ROOT / 'own_inverse_sealed_actual_v2.py'
candidate = candidate_path.read_text()
edits = [
    ('inverse-actual-prepared-v1.sUupdgsv', 'inverse-actual-prepared-v2.g5UoQ9Ag'),
    ('inverse-sealed-actual-R1B1O1L1E1-175-prepared-v1', 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v2'),
    ('inverse-sealed-L1E1-175-actual-owned-v1', 'inverse-sealed-L1E1-175-actual-owned-v2'),
    ('2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a', MANIFEST),
]


def inverse(text):
    for before, after in reversed(edits):
        if text.count(after) != 1:
            raise ValueError('nonunique owner adaptation')
        text = text.replace(after, before, 1)
    if text != original:
        raise ValueError('owner body differs outside four declared literal anchors')


inverse(candidate)
negative_checks = 0
for text in (candidate.replace(edits[0][1], 'wrong'), candidate + '\n' + edits[0][1],
             candidate.replace('check=False', 'check=True')):
    try:
        inverse(text)
    except ValueError:
        negative_checks += 1
assert negative_checks == 3
tree = ast.parse(candidate)
calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
         and isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
         and node.func.value.id == 'subprocess' and node.func.attr == 'run']
assert len(calls) == 1 and not any(isinstance(node, ast.While) for node in ast.walk(tree))
assert not (ROOT / 'inverse-sealed-L1E1-175-actual-owned-v2').exists()
assert not (NEW_RUN / 'project').exists() and not (NEW_RUN / 'launch_started.txt').exists()
spec = importlib.util.spec_from_file_location('frozen_verify', NEW_RUN / 'frozen_sources/inverse_sealed_actual.py')
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
assert helper.verify(NEW_RUN, MANIFEST) == new
print(json.dumps({'source_only_preparation': True, 'vendor_calls_executed': 0,
    'manifest_sha256': MANIFEST, 'changed_frozen_sources': changed, 'total_frozen_sources': 64,
    'runtime_modules_unchanged': len(new['runtime_rtl']), 'compiled_unchanged': len(new['compiled']),
    'owner_sha256': sha(candidate_path), 'owner_literal_edits': 4, 'owner_negative_checks': 3,
    'runner_sha256': new['source_sha256']['simulate_inverse_sealed_actual.tcl'],
    'old_automation_failure_preserved': not (OLD_RUN / 'results.json').exists()}, indent=2))

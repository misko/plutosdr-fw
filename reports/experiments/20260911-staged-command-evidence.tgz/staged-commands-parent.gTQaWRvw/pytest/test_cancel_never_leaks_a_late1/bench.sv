`timescale 1ns/1ps
module tb;
localparam D=70,T=32,E=T+D+12,W=3*D+4*T+31,N=16;
reg clk=0;always #5 clk=~clk;
reg resetn=0,abort_epoch=0,command_valid=0,response_ready=1,lookup_valid=0;
reg [1:0] command_opcode=0;
reg [T-1:0] command_tag=0,lookup_tag=0;
reg [D-1:0] command_descriptor=0;
wire command_ready,response_valid,lookup_found,lookup_committed,tags_exhausted,fault;
wire [1:0] response_opcode,occupied,committed;
wire [T-1:0] response_tag;
wire [D-1:0] lookup_descriptor;
starlink_pss_descriptor_commands #(.TAG_WIDTH(T)) dut(.*);
wire [E-1:0] observed={command_ready,response_valid,response_opcode,response_tag,fault,occupied,committed,tags_exhausted,lookup_found,lookup_committed,lookup_descriptor};
reg [W-1:0] vectors[0:N-1];reg [E-1:0] expected_before,expected_after;integer row;
initial begin
  $readmemh("/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/staged-commands-parent.gTQaWRvw/pytest/test_cancel_never_leaks_a_late1/vectors.mem",vectors);
  for(row=0;row<N;row=row+1) begin
    @(negedge clk);
    {resetn,abort_epoch,command_valid,command_opcode,command_tag,command_descriptor,response_ready,lookup_valid,lookup_tag,expected_before,expected_after}=vectors[row];
    #1;if(observed!==expected_before) $fatal(1,"PRE row=%0d actual=%h expected=%h",row,observed,expected_before);
    @(posedge clk);#0.1;
    if(observed!==expected_after) $fatal(1,"POST row=%0d actual=%h expected=%h",row,observed,expected_after);
  end
  $display("COMMANDS_PASS rows=%0d",N);$finish(0);
end
endmodule

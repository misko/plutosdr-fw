"""Bounded root-owned registered-boundary physical test; no deployment claim."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
source=root.parent/'destination-actual-worktree-v1'
base='hdl/library/starlink_pss_acquisition/staged_control/'
names=[base+n for n in ('starlink_pss_descriptor_commands.v','descriptor_commands_timing_probe.v','route_descriptor_commands.tcl')]
names+=['tests/test_starlink_descriptor_commands.py']
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
assert not (root/'run').exists() and not (root/'pytest').exists()
pins={name:sha(source/name) for name in names}
for name in names:
    path=root/'source_snapshot'/name;path.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source/name,path)
with (root/'before.json').open('x') as handle: json.dump(pins,handle,indent=2)
(root/'tmp').mkdir()
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
env.update(TMPDIR=str(root/'tmp'),PYTHONDONTWRITEBYTECODE='1')
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest','-q','--tb=short','-p','no:cacheprovider',
     'tests/test_starlink_descriptor_commands.py','--basetemp='+str(root/'pytest'),'--junitxml='+str(root/'results.xml')]
with (root/'pytest.log').open('x') as handle:
    tests=subprocess.run(cmd,cwd=source,env=env,stdout=handle,stderr=subprocess.STDOUT,timeout=90)
counts={key:sum(int(n.attrib.get(key,0)) for n in ET.parse(root/'results.xml').iter('testsuite')) for key in ('tests','failures','errors','skipped')}
assert tests.returncode==0 and counts==dict(tests=20,failures=0,errors=0,skipped=0),(root/'pytest.log').read_text()
assert pins=={name:sha(source/name) for name in names}
print('20 tests PASS; starting registered-boundary route.',flush=True)
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
runner=root/'source_snapshot'/base/'route_descriptor_commands.tcl'
cmd=['/opt/Xilinx/Vivado/2022.2/bin/vivado','-mode','batch','-notrace','-log',str(root/'vivado.log'),
     '-journal',str(root/'vivado.jou'),'-source',str(runner),'-tclargs',str(root/'run')]
with (root/'command.json').open('x') as handle:json.dump(cmd,handle,indent=2)
start=time.monotonic();timed_out=False
with (root/'stdout.log').open('x') as handle:
    proc=subprocess.Popen(cmd,cwd=root,env=env,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
    with (root/'process.json').open('x') as receipt:json.dump(dict(pid=proc.pid,process_group=proc.pid),receipt)
    try:code=proc.wait(timeout=300)
    except subprocess.TimeoutExpired:
        timed_out=True;os.killpg(proc.pid,signal.SIGTERM)
        try:code=proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid,signal.SIGKILL);code=proc.wait(timeout=10)
unchanged=pins=={name:sha(source/name) for name in names}=={name:sha(root/'source_snapshot'/name) for name in names}
dcp=root/'run/descriptor_commands_routed.dcp'
result=dict(vendor_exit=code,timed_out=timed_out,wall_seconds=time.monotonic()-start,tests=counts,
            sources_unchanged=unchanged,dcp_sha256=sha(dcp) if dcp.is_file() else None,receiver_qualified=False)
with (root/'execution.json').open('x') as handle:json.dump(result,handle,indent=2)
print('\n'.join((root/'stdout.log').read_text().splitlines()[-12:]))
print(json.dumps(result))
assert code==0 and not timed_out and unchanged and dcp.is_file()

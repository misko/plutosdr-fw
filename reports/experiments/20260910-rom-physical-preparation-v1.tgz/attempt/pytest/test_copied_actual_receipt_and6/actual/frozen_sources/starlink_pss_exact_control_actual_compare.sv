weakened old observer

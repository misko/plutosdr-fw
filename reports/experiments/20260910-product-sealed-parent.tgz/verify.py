"""Read-only parent audit of original87683; no test or vendor relaunch."""
import hashlib
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

HERE = Path(__file__).resolve().parent
FW = Path('/tmp/starlink-rom-prefetch.j829ht/fw')
ACQ = FW / 'hdl/library/starlink_pss_acquisition'
PINS = {
    'starlink_pss_checked_product_read.v': '30c8cb1dee84c2ebc4289cf101e85572d9655621db6075957557bab445251074',
    'starlink_pss_product_sealed_adapter.v': '054cccffabc661a90b2c8a20d63675db4ce64aa271bb09836b207691369f6fbd',
    'starlink_pss_epoch_sealed_bank.v': 'd9c2382f9087ccd2088fa5a5d3fed5c6fe885359d6d4c367ed2ea81ce099d9f6',
    'tb_starlink_pss_checked_product_read.sv': 'c863a6d31a0009aab10529ba5a6c45d10913dcf3d07d9553f4932533b8bda168',
    'tb_starlink_pss_product_sealed_adapter.sv': 'c8bb28908c7541059dd2a8de5fc0f7bb07e185cfff5c6f4b9c77976e53608ec2',
    'test_checked_product_read.py': '4dd63651f4e0ebcb633623c92507f5fdc925870f1253b437f140d52a3a6fead7',
    'test_product_sealed_adapter.py': '667d81221f41957efb9f7beadcd3686ba9b2c8d1b6dd07b15ed619bc2198b938',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


for name, pin in PINS.items():
    base = FW / 'tests/starlink_oracle' if name.endswith('.py') else (ACQ / 'tb' if name.endswith('.sv') else ACQ)
    assert sha(base / name) == pin, name

xml = HERE / 'results.xml'
assert sha(xml) == '92e97b822e12f194b7e4410f83b90f8d2d34527e17d2324d3b44e2d0e222e955'
suite = ET.parse(xml).getroot().find('testsuite')
assert {key: suite.attrib[key] for key in ('tests', 'failures', 'errors', 'skipped')} == {
    'tests': '848', 'failures': '0', 'errors': '0', 'skipped': '0'}
assert len(suite.findall('testcase')) == 848
fixtures = [HERE / 'cases/read_queue0/original', HERE / 'cases/product_adapter0/original']
closure = {}
for fixture in fixtures:
    sources = json.loads((fixture / 'sources.json').read_text())
    for name, pin in sources.items():
        assert sha(fixture / name) == pin
        if name in PINS:
            assert pin == PINS[name]
        closure[str((fixture / name).relative_to(HERE))] = pin
    assert json.loads((fixture / 'compile.json').read_text())['exit'] == 0
    assert json.loads((fixture / 'case-0-bit-0-target-37.json').read_text())['exit'] == 0
reader = (fixtures[0] / 'case-0-bit-0-target-37.log').read_text()
assert reader.count('sent=512 received=512 span=511 holes=0') == 8
adapter = (fixtures[1] / 'case-0-bit-0-target-37.log').read_text()
jobs = re.findall(r'PRODUCT_ADAPTER_JOB job=(\d+) take=(\d+) seal_delta=(\d+) publish_delta=(\d+) completion_to_publish=(\d+) head_delta=(\d+) release_after_core=(\d+) core_span=(\d+) holes=(\d+)', adapter)
assert len(jobs) == 8
for number, row in enumerate(jobs):
    assert list(map(int, row[:6])) == [number, 512, 2, 3, 6, 10]
    assert list(map(int, row[7:])) == [511, 0]
latencies = re.findall(r'PRODUCT_ADAPTER_LATENCY job=(\d+) admission_to_release=(\d+) handoff_to_first_core=(\d+) last_core_to_release=(\d+)', adapter)
assert [list(map(int, row)) for row in latencies] == [[i, 1555, 2, 1] for i in range(8)]
graph = json.loads((fixtures[1] / 'combinational-graph.json').read_text())
assert graph['cycles'] == 0 and graph['continuous_nodes'] == 3123
assert graph['netlist_sha256'] == sha(fixtures[1] / 'sim.vvp')
receipt = {
    'scope': 'original87683 offline Icarus prototype, not vendor FFT or routed timing',
    'original_process_exit': 0, 'tests': 848, 'seconds': float(suite.attrib['time']),
    'source_pins': PINS, 'compiled_closure': closure,
    'results_xml_sha256': sha(xml), 'healthy_leases': 8,
    'continuous_core_words_per_lease': 512, 'continuous_graph': graph,
    'logical_state_bits_reported_not_mapped': 760,
    'top_integration': False, 'physical_timing': False, 'radio_access': False,
}
with (HERE / 'verification.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
print(json.dumps(receipt, indent=2))

module extra;
starlink_pss_checked_product_read #(.CHECKED_PRODUCT_READ(32'bx)) dut();
endmodule

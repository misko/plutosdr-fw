# Generate only an isolated candidate clock IP; no receiver or radio changes.
if {$argc != 1 || [version -short] ne "2022.2"} {
  error "expected Vivado2022.2 and NEW_OUTPUT"
}
set out [file normalize [lindex $argv 0]]
if {[file exists $out]} { error "refusing to overwrite clock evidence" }
file mkdir $out
file copy [info script] [file join $out clock-probe.tcl]
set_param general.maxThreads 2
create_project bank_clock_probe [file join $out project] -part xc7z010clg400-1
set_property target_language Verilog [current_project]
create_ip -name clk_wiz -vendor xilinx.com -library ip -version 6.0 \
  -module_name starlink_bank_clock175_candidate
set ip [get_ips starlink_bank_clock175_candidate]
set_property -dict [list CONFIG.PRIM_IN_FREQ {100.000} \
  CONFIG.CLKOUT1_REQUESTED_OUT_FREQ {175.000} \
  CONFIG.PRIM_SOURCE {No_buffer} CONFIG.PRIMITIVE {MMCM} \
  CONFIG.USE_LOCKED {true} CONFIG.USE_RESET {true} \
  CONFIG.RESET_TYPE {ACTIVE_LOW} CONFIG.CLKOUT1_DRIVES {BUFG}] $ip
generate_target all $ip
report_property $ip -file [file join $out ip_properties.rpt]
set receipt [open [file join $out scope.txt] w]
puts $receipt "scope=isolated_generated_clock_IP_not_receiver_clock_qualification"
puts $receipt "requested_input_MHz=100; requested_output_MHz=175"
puts $receipt "receiver_200MHz_AD9361_delay_reference_unchanged=true"
puts $receipt "no_receiver_build_no_place_no_route_no_radio=true"
close $receipt
close_project
puts "BANK_CLOCK_IP_GENERATED_NOT_DEPLOYED_OR_PHYSICALLY_QUALIFIED"

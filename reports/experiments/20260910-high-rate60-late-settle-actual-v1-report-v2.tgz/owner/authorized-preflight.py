"""Record the separately authorized one-shot launch before starting Vivado."""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

BASE=Path(__file__).resolve().parent
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
proposal=json.loads((BASE/"successor-proposal.json").read_bytes())
for name in proposal["absent_targets"]:
    p=Path(name)
    assert not p.exists() and not p.is_symlink(),name
owner=Path(proposal["working_owner"])
owner.mkdir()
(owner/"tmp").mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
bundle=BASE/"frozen-bundle"
r=json.loads((bundle/"bundle.json").read_bytes())
assert sha((bundle/"bundle.json").read_bytes())==proposal["bundle_sha256"]
assert sha((bundle/"case/simulate_high_rate60_bank_native_late.tcl").read_bytes())==proposal["runner_sha256"]
assert all(sha((bundle/n).read_bytes())==v for n,v in r["files"].items())
before={n:sha((WORK/n).read_bytes()) for n in r["source_sha256"]}
assert before==r["source_sha256"] and len(before)==119
(owner/"approved-proposal.json").write_bytes((BASE/"successor-proposal.json").read_bytes())
receipt=proposal | {"classification":"AUTHORIZED_ONE_SHOT_PRELAUNCH_NOT_YET_EXECUTED",
    "launch_fw":"9b67d3db938cbbb5aec42041a10a906464282d3f",
    "launch_hdl":"ecbb3712965ff39b144b5adf84a2a262c6c53dff",
    "prelaunch_utc":datetime.now(timezone.utc).isoformat(),"source_before":before,
    "authorizer":"root separately authorized exactly one corrected late60 vendor run",
    "owner":"/root/coarse_narrow_acquisition","requires_new_authorization":False,
    "status":"all four targets absent; exclusive owner/tmp created; all376 bundle payloads/119live sources exact; argv recorded"}
(owner/"owner.json").write_text(json.dumps(receipt,sort_keys=True,indent=2)+"\n")
print(json.dumps({k:receipt[k] for k in ["classification","prelaunch_utc","launch_fw","launch_hdl","bundle_sha256","source_signature","status"]},sort_keys=True))

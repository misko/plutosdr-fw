"""Read-only post-run source/artifact audit, including failed execution paths."""

import hashlib
import json
from pathlib import Path

OWNER=Path(__file__).resolve().parent
BASE=OWNER.parent
RUN=BASE/"main-high-rate60-bank175-late447-settle-v1"
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
EXTERNAL=BASE/"frozen-bundle"
ORIGINAL=WORK/"build/high-rate60-late-settle-prelaunch-v1"
SIM=RUN/"project/high_rate60_bank_native_late.sim/sim_1/behav/xsim"
EXPECTED="79febd5abe231065f9fc77abd7c587104e4608ffd8eae40ebd5b4f20a6ac1043"


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        while chunk:=f.read(1024*1024): h.update(chunk)
    return h.hexdigest()


def main():
    out=OWNER/"post-audit.json"
    assert not out.exists()
    r=json.loads((EXTERNAL/"bundle.json").read_bytes())
    checks={}
    for label,base in [("original",ORIGINAL),("relocated",EXTERNAL),("copied",RUN/"inputs")]:
        checks[label+"_bundle_sha"]=(base/"bundle.json").is_file() and sha(base/"bundle.json")==EXPECTED
        checks[label+"_files"]=all((base/n).is_file() and sha(base/n)==v for n,v in r["files"].items())
    live={name:sha(WORK/name) for name in r["source_sha256"]}
    before=json.loads((OWNER/"owner.json").read_bytes())["source_before"]
    checks["before_after_live_sources"]=live==before==r["source_sha256"] and len(live)==119
    memories={}
    if SIM.is_dir():
        paths=list((EXTERNAL/"healthy/vectors").glob("*.mem"))+[EXTERNAL/"case/native60_late_registers.mem"]
        paths += [EXTERNAL/"source_snapshot/hdl/library/starlink_pss_acquisition"/n
                  for n in ["pilot_mixer_q16.mem","pilot_halfband2_q17.mem","pilot_fir3_q17.mem",
                            "tb/upper_edge_pss60_x4_ddc_kernel_q17.mem"]]
        for p in paths:
            memories[p.name]={"expected":sha(p),"actual":sha(SIM/p.name) if (SIM/p.name).is_file() else None}
        checks["simulator_memories"]=all(v["expected"]==v["actual"] for v in memories.values())
    generated={"present":False}
    if (RUN/"generated_ip.txt").is_file():
        before_ip,path=(RUN/"generated_ip.txt").read_text().strip().split(maxsplit=1)
        after=sha(Path(path)) if Path(path).is_file() else None
        generated={"present":True,"path":path,"before_sha256":before_ip,"after_sha256":after}
        checks["generated_ip"]=before_ip==after
    else: generated["classification"]="runner did not reach generated-IP receipt"
    all_paths=list(RUN.rglob("*"))
    assert not any(p.is_symlink() for p in all_paths)
    files=sorted(p for p in all_paths if p.is_file())
    assert len(files)<=900 and sum(p.stat().st_size for p in files)<150_000_000
    assert all(p.stat().st_size<64_000_000 for p in files)
    artifacts={p.relative_to(RUN).as_posix():{"sha256":sha(p),"bytes":p.stat().st_size} for p in files}
    external_logs={p.name:{"sha256":sha(p),"bytes":p.stat().st_size}
                   for p in [RUN.with_suffix(".vivado.log"),RUN.with_suffix(".vivado.jou")] if p.is_file()}
    terminal=json.loads((RUN/"terminal_receipt.json").read_bytes()) if (RUN/"terminal_receipt.json").is_file() else None
    result={"result":"POST_RUN_INTEGRITY_AUDIT_PASS" if all(checks.values()) else "POST_RUN_INTEGRITY_AUDIT_FAILED",
        "checks":checks,"original_handle":2011,"bundle_before_and_after_sha256":EXPECTED,
        "source_signature":r["source_signature"],"live_source_sha256":live,"payload_files_per_bundle":len(r["files"]),
        "simulator_memories":memories,"generated_ip":generated,"full_run_files":len(artifacts),
        "full_run_bytes":sum(v["bytes"] for v in artifacts.values()),"full_run_artifacts":artifacts,
        "external_logs":external_logs,"terminal":terminal,"audit_script_sha256":sha(Path(__file__)),"retries":0,
        "terminal_status":(RUN/"run_status.txt").read_text() if (RUN/"run_status.txt").is_file() else None}
    out.write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps({k:result[k] for k in ["result","checks","full_run_files","full_run_bytes","generated_ip"]},sort_keys=True))
    assert all(checks.values())


if __name__=="__main__": main()

"""Compact actual result package; original generated run retained untouched."""

import hashlib
import io
import json
import tarfile
from pathlib import Path

OWNER=Path(__file__).resolve().parent
BASE=OWNER.parent
RUN=BASE/"main-high-rate60-bank175-late447-settle-v1"
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
SIM=RUN/"project/high_rate60_bank_native_late.sim/sim_1/behav/xsim"
ARCHIVE=BASE/"20260910-high-rate60-late-settle-actual-v1-report-v2.tgz"


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    assert not ARCHIVE.exists()
    audit=json.loads((OWNER/"post-audit.json").read_bytes())
    assert audit["result"]=="POST_RUN_INTEGRITY_AUDIT_PASS" and all(audit["checks"].values())
    assert audit["terminal_status"]=="run_tcl_exit=0 integrity_exit=0\n\n"
    before={n:sha((WORK/n).read_bytes()) for n in audit["live_source_sha256"]}
    assert before==audit["live_source_sha256"]
    terminal=json.loads((RUN/"terminal_receipt.json").read_bytes())
    assert terminal==json.loads((OWNER/"independent-result.json").read_bytes())
    assert terminal["result"]=="HIGH_RATE60_LATE_SIMULATION_VERIFIED"
    payload={}
    def add(name,path):
        assert name not in payload and path.is_file() and not path.is_symlink() and path.stat().st_size<10_000_000
        payload[name]=path.read_bytes()
    for p in sorted((RUN/"inputs").rglob("*")):
        assert not p.is_symlink()
        if p.is_file(): add("frozen_inputs/"+p.relative_to(RUN/"inputs").as_posix(),p)
    for name in ["owner.json","approved-proposal.json","audit.py","post-audit.json","independent-result.json","package-report-v2.py"]:
        add("owner/"+name,OWNER/name)
    add("owner/authorized-preflight.py",BASE/"authorized-preflight.py")
    for name in ["before_integrity.txt","after_integrity.txt","generated_ip.txt","run_status.txt","terminal_receipt.json"]:
        add("run/"+name,RUN/name)
    for name in ["simulate.log","native60_actual_source.txt","native60_actual_capture.txt","native60_actual_raw_tuples.txt",
                 "native60_actual_holds.txt","paired60_actual_prime.txt","paired_pilot_actual.ci16"]:
        add("simulation/"+name,SIM/name)
    for p in sorted(SIM.glob("*.log")):
        if p.name!="simulate.log": add("simulation/"+p.name,p)
    before_ip,wrapper=(RUN/"generated_ip.txt").read_text().strip().split(maxsplit=1)
    add("generated_ip/"+Path(wrapper).name,Path(wrapper))
    assert sha(payload["generated_ip/"+Path(wrapper).name])==before_ip
    xci=RUN/"project/high_rate60_bank_native_late.srcs/sources_1/ip/starlink_pss_fft512_bfp18_rt_candidate/starlink_pss_fft512_bfp18_rt_candidate.xci"
    add("generated_ip/"+xci.name,xci)
    for suffix in [".vivado.log",".vivado.jou"]: add("external/"+RUN.with_suffix(suffix).name,RUN.with_suffix(suffix))
    add("report.md",WORK/"docs/starlink-high-rate60-late-settle-actual-result-20260910.md")
    assert before=={n:sha((WORK/n).read_bytes()) for n in before}
    assert len(payload)<430 and sum(map(len,payload.values()))<15_000_000
    files={n:{"sha256":sha(data),"bytes":len(data)} for n,data in sorted(payload.items())}
    receipt={"classification":"ONE_AUTHORIZED_CORRECTED_EXPECTED_LATE_ACTUAL_PASS",
        "files":files,"original_handle":2011,"original_exit":0,"source_signature":audit["source_signature"],
        "prior_actual88460":"overallFAIL preserved, not reclassified",
        "full_run_inventory":"owner/post-audit.json","full_run_files":672,"full_run_bytes":55835869,
        "raw_run":str(RUN),"omissions":"large generated project/waves retained in raw run, not duplicated",
        "source_before_after_exact":True,"new_actual_launches_in_packaging":0}
    payload["receipt.json"]=(json.dumps(receipt,sort_keys=True,indent=2)+"\n").encode()
    with tarfile.open(ARCHIVE,"w:gz") as tar:
        for name,data in sorted(payload.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    with tarfile.open(ARCHIVE,"r:gz") as tar:
        members=tar.getmembers()
        assert len(members)==len(payload) and len({m.name for m in members})==len(members)
        for m in members:
            assert m.isfile() and not m.name.startswith("/") and ".." not in Path(m.name).parts
            assert tar.extractfile(m).read()==payload[m.name]
    result={"archive":str(ARCHIVE),"sha256":sha(ARCHIVE.read_bytes()),"bytes":ARCHIVE.stat().st_size,
        "safe_regular_members":len(payload),"hash_length_receipts":len(files),"original_handle":2011,
        "original_exit":0,"classification":"expected-late actual PASS, no causal/physical promotion",
        "source_signature":audit["source_signature"],"bundle_sha256":audit["bundle_before_and_after_sha256"]}
    (OWNER/"package-report-v2-receipt.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__": main()

"""Paired60-specific result gate. Original native limits and69 goldens unchanged.

Native evidence validation is a narrowly scoped adaptation of the previously
reviewed native60 verifier: paired outer identity replaces standalone terminal,
while all tuple/source/clock/readback/hold/deadline conditions remain exact.
"""

import json
import re
from collections import Counter

from .high_rate60_harness import PROFILE, check_recipe, rows
from .native60_budget import _receipt, check_cohort, require, verify_snapshot
from .native60_budget_recipe import recipe


from .high_rate60_late_result import verify_native_component


from .high_rate60_late import TERMINAL, PROFILE

EXPECTED_MARKERS = {
    "HIGH_RATE60_PASS": 1, "HIGH_RATE60_PREROLL_PASS": 1,
    "HIGH_RATE60_PREFIX": 1, "HIGH_RATE60_CONTINUOUS": 1,
    "HIGH_RATE60_FFT_CLOCK": 1, "HIGH_RATE60_OVERLAP": 1,
    "HIGH_RATE60_RETENTION_PASS": 1, "HIGH_RATE60_STOP": 1,
    "HIGH_RATE60_PIL1_SNAPSHOT": 1, "HIGH_RATE60_PILOT_WORD": 512,
}


def verify_results(directory, cohort):
    r = check_recipe()
    log_path = directory / "simulate.log"
    require(log_path.is_file() and log_path.stat().st_size < 10_000_000, "missing/oversized paired60 log")
    log = log_path.read_text()
    require(not re.search(r"(?i)\b(?:fail(?:ed|ure)?|fatal|error|warning)\b|parser_only", log), "paired60 failure/nonservice log")
    require(log.splitlines().count(TERMINAL) == 1 and
            sum(line.startswith("HIGH_RATE60_PASS") for line in log.splitlines()) == 1, "paired60 terminal identity/count")
    native = verify_native_component(directory, cohort, log)
    preroll = _receipt(log, "HIGH_RATE60_PREROLL_PASS", ["disabled_prime", "original_raw", "intermediate30", "canonical", "public_psma", "caps", "native_taps"],
                       {"public_psma", "caps"})
    require(preroll == {"disabled_prime": 2, "original_raw": 3111, "intermediate30": 1549,
                       "canonical": 768, "public_psma": 0x10008, "caps": 0x7ff, "native_taps": 264}, "public60 admission/preroll")
    fields = ["source", "original", "prime", "continuous", "ingress", "enabled_raw", "intermediate30", "intermediate30_accepted",
              "canonical", "pilot_accepted", "pilot_mixed", "pilot_half", "pilot_all", "forward_input", "forward", "product",
              "inverse_input", "inverse", "prepare", "ratio", "visible_scores", "admitted_scores"]
    p = _receipt(log, "HIGH_RATE60_PREFIX", fields)
    require(p["source"] == p["ingress"] == 16425 and p["original"] == 16423 and p["prime"] == 2 and p["continuous"] == 13312 and
            p["admitted_scores"] == 894 and 894 <= p["visible_scores"] <= 1341 and 14475 <= p["enabled_raw"] < 16423 and
            3609 <= p["canonical"] < 4096 and 3609 <= p["pilot_mixed"] <= p["pilot_accepted"] <= p["canonical"] and
            1805 <= p["pilot_half"] <= 2048 and 602 <= p["pilot_all"] <= 683,
            "source/cascade/pilot/map support-only bounds")
    require(7231 <= p["intermediate30_accepted"] <= p["intermediate30"] <= (p["enabled_raw"]-13)//2 and
            p["canonical"] <= (p["intermediate30_accepted"]-13)//2,
            "two-stage accepted/emitted support arithmetic")
    for name in ["forward_input", "forward", "product", "inverse_input", "inverse"]:
        require(1024 <= p[name] <= 3584, "FFT stage prefix outside two-block/full-golden support")
    require(p["forward_input"] >= p["forward"] >= p["product"] >= p["inverse_input"] >= p["inverse"] and
            3129 >= p["prepare"] >= p["ratio"] >= p["visible_scores"], "impossible FFT/score prefix ordering")
    cont = _receipt(log, "HIGH_RATE60_CONTINUOUS", ["count", "first", "stop", "first_rise_fs", "last_rise_fs", "off_fs", "startup_pause_outside_segment"])
    require(cont["count"] == 13312 and cont["first"] == 34359738322 and cont["stop"] == 34359751634 and
            cont["startup_pause_outside_segment"] == 1 and
            abs(cont["last_rise_fs"]-cont["first_rise_fs"]-13311*16666666) <= 1 and
            abs(cont["off_fs"]-cont["last_rise_fs"]-8333333) <= 1,
            "continuous13312 original source edge/index interval")
    phase = (cont["first_rise_fs"]-10433333) % 16666666
    require(cont["first_rise_fs"] >= 10433333 and min(phase,16666666-phase) <= 1, "continuous segment is not source-clock aligned")
    b, clock = native["budget"], native["clock"]
    # Common-source coordinates must agree with actual control-cycle witnesses,
    # not merely independently satisfy the old native bounds.
    adm = native["rejection"]
    rise_at = lambda index: cont["first_rise_fs"]+(index-cont["first"])*16666666
    for cycle, time_fs in [(adm["handshake_cycle"], rise_at(adm["index"])),
                           (adm["trigger_cycle"], rise_at(34359740288)-8333333)]:
        require(cycle*10000000-5000000 <= time_fs < cycle*10000000+5000000,
                "late command cycle not on continuous original source coordinate")
    off_time = 18766666 + (clock["source_edges"]-clock["after_off_edges"]-1)*16666666
    require(abs(off_time-cont["off_fs"]) <= 1, "native and continuous source-off coordinates disagree")
    prime = (directory / "paired60_actual_prime.txt").read_text().splitlines()
    require(prime == [f"{34359735209+n:016x} {n+1:08x}" for n in range(2)], "separate disabled prime evidence")
    fft = _receipt(log, "HIGH_RATE60_FFT_CLOCK", ["first_edge_fs", "first_fall_fs", "half_fs", "period_fs", "edges", "ideal_clock", "mmcm_claim"])
    for field, expected in {"first_edge_fs": 4157143, "first_fall_fs": 7014286, "half_fs": 2857143, "period_fs": 5714286}.items():
        require(abs(fft[field]-expected) <= 1, "actual175 ideal oscillator origin/cadence")
    require(fft["ideal_clock"] == 1 and fft["mmcm_claim"] == 0 and
            fft["edges"] == (b["quiet_end"]*10000000-4157143)//5714286+1, "FFT edge inventory/scope")
    overlap = _receipt(log, "HIGH_RATE60_OVERLAP", ["capture_actual_fft", "compute_coarse_pilot", "compute_after_stop", "bank_quiet_fast_cycles", "source_at_stop", "source_at_native_observation", "source_at_map_release", "fft_after_reject", "pilot_after_reject"])
    require(overlap["capture_actual_fft"] == overlap["compute_coarse_pilot"] == overlap["compute_after_stop"] == 0 and
            1 <= overlap["fft_after_reject"] <= p["forward_input"] and 1 <= overlap["pilot_after_reject"] <= p["pilot_accepted"] and
            overlap["bank_quiet_fast_cycles"] >= 32 and 3113 < overlap["source_at_stop"] < 16425 and
            overlap["source_at_native_observation"] == overlap["source_at_map_release"] == 16425,
            "actual own-domain overlap/source-off/retention witnesses missing")
    retention = _receipt(log, "HIGH_RATE60_RETENTION_PASS", ["map_retained_through_late_observation", "native_result_created", "map_words", "source"])
    require(retention == {"map_retained_through_late_observation": 1, "native_result_created": 0, "map_words": 447, "source": 16425}, "independent map/native result lifetime")
    stop = _receipt(log, "HIGH_RATE60_STOP", ["selected", "visible", "source", "canonical", "pilot", "native_capture", "native_busy"])
    require(stop["selected"] == 894 and 894 <= stop["visible"] <= p["visible_scores"] and stop["source"] == overlap["source_at_stop"] and
            stop["canonical"]+512 < p["canonical"] and 1 <= stop["pilot"] < 512 and
            stop["native_capture"] == stop["native_busy"] == 0, "STOP prefix/independent pilot/native lifetime")
    words = rows((cohort / "pilot_expected_ci16.mem").read_bytes(),512,8)
    indexes = rows((cohort / "pilot_expected_index_u64.mem").read_bytes(),512,16)
    observed = re.findall(r"^HIGH_RATE60_PILOT_WORD ordinal=(\d+) newest=([0-9a-f]{16}) word=([0-9a-f]{8})$",log,re.MULTILINE)
    require(observed == [(str(n),f"{indexes[n]:016x}",f"{words[n]:08x}") for n in range(512)], "all512 pilot values/indexes")
    require((directory / "paired_pilot_actual.ci16").read_bytes() == (cohort / "pilot_expected.ci16").read_bytes(), "independent2048 pilot bytes")
    snapshots = re.findall(r"^HIGH_RATE60_PIL1_SNAPSHOT generation=1 raw_words=((?: [0-9a-f]{8}){26})$",log,re.MULTILINE)
    require(len(snapshots) == 1, "PIL1 snapshot uniqueness/generation")
    snap = [int(word,16) for word in snapshots[0].split()]
    pairs = [snap[2*n] | snap[2*n+1]<<32 for n in range(8)]
    require(pairs == [indexes[0],indexes[-1],512,512,90,0,p["pilot_accepted"],p["pilot_all"]] and
            snap[16] == snap[18] == 0 and snap[17]&255 == 0 and snap[19] == 24 and snap[20] == r["pilot_visit"] and not any(snap[22:]),
            "PIL1 coherent counts/support/visit/health")
    require(Counter(re.findall(r"^(HIGH_RATE60_\S+)", log, re.MULTILINE)) == EXPECTED_MARKERS,
            "missing/unrecognized/duplicate paired60 evidence marker inventory")
    return {"result": "HIGH_RATE60_LATE_SIMULATION_VERIFIED", "profile": PROFILE, "prefix": p, "overlap": overlap,
            "native": native, "continuous": cont, "fft_clock": fft,
            "scope": "expected expired native command; healthy coarse/PIL1 only; no causal/RF/physical claim"}

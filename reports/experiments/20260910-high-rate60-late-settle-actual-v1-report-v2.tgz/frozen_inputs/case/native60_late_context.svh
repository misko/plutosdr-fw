// Read-only internal witnesses, public coefficient/command/result transactions.
`define N60_CORE native.i_core
`define N60_RAW native.i_core.i_raw_tracking_core
`define N60_SCHED native.i_core.i_raw_tracking_core.i_candidate_scheduler
  localparam [63:0] NATIVE_CENTER = 64'd34359740384;
  localparam [63:0] NATIVE_CAPTURE_FIRST = 64'd34359740256;
  localparam [31:0] NATIVE_REQUEST = 32'h60000520, NATIVE_GENERATION = 32'h60000001;
  wire native_irq, native_injected;
  reg [31:0] native_coefficients [0:263], native_packet [0:25], native_capture [0:519];
  reg [31:0] native_raw_lag [0:256]; // Frozen signed32 memory, actual signed9 wire.
  reg [63:0] native_raw_index [0:256];
  reg [47:0] native_raw_real [0:256], native_raw_imag [0:256];
  reg [47:0] native_raw_ex [0:256], native_raw_eh [0:256];
  reg [95:0] native_raw_power [0:256];
  reg [11:0] native_raw_saturation [0:256]; // Validate high3 before wire9 comparison.
  reg native_raw_qualified [0:256];
  integer native_admissions = 0, native_capture_count = 0, native_raw_count = 0;
  integer native_qualified_count = 0, native_packet_reads = 0, native_readout_transactions = 0;
  integer native_capture_end_cycle = -1, native_publish_cycle = -1, native_release_cycle = -1;
  integer native_drain_cycle = -1, native_trigger_cycle = -1, native_raw_at_publish = -1;
  integer native_raw_after_publish = 0, native_raw_fd, native_capture_fd;
  integer native_hold_cycles = 0, native_maximum_hold = 0, native_hold_fd;
  reg native_configured = 0, native_command_issued = 0, native_released = 0;
  reg [95:0] native_square_re, native_square_im;
  reg [466:0] native_held_payload;
  wire [466:0] native_raw_payload = {`N60_CORE.raw_result_request_id,
      `N60_CORE.raw_result_center_index, `N60_CORE.raw_result_center_timestamp,
      `N60_CORE.raw_result_coefficient_generation, `N60_CORE.raw_result_lag,
      `N60_CORE.raw_result_timestamp, `N60_CORE.raw_result_c_re, `N60_CORE.raw_result_c_im,
      `N60_CORE.raw_result_ex, `N60_CORE.raw_result_eh,
      `N60_CORE.raw_result_saturation_events, `N60_CORE.raw_result_in_track_aperture};
  wire native_engine_idle = (`N60_RAW.correlator_busy === 1'b0) &&
      (`N60_CORE.g_dsp_exact_reducer.i_exact_reducer.state === 4'd0) &&
      (`N60_CORE.reduced_result_valid === 1'b0) &&
      (`N60_RAW.i_capture_bridge.engine_state === 3'd0) &&
      (`N60_RAW.i_capture_bridge.descriptor_read_valid === 1'b0) &&
      (`N60_RAW.bridge_engine_sample_valid === 1'b0) &&
      (`N60_RAW.bridge_engine_job_start === 1'b0) &&
      (`N60_RAW.bridge_engine_job_done === 1'b0) &&
      (`N60_CORE.raw_result_valid === 1'b0) && (native.capture_active === 1'b0) &&
      (`N60_SCHED.o_capture_valid === 1'b0);
  axi_starlink_pss_tracker #(.RATE_MSPS(60), .ENABLE_INJECTION(0), .USE_DSP_REDUCER(1)) native (
    .sample_clk(sample_clk), .sample_reset(!resetn), .sample_i(sample_data[15:0]),
    .sample_q(sample_data[31:16]), .sample_strobe(sample_strobe), .sample_enable(source_enable),
    .sample_index(sample_index), .sample_timestamp(sample_index),
    .selected_sample_i(), .selected_sample_q(), .selected_sample_strobe(),
    .selected_sample_enable(), .selected_sample_index(), .selected_sample_timestamp(),
    .selected_sample_injected(native_injected), .irq(native_irq),
    .s_axi_aclk(clk), .s_axi_aresetn(resetn),
    .s_axi_awaddr(awaddr[2]), .s_axi_awvalid(awvalid[2]), .s_axi_awready(awready[2]),
    .s_axi_wdata(wdata[2]), .s_axi_wstrb(4'hf), .s_axi_wvalid(wvalid[2]), .s_axi_wready(wready[2]),
    .s_axi_bvalid(bvalid[2]), .s_axi_bresp(bresp[2]), .s_axi_bready(bready[2]),
    .s_axi_araddr(araddr[2]), .s_axi_arvalid(arvalid[2]), .s_axi_arready(arready[2]),
    .s_axi_rvalid(rvalid[2]), .s_axi_rdata(rdata[2]), .s_axi_rresp(rresp[2]), .s_axi_rready(rready[2]),
    .s_axi_awprot(3'd0), .s_axi_arprot(3'd0)
  );
  `include "bank_native60_late_logic.svh"
  task automatic configure_native;
    integer tap, timeout;
    reg [31:0] readback;
    $readmemh("native_coefficients_q15.mem", native_coefficients);
    $readmemh("native_expected_packet.mem", native_packet);
    $readmemh("native_capture_ci16.mem", native_capture);
    $readmemh("native_raw_lags_s32.mem", native_raw_lag);
    $readmemh("native_raw_start_u64.mem", native_raw_index);
    $readmemh("native_raw_real_s48.mem", native_raw_real); $readmemh("native_raw_imag_s48.mem", native_raw_imag);
    $readmemh("native_raw_ex_u48.mem", native_raw_ex); $readmemh("native_raw_eh_u48.mem", native_raw_eh);
    $readmemh("native_raw_power_u96.mem", native_raw_power);
    $readmemh("native_raw_saturation_u12.mem", native_raw_saturation);
    $readmemh("native_raw_qualified_u1.mem", native_raw_qualified);
    for (integer n = 0; n < 257; n = n + 1) begin
      if (native_raw_lag[n] !== n-128 ||
          native_raw_lag[n] !== {{23{native_raw_lag[n][8]}}, native_raw_lag[n][8:0]} ||
          native_raw_saturation[n][11:9] !== 3'b0)
        fail("frozen signed32-to-wire9 lag or saturation padding invalid");
    end
    native_raw_fd = $fopen("native60_actual_raw_tuples.txt", "w");
    native_capture_fd = $fopen("native60_actual_capture.txt", "w");
    native_hold_fd = $fopen("native60_actual_holds.txt", "w");
    if (!native_raw_fd || !native_capture_fd || !native_hold_fd) fail("native60 tuple/capture/hold log unavailable");
    expect_reg(2, 8'h00, 32'h50535354); expect_reg(2, 8'h04, 32'h00010003);
    expect_reg(2, 8'h08, 60); expect_reg(2, 8'h0c, 32'h0f8c1108); expect_reg(2, 8'h10, 32'h1d);
    write_reg(2, 8'h44, 1);
    for (tap = 0; tap < 264; tap = tap + 1)
      write_reg(2, 8'h40, {native_coefficients[tap][15:0], native_coefficients[tap][31:16]});
    write_reg(2, 8'h48, NATIVE_GENERATION); write_reg(2, 8'h44, 2);
    timeout = 0; readback = 0;
    while (readback !== NATIVE_GENERATION && timeout < 2000) begin
      read_reg(2, 8'h4c, readback); timeout = timeout + 1;
    end
    if (readback !== NATIVE_GENERATION) fail("native60 coefficient commit timeout");
    expect_reg(2, 8'h60, 1073758594); expect_reg(2, 8'h64, 0);
    native_configured = 1; native_healthy();
    $display("NATIVE60_CONFIG cycle=%0d id=50535354 abi=00010003 rate=60 geometry=0f8c1108 caps=0000001d generation=60000001 eh=1073758594", cycles);
  endtask
`undef N60_CORE
`undef N60_RAW
`undef N60_SCHED

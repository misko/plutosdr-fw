module parameter_probe;
      starlink_pss_fft_bank_owned_local_admission_probe #(.KERNEL_ROM_FILE("/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-candidate175-monitor-prepared-v3/frozen_sources/upper_edge_pss_kernel_q17.mem"),.LOCAL_FIRST_ADMISSION(1)) dut ();
      initial begin #1;
        if (dut.input_guard.LOCAL_FIRST_ADMISSION !== 1) $fatal(1,"wrong actual local-admission binding");
        $display("LOCAL_ADMISSION_SYNTAX_PARAMETER_ONLY value=%b",dut.input_guard.LOCAL_FIRST_ADMISSION); $finish(0);
      end
    endmodule
    
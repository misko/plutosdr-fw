set registered 1
set round 1
set operands 1
set simlog {/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic/hdl/library/starlink_pss_acquisition/build/bank-arithmetic-actual-candidate175-monitor-prepared-v3/project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim/simulate.log}

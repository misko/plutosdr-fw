"""Independent typed continuous graph. No synthesis or physical timing claim.

Every referenced v/L/LS label must be defined. Only declared variables/arrays
are cuts. The sole permitted function was read in the pinned baseline source:
it is automatic, fully assigned, pure and depends only on its value argument.
"""
import hashlib
import json
from pathlib import Path
import re

TOKEN = re.compile(r'\b(?:LS?_0x|v0x)[0-9a-f]+(?:_\d+)*\b')
ALLOWED = {'net','net/2u','net/2s','net/s','arith/sum','arith/sub','arith/mult',
           'array/port','cmp/eeq','cmp/eq','cmp/gt','cmp/gt.s','cmp/ge.s','cmp/ne',
           'cmp/nee','concat','concat8','functor','part','part/v','reduce/and',
           'reduce/nor','reduce/or','reduce/xor','shift/l','ufunc/vec4'}
STATE = {'var','var/i','var/s','array'}


def parse(text):
    graph, definitions = {}, {}
    for line in text.splitlines():
        match = re.match(r'(\w+) \.(\S+) (.*);',line)
        if not match:
            continue
        label, operation, body = match.groups()
        if label in definitions:
            raise ValueError('DUPLICATE_DEFINITION '+label)
        definitions[label] = operation
        if operation.startswith('net') or label.startswith(('L_','LS_')):
            if operation not in ALLOWED:
                raise ValueError('UNKNOWN_OPERATION '+operation)
            if operation == 'ufunc/vec4' and not re.match(
                    r'TD_tb\.dut\.retained\.island\.product\.arithmetic\.boundary_round_and_saturate, 19, ',body):
                raise ValueError('UNREVIEWED_FUNCTION')
            graph[label] = set(TOKEN.findall(body))
    references = set().union(set(), *graph.values())
    missing = references - definitions.keys()
    if missing:
        raise ValueError('UNRESOLVED_REFERENCE '+repr(sorted(missing)))
    for leaf in references - graph.keys():
        if definitions[leaf] not in STATE:
            raise ValueError('UNREVIEWED_STATE_CUT '+leaf+' '+definitions[leaf])
    return graph


def cycle(graph):
    colors, stack = {}, []
    def visit(node):
        if colors.get(node)==1:
            return stack[stack.index(node):]+[node]
        if colors.get(node)==2:
            return None
        colors[node]=1;stack.append(node)
        for child in sorted(graph.get(node,())):
            found=visit(child)
            if found:
                return found
        stack.pop();colors[node]=2
        return None
    for node in sorted(graph):
        found=visit(node)
        if found:
            return found
    return None


def main():
    root=Path(__file__).resolve().parent
    specimens=[('L_0xa .functor BUF 1, v0xb_0;\n','UNRESOLVED_REFERENCE'),
               ('L_0xa .functor BUF 1, LS_0xb_0_4;\n','UNRESOLVED_REFERENCE'),
               ('L_0xa .unreviewed 1, C4<0>;\n','UNKNOWN_OPERATION'),
               ('v0xb_0 .unreviewed 1;\nL_0xa .functor BUF 1, v0xb_0;\n','UNREVIEWED_STATE_CUT'),
               ('L_0xa .ufunc/vec4 TD_unknown, 1, C4<0>;\n','UNREVIEWED_FUNCTION')]
    for specimen,reason in specimens:
        try:
            parse(specimen)
        except ValueError as exc:
            assert reason in str(exc)
        else:
            raise AssertionError('unsafe parser specimen accepted')
    assert cycle(parse('L_0xa .functor BUF 1, LS_0xb_0_4;\nLS_0xb_0_4 .concat [1], L_0xa;\n'))
    assert cycle(parse('v0xb_0 .var "q", 0 0;\nL_0xa .functor BUF 1, v0xb_0;\n')) is None
    # Pytest also creates a convenience ...current symlink to this same case.
    candidates=[p for p in (root/'pytest').glob('test_composition_continuous*/graph/sim.vvp')
                if not p.parent.parent.is_symlink()]
    assert len(candidates)==1
    source=candidates[0].read_bytes()
    graph=parse(source.decode())
    found=cycle(graph)
    result={'scope':'COMPLETE_TYPED_CONTINUOUS_GRAPH_NOT_SYNTHESIS_OR_PHYSICAL_TIMING',
            'file':str(candidates[0].relative_to(root)),
            'netlist_sha256':hashlib.sha256(source).hexdigest(),
            'nodes':len(graph),'LS_nodes':sum(n.startswith('LS_') for n in graph),
            'cycle':found,'parser_controls':7}
    with (root/'strict-graph-result.json').open('x') as output:
        json.dump(result,output,indent=2)
    assert len(graph)==5893 and result['LS_nodes']==69 and found is None,result
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()

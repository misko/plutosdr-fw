"""Verify original route receipts and archive once, outside the tmpfs."""
import hashlib
import json
import re
import tarfile
from pathlib import Path

HERE = Path(__file__).absolute().parent
FW = Path("/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic")
BUILD = FW / "hdl/library/starlink_pss_acquisition/build"
OWNER = HERE.parent / "local-admission-route-v1.EzXzzuNB"
ROUTE = OWNER / "route"
SYNTH = BUILD / "local-admission-ooc-L1R1B1O1-175-owned-v1/synthesis"
PREPARED = BUILD / "local-admission-ooc-L1R1B1O1-175-prepared-v1"
BASELINE = Path("/tmp/starlink-arithmetic-route-v1.VNX5gK/route")
OUTPUT = HERE / "20260910-local-admission-ooc-route-v1.tgz"


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


terminal = json.loads((OWNER / "terminal.json").read_text())
before = json.loads((OWNER / "before.json").read_text())
assert terminal["tool_returncode"] == 0 and terminal["errors"] == []
assert terminal["marker_count"] == 1 and len(terminal["products"]) == 15
assert terminal["source_hashes_before"] == terminal["source_hashes_after"] == before["source_hashes"]
for name, expected in terminal["source_hashes_after"].items():
    assert sha(Path(name)) == expected
assert before["owner_sha256"] == sha(OWNER / "own_route.py")
for name, value in terminal["products"].items():
    assert sha(OWNER / name) == value["sha256"]
    assert (OWNER / name).stat().st_size == value["bytes"] > 0
assert sha(ROUTE / "probe.tcl") == "0873675fcec384f676a80b75b746460fbff2ecc3ee162f6111705ead2fad6d4a"
log = (OWNER / "outer.log").read_text()
assert log.splitlines().count("COMPLETED_INPUT_DIAGNOSTIC_RECORDED_NOT_A_PHYSICAL_RELEASE_PASS") == 1
assert not re.search(r"^(ERROR|CRITICAL WARNING):", log, re.MULTILINE)
assert log.count("# route_design\n") == 1
assert "using a maximum of 2 CPUs" in log
assert "HD.CLK_SRC" in log and "HD.PARTPIN_LOCS" in log
constraints = (ROUTE / "inherited_constraints.xdc").read_text()
active = [line.strip() for line in constraints.splitlines() if line.strip() and not line.startswith("#")]
assert active == [
    "create_clock -period 10.000 -name source_100 [get_ports clk]",
    "create_clock -period 5.714 -name island_175 [get_ports fft_clk]",
    "current_instance -quiet",
]
timing = (ROUTE / "timing_unqualified.rpt").read_text()
assert "Timing constraints are not met." in timing
assert re.search(r"^\s+-1\.549\s+-389\.428\s+541\s+10489\s+0\.058\s+0\.000\s+0\s+10489\s+1\.830\s+0\.000\s+0\s+4905\s*$", timing, re.MULTILINE)
expected_groups = {
    "island_175": [-1.549, -305.523, 413, 9822, .058],
    "source_100": [1.281, 0, 0, 257, .100],
    "source_100    island_175": [-.652, -8.873, 50, 67, .128],
    "island_175    source_100": [-1.241, -75.032, 78, 78, .118],
    "**async_default**  island_175         island_175": [.673, 0, 0, 265, .711],
}
for key, expected in expected_groups.items():
    prefix = r"\s+".join(re.escape(word) for word in key.split())
    match = re.search(r"^" + prefix + r"\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(\d+\.\d+)\s+0\.000\s+0\s+", timing, re.MULTILINE)
    assert match and [float(word) for word in match.groups()] == expected, key
checks = dict(re.findall(r"^\d+\. checking (\w+) \((\d+)\)$", (ROUTE / "check_timing_unqualified.rpt").read_text(), re.MULTILINE))
assert checks["no_input_delay"] == "114" and checks["no_output_delay"] == "124"
assert checks["unconstrained_internal_endpoints"] == "0"
cdc = re.findall(r"^(CDC-\d+)\s+(Info|Warning)\s+(\d+)\s+", (ROUTE / "cdc_unqualified.rpt").read_text(), re.MULTILINE)
assert cdc == [("CDC-3", "Info", "6"), ("CDC-15", "Warning", "139")]
status = (ROUTE / "route_status.rpt").read_text()
for label, count in (("routable nets", 6676), ("fully routed nets", 6676), ("nets with routing errors", 0)):
    assert re.search(re.escape(label) + r"\.+\s+:\s+" + str(count) + r"\s+:", status)
resource = {"Slice LUTs": 1960, "LUT as Logic": 1772, "LUT as Memory": 188,
            "Slice Registers": 4551, "Slice": 1087, "DSPs": 21, "RAMB18": 15}
utilization = (ROUTE / "utilization.rpt").read_text()
for key, value in resource.items():
    assert re.search(r"^\|\s+" + re.escape(key) + r"\s+\|\s+" + str(value) + r"\s+\|", utilization, re.MULTILINE)
scope = (SYNTH / "scope.txt").read_text()
source_after = {}
for line in scope.split("source_hashes_before_synthesis=", 1)[1].split("\ntop_resource_probe_clocks_MHz=", 1)[0].splitlines():
    expected, path = line.split("  ", 1)
    assert sha(Path(path)) == expected
    source_after[path] = expected
assert len(source_after) == 14
assert sha(PREPARED / "SHA256SUMS") == "4ebd909dad1ade64272a33dcc034b9f791270ce1191827266c83ad23ee86703b"
files = {}
for prefix, root in (("owner", OWNER), ("synthesis_frozen_sources", SYNTH / "frozen_sources")):
    for path in sorted(root.rglob("*")):
        assert not path.is_symlink(), path
        if path.is_file():
            files[prefix + "/" + str(path.relative_to(root))] = path
files["source/fft_bank_owned_synth.dcp"] = SYNTH / "fft_bank_owned_synth.dcp"
files["source/synthesis_scope.txt"] = SYNTH / "scope.txt"
files["source/prepared_SHA256SUMS"] = PREPARED / "SHA256SUMS"
files["source/synthesis_receipt.json"] = FW / "reports/experiments/20260910-local-admission-ooc-synthesis-v1.json"
for name in ("receipt.txt", "timing_unqualified.rpt", "island_175_max.rpt", "utilization.rpt", "route_status.rpt"):
    files["arithmetic_baseline/" + name] = BASELINE / name
report = "docs/starlink-local-admission-ooc-route-20260910.md"
files[report] = FW / report
files["archive_route.py"] = Path(__file__).absolute()
hashes = {name: sha(path) for name, path in files.items()}
with OUTPUT.open("xb") as stream:
    with tarfile.open(fileobj=stream, mode="w:gz") as archive:
        for name, path in sorted(files.items()):
            archive.add(path, arcname=name, recursive=False)
with tarfile.open(OUTPUT, "r:gz") as archive:
    members = archive.getmembers()
    assert len(members) == len(files) == len({item.name for item in members})
    for item in members:
        assert item.isfile() and not item.name.startswith("/") and ".." not in Path(item.name).parts
        assert hashlib.sha256(archive.extractfile(item).read()).hexdigest() == hashes[item.name]
assert hashes == {name: sha(path) for name, path in files.items()}
result = {
    "scope": "one_authorized_L1_diagnostic_route_TOOL_EXIT0_TIMING_FAIL_NO_RELEASE",
    "original_handle": 30536, "owner": str(OWNER), "owner_terminal": terminal,
    "archive": OUTPUT.name, "archive_sha256": sha(OUTPUT), "archive_bytes": OUTPUT.stat().st_size,
    "safe_unique_regular_files": len(files), "file_sha256": hashes,
    "source_after_route_matches_original_synthesis_before_sha256": source_after,
    "unqualified_timing_groups": expected_groups, "unqualified_check_timing": checks,
    "unqualified_CDC": cdc, "routed_resource": resource,
    "deployment_eligible": False,
}
with OUTPUT.with_suffix(".json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps({key: value for key, value in result.items() if key not in ("owner_terminal", "file_sha256", "source_after_route_matches_original_synthesis_before_sha256")}, indent=2))

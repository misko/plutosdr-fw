"""Post-hoc diagnostic only: never changes or passes original failed automation.

Extract actual core events independently; report every profile-mismatched row
separately, and repeat frozen numerical/timing/protocol checks on those jobs.
This does not repair the original parser or grant future-run acceptance.
"""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-actual-prepared-v1.sUupdgsv')
PREP = ROOT / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v1'
OWNER = ROOT / 'inverse-sealed-L1E1-175-actual-owned-v1'
SOURCE = PREP / 'frozen_sources'
SIM = PREP / 'project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim'


def require(condition, why):
    if not condition:
        raise ValueError(why)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


manifest_sha = '2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a'
require(sha(PREP / 'manifest.json') == manifest_sha, 'frozen manifest pin')
manifest = json.loads((PREP / 'manifest.json').read_text())
inventory = {'manifest.json': manifest_sha}
inventory.update({'frozen_sources/' + p.name: sha(p) for p in SOURCE.iterdir()})
expected = {'manifest.json': manifest_sha}
expected.update({'frozen_sources/' + name: value for name, value in manifest['source_sha256'].items()})
terminal = json.loads((OWNER / 'terminal.json').read_text())
before = json.loads((OWNER / 'before.json').read_text())
require(inventory == expected == before['source_sha256'] == terminal['after_source_sha256'], 'source integrity')
require(terminal['original_process_exit'] == 1 and terminal['source_unchanged'] is True
        and terminal['launch_error'] is None and terminal['after_integrity_error'] is None,
        'expected preserved failed original')
require(not (PREP / 'results.json').exists(), 'unexpected successful automation artifact')


def load(name):
    path = SOURCE / (name + '.py')
    require(sha(path) == manifest['source_sha256'][path.name], 'frozen helper pin')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


jobs, mismatches, current = [], [], None
fields = {'config': 'config', 'core_input': 'input', 'core_output': 'raw',
          'status': 'status', 'guard_commit': 'commit'}
with (SIM / 'fft_bank_owned_trace.csv').open() as stream:
    for raw in csv.DictReader(stream):
        if raw['epoch'] not in ('1', '2') or raw['running'] != '1':
            current = None
            continue
        row = {key: int(value) for key, value in raw.items()}
        require(row['fault'] == 0, 'actual fault inside healthy running epoch')
        if row['profile'] != row['epoch'] - 1:
            mismatches.append(row)
            require(not any(row[k] for k in (*fields, 'admit')), 'profile mismatch with core event')
        if row['admit']:
            require(row['admit'] == 1, 'nonbinary admission')
            current = dict(epoch=row['epoch'], inverse=row['inverse'], start=row['block_start'],
                           admit=row['cycle'], **{v: [] for v in fields.values()})
            jobs.append(current)
        for field, key in fields.items():
            if row[field]:
                require(row[field] == 1 and current is not None
                        and row['inverse'] == current['inverse'], 'event owner/phase')
                current[key].append(row['cycle'] - current['admit'])
timing = load('inverse_sealed_actual_timing')
arithmetic = load('bank_arithmetic_actual')
intervals = timing.verify_jobs(jobs, True)
numerics = arithmetic.verify_events(SIM / 'bank_arithmetic_events.csv', SOURCE)
cycles = timing.verify_event_cycles(SIM / 'bank_arithmetic_events.csv', jobs)
protocol = timing.verify_protocol(SIM / 'inverse_sealed_protocol.csv', jobs,
    arithmetic.words(SOURCE / 'inverse_q17.mem', 1536),
    arithmetic.words(SOURCE / 'forward_exponents.mem', 3),
    arithmetic.words(SOURCE / 'inverse_exponents.mem', 3))
print(json.dumps({'original_automation': 'FAIL', 'posthoc_diagnostic_only': True,
    'source_count': len(manifest['source_sha256']), 'job_count': len(jobs),
    'all_profile_mismatches': mismatches, 'healthy_running_faults': 0,
    'pair_intervals': intervals, 'numerics': numerics, 'event_cycles': cycles,
    'protocol': protocol, 'csv_sha256': {name: sha(SIM / name) for name in
        ('fft_bank_owned_trace.csv', 'bank_arithmetic_events.csv', 'inverse_sealed_protocol.csv')},
    'deployment_eligible': False}, indent=2, sort_keys=True))

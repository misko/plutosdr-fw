"""Read-only parent audit of the single approved inverse actual run.

No vendor launch, source edit, acceptance-bound change or waveform qualification.
Requires the original execution owner to have completed successfully first.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

BASE = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/inverse-actual-prepared-v1.sUupdgsv')
PREP = BASE / 'inverse-sealed-actual-R1B1O1L1E1-175-prepared-v1'
OWNER = BASE / 'inverse-sealed-L1E1-175-actual-owned-v1'
SOURCE = PREP / 'frozen_sources'
PYTHON = '/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python'
MANIFEST_SHA = '2c1bf9badc769aeae54fe1848d8ce8a3f1cda810e096a541ea5b5840618feb8a'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    require(path.is_file() and not path.is_symlink(), 'regular file required: ' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    pins = {
        BASE / 'own_inverse_sealed_actual_v1.py': 'c77a1a119df74e7e3a93281e59f03a0050bb9e29f03354253618152a6ab1d96f',
        PREP / 'manifest.json': MANIFEST_SHA,
        SOURCE / 'simulate_inverse_sealed_actual.tcl': '23e9e9b989e35f013113bd6356288952bf05d58c57d7803c8baa1d74b8239972',
        SOURCE / 'inverse_sealed_actual.py': 'c3c1c764a20061ce2026cbea653464d94752019e91acb8a359a414a5f591e9ab',
    }
    for path, expected in pins.items():
        require(sha(path) == expected, 'external source pin: ' + str(path))
    terminal = json.loads((OWNER / 'terminal.json').read_text())
    require(type(terminal['original_process_exit']) is int and terminal['original_process_exit'] == 0,
            'original process did not pass')
    require(terminal['launch_error'] is None and terminal['after_integrity_error'] is None
            and terminal['source_unchanged'] is True, 'owner integrity/launch failed')
    before = json.loads((OWNER / 'before.json').read_text())
    require(terminal['started_utc'] == before['started_utc'], 'different original execution')
    manifest = json.loads((PREP / 'manifest.json').read_text())
    inventory = {'manifest.json': sha(PREP / 'manifest.json')}
    inventory.update({'frozen_sources/' + path.name: sha(path) for path in SOURCE.iterdir()})
    expected_inventory = {'manifest.json': MANIFEST_SHA}
    expected_inventory.update({'frozen_sources/' + name: value
                               for name, value in manifest['source_sha256'].items()})
    require(len(inventory) == 65 and inventory == expected_inventory
            == before['source_sha256'] == terminal['after_source_sha256'], 'full before/after/live source inventory')
    expected_command = ['/opt/Xilinx/Vivado/2022.2/bin/vivado', '-mode', 'batch', '-source',
        str(SOURCE / 'simulate_inverse_sealed_actual.tcl'), '-log', str(OWNER / 'vivado.log'),
        '-journal', str(OWNER / 'vivado.jou'), '-tclargs', str(PREP), PYTHON, MANIFEST_SHA]
    require(before['command'] == expected_command, 'exact original launch command')
    outcome = (PREP / 'run_outcome.txt').read_text()
    for field in ('run_status', 'after_status'):
        require(re.findall(r'^' + field + r'=(.*)$', outcome, re.MULTILINE) == ['0'], field + ' failed')
    marker = 'INVERSE_SEALED_ACTUAL_CORE_VERIFIED_NO_SCORER_RTL_PHYSICAL_OR_RF_CLAIM'
    require((OWNER / 'outer.log').read_text().splitlines().count(marker) == 1, 'unique original terminal marker')
    environment = {key: value for key, value in os.environ.items()
                   if key not in ('LD_LIBRARY_PATH', 'PYTHONHOME', 'PYTHONPATH', 'PYTHONOPTIMIZE')}
    checked = subprocess.run([PYTHON, '-B', str(SOURCE / 'inverse_sealed_actual.py'), 'results',
        str(PREP), '--expected', MANIFEST_SHA], cwd='/', env=environment,
        capture_output=True, text=True, check=True, timeout=60)
    result = json.loads(checked.stdout)
    require(result == json.loads((PREP / 'results.json').read_text()), 'independent composed result repeat')
    require(result['actual_run'] is True and result['physical_RF_or_scorer_RTL_qualified'] is False,
            'scope qualification changed')
    sim = PREP / 'project/fft_bank_arithmetic_actual.sim/sim_1/behav/xsim'
    names = ['fft_bank_owned_trace.csv', 'bank_arithmetic_events.csv', 'inverse_sealed_protocol.csv',
             'simulate.log', 'tb_starlink_pss_inverse_sealed_actual_behav.wdb']
    products = {name: {'bytes': (sim / name).stat().st_size, 'sha256': sha(sim / name)} for name in names}
    require(all(row['bytes'] > 0 for row in products.values()), 'empty required output')
    require(products['fft_bank_owned_trace.csv']['sha256'] == result['trace_sha256']
            and products['inverse_sealed_protocol.csv']['sha256'] == result['protocol_sha256']
            and products['simulate.log']['sha256'] == result['log_sha256'], 'full output hashes')
    print(json.dumps({'owner': terminal, 'source_count': 64, 'products': products,
        'composed_results': result, 'recorded_wave_history_verified': False,
        'physical_or_radio_qualified': False}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()

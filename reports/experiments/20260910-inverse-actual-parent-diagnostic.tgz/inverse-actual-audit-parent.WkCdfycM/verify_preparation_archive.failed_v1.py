"""Retained first audit: omitted separately pinned inventory.json; failed."""
import hashlib
import io
import json
from pathlib import PurePosixPath
import subprocess
import tarfile

REPO = '/tmp/starlink-coarse-alternatives.Y3JzOI/bank-arithmetic'
COMMIT = '577c670acbdcc9c2758036f1f76b1c71ff87b708'
STEM = 'reports/experiments/20260910-inverse-sealed-actual-preparation-v1'


def blob(suffix):
    return subprocess.check_output(['git', '-C', REPO, 'show', COMMIT + ':' + STEM + suffix])


receipt = json.loads(blob('.json'))
data = blob('.tgz')
expected = '38fad05b62eca8a189c8b8ff3a67675b708c3f7a0bc4ab26c69a8c375cd27936'
if len(data) != 31039671 or hashlib.sha256(data).hexdigest() != expected:
    raise ValueError('committed archive pin mismatch')
actual = {}
with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
    for member in archive:
        path = PurePosixPath(member.name)
        if (not member.isfile() or path.is_absolute() or '..' in path.parts
                or path.as_posix() != member.name or member.name in actual):
            raise ValueError('unsafe or duplicate archive member: ' + member.name)
        stream = archive.extractfile(member)
        actual[member.name] = hashlib.file_digest(stream, 'sha256').hexdigest()
if len(actual) != 4506 or actual != receipt['files']:
    raise ValueError('complete committed member inventory mismatch')
print(json.dumps({'commit': COMMIT, 'archive_sha256': expected,
                  'verified_regular_members': len(actual), 'extracted_or_executed': False}))

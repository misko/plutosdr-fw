"""Parent post-run compiled-source receipts and independent fresh product words."""
import hashlib
import json
from pathlib import Path
import re
import runpy

root=Path(__file__).resolve().parent
manifests=sorted((root/'cases').rglob('sources.json'))
entries=0
for path in manifests:
    pins=json.loads(path.read_text())
    for name,digest in pins.items():
        assert hashlib.sha256((path.parent/name).read_bytes()).hexdigest()==digest,(path,name)
        entries+=1
top=root/'cases/integrated0/top'
pins=json.loads((root/'source-pins.json').read_text())
for path in top.glob('starlink_pss_*.v'):
    name='hdl/library/starlink_pss_acquisition/'+path.name
    if name not in pins:
        name='hdl/library/starlink_pss_acquisition/tb/'+path.name
    assert hashlib.sha256(path.read_bytes()).hexdigest()==pins[name],path.name
graph_helper=runpy.run_path(str(root/'source/tests/starlink_oracle/product_interface_graph.py'))
graph,_=graph_helper['parse']((top/'sim.vvp').read_text())
assert graph_helper['first_cycle'](graph) is None
kernel=[int(v,16) for v in (top/'upper_edge_pss_kernel_q17.mem').read_text().splitlines()]
old=[int(v,16) for v in (top/'actor_expected_product.mem').read_text().splitlines()]
fresh=[int(v,16) for v in (top/'actor_fresh_expected_product.mem').read_text().splitlines()]
def s18(value):
    return (value & 0x1ffff)-(value & 0x20000)
def q18(value):
    # Independent magnitude/remainder implementation, symmetric ties to even.
    magnitude=abs(value)
    whole=magnitude>>18
    fraction=magnitude & 0x3ffff
    if fraction>0x20000 or (fraction==0x20000 and whole&1):
        whole+=1
    result=whole if value>=0 else -whole
    return max(-131072,min(131071,result)) & 0x3ffff
for n,word in enumerate(kernel):
    ki,kq=s18(word),s18(word>>18)
    i,q=n%23-4107,n%17+3064
    expected=q18(i*ki-q*kq)|(q18(i*kq+q*ki)<<18)
    assert fresh[n]==expected,(n,fresh[n],expected)
assert len(kernel)==len(old)==len(fresh)==512
assert sum(a!=b for a,b in zip(old,fresh,strict=True))==512
for reset in (0,1):
    negative=top/f'case-17-bit-{reset}-target-0'
    assert json.loads(negative.with_suffix('.json').read_text())['exit']!=0
    assert 'CHECKED_TOP_PREJOIN_SOURCE_NOT_ACCEPTED n=2 req=0 ack_sync=11 fast_ack=1 write=2 epoch=0 fault=0' in negative.with_suffix('.log').read_text()
    path=top/f'case-19-bit-{reset}-target-0'
    assert json.loads(path.with_suffix('.json').read_text())['exit']==0
    text=path.with_suffix('.log').read_text()
    assert not re.search(r'\b(fatal|error)\b',text,re.I)
    assert text.count(f'CHECKED_TOP_DISTINCT_PAYLOAD_PASS reset={reset} input_words_changed=512 expected_outputs_changed=512 independently_checked=512 starts=2 ack=1 releases=1 control_actor_not_fft=1')==1
result={'compiled_manifests':len(manifests),'verified_entries':entries,
        'integrated_graph_nodes':len(graph),'integrated_graph_LS':sum(n.startswith('LS_') for n in graph),
        'integrated_graph_acyclic':True,'independent_fresh_products':512,
        'distinct_old_fresh_products':512,'both_reset_directions_verified':True,
        'continuous_capture_or_actual_fft_claim':False}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

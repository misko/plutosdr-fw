"""Bounded portable original-failure package; no input or simulation edits."""

import hashlib
import io
import json
import tarfile
from pathlib import Path

OWNER=Path(__file__).resolve().parent
RUN=OWNER.with_name("main-high-rate60-bank175-late447-v1")
WORK=Path("/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired")
SIM=RUN/"project/high_rate60_bank_native_late.sim/sim_1/behav/xsim"
OUTPUT=WORK/"reports/experiments/20260910-high-rate60-late-original-failure-v1.tgz"


def sha(data): return hashlib.sha256(data).hexdigest()


def main():
    assert not OUTPUT.exists()
    payload={}
    def add(name,path):
        assert name not in payload and not path.is_symlink() and path.is_file()
        assert path.stat().st_size<=10_000_000
        payload[name]=path.read_bytes()
    bundle=RUN/"inputs"
    for p in sorted(bundle.rglob("*")):
        if p.is_file(): add("frozen_inputs/"+p.relative_to(bundle).as_posix(),p)
    for name in ["owner.json","audit.py","post-audit.json","package.py"]: add("owner/"+name,OWNER/name)
    for name in ["before_integrity.txt","after_integrity.txt","generated_ip.txt","run_status.txt"]: add("run/"+name,RUN/name)
    for name in ["simulate.log","native60_actual_source.txt","native60_actual_capture.txt","native60_actual_raw_tuples.txt",
                 "native60_actual_holds.txt","paired60_actual_prime.txt","paired_pilot_actual.ci16"]:
        add("simulation/"+name,SIM/name)
    for p in sorted(SIM.glob("*.log")):
        if p.name!="simulate.log": add("simulation/"+p.name,p)
    before,wrapper=(RUN/"generated_ip.txt").read_text().strip().split(maxsplit=1)
    add("generated_ip/"+Path(wrapper).name,Path(wrapper))
    assert sha(payload["generated_ip/"+Path(wrapper).name])==before
    xci=RUN/"project/high_rate60_bank_native_late.srcs/sources_1/ip/starlink_pss_fft512_bfp18_rt_candidate/starlink_pss_fft512_bfp18_rt_candidate.xci"
    add("generated_ip/"+xci.name,xci)
    for suffix in [".vivado.log",".vivado.jou"]: add("external/"+RUN.with_suffix(suffix).name,RUN.with_suffix(suffix))
    for name in ["starlink-high-rate60-late-prelaunch-20260910.md","starlink-high-rate60-late-actual-v1-failure-20260910.md"]:
        add("reports/"+name,WORK/"docs"/name)
    # Preserve each failed/prior test's exact source manifest and all additive
    # sources; unchanged108 dependencies are already complete in final inputs.
    for version in [1,2,3]:
        temp=Path(f"/tmp/starlink-highrate60-late-offline-v{version}")
        add(f"offline/v{version}/junit.xml",WORK/f"build/high-rate60-late-offline-v{version}.xml")
        log=WORK/f"build/high-rate60-late-offline-v{version}.log"
        if log.exists(): add(f"offline/v{version}/pytest.log",log)
        old=temp/"late60_bundle0/bundle"
        add(f"offline/v{version}/bundle.json",old/"bundle.json")
        receipt=json.loads((old/"bundle.json").read_bytes())
        healthy=json.loads((old/"healthy/bundle.json").read_bytes())
        for name in receipt["source_sha256"]:
            if name not in healthy["source_sha256"]:
                add(f"offline/v{version}/additive_sources/"+name,old/"source_snapshot"/name)
        for p in (temp/"test_late_whole_composition_co0").glob("*"):
            if p.is_file() and p.suffix in [".json",".log"]: add(f"offline/v{version}/compile/"+p.name,p)
    assert len(payload)<500 and sum(map(len,payload.values()))<20_000_000
    manifest={n:{"sha256":sha(data),"bytes":len(data)} for n,data in sorted(payload.items())}
    receipt={"classification":"original actual88460 overallFAIL; no rerun/correction included",
        "files":manifest,"raw_run":"/tmp/starlink-bank-route.I50MDJ/main-high-rate60-bank175-late447-v1",
        "raw_full_inventory":"owner/post-audit.json","omissions":"generated project/waves retained in raw run, not duplicated; individual parser mutants remain in their original bounded pytest trees"}
    payload["receipt.json"]=(json.dumps(receipt,sort_keys=True,indent=2)+"\n").encode()
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(OUTPUT,"w:gz") as tar:
        for name,data in sorted(payload.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    with tarfile.open(OUTPUT,"r:gz") as tar:
        members=tar.getmembers()
        assert len(members)==len(payload) and len({m.name for m in members})==len(members)
        for member in members:
            assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
            data=tar.extractfile(member).read()
            assert data==payload[member.name]
    result={"archive":str(OUTPUT),"sha256":sha(OUTPUT.read_bytes()),"bytes":OUTPUT.stat().st_size,
        "safe_regular_members":len(payload),"hash_receipts":len(manifest),"classification":"original actual overallFAIL preserved"}
    (OWNER/"package-receipt.json").write_text(json.dumps(result,sort_keys=True,indent=2)+"\n")
    print(json.dumps(result,sort_keys=True))


if __name__=="__main__": main()

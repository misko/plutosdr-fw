`timescale 1ns/1ps
module tb;
reg [69:0] engine_metadata,product_bank_metadata;
reg [74:0] return_metadata;
reg next_inverse,forward_committed,product_bank_valid,product_bank_last;
reg [8:0] product_bank_position;
integer bit_index,a,b,c,n,seed=32'h2819af35,checks=0;
function automatic four(input integer digit);
  case(digit)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
  // BEGIN BALANCED HANDOFF IDENTITY
  // Preserve the complete current 70-bit equality, including four-state
  // behavior. Keep small parallel leaves to avoid a long inferred carry chain.
  // No sampled certificate, extra latency or delayed publication veto.
  wire [69:0] handoff_expected_metadata =
    {1'b1, engine_metadata[68:5], return_metadata[4:0]};
  (* keep = "true" *) wire [23:0] handoff_leaf_equal;
  (* keep = "true" *) wire [3:0] handoff_group_equal;
  generate
    for (genvar leaf = 0; leaf < 24; leaf = leaf + 1) begin : handoff_leaves
      localparam integer BITS = leaf == 23 ? 1 : 3;
      assign handoff_leaf_equal[leaf] = product_bank_metadata[3*leaf +: BITS] ==
        handoff_expected_metadata[3*leaf +: BITS];
    end
    for (genvar group_index = 0; group_index < 4; group_index = group_index + 1) begin : handoff_groups
      assign handoff_group_equal[group_index] = &handoff_leaf_equal[6*group_index +: 6];
    end
  endgenerate
  wire forward_handoff_identity = &handoff_group_equal;
  // END BALANCED HANDOFF IDENTITY
  // The return exponent register is immutable after the forward guard commit.
  // A bank claiming ownership with the wrong descriptor cannot ACK that guard.
  // Distribute the SAME current ownership predicate over five comparison groups.
  // Each group combines at most five existing three-bit leaves with one enable.
  // The full identity above still drives ACK/completion; there is no new state,
  // delayed certificate, private bypass or changed publication/fault priority.
  wire handoff_fault_enabled = !next_inverse && forward_committed && product_bank_valid;
  (* keep = "true" *) wire [4:0] handoff_identity_fault;
  generate for (genvar fault_group = 0; fault_group < 5; fault_group = fault_group + 1) begin : gated_handoff_fault
    localparam integer LEAVES = fault_group == 4 ? 4 : 5;
    assign handoff_identity_fault[fault_group] = handoff_fault_enabled &&
      !( &handoff_leaf_equal[5*fault_group +: LEAVES] );
  end endgenerate
  wire handoff_fault_now = (|handoff_identity_fault) ||
    (handoff_fault_enabled && (product_bank_position != 0 || product_bank_last));

wire reference_identity = product_bank_metadata == {1'b1,engine_metadata[68:5],return_metadata[4:0]};
wire reference_fault = !next_inverse && forward_committed && product_bank_valid &&
  (!reference_identity || product_bank_position != 0 || product_bank_last);
task automatic compare;
begin
  #1;
  if(forward_handoff_identity!==reference_identity || handoff_fault_now!==reference_fault)
    $fatal(1,"native metadata predicate mismatch");
  checks=checks+1;
end
endtask
initial begin
  product_bank_position=0;product_bank_last=0;
  for(bit_index=0;bit_index<70;bit_index=bit_index+1)
    for(a=0;a<4;a=a+1)for(b=0;b<4;b=b+1)for(c=0;c<64;c=c+1)begin
      engine_metadata=0;return_metadata=0;
      if(bit_index<5)return_metadata[bit_index]=four(a);
      else if(bit_index<69)engine_metadata[bit_index]=four(a);
      product_bank_metadata={1'b1,engine_metadata[68:5],return_metadata[4:0]};
      product_bank_metadata[bit_index]=four(b);
      next_inverse=four(c%4);forward_committed=four((c/4)%4);product_bank_valid=four((c/16)%4);
      compare;
    end
  for(n=0;n<20000;n=n+1)begin
    engine_metadata={$random(seed),$random(seed),$random(seed)};
    return_metadata={$random(seed),$random(seed),$random(seed)};
    product_bank_metadata={1'b1,engine_metadata[68:5],return_metadata[4:0]};
    if(n%2)product_bank_metadata[n%70]=four((n/2)%4);
    product_bank_position=(n%3==0)?0:$random(seed);product_bank_last=four(n%4);
    next_inverse=four((n/4)%4);forward_committed=four((n/16)%4);product_bank_valid=four((n/64)%4);
    compare;
  end
  $display("PUBLICATION_METADATA_PASS checks=%0d",checks);$finish;
end
endmodule

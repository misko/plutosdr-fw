`timescale 1ns/1ps
module tb;
reg [23:0] handoff_leaf_equal;
reg next_inverse,forward_committed,product_bank_valid,product_bank_last;
reg [8:0] product_bank_position;
wire forward_handoff_identity = &handoff_leaf_equal;
integer n,j,k,checks=0;
function automatic four(input integer digit);
  case(digit)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
  wire handoff_fault_enabled = !next_inverse && forward_committed && product_bank_valid;
  (* keep = "true" *) wire [4:0] handoff_identity_fault;
  generate for (genvar fault_group = 0; fault_group < 5; fault_group = fault_group + 1) begin : gated_handoff_fault
    localparam integer LEAVES = fault_group == 4 ? 4 : 5;
    assign handoff_identity_fault[fault_group] = handoff_fault_enabled &&
      !( &handoff_leaf_equal[4*fault_group +: LEAVES] );
  end endgenerate
  wire handoff_fault_now = (|handoff_identity_fault) ||
    (handoff_fault_enabled && (product_bank_position != 0 || product_bank_last));

wire reference_fault = !next_inverse && forward_committed && product_bank_valid &&
  (!forward_handoff_identity || product_bank_position != 0 || product_bank_last);
initial begin
  for(n=0;n<1048576;n=n+1)begin
    k=n;handoff_leaf_equal='1;
    for(j=0;j<5;j=j+1)begin handoff_leaf_equal[5*j]=four(k%4);k=k/4;end
    next_inverse=four(k%4);k=k/4;
    forward_committed=four(k%4);k=k/4;
    product_bank_valid=four(k%4);k=k/4;
    product_bank_position=0;product_bank_position[0]=four(k%4);k=k/4;
    product_bank_last=four(k%4);
    #1;
    if(handoff_fault_now!==reference_fault)$fatal(1,"four-state fault mismatch vector=%0d",n);
    checks=checks+1;
  end
  $display("PUBLICATION_FACTOR_PASS checks=%0d",checks);$finish;
end
endmodule

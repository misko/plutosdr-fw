`timescale 1ns/1ps
// Standalone ROM only: exact old-source shadow, no FFT or physical claim.
module tb_starlink_pss_rom_read_ahead;
  parameter integer WIDTH=18, BALANCED=1, SCRATCH=1;
  reg clk=0, resetn=0, flush=0, input_valid=0, output_ready=0;
  reg [8:0] input_bin_index=0;
  reg [4:0] input_block_exponent=0;
  reg input_last=0;
  reg [63:0] input_block_start_index=0;
  always #5 clk=~clk;
`define PORTS .clk(clk),.resetn(resetn),.flush(flush),.input_valid(input_valid), \
    .output_ready(output_ready),.input_bin_index(input_bin_index), \
    .input_block_exponent(input_block_exponent),.input_last(input_last), \
    .input_block_start_index(input_block_start_index)
  original_kernel #(.ROM_FILE("kernel.mem"),.DATA_WIDTH(WIDTH),
    .BALANCED_BLOCK_IDENTITY_EQ(BALANCED),.PRIVATE_NEXT_START_SCRATCH(SCRATCH)) original (`PORTS);
  starlink_pss_kernel_rom_read_ahead #(.ROM_FILE("kernel.mem"),.DATA_WIDTH(WIDTH),
    .BALANCED_BLOCK_IDENTITY_EQ(BALANCED),.PRIVATE_NEXT_START_SCRATCH(SCRATCH)) default_rom (`PORTS);
  starlink_pss_kernel_rom_read_ahead #(.ROM_FILE("kernel.mem"),.DATA_WIDTH(WIDTH),
    .BALANCED_BLOCK_IDENTITY_EQ(BALANCED),.PRIVATE_NEXT_START_SCRATCH(SCRATCH),
    .PRIVATE_ROM_READ_AHEAD(1),.PRIVATE_BLOCK_METADATA_READ_AHEAD(1)) candidate (`PORTS);
  starlink_pss_kernel_rom_read_ahead #(.ROM_FILE("kernel.mem"),.DATA_WIDTH(WIDTH),
    .BALANCED_BLOCK_IDENTITY_EQ(BALANCED),.PRIVATE_NEXT_START_SCRATCH(SCRATCH),
    .PRIVATE_ROM_READ_AHEAD(1),.PRIVATE_BLOCK_METADATA_READ_AHEAD(0)) word_only (`PORTS);
  starlink_pss_kernel_rom_read_ahead #(.ROM_FILE("kernel.mem"),.DATA_WIDTH(WIDTH),
    .BALANCED_BLOCK_IDENTITY_EQ(BALANCED),.PRIVATE_NEXT_START_SCRATCH(SCRATCH),
    .PRIVATE_ROM_READ_AHEAD(0),.PRIVATE_BLOCK_METADATA_READ_AHEAD(1)) metadata_only (`PORTS);
`undef PORTS
`define VIEW(g) {g.input_ready,g.output_valid,g.output_kernel_i,g.output_kernel_q, \
    g.output_kernel_word,g.output_bin_index,g.output_block_exponent,g.output_last, \
    g.output_block_start_index,g.accepted_pulse,g.emitted_pulse, \
    g.input_block_complete_pulse,g.sequence_error_pulse,g.metadata_error_pulse, \
    g.protocol_fault,g.expected_bin_index,g.block_exponent,g.block_start_index, \
    g.expected_next_block_start,g.have_previous_block,g.output_stage_ready, \
    g.input_accept,g.at_block_start,g.sequence_error_now,g.metadata_error_now, \
    g.protocol_error_now,g.block_identity_equal}
  wire [1023:0] old_view=`VIEW(original), default_view=`VIEW(default_rom), new_view=`VIEW(candidate);
  wire [1023:0] word_view=`VIEW(word_only), metadata_view=`VIEW(metadata_only);
  integer checks=0, cycles=0, healthy=0, stalls=0, faults=0, unknowns=0;
  integer occupied_unknown_ready=0, flush_selector_zero=0, flush_selector_one=0;
  reg [2*WIDTH-1:0] words[0:511];
  reg [31:0] rng=32'h7e571eaf;
  function automatic [31:0] step(input [31:0] x);
    reg [31:0] y;
    begin y=x^(x<<13); y=y^(y>>17); step=y^(y<<5); end
  endfunction
  task compare;
    begin
      if(old_view !== default_view || old_view !== new_view || old_view !== word_view || old_view !== metadata_view) begin
        $display("ROM_READ_AHEAD_MISMATCH cycles=%0d old=%h default=%h new=%h",cycles,old_view,default_view,new_view);
        $fatal(1,"unconditional visible and old-private-state mismatch");
      end
      checks=checks+1;
    end
  endtask
  task prime_occupied;
    begin
      reset_epoch(); input_valid=1; output_ready=1; input_bin_index=0;
      input_last=0; input_block_exponent=3; input_block_start_index=64'h123;
      tick();
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         candidate.private_rom_read_ahead.use_speculative!==1 ||
         candidate.output_kernel_word!==words[0])
        $fatal(1,"directed occupied selector-one precondition missing");
      input_bin_index=1;
    end
  endtask
  task occupied_unknown_ready_case(input reg ready_value);
    begin
      prime_occupied(); output_ready=ready_value;
      #1;
      if(candidate.input_accept!==1'bx || candidate.output_stage_ready!==1'bx)
        $fatal(1,"directed active unknown-ready boundary missing");
      tick();
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         candidate.expected_bin_index!==1 ||
         candidate.private_rom_read_ahead.use_speculative!==0 ||
         candidate.output_kernel_word!==words[0])
        $fatal(1,"unknown-ready must retain occupied coefficient");
      output_ready=0; tick();
      if(candidate.output_valid!==1 || candidate.output_kernel_word!==words[0])
        $fatal(1,"known stall after unknown-ready changed coefficient");
      input_valid=0; output_ready=1; tick();
      if(candidate.output_valid!==0 || candidate.output_kernel_word!==words[0])
        $fatal(1,"known drain after unknown-ready changed coefficient");
      input_valid=1; tick();
      if(candidate.output_valid!==1 || candidate.output_kernel_word!==words[1] ||
         candidate.protocol_fault!==0)
        $fatal(1,"healthy refill after unknown-ready failed");
      occupied_unknown_ready=occupied_unknown_ready+1;
    end
  endtask
  task flush_occupied_selector(input integer selected);
    begin
      prime_occupied();
      if(!selected) begin output_ready=0; tick(); end
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         candidate.private_rom_read_ahead.use_speculative!==selected[0])
        $fatal(1,"directed occupied flush selector precondition missing");
      flush=1; tick();
      if(candidate.output_valid!==0 || candidate.output_kernel_word!==0 ||
         candidate.private_rom_read_ahead.use_speculative!==0)
        $fatal(1,"occupied flush did not clear visible coefficient");
      if(selected) flush_selector_one=flush_selector_one+1;
      else flush_selector_zero=flush_selector_zero+1;
      flush=0; input_valid=1; output_ready=1; input_bin_index=0; tick();
      if(candidate.output_valid!==1 || candidate.output_kernel_word!==words[0] ||
         candidate.protocol_fault!==0)
        $fatal(1,"healthy refill after occupied flush failed");
    end
  endtask
  always @(posedge clk) begin
    cycles=cycles+1; compare(); #1; compare();
  end
  task tick;
    begin @(negedge clk); #1; compare(); end
  endtask
  task reset_epoch;
    begin
      resetn=0; flush=0; input_valid=0; output_ready=0;
      tick(); tick(); resetn=1; tick();
    end
  endtask
  task block(input [63:0] base, input [4:0] exponent, input integer bubbles);
    integer n;
    begin
      for(n=0;n<512;n=n+1) begin
        input_valid=1; input_bin_index=n; input_last=(n==511);
        input_block_exponent=exponent; input_block_start_index=base;
        output_ready=1; tick();
        if(candidate.output_valid!==1 || candidate.output_kernel_word!==words[n])
          $fatal(1,"accepted coefficient latency/value mismatch");
        if(bubbles && n%7==0) begin
          output_ready=0; input_valid=1; input_bin_index=~n;
          input_block_start_index=~base; tick(); tick(); stalls=stalls+2;
        end
        // Reading a bubble must not change the last visible coefficient.
        if(bubbles) begin
          output_ready=1; input_valid=0; input_bin_index=n^9'h155;
          tick();
          if(candidate.output_kernel_word!==words[n]) $fatal(1,"invalid coefficient changed");
        end
      end
      healthy=healthy+1;
    end
  endtask
// Additive standalone epochs; the frozen original bench remains intact.
integer metadata_fault_bits=0, metadata_unknown_first=0;
integer metadata_bubbles=0, metadata_flush_zero=0, metadata_flush_one=0;
integer metadata_wrap_blocks=0, metadata_malformed_first=0;
integer metadata_unknown_framing=0;
task metadata_prime;
  begin
    reset_epoch(); input_valid=1; output_ready=1; input_bin_index=0;
    input_last=0; input_block_start_index=64'hfedcba9876543210;
    input_block_exponent=5'h15; tick();
    if(candidate.private_block_metadata_read_ahead.use_speculative!==1 ||
       candidate.block_start_index!==64'hfedcba9876543210 ||
       candidate.block_exponent!==5'h15 || candidate.output_valid!==1)
      $fatal(1,"metadata healthy first-beat witness missing");
  end
endtask
task metadata_walk(input [63:0] base, input [4:0] exponent);
  integer bin_number;
  begin
    for(bin_number=0;bin_number<512;bin_number=bin_number+1) begin
      input_valid=1; output_ready=1; input_bin_index=bin_number;
      input_last=(bin_number==511); input_block_start_index=base;
      input_block_exponent=exponent; tick();
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         candidate.block_start_index!==base || candidate.block_exponent!==exponent)
        $fatal(1,"metadata continuous/wrap block witness missing");
    end
    metadata_wrap_blocks=metadata_wrap_blocks+1;
  end
endtask
task metadata_extra_cases;
  integer bit_number, kind, selected;
  reg [68:0] changed_tuple;
  begin
    // Every tuple bit must retain the admitted descriptor on interior faults.
    for(bit_number=0;bit_number<69;bit_number=bit_number+1) begin
      metadata_prime(); input_bin_index=1;
      changed_tuple={64'hfedcba9876543210,5'h15} ^ (69'b1<<bit_number);
      {input_block_start_index,input_block_exponent}=changed_tuple;
      tick();
      if(candidate.protocol_fault!==1 || candidate.metadata_error_pulse!==1 ||
         candidate.output_valid!==0 ||
         {candidate.block_start_index,candidate.block_exponent}!==
           {64'hfedcba9876543210,5'h15})
        $fatal(1,"metadata bit fault changed admitted tuple or veto");
      metadata_fault_bits=metadata_fault_bits+1;
    end
    // Speculative capture is allowed on invalid/X/Z-valid first-slot bubbles,
    // but the externally and checker-visible tuple must stay exactly zero.
    for(kind=0;kind<3;kind=kind+1) begin
      reset_epoch(); output_ready=1; input_valid=kind==0 ? 1'b0 :
        (kind==1 ? 1'bx : 1'bz);
      input_bin_index=0; input_last=0;
      input_block_start_index=64'h0123456789abcdef; input_block_exponent=5'h1f;
      tick();
      if(candidate.private_block_metadata_read_ahead.speculative_metadata!==
           {64'h0123456789abcdef,5'h1f} ||
         {candidate.block_start_index,candidate.block_exponent}!==69'b0 ||
         candidate.private_block_metadata_read_ahead.use_speculative!==0)
        $fatal(1,"metadata invalid first-slot capture/retention witness missing");
      metadata_bubbles=metadata_bubbles+1;
    end
    // First-block metadata is not validated against previous history. Keep the
    // original procedural semantics when the accepted tuple itself has X/Z.
    for(kind=0;kind<2;kind=kind+1) begin
      reset_epoch(); output_ready=1; input_valid=1; input_bin_index=0; input_last=0;
      input_block_start_index=kind ? 64'bz : 64'bx;
      input_block_exponent=kind ? 5'bz : 5'bx; tick();
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         {candidate.block_start_index,candidate.block_exponent}!==
         {input_block_start_index,input_block_exponent})
        $fatal(1,"metadata accepted unknown first tuple changed");
      metadata_unknown_first=metadata_unknown_first+1;
    end
    for(selected=0;selected<2;selected=selected+1) begin
      metadata_prime();
      if(!selected) begin output_ready=0; tick(); end
      if(candidate.output_valid!==1 ||
         candidate.private_block_metadata_read_ahead.use_speculative!==selected[0])
        $fatal(1,"metadata occupied flush selector witness missing");
      flush=1; tick();
      if({candidate.block_start_index,candidate.block_exponent}!==69'b0 ||
         candidate.private_block_metadata_read_ahead.use_speculative!==0)
        $fatal(1,"metadata flush failed");
      if(selected) metadata_flush_one=metadata_flush_one+1;
      else metadata_flush_zero=metadata_flush_zero+1;
    end
    for(kind=0;kind<2;kind=kind+1) begin
      reset_epoch(); output_ready=1; input_valid=1; input_bin_index=0;
      input_last=kind ? 1'bz : 1'bx;
      input_block_start_index=64'h8070605040302010; input_block_exponent=9;
      #1;
      if(candidate.protocol_error_now!==1'bx || candidate.input_accept!==1)
        $fatal(1,"metadata unknown first framing precondition missing");
      tick();
      if(candidate.output_valid!==1 || candidate.protocol_fault!==0 ||
         candidate.block_start_index!==64'h8070605040302010 || candidate.block_exponent!==9)
        $fatal(1,"metadata procedural unknown framing branch changed");
      metadata_unknown_framing=metadata_unknown_framing+1;
    end
    // Malformed first TLAST and ordinal must not expose the speculative tuple.
    for(kind=0;kind<2;kind=kind+1) begin
      reset_epoch(); output_ready=1; input_valid=1;
      input_bin_index=kind ? 0 : 1; input_last=kind ? 1 : 0;
      input_block_start_index=64'h8000000000000001; input_block_exponent=31;
      tick();
      if(candidate.protocol_fault!==1 || candidate.sequence_error_pulse!==1 ||
         candidate.output_valid!==0 ||
         {candidate.block_start_index,candidate.block_exponent}!==69'b0)
        $fatal(1,"metadata malformed first publication escaped");
      metadata_malformed_first=metadata_malformed_first+1;
    end
    reset_epoch(); metadata_walk(64'hffffffffffffff38,5'h1f);
    if(candidate.expected_next_block_start!==64'hf7 ||
       candidate.at_block_start!==1 || candidate.have_previous_block!==1)
      $fatal(1,"metadata modulo-64 plus447 witness missing");
    input_valid=0; input_bin_index=0; input_last=0;
    input_block_start_index=64'h80000000000000f7; input_block_exponent=0; tick();
    if(candidate.block_start_index!==64'hffffffffffffff38 || candidate.protocol_fault!==0)
      $fatal(1,"metadata next-first invalid bubble changed old tuple");
    metadata_walk(64'hf7,5'h02);
    input_valid=1; input_bin_index=0; input_last=0;
    input_block_start_index=64'h80000000000002b6; input_block_exponent=0; tick();
    if(candidate.metadata_error_pulse!==1 || candidate.protocol_fault!==1 ||
       candidate.block_start_index!==64'hf7 || candidate.block_exponent!==2)
      $fatal(1,"metadata next-block bit63 mismatch escaped");
    if(metadata_fault_bits!=69 || metadata_unknown_first!=2 || metadata_bubbles!=3 ||
       metadata_flush_zero!=1 || metadata_flush_one!=1 || metadata_wrap_blocks!=2 ||
       metadata_malformed_first!=2 || metadata_unknown_framing!=2)
      $fatal(1,"missing metadata extra coverage");
    $display("ROM_METADATA_EXTRA_PASS bit_faults=%0d unknown_first=%0d invalid_bubbles=%0d flush_zero=%0d flush_one=%0d wrap_blocks=%0d malformed_first=%0d",metadata_fault_bits,metadata_unknown_first,metadata_bubbles,metadata_flush_zero,metadata_flush_one,metadata_wrap_blocks,metadata_malformed_first);
    $display("ROM_METADATA_FOUR_STATE_PASS unknown_framing=%0d",metadata_unknown_framing);
  end
endtask

  integer n, bit_index;
  initial begin
    if($bits(`VIEW(original))>1024) $fatal(1,"comparison truncation");
    $readmemh("kernel.mem",words);
    #1; reset_epoch(); block(64'h123456780,5'd3,0); block(64'h12345693f,5'd7,1);
    for(bit_index=0;bit_index<64;bit_index=bit_index+1) begin
      reset_epoch(); output_ready=1; input_valid=1; input_bin_index=0;
      input_last=0; input_block_start_index=64'h123456780; input_block_exponent=3; tick();
      input_bin_index=1; input_block_start_index=64'h123456780^(64'b1<<bit_index); tick();
      if(candidate.protocol_fault!==1) $fatal(1,"metadata fault missing");
      input_valid=0; input_bin_index=500; tick(); faults=faults+1;
    end
    // Four-state metadata on an otherwise accepted beat exercises the exact
    // original procedural 'if(error) ... else lookup' behavior, not sanitization.
    for(n=0;n<2;n=n+1) begin
      reset_epoch(); output_ready=1; input_valid=1; input_bin_index=0;
      input_last=0; input_block_start_index=64'h123; input_block_exponent=3; tick();
      input_bin_index=1; input_block_start_index=n ? 64'bz : 64'bx; tick();
      if(candidate.output_kernel_word!==words[1]) $fatal(1,"unknown metadata branch changed");
      unknowns=unknowns+1;
    end
    occupied_unknown_ready_case(1'bx);
    occupied_unknown_ready_case(1'bz);
    flush_occupied_selector(0);
    flush_occupied_selector(1);
    metadata_extra_cases();
    // Deterministic unconstrained input stream, explicitly not all healthy jobs.
    for(n=0;n<20000;n=n+1) begin
      rng=step(rng); resetn=(n%137!=0); flush=(n%193==0);
      input_valid=rng[0]; output_ready=rng[1]; input_bin_index=rng[10:2];
      input_last=rng[11]; input_block_exponent=rng[16:12];
      input_block_start_index={rng,~rng};
      case(n%97)
        1: input_valid=1'bx;
        2: input_valid=1'bz;
        3: output_ready=1'bx;
        4: output_ready=1'bz;
        5: input_bin_index=9'bx;
        6: input_last=1'bz;
        7: flush=1'bx;
        8: resetn=1'bx;
      endcase
      tick();
    end
    reset_epoch(); block(64'h2468,5'd2,1); flush=1; tick(); flush=0; tick();
    if(healthy!=3 || faults!=64 || unknowns!=2 || stalls==0)
      $fatal(1,"missing coverage");
    if(occupied_unknown_ready!=2 || flush_selector_zero!=1 || flush_selector_one!=1)
      $fatal(1,"missing directed active four-state/flush coverage");
    $display("ROM_READ_AHEAD_ACTIVE_BOUNDARIES_PASS occupied_unknown_ready=%0d flush_selector_zero=%0d flush_selector_one=%0d",occupied_unknown_ready,flush_selector_zero,flush_selector_one);
    $display("ROM_READ_AHEAD_OFFLINE_PASS width=%0d balanced=%0d scratch=%0d healthy=%0d faults=%0d unknown_metadata=%0d stalls=%0d cycles=%0d checks=%0d",WIDTH,BALANCED,SCRATCH,healthy,faults,unknowns,stalls,cycles,checks);
    $finish(0);
  end
  initial begin #1000000; $fatal(1,"watchdog"); end
endmodule

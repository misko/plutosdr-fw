module guard;reg[7:0]fault_reasons=0;endmodule
module design;
for(genvar n=0;n<2;n=n+1)begin:owners guard result_guard();end
endmodule
module tb;design dut();reg choose=0;
for(genvar n=0;n<2;n=n+1)begin:pulse_guard_reference guard original();end
initial begin if(choose==0)begin force dut.owners[0].result_guard.fault_reasons=8'h04;force pulse_guard_reference[0].original.fault_reasons=8'h04; end
else begin force dut.owners[1].result_guard.fault_reasons=8'h04;force pulse_guard_reference[1].original.fault_reasons=8'h04; end
if(choose==0)begin release dut.owners[0].result_guard.fault_reasons;release pulse_guard_reference[0].original.fault_reasons; end
else begin release dut.owners[1].result_guard.fault_reasons;release pulse_guard_reference[1].original.fault_reasons; end $finish;end endmodule
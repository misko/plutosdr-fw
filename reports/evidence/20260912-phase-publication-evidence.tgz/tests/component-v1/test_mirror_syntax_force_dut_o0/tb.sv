module child;wire output_replay_accept=1;endmodule
module tb;child dut();wire phase_original_accept=1;initial begin begin force dut.output_replay_accept=1'b0;force phase_original_accept=1'b0; end begin release dut.output_replay_accept;release phase_original_accept; end begin end $finish;end endmodule

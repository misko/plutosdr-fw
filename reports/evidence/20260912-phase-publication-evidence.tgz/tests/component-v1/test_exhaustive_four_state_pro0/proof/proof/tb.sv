
module tb;
reg preparing,fast_running,other_fault;
reg[5:0]events;
wire[5:0]preflight_events_now=fast_running && preparing ? events : 6'b0;
wire preparation_fault_now=|preflight_events_now;
wire old_accept=!preparing && !(other_fault || preparation_fault_now);
wire new_accept=!preparing && !other_fault;
function four(input integer n);
case(n&3)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
integer n,b,active_faults=0;
initial begin
 for(n=0;n<262144;n=n+1)begin
  preparing=four(n);fast_running=four(n>>2);other_fault=four(n>>4);
  for(b=0;b<6;b=b+1)events[b]=four(n>>(6+2*b));
  #1;
  if(old_accept!==new_accept)$fatal(1,"phase equivalence differs n=%0d",n);
  if(preparing===1 && preparation_fault_now===1)begin
   if(new_accept!==0)$fatal(1,"preflight permitted publication");
   active_faults=active_faults+1;
  end
 end
 if(active_faults==0)$fatal(1,"vacuous active preflight");
 $display("PUBLICATION_PHASE_PROOF_PASS vectors=262144 active_faults=%0d",active_faults);$finish;
end
endmodule

module tb;
 function value(input integer n);
   case(n&3) 0:value=0;1:value=1;2:value=1'bx;3:value=1'bz;endcase
 endfunction

 reg resetn=0,parent_fault=0,scalar_fault=0,q=0,p=0,good=0,command_valid=0,response_ready=0;
 wire fault,local_fault;
 starlink_pss_descriptor_local_fault dut(
   .clk(1'b0),.resetn(resetn),.abort_epoch(parent_fault||scalar_fault),
   .command_valid(command_valid),.response_ready(response_ready),
   .command_opcode(2'b0),.command_tag(32'b0),.command_descriptor(70'b0),
   .lookup_valid(1'b0),.lookup_tag(32'b0),.fault(fault),.local_fault(local_fault));
 wire original_parent=resetn&&(parent_fault||scalar_fault||fault);
 wire local_parent=resetn&&(parent_fault||scalar_fault||local_fault);
 integer n;
 initial begin
   force dut.fault_q=q;force dut.pending=p;force dut.pending_good=good;
   // Parent fault register is known after coordinated reset; scalar_fault
   // is built entirely from case-inequality checks and is always known.
   for(n=0;n<16384;n=n+1)begin
     parent_fault=n&1;scalar_fault=(n>>1)&1;resetn=value(n>>2);
     q=value(n>>4);p=value(n>>6);good=value(n>>8);
     command_valid=value(n>>10);response_ready=value(n>>12);
     #1;if(original_parent!==local_parent)$fatal(1,"local fault absorption changed");
   end
   $display("ABSORPTION_PASS vectors=16384");$finish;
 end
endmodule
// SPDX-License-Identifier: GPL-2.0
// Experimental writer-clock adapter: staged descriptor commands + one real
// explicit-commit payload bank. This is not the FFT completion validator.
// complete_* MUST describe an independently validated, fully privately written
// block, including its exact saved final word. No other writer may touch that
// bank from complete acceptance until publication_busy falls after release.
// replay_* exclusively drives that bank's final position/TLAST. replay_ready
// may indicate PRIVATE consumption if the caller separately gates actual
// authorization with current faults and aborts the epoch on a veto. The real
// bank request transition, never this private receipt, proves publication.
// bank_request/ack must be that bank's writer-domain ownership observations.
// All tag holders and both bank clock domains MUST share coordinated reset.
`timescale 1ns/1ps
module starlink_pss_completion_mailbox_stage #(
  parameter integer DESCRIPTOR_WIDTH=70, TAG_WIDTH=32, DATA_WIDTH=36,
  parameter integer PRIVATE_FINAL_CAPTURE=0
) (
  input wire clk, resetn, abort_epoch,
  input wire allocate_valid,
  output wire allocate_ready,
  input wire [DESCRIPTOR_WIDTH-1:0] allocate_descriptor,
  output wire allocated_valid,
  input wire allocated_ready,
  output reg [TAG_WIDTH-1:0] allocated_tag,
  input wire complete_valid,
  output wire complete_ready,
  input wire [TAG_WIDTH-1:0] complete_tag,
  input wire [DATA_WIDTH-1:0] complete_final_data,
  output wire replay_valid,
  input wire replay_ready,
  output wire [TAG_WIDTH-1:0] replay_tag,
  output wire [DATA_WIDTH-1:0] replay_data,
  input wire bank_request, bank_ack_sync, bank_fault,
  output wire publication_busy,
  output wire published_valid,
  output wire released_valid,
  output reg [TAG_WIDTH-1:0] released_tag,
  input wire lookup_valid,
  input wire [TAG_WIDTH-1:0] lookup_tag,
  output wire lookup_found, lookup_committed,
  output wire [DESCRIPTOR_WIDTH-1:0] lookup_descriptor,
  output wire [1:0] occupied, committed,
  output wire tags_exhausted, fault
);
  localparam [1:0] ALLOCATE=0, COMMIT=1, RELEASE=2;
  localparam [1:0] C_IDLE=0, C_SEND=1, C_RESPONSE=2;
  localparam [2:0] P_EMPTY=0, P_COMMIT=1, P_COMMIT_RESPONSE=2,
    P_REPLAY=3, P_ACK=4, P_RELEASE=5, P_RELEASE_RESPONSE=6;
  reg [1:0] command_state;
  reg [2:0] phase;
  reg [1:0] command_opcode;
  reg [TAG_WIDTH-1:0] command_tag, active_tag;
  reg [DESCRIPTOR_WIDTH-1:0] command_descriptor;
  reg [DATA_WIDTH-1:0] final_data;
  reg initial_request, fault_q, allocated_pending, released_pending;
  reg publication_seen, published_pending;
  // One-entry receipt: reserves/fixes payload immediately, sequences next edge.
  reg complete_pending;
  wire ledger_fault, ledger_local_fault, command_ready, response_valid;
  wire [1:0] response_opcode;
  wire [TAG_WIDTH-1:0] response_tag;
  wire scalar_fault = abort_epoch !== 1'b0 || bank_fault !== 1'b0 ||
    (allocate_valid !== 1'b0 && allocate_valid !== 1'b1) ||
    (allocated_ready !== 1'b0 && allocated_ready !== 1'b1) ||
    (complete_valid !== 1'b0 && complete_valid !== 1'b1) ||
    (replay_ready !== 1'b0 && replay_ready !== 1'b1);
  // Child abort is exactly scalar_fault || fault_q, already vetoed here.
  // Keep intrinsic ledger faults current, without re-importing that abort.
  assign fault = resetn && (fault_q || scalar_fault || ledger_local_fault);
  wire live = resetn && !fault;
  assign allocated_valid = live && allocated_pending;
  assign released_valid = live && released_pending;
  assign published_valid = live && published_pending;
  wire command_valid = live && command_state==C_SEND;
  wire response_ready = live && command_state==C_RESPONSE;
  // Never put a blocked third ALLOCATE into the serialized command port.
  // A held allocation result occupies only its return register, not this port.
  wire allocation_room = occupied!=2'b11 && !tags_exhausted && !allocated_valid;
  assign allocate_ready = live && !complete_pending && command_state==C_IDLE && allocation_room &&
    phase!=P_COMMIT && phase!=P_RELEASE;
  assign complete_ready = live && phase==P_EMPTY && !complete_pending &&
    ((bank_request===1'b0 && bank_ack_sync===1'b0) ||
     (bank_request===1'b1 && bank_ack_sync===1'b1));
  assign replay_valid = live && phase==P_REPLAY;
  assign replay_tag = active_tag;
  assign replay_data = final_data;
  assign publication_busy = phase!=P_EMPTY || complete_pending;

  starlink_pss_descriptor_local_fault #(.DESCRIPTOR_WIDTH(DESCRIPTOR_WIDTH),.TAG_WIDTH(TAG_WIDTH)) ledger (
    .clk(clk),.resetn(resetn),.abort_epoch(scalar_fault || fault_q),
    .command_valid(command_valid),.command_ready(command_ready),
    .command_opcode(command_opcode),.command_tag(command_tag),.command_descriptor(command_descriptor),
    .response_valid(response_valid),.response_ready(response_ready),
    .response_opcode(response_opcode),.response_tag(response_tag),
    .lookup_valid(lookup_valid),.lookup_tag(lookup_tag),.lookup_found(lookup_found),
    .lookup_committed(lookup_committed),.lookup_descriptor(lookup_descriptor),
    .occupied(occupied),.committed(committed),.tags_exhausted(tags_exhausted),.fault(ledger_fault),.local_fault(ledger_local_fault)
  );

  // Private payloads may track unvalidated/X inputs only while ownership is
  // empty. Acceptance still uses the original fault-qualified handshake and
  // captures these same inputs on that edge. Non-empty phase freezes them
  // through COMMIT, replay, publication and the real reader ACK/RELEASE.
  // Invalid replay payloads have no meaning. No public-valid gate is removed.
  wire capture_final_payload = PRIVATE_FINAL_CAPTURE ? (phase==P_EMPTY && !complete_pending) :
    (!fault && complete_valid && complete_ready);
  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      active_tag<=0;final_data<=0;initial_request<=0;
    end else if (capture_final_payload) begin
      active_tag<=complete_tag;final_data<=complete_final_data;
      initial_request<=bank_request;
    end
  end

  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      command_state<=C_IDLE;phase<=P_EMPTY;command_opcode<=0;command_tag<=0;
      command_descriptor<=0;
      fault_q<=0;allocated_pending<=0;allocated_tag<=0;released_pending<=0;released_tag<=0;
      publication_seen<=0;published_pending<=0;complete_pending<=0;
    end else if (fault) begin
      fault_q<=1;allocated_pending<=0;released_pending<=0;
      published_pending<=0;
    end else begin
      released_pending<=0;
      published_pending<=0;
      if (allocated_valid && allocated_ready) allocated_pending<=0;
      if (complete_valid && complete_ready) begin
        complete_pending<=1;publication_seen<=0;
      end
      // Fault holds this private receipt occupied; reset alone purges it.
      // No publication/release is authorized merely by consuming the receipt.
      if (complete_pending) begin phase<=P_COMMIT;complete_pending<=0;end
      if (phase==P_REPLAY && replay_ready) phase<=P_ACK;
      // P_ACK is an observation boundary, not proof of publication. Reject a
      // missing actual request transition before notification or RELEASE.
      // Equality while idle, or merely a successful COMMIT response, is NOT ACK.
      if (phase==P_ACK) begin
        if (bank_request !== !initial_request ||
            (bank_ack_sync !== 1'b0 && bank_ack_sync !== 1'b1)) fault_q<=1;
        else begin
          if (!publication_seen) begin publication_seen<=1;published_pending<=1;end
          if (bank_ack_sync==bank_request) phase<=P_RELEASE;
        end
      end
      case (command_state)
        C_IDLE: begin
          // Payload release/completion take priority over new allocation.
          if (phase==P_RELEASE || phase==P_COMMIT) begin
            command_opcode<=phase==P_RELEASE ? RELEASE : COMMIT;
            command_tag<=active_tag;command_descriptor<=0;command_state<=C_SEND;
            phase<=phase==P_RELEASE ? P_RELEASE_RESPONSE : P_COMMIT_RESPONSE;
          end else if (allocate_valid && allocate_ready) begin
            command_opcode<=ALLOCATE;command_tag<=0;
            command_descriptor<=allocate_descriptor;command_state<=C_SEND;
          end
        end
        C_SEND: if (command_ready) command_state<=C_RESPONSE;
        C_RESPONSE: if (response_valid) begin
          command_state<=C_IDLE;
          if (response_opcode!==command_opcode ||
              (command_opcode!=ALLOCATE && response_tag!==active_tag)) fault_q<=1;
          else case (command_opcode)
            ALLOCATE: begin allocated_pending<=1;allocated_tag<=response_tag;end
            COMMIT: phase<=P_REPLAY;
            RELEASE: begin phase<=P_EMPTY;released_pending<=1;released_tag<=response_tag;end
            default: fault_q<=1;
          endcase
        end
        default: fault_q<=1;
      endcase
    end
  end
endmodule
// SPDX-License-Identifier: GPL-2.0
// Experimental serialized control plane; sample/FFT processing is independent.
`timescale 1ns/1ps
module starlink_pss_descriptor_local_fault #(
  parameter integer DESCRIPTOR_WIDTH=70, TAG_WIDTH=32
) (
  input wire clk, resetn, abort_epoch,
  input wire command_valid,
  output wire command_ready,
  input wire [1:0] command_opcode,
  input wire [TAG_WIDTH-1:0] command_tag,
  input wire [DESCRIPTOR_WIDTH-1:0] command_descriptor,
  output wire response_valid,
  input wire response_ready,
  output reg [1:0] response_opcode,
  output reg [TAG_WIDTH-1:0] response_tag,
  input wire lookup_valid,
  input wire [TAG_WIDTH-1:0] lookup_tag,
  output wire lookup_found, lookup_committed,
  output wire [DESCRIPTOR_WIDTH-1:0] lookup_descriptor,
  output wire [1:0] occupied, committed,
  output wire tags_exhausted, fault,
  output wire local_fault
);
  localparam [1:0] ALLOCATE=0, COMMIT=1, RELEASE=2;
  localparam [1:0] FREE=0, OWNED=1, PUBLISHED=2;
  reg [1:0] state0, state1;
  reg [TAG_WIDTH-1:0] tag0, tag1, next_tag;
  reg [DESCRIPTOR_WIDTH-1:0] descriptor0, descriptor1;
  reg exhausted, fault_q, response_pending;
  reg pending, pending_good, pending_slot;
  reg [1:0] pending_opcode;
  reg [TAG_WIDTH-1:0] pending_tag;
  reg [DESCRIPTOR_WIDTH-1:0] pending_descriptor;

  initial if (TAG_WIDTH<1 || DESCRIPTOR_WIDTH<1)
    $fatal(1,"positive descriptor/tag widths required");

  wire tag_match0 = command_tag === tag0;
  wire tag_match1 = command_tag === tag1;
  wire commit0 = state0==OWNED && tag_match0;
  wire commit1 = state1==OWNED && tag_match1;
  wire release0 = state0==PUBLISHED && tag_match0;
  wire release1 = state1==PUBLISHED && tag_match1;
  // Scalar front-end controls only. Wide tag validation ends at pending_good.
  wire abort_now = abort_epoch !== 1'b0 ||
    (command_valid !== 1'b0 && command_valid !== 1'b1) ||
    (response_ready !== 1'b0 && response_ready !== 1'b1);
  assign fault = resetn && (fault_q || abort_now || (pending && !pending_good));
  // Caller retains abort_epoch as an immediate veto. Do not echo it through
  // another hierarchy of fault reductions; every intrinsic cause stays live.
  assign local_fault = resetn && (fault_q || (pending && !pending_good) ||
    (command_valid !== 1'b0 && command_valid !== 1'b1) ||
    (response_ready !== 1'b0 && response_ready !== 1'b1));
  wire live = resetn && !fault;
  assign command_ready = resetn && !abort_now && !fault_q && !pending && !response_pending &&
    (command_opcode !== ALLOCATE || (!exhausted && (state0==FREE || state1==FREE)));
  assign response_valid = live && response_pending;
  assign tags_exhausted = exhausted;
  assign occupied = {state1!=FREE,state0!=FREE};
  assign committed = live ? {state1==PUBLISHED,state0==PUBLISHED} : 2'b0;
  wire lookup0 = state0!=FREE && lookup_tag === tag0;
  wire lookup1 = state1!=FREE && lookup_tag === tag1;
  assign lookup_found = live && lookup_valid === 1'b1 && (lookup0 || lookup1);
  assign lookup_committed = lookup_found &&
    ((lookup0 && state0==PUBLISHED) || (lookup1 && state1==PUBLISHED));
  assign lookup_descriptor = lookup_found ? (lookup0 ? descriptor0 : descriptor1) : {DESCRIPTOR_WIDTH{1'b0}};

  // At most one command or unconsumed response exists. No allocation/commit/
  // release can alter either slot between validation and applying its result.
  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      state0<=FREE;state1<=FREE;tag0<=0;tag1<=0;next_tag<=0;
      descriptor0<=0;descriptor1<=0;exhausted<=0;fault_q<=0;
      response_pending<=0;response_opcode<=0;response_tag<=0;
      pending<=0;pending_good<=0;pending_slot<=0;pending_opcode<=0;
      pending_tag<=0;pending_descriptor<=0;
    end else if (abort_now || fault_q) begin
      fault_q<=1;pending<=0;response_pending<=0;
    end else begin
      if (response_pending && response_ready) response_pending<=0;
      if (pending) begin
        pending<=0;
        if (!pending_good) begin fault_q<=1;response_pending<=0;end
        else begin
          response_pending<=1;response_opcode<=pending_opcode;response_tag<=pending_tag;
          case (pending_opcode)
            ALLOCATE: begin
              if (!pending_slot) begin state0<=OWNED;tag0<=pending_tag;descriptor0<=pending_descriptor;end
              else begin state1<=OWNED;tag1<=pending_tag;descriptor1<=pending_descriptor;end
              if (&next_tag) exhausted<=1;
              else next_tag<=next_tag+1'b1;
            end
            COMMIT: if (!pending_slot) state0<=PUBLISHED;else state1<=PUBLISHED;
            RELEASE: if (!pending_slot) state0<=FREE;else state1<=FREE;
            default: begin fault_q<=1;response_pending<=0;end
          endcase
        end
      end else if (command_valid && command_ready) begin
        pending<=1;pending_opcode<=command_opcode;
        pending_tag<=command_tag;pending_descriptor<=command_descriptor;
        pending_slot<=0;pending_good<=0;
        case (command_opcode)
          ALLOCATE: begin
            pending_good<=1;pending_slot<=state0!=FREE;pending_tag<=next_tag;
          end
          COMMIT: begin pending_good<=commit0 || commit1;pending_slot<=!commit0;end
          RELEASE: begin pending_good<=release0 || release1;pending_slot<=!release0;end
          default: pending_good<=0;
        endcase
      end
    end
  end
endmodule
// SPDX-License-Identifier: GPL-2.0
// Experimental writer-clock adapter: staged descriptor commands + one real
// explicit-commit payload bank. This is not the FFT completion validator.
// complete_* MUST describe an independently validated, fully privately written
// block, including its exact saved final word. No other writer may touch that
// bank from complete acceptance until publication_busy falls after release.
// replay_* exclusively drives that bank's final position/TLAST. replay_ready
// may indicate PRIVATE consumption if the caller separately gates actual
// authorization with current faults and aborts the epoch on a veto. The real
// bank request transition, never this private receipt, proves publication.
// bank_request/ack must be that bank's writer-domain ownership observations.
// All tag holders and both bank clock domains MUST share coordinated reset.
`timescale 1ns/1ps
module original_completion_mailbox #(
  parameter integer DESCRIPTOR_WIDTH=70, TAG_WIDTH=32, DATA_WIDTH=36,
  parameter integer PRIVATE_FINAL_CAPTURE=0
) (
  input wire clk, resetn, abort_epoch,
  input wire allocate_valid,
  output wire allocate_ready,
  input wire [DESCRIPTOR_WIDTH-1:0] allocate_descriptor,
  output wire allocated_valid,
  input wire allocated_ready,
  output reg [TAG_WIDTH-1:0] allocated_tag,
  input wire complete_valid,
  output wire complete_ready,
  input wire [TAG_WIDTH-1:0] complete_tag,
  input wire [DATA_WIDTH-1:0] complete_final_data,
  output wire replay_valid,
  input wire replay_ready,
  output wire [TAG_WIDTH-1:0] replay_tag,
  output wire [DATA_WIDTH-1:0] replay_data,
  input wire bank_request, bank_ack_sync, bank_fault,
  output wire publication_busy,
  output wire published_valid,
  output wire released_valid,
  output reg [TAG_WIDTH-1:0] released_tag,
  input wire lookup_valid,
  input wire [TAG_WIDTH-1:0] lookup_tag,
  output wire lookup_found, lookup_committed,
  output wire [DESCRIPTOR_WIDTH-1:0] lookup_descriptor,
  output wire [1:0] occupied, committed,
  output wire tags_exhausted, fault
);
  localparam [1:0] ALLOCATE=0, COMMIT=1, RELEASE=2;
  localparam [1:0] C_IDLE=0, C_SEND=1, C_RESPONSE=2;
  localparam [2:0] P_EMPTY=0, P_COMMIT=1, P_COMMIT_RESPONSE=2,
    P_REPLAY=3, P_ACK=4, P_RELEASE=5, P_RELEASE_RESPONSE=6;
  reg [1:0] command_state;
  reg [2:0] phase;
  reg [1:0] command_opcode;
  reg [TAG_WIDTH-1:0] command_tag, active_tag;
  reg [DESCRIPTOR_WIDTH-1:0] command_descriptor;
  reg [DATA_WIDTH-1:0] final_data;
  reg initial_request, fault_q, allocated_pending, released_pending;
  reg publication_seen, published_pending;
  // One-entry receipt: reserves/fixes payload immediately, sequences next edge.
  reg complete_pending;
  wire ledger_fault, command_ready, response_valid;
  wire [1:0] response_opcode;
  wire [TAG_WIDTH-1:0] response_tag;
  wire scalar_fault = abort_epoch !== 1'b0 || bank_fault !== 1'b0 ||
    (allocate_valid !== 1'b0 && allocate_valid !== 1'b1) ||
    (allocated_ready !== 1'b0 && allocated_ready !== 1'b1) ||
    (complete_valid !== 1'b0 && complete_valid !== 1'b1) ||
    (replay_ready !== 1'b0 && replay_ready !== 1'b1);
  assign fault = resetn && (fault_q || scalar_fault || ledger_fault);
  wire live = resetn && !fault;
  assign allocated_valid = live && allocated_pending;
  assign released_valid = live && released_pending;
  assign published_valid = live && published_pending;
  wire command_valid = live && command_state==C_SEND;
  wire response_ready = live && command_state==C_RESPONSE;
  // Never put a blocked third ALLOCATE into the serialized command port.
  // A held allocation result occupies only its return register, not this port.
  wire allocation_room = occupied!=2'b11 && !tags_exhausted && !allocated_valid;
  assign allocate_ready = live && !complete_pending && command_state==C_IDLE && allocation_room &&
    phase!=P_COMMIT && phase!=P_RELEASE;
  assign complete_ready = live && phase==P_EMPTY && !complete_pending &&
    ((bank_request===1'b0 && bank_ack_sync===1'b0) ||
     (bank_request===1'b1 && bank_ack_sync===1'b1));
  assign replay_valid = live && phase==P_REPLAY;
  assign replay_tag = active_tag;
  assign replay_data = final_data;
  assign publication_busy = phase!=P_EMPTY || complete_pending;

  starlink_pss_descriptor_commands #(.DESCRIPTOR_WIDTH(DESCRIPTOR_WIDTH),.TAG_WIDTH(TAG_WIDTH)) ledger (
    .clk(clk),.resetn(resetn),.abort_epoch(scalar_fault || fault_q),
    .command_valid(command_valid),.command_ready(command_ready),
    .command_opcode(command_opcode),.command_tag(command_tag),.command_descriptor(command_descriptor),
    .response_valid(response_valid),.response_ready(response_ready),
    .response_opcode(response_opcode),.response_tag(response_tag),
    .lookup_valid(lookup_valid),.lookup_tag(lookup_tag),.lookup_found(lookup_found),
    .lookup_committed(lookup_committed),.lookup_descriptor(lookup_descriptor),
    .occupied(occupied),.committed(committed),.tags_exhausted(tags_exhausted),.fault(ledger_fault)
  );

  // Private payloads may track unvalidated/X inputs only while ownership is
  // empty. Acceptance still uses the original fault-qualified handshake and
  // captures these same inputs on that edge. Non-empty phase freezes them
  // through COMMIT, replay, publication and the real reader ACK/RELEASE.
  // Invalid replay payloads have no meaning. No public-valid gate is removed.
  wire capture_final_payload = PRIVATE_FINAL_CAPTURE ? (phase==P_EMPTY && !complete_pending) :
    (!fault && complete_valid && complete_ready);
  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      active_tag<=0;final_data<=0;initial_request<=0;
    end else if (capture_final_payload) begin
      active_tag<=complete_tag;final_data<=complete_final_data;
      initial_request<=bank_request;
    end
  end

  always @(posedge clk or negedge resetn) begin
    if (!resetn) begin
      command_state<=C_IDLE;phase<=P_EMPTY;command_opcode<=0;command_tag<=0;
      command_descriptor<=0;
      fault_q<=0;allocated_pending<=0;allocated_tag<=0;released_pending<=0;released_tag<=0;
      publication_seen<=0;published_pending<=0;complete_pending<=0;
    end else if (fault) begin
      fault_q<=1;allocated_pending<=0;released_pending<=0;
      published_pending<=0;
    end else begin
      released_pending<=0;
      published_pending<=0;
      if (allocated_valid && allocated_ready) allocated_pending<=0;
      if (complete_valid && complete_ready) begin
        complete_pending<=1;publication_seen<=0;
      end
      // Fault holds this private receipt occupied; reset alone purges it.
      // No publication/release is authorized merely by consuming the receipt.
      if (complete_pending) begin phase<=P_COMMIT;complete_pending<=0;end
      if (phase==P_REPLAY && replay_ready) phase<=P_ACK;
      // P_ACK is an observation boundary, not proof of publication. Reject a
      // missing actual request transition before notification or RELEASE.
      // Equality while idle, or merely a successful COMMIT response, is NOT ACK.
      if (phase==P_ACK) begin
        if (bank_request !== !initial_request ||
            (bank_ack_sync !== 1'b0 && bank_ack_sync !== 1'b1)) fault_q<=1;
        else begin
          if (!publication_seen) begin publication_seen<=1;published_pending<=1;end
          if (bank_ack_sync==bank_request) phase<=P_RELEASE;
        end
      end
      case (command_state)
        C_IDLE: begin
          // Payload release/completion take priority over new allocation.
          if (phase==P_RELEASE || phase==P_COMMIT) begin
            command_opcode<=phase==P_RELEASE ? RELEASE : COMMIT;
            command_tag<=active_tag;command_descriptor<=0;command_state<=C_SEND;
            phase<=phase==P_RELEASE ? P_RELEASE_RESPONSE : P_COMMIT_RESPONSE;
          end else if (allocate_valid && allocate_ready) begin
            command_opcode<=ALLOCATE;command_tag<=0;
            command_descriptor<=allocate_descriptor;command_state<=C_SEND;
          end
        end
        C_SEND: if (command_ready) command_state<=C_RESPONSE;
        C_RESPONSE: if (response_valid) begin
          command_state<=C_IDLE;
          if (response_opcode!==command_opcode ||
              (command_opcode!=ALLOCATE && response_tag!==active_tag)) fault_q<=1;
          else case (command_opcode)
            ALLOCATE: begin allocated_pending<=1;allocated_tag<=response_tag;end
            COMMIT: phase<=P_REPLAY;
            RELEASE: begin phase<=P_EMPTY;released_pending<=1;released_tag<=response_tag;end
            default: fault_q<=1;
          endcase
        end
        default: fault_q<=1;
      endcase
    end
  end
endmodule

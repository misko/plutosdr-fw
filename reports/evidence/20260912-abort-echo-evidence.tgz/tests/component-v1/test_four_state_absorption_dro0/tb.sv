module tb;
 function value(input integer n);
   case(n&3) 0:value=0;1:value=1;2:value=1'bx;3:value=1'bz;endcase
 endfunction

 reg resetn=0,g=0,b=0,input_valid=0,output_ready=0,q=0;
 wire fault,local_fault;
 starlink_pss_identity_local_fault dut(
   .clk(1'b0),.resetn(resetn),.abort_epoch(g||b),.local_abort_epoch(b),
   .input_valid(input_valid),.output_ready(output_ready),
   .input_data(36'b0),.input_position(9'b0),.input_last(1'b0),
   .input_metadata(70'b0),.reference_metadata(70'b0),.refill_capacity(1'b0),
   .fault(fault),.local_fault(local_fault));
 wire original_parent=(g!==1'b0)||(fault!==1'b0);
 wire local_parent=(g!==1'b0)||(local_fault!==1'b0);
 integer n;
 initial begin
   force dut.fault_q=q;
   for(n=0;n<4096;n=n+1)begin
     resetn=value(n);g=value(n>>2);b=value(n>>4);
     input_valid=value(n>>6);output_ready=value(n>>8);q=value(n>>10);
     #1;if(original_parent!==local_parent)$fatal(1,"local fault absorption changed");
   end
   $display("ABSORPTION_PASS vectors=4096");$finish;
 end
endmodule
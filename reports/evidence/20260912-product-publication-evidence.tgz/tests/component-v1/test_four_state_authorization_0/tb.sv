
`timescale 1ns/1ps
module tb;
reg product_bank_valid,forward_committed,next_inverse,other_fault,handoff_bad,result_fault,guard_fault,forward_buffer_fault;
wire[1:0]guard_offered_local_fault={2{guard_fault}};
wire handoff_fault_now=!next_inverse && forward_committed && product_bank_valid && handoff_bad;
wire external_fault_now=other_fault || handoff_fault_now;
wire product_writer_fault=other_fault;
wire original_auth=forward_committed && !external_fault_now && !result_fault &&
    (guard_offered_local_fault === 2'b00) && (forward_buffer_fault === 1'b0);
wire candidate_auth=forward_committed && (product_bank_valid === 1'b0) &&
    !product_writer_fault && !result_fault &&
    (guard_offered_local_fault === 2'b00) && (forward_buffer_fault === 1'b0);
function four(input integer n);
case(n&3)0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
endfunction
integer n,checks=0,reader_vetoes=0;
initial begin
 for(n=0;n<65536;n=n+1)begin
  product_bank_valid=four(n);forward_committed=four(n>>2);
  next_inverse=four(n>>4);other_fault=four(n>>6);handoff_bad=four(n>>8);
  result_fault=four(n>>10);guard_fault=four(n>>12);forward_buffer_fault=four(n>>14);
  #1;
  if(product_bank_valid===0)begin
   if(original_auth!==candidate_auth)$fatal(1,"writer authorization mismatch");
   checks=checks+1;
  end else begin
   if(candidate_auth!==0)$fatal(1,"reader idle fence not fail closed");
   reader_vetoes=reader_vetoes+1;
  end
 end
 if(checks!=16384 || reader_vetoes!=49152)$fatal(1,"vacuous vectors");
 $display("PRODUCT_AUTHORIZATION_PASS vectors=65536 writer_checks=16384 reader_vetoes=49152");$finish;
end
endmodule

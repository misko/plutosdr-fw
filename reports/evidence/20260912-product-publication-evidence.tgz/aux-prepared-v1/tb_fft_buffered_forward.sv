// Actual generated FFT + sealed forward RAM + real kernel/product/inverse path.
// Separate from reference-topology equivalence campaigns. No RF/board claim.
`timescale 1ns/1ps
`default_nettype none
module tb;
  reg auxiliary_active=0;
  reg clk=0,fft_clk=0,resetn=0,fft_resetn=0;
  always #2.857143 fft_clk=~fft_clk;
  initial begin #1.3;forever #5 clk=~clk;end
  reg input_valid=0,input_last=0,output_ready=0;
  reg [35:0] input_data=0;
  reg [8:0] input_position=0;
  reg [63:0] input_block_start=0,context_start_base=1000;
  wire input_ready,output_valid,output_last,fault;
  wire [35:0] output_data;
  wire [8:0] output_position;
  wire [74:0] output_metadata;
  starlink_pss_fft_product_publication_impl #(.REGISTERED_SCHEDULING(1),
    .BOUNDARY_ROUND_SAT(1),.REGISTER_OPERANDS(1),.LOCAL_FIRST_ADMISSION(1),
    .PRIVATE_DESCRIPTOR_OFFER(1),.CLOSED_INPUT_CUTOVER(1),
    .INPUT_OFFER_FAULT_SUMMARY(1),.CONTEXTUAL_DESTINATION_SUMMARY(1),
    .REPLAY_QUIET_PUBLICATION(1),.SPLIT_PREFLIGHT_IDENTITY(1),
    .MONOTONIC_OUTER_RESET(1),.PARALLEL_KERNEL_READY(1),.PRIVATE_QUARANTINE_OFFER(1)) dut(.*);
  reg [31:0] samples[0:1405];
  reg [35:0] forwards[0:1535],products[0:1535],inverses[0:1535];
  reg [4:0] fe[0:2],ie[0:2];
  integer mode=0,fast_cycles=0,slow_cycles=0,log_file;
  integer jobs=0,reads=0,inputs=0,raws=0,statuses=0,frames=0;
  integer fixture=0,phase=0,input_count=0,raw_position=0;
  integer product_words=0,inverse_words=0,replay_words=0;
  integer reservations=0,seals=0,done_count=0,forward_closes=0;
  integer publications=0,releases=0,captured=0,replayed=0;
  integer last_forward=-1,max_service=0,stall_cycles=0;
  integer block_index,word_index;
  reg sealed=0,old_request=0,stalled=0;
  reg [120:0] held_output;
  reg [35:0] expected;
  task automatic log_word(input string stream,input integer job,position,
                          input [47:0] data,input [9:0] exponent);
    $fdisplay(log_file,"%0d,%s,%0d,%0d,%012h,%03h",mode,stream,job,position,data,exponent);
  endtask
  always @(negedge clk) begin
    slow_cycles=slow_cycles+1;
    output_ready=auxiliary_active ? aux_ready : (mode%2==0 || slow_cycles%17<9);
  end
  always @(posedge clk) begin
    if(resetn && fft_resetn && !auxiliary_active) begin
      if(stalled && (!output_valid || held_output!=={output_data,output_position,output_last,output_metadata}))
        $fatal(1,"buffered stalled output changed");
      stalled=output_valid && !output_ready;
      held_output={output_data,output_position,output_last,output_metadata};
      if(stalled)stall_cycles=stall_cycles+1;
      if(output_valid && output_ready) begin
        if(reads>=1536 || output_position!==9'(reads%512) || output_last!==(reads%512==511) ||
           output_data!==inverses[reads] ||
           output_metadata!=={1'b1,64'(context_start_base+(reads/512)*447),fe[reads/512],ie[reads/512]})
          $fatal(1,"buffered native output mismatch read=%0d",reads);
        log_word("read",reads/512,reads%512,{12'b0,output_data},output_metadata[9:0]);
        reads=reads+1;
      end
    end else stalled=0;
  end
  always @(posedge fft_clk) begin
    fast_cycles=fast_cycles+1;
    if(dut.fast_running && !auxiliary_active) begin
      if(fault!==0 || dut.any_fast_fault!==0)
        $fatal(1,"buffered health cycle=%0d state=%0d F=%h I=%h bank=%b preflight=%h captured=%0d sealed=%b replay=%0d",
          fast_cycles,dut.state,dut.owners[0].result_guard.faults_now,
          dut.owners[1].result_guard.faults_now,dut.forward_buffer_fault,dut.preflight_events_now,captured,sealed,replayed);
      if(dut.forward_buffer_reserve && dut.forward_buffer_reserve_ready) begin
        if(dut.forward_buffer_owned || reservations!=forward_closes)
          $fatal(1,"buffer reservation before previous product ownership closed");
        reservations=reservations+1;captured=0;replayed=0;sealed=0;
      end
      if(dut.job_accept) begin
        if(dut.engine_metadata[68:5]<context_start_base || (dut.engine_metadata[68:5]-context_start_base)%447!=0)
          $fatal(1,"buffered admission timestamp");
        fixture=(dut.engine_metadata[68:5]-context_start_base)/447;phase=dut.next_inverse;
        if(fixture>2 || phase!==jobs[0])$fatal(1,"buffered job order");
        if(!phase && (!dut.forward_buffer_owned || reservations!=forward_closes+1))
          $fatal(1,"forward starts without reserved RAM");
        if(phase && (forward_closes!=fixture+1 || replayed!=512))
          $fatal(1,"inverse starts before real product acknowledgment");
        jobs=jobs+1;raw_position=0;input_count=0;
        if(!phase) begin
          if(last_forward>=0 && fast_cycles-last_forward>max_service)max_service=fast_cycles-last_forward;
          last_forward=fast_cycles;
        end
      end
      if(dut.core_input_valid && dut.core_input_ready) begin
        expected=phase ? products[fixture*512+input_count] :
          {samples[fixture*447+input_count][31:16],2'b0,samples[fixture*447+input_count][15:0],2'b0};
        if(input_count>=512 || dut.core_input_data!=={6'b0,expected[35:18],6'b0,expected[17:0]} ||
           dut.core_input_last!==(input_count==511))$fatal(1,"buffered core input");
        if(phase)log_word("inputI",fixture,input_count,dut.core_input_data,0);
        else log_word("inputF",fixture,input_count,dut.core_input_data,0);
        inputs=inputs+1;input_count=input_count+1;
      end
      if(dut.event_frame)frames=frames+1;
      if(dut.core_status_valid) begin
        if(raw_position!=2 || dut.core_status_data!=={3'b0,(phase?ie[fixture]:fe[fixture])})
          $fatal(1,"buffered core status");
        statuses=statuses+1;
      end
      if(dut.core_output_valid) begin
        expected=phase?inverses[fixture*512+raw_position]:forwards[fixture*512+raw_position];
        if(raw_position>=512 || input_count!=512 ||
           dut.core_output_data!=={{6{expected[35]}},expected[35:18],{6{expected[17]}},expected[17:0]} ||
           dut.core_output_user!=={3'b0,(phase?ie[fixture]:fe[fixture]),7'b0,9'(raw_position)} ||
           dut.core_output_last!==(raw_position==511))$fatal(1,"buffered raw FFT");
        if(phase)log_word("rawI",fixture,raw_position,dut.core_output_data,{5'b0,ie[fixture]});
        else begin
          log_word("rawF",fixture,raw_position,dut.core_output_data,{5'b0,fe[fixture]});
          if(!dut.forward_buffer_capture_ready || !dut.forward_buffer_owned || sealed)
            $fatal(1,"realtime forward output not captured");
          captured=captured+1;
        end
        raw_position=raw_position+1;raws=raws+1;
      end
      if(dut.guard_commit[0]) begin
        if(captured!=512 || sealed || !dut.forward_buffer_owned)
          $fatal(1,"seal without exactly one full owned capture");
        sealed=1;seals=seals+1;
      end
      if(dut.forward_buffer_valid) begin
        if(!sealed || captured!=512 || !dut.forward_buffer_owned)
          $fatal(1,"unsealed or unowned replay");
        if(dut.forward_buffer_data!==forwards[replay_words] ||
           dut.forward_buffer_position!==9'(replayed) || dut.forward_buffer_last!==(replayed==511) ||
           dut.forward_buffer_exponent!==fe[replay_words/512] ||
           dut.forward_buffer_descriptor!=={1'b0,64'(context_start_base+(replay_words/512)*447),5'b0})
          $fatal(1,"forward replay numerical/identity");
        if(dut.forward_buffer_read_ready)begin replay_words=replay_words+1;replayed=replayed+1;end
      end
      if(dut.forward_buffer_done) begin
        if(replayed!=512)$fatal(1,"buffer completion before final consume");
        done_count=done_count+1;
      end
      if(dut.completion_accept && !dut.held_phase) begin
        if(replayed!=512 || !dut.product_bank_valid || !dut.forward_buffer_owned || done_count!=forward_closes+1)
          $fatal(1,"forward close before sealed replay and product ownership");
        forward_closes=forward_closes+1;
      end
      if(dut.product_valid && dut.product_stage_ready) begin
        if(product_words>=1536 || {dut.product_q,dut.product_i}!==products[product_words] ||
           dut.product_position!==9'(product_words%512))$fatal(1,"buffered product");
        log_word("product",product_words/512,product_words%512,{12'b0,dut.product_q,dut.product_i},{5'b0,dut.product_exponent});
        product_words=product_words+1;
      end
      if(dut.guard_private_out[1] && dut.output_bank_ready) begin
        if(inverse_words>=1536 || dut.guard_return_data[1]!==inverses[inverse_words] ||
           dut.guard_return_position[1]!==9'(inverse_words%512))$fatal(1,"buffered private inverse");
        log_word("privateI",inverse_words/512,inverse_words%512,{12'b0,dut.guard_return_data[1]},dut.guard_return_metadata[1][9:0]);
        inverse_words=inverse_words+1;
      end
      if(dut.output_request!==old_request)begin old_request=dut.output_request;publications=publications+1;end
      if(dut.reader_release)begin
        if(reads!=(releases+1)*512 || dut.output_request!==dut.output_ack_sync)$fatal(1,"early reader release");
        releases=releases+1;
      end
    end
  end
  initial begin
    $readmemh("samples_ci16.mem",samples);$readmemh("forward_q17.mem",forwards);
    $readmemh("product_q17.mem",products);$readmemh("inverse_q17.mem",inverses);
    $readmemh("forward_exponents.mem",fe);$readmemh("inverse_exponents.mem",ie);
    log_file=$fopen("buffered_words.csv","w");
    $fdisplay(log_file,"context,stream,job,position,data,exponent");
    for(mode=0;mode<6;mode=mode+1)begin
      @(negedge fft_clk);resetn=0;fft_resetn=0;input_valid=0;
      repeat(10)@(negedge fft_clk);
      jobs=0;reads=0;inputs=0;raws=0;statuses=0;frames=0;
      product_words=0;inverse_words=0;replay_words=0;reservations=0;seals=0;
      done_count=0;forward_closes=0;publications=0;releases=0;old_request=0;
      captured=0;replayed=0;sealed=0;last_forward=-1;max_service=0;stall_cycles=0;
      context_start_base=mode>=4 ? 64'h5a5a5a5a5a5a5000 : mode>=2 ? 64'ha5a5a5a5a5a5a000 : 64'd1000;
      resetn=1;fft_resetn=1;
      for(block_index=0;block_index<3;block_index=block_index+1)begin
        for(word_index=0;word_index<512;word_index=word_index+1)begin
          @(negedge clk);input_valid=1;input_position=word_index;input_last=word_index==511;
          input_block_start=context_start_base+block_index*447;
          input_data={samples[block_index*447+word_index][31:16],2'b0,samples[block_index*447+word_index][15:0],2'b0};
          @(posedge clk);while(input_ready!==1)@(posedge clk);
          #0.001;
        end
        @(negedge clk);input_valid=0;
      end
      while(reads!=1536 || !dut.retained_reusable)@(negedge fft_clk);
      repeat(20)@(negedge fft_clk);
      if(jobs!=6 || inputs!=3072 || raws!=3072 || statuses!=6 || frames!=6 ||
         product_words!=1536 || inverse_words!=1536 || replay_words!=1536 ||
         reservations!=3 || seals!=3 || done_count!=3 || forward_closes!=3 || publications!=3 || releases!=3)
        $fatal(1,"buffered complete inventory");
      if(max_service>5215)$fatal(1,"buffered coarse service deadline cycles=%0d",max_service);
      if(mode%2==1 && stall_cycles<500)$fatal(1,"buffered output stall coverage");
      $display("BUFFERED_CONTEXT_PASS mode=%0d reads=1536 replay=1536 reservations=3 seals=3 closes=3 max_service=%0d stalls=%0d base=%016h",
        mode,max_service,stall_cycles,context_start_base);
    end
    auxiliary_active=1;
    run_retry_admission_boundaries;
    run_buffered_auxiliary;
    report_output_identity;
    report_registered_abort;
    report_local_fault;
    report_balanced_forward_identity;
    report_forward_private_status;
    report_parallel_product_identity;
    report_product_retirement_receipt;
    report_private_forward_descriptor;
    report_output_retirement_receipt;
    report_private_replay_sequence;
    report_retry_admission;
    report_pulse_guards;
    report_phase_publication;
    report_product_publication;
    $fclose(log_file);
    $display("BUFFERED_FFT_PASS contexts=6 seven_stream_words=64512 no_board_or_continuous_claim");$finish;
  end
  initial begin #6000000;$fatal(1,"buffered actual FFT timeout state=%0d capture=%0d replay=%0d seals=%0d fault=%b",dut.state,captured,replayed,seals,fault);end
// Fault injection on the actual FFT integration, not a substitute FFT model.
  integer aux_reads=0,aux_releases=0,aux_case=0,aux_side=0;
  integer aux_products=0,aux_replays=0,aux_stalls=0;
  reg aux_fault_expected=0,aux_ready=1;
  reg [35:0] aux_held_data;
  reg [8:0] aux_held_position;
  always @(posedge clk)if(auxiliary_active && resetn && fft_resetn)begin
    if(output_valid && output_ready)begin
      if(aux_fault_expected || aux_reads>=512 || output_data!==inverses[aux_reads] ||
         output_position!==9'(aux_reads) || output_last!==(aux_reads==511) ||
         output_metadata!=={1'b1,64'd1000,fe[0],ie[0]})$fatal(1,"auxiliary stale/numerically wrong output");
      aux_reads=aux_reads+1;
    end
  end
  always @(posedge fft_clk)if(auxiliary_active && dut.fast_running)begin
    if(!aux_fault_expected && (dut.any_fast_fault!==0 || fault!==0))
      $fatal(1,"auxiliary healthy fault case=%0d state=%0d guard=%h bank=%b",aux_case,dut.state,dut.owners[0].result_guard.faults_now,dut.forward_buffer_fault);
    if(dut.reader_release)begin
      if(aux_fault_expected || aux_reads!=512)$fatal(1,"auxiliary early reader release");
      aux_releases=aux_releases+1;
    end
    if(!aux_fault_expected && dut.forward_buffer_valid && dut.forward_buffer_read_ready)begin
      if(aux_replays>=512 || dut.forward_buffer_data!==forwards[aux_replays] ||
         dut.forward_buffer_position!==9'(aux_replays))$fatal(1,"auxiliary replay arithmetic");
      aux_replays=aux_replays+1;
    end
    if(!aux_fault_expected && dut.product_valid && dut.product_stage_ready)begin
      if(aux_products>=512 || {dut.product_q,dut.product_i}!==products[aux_products])$fatal(1,"auxiliary product arithmetic");
      aux_products=aux_products+1;
    end
  end
  task automatic aux_reset;
    begin
      @(negedge fft_clk);resetn=0;fft_resetn=0;input_valid=0;
      release dut.core_output_user;release dut.core_output_valid;release dut.core_status_valid;
      release dut.core_status_data;release dut.input_fault_now;release dut.forward_buffer_position;
      release dut.final_fence;release dut.kernel_ready;release replay_kernel_reference.input_ready;
      repeat(12)@(negedge fft_clk);
      aux_reads=0;aux_releases=0;aux_products=0;aux_replays=0;aux_fault_expected=0;aux_ready=1;
      resetn=1;fft_resetn=1;
      while(!dut.fast_running || !dut.slow_running)@(negedge fft_clk);
    end
  endtask
  task automatic aux_send;
    integer n;
    begin
      for(n=0;n<512;n=n+1)begin
        @(negedge clk);input_valid=1;input_position=n;input_last=n==511;input_block_start=1000;
        input_data={samples[n][31:16],2'b0,samples[n][15:0],2'b0};
        @(posedge clk);while(input_ready!==1)@(posedge clk);#0.001;
      end
      @(negedge clk);input_valid=0;
    end
  endtask
  task automatic aux_finish;
    begin
      while(aux_reads!=512 || !dut.retained_reusable)@(negedge fft_clk);
      repeat(30)@(negedge fft_clk);
      if(aux_releases!=1 || aux_products!=512 || aux_replays!=512 || fault!==0)
        $fatal(1,"auxiliary fresh inventory");
    end
  endtask
  task automatic aux_recover;
    begin aux_reset;aux_send;aux_finish;end
  endtask
  task automatic aux_fault(input integer which);
    begin
      aux_reset;aux_ready=0;aux_send;
      if(which<2)while(!dut.core_output_valid || dut.core_output_user[8:0]!=100)@(negedge fft_clk);
      else if(which==2)while(!dut.guard_commit[0])@(negedge fft_clk);
      else if(which==4)begin
        while(!dut.core_output_valid || !dut.core_output_last)@(negedge fft_clk);
        @(negedge fft_clk);
      end else while(!dut.forward_buffer_valid || dut.forward_buffer_position!=100)@(negedge fft_clk);
      aux_fault_expected=1;
      case(which)
        0:force dut.core_output_user[8:0]=9'd0;
        1:force dut.core_output_user[20:16]=5'd31;
        2:force dut.input_fault_now=1'b1;
        3:force dut.forward_buffer_position=9'd0;
        4:force dut.core_output_valid=1'b1;
        5:force dut.core_status_valid=1'b1;
      endcase
      @(negedge fft_clk);
      release dut.core_output_user;release dut.input_fault_now;release dut.forward_buffer_position;
      release dut.core_output_valid;release dut.core_status_valid;
      repeat(100)begin
        @(negedge fft_clk);
        if(dut.output_request!==0 || dut.product_bank_valid || dut.job_accept || dut.completion_accept || output_valid)
          $fatal(1,"fault allowed publication/reuse case=%0d",which);
      end
      if(fault!==1 || aux_reads!=0 || aux_releases!=0)$fatal(1,"fault not quarantined case=%0d",which);
      aux_recover;
      $display("BUFFERED_FAULT_PASS case=%0d rejected_publications=0 fresh_reads=512 fresh_releases=1",which);
    end
  endtask
  task automatic aux_reset_boundary(input integer boundary,side);
    begin
      aux_reset;aux_ready=0;
      if(boundary==1)force dut.final_fence=1'b0;
      aux_send;
      if(boundary==0)while(!dut.core_output_valid || dut.core_output_user[8:0]!=100)@(negedge fft_clk);
      else if(boundary==1)while(dut.forward_buffer.write_count!=512)@(negedge fft_clk);
      else begin
        while(!dut.forward_buffer_valid || dut.forward_buffer_position!=(boundary==2?100:511))@(negedge fft_clk);
        force dut.kernel_ready=1'b0;force replay_kernel_reference.input_ready=1'b0;
        repeat(7)@(negedge fft_clk);
      end
      if(side==0)resetn=0;else fft_resetn=0;
      #0.001;
      if(dut.fast_running!==0 || output_valid!==0)$fatal(1,"reset did not immediately fence output");
      repeat(12)@(negedge fft_clk);
      release dut.final_fence;release dut.kernel_ready;release replay_kernel_reference.input_ready;
      aux_reads=0;aux_releases=0;aux_products=0;aux_replays=0;
      resetn=1;fft_resetn=1;
      repeat(100)begin
        @(negedge fft_clk);
        if(output_valid || dut.output_request!==0 || dut.job_accept || dut.forward_buffer_valid || dut.forward_buffer_owned)
          $fatal(1,"reset retained stale ownership boundary=%0d side=%0d",boundary,side);
      end
      aux_recover;
      $display("BUFFERED_RESET_PASS boundary=%0d side=%0d stale_outputs=0 fresh_reads=512 fresh_releases=1",boundary,side);
    end
  endtask
  task automatic aux_delay(input integer which);
    integer n;
    begin
      aux_reset;
      if(which==0)force dut.core_status_valid=1'b0;
      aux_send;
      if(which==0)begin
        while(dut.forward_buffer.write_count!=512)@(negedge fft_clk);
        repeat(17)begin
          @(negedge fft_clk);
          if(dut.forward_buffer_valid || dut.forward_committed || dut.product_bank_valid)
            $fatal(1,"unqualified status allowed replay");
        end
        force dut.core_status_data={3'b0,fe[0]};force dut.core_status_valid=1'b1;
        @(negedge fft_clk);release dut.core_status_valid;release dut.core_status_data;
      end else begin
        while(!dut.forward_buffer_valid || dut.forward_buffer_position!=100)@(negedge fft_clk);
        force dut.kernel_ready=1'b0;force replay_kernel_reference.input_ready=1'b0;
        aux_held_data=dut.forward_buffer_data;aux_held_position=dut.forward_buffer_position;
        for(n=0;n<128;n=n+1)begin
          @(negedge fft_clk);
          if(!dut.forward_buffer_valid || dut.forward_buffer_data!==aux_held_data ||
             dut.forward_buffer_position!==aux_held_position || dut.product_bank_valid)
            $fatal(1,"elastic replay changed while stalled");
        end
        release dut.kernel_ready;release replay_kernel_reference.input_ready;
      end
      aux_finish;
      $display("BUFFERED_DELAY_PASS case=%0d fresh_reads=512 replay=512 products=512",which);
    end
  endtask
  task automatic run_buffered_auxiliary;
    begin
      auxiliary_active=1;
      for(aux_case=0;aux_case<6;aux_case=aux_case+1)aux_fault(aux_case);
      for(aux_case=0;aux_case<4;aux_case=aux_case+1)
        for(aux_side=0;aux_side<2;aux_side=aux_side+1)aux_reset_boundary(aux_case,aux_side);
      for(aux_case=0;aux_case<2;aux_case=aux_case+1)aux_delay(aux_case);
      run_output_identity_boundaries;
      $display("BUFFERED_AUX_PASS faults=6 resets=8 delays=2 fresh_recovery=1 actual_fft=1");
    end
  endtask

// Read-only current-word reconstruction against the real output bank's header.
  integer output_identity_checks=0,output_identity_words=0,output_identity_finals=0;
  integer output_identity_first_refills=0;
  wire output_original_framing = dut.output_stage_position==dut.output_bank.write_position &&
    dut.output_stage_last==(dut.output_bank.write_position==9'd511) &&
    (dut.output_bank.write_position==0 || dut.output_stage_metadata[36:0]==dut.output_bank.metadata_in_hold);
  always @(posedge fft_clk)if(dut.fast_running)begin
    if(dut.output_bank.input_accept)begin
      if(dut.output_bank.input_framing_valid!==output_original_framing)
        $fatal(1,"output registered identity differs from held actual word");
      output_identity_words=output_identity_words+1;
      if(dut.output_stage_last)output_identity_finals=output_identity_finals+1;
    end
    if(dut.output_writer_metadata_load && dut.output_stage_offer_valid && dut.output_stage_ready)
      output_identity_first_refills=output_identity_first_refills+1;
    if(dut.output_replay_accept && (!dut.output_stage_valid || !dut.output_stage_last ||
       !dut.output_bank.input_accept || !dut.output_bank.input_framing_valid))
      $fatal(1,"output replay accepted before actual validated final write");
    if(dut.output_stage_offer_valid && !dut.output_publication_busy && dut.guard_last_out[1])
      $fatal(1,"unqualified live final entered output stage");
    output_identity_checks=output_identity_checks+1;
  end
  task automatic report_output_identity;
    begin
      if(output_identity_checks<10000 || output_identity_words<9216 ||
         output_identity_finals<18 || output_identity_first_refills<18)
        $fatal(1,"output identity comparison coverage missing");
      $display("OUTPUT_IDENTITY_PASS checks=%0d words=%0d finals=%0d first_refills=%0d actual_word_exact=1 actual_publication=1",
        output_identity_checks,output_identity_words,output_identity_finals,output_identity_first_refills);
    end
  endtask

// Actual-FFT faults at the new capture/certificate/publication boundary.
  integer output_boundary;
  reg [36:0] output_bad_metadata;
  task automatic output_identity_boundary(input integer boundary);
    begin
      aux_reset;aux_ready=0;aux_send;
      if(boundary==0)
        while(!dut.output_stage_offer_valid || dut.output_publication_busy ||
              dut.guard_return_position[1]!=100 || !dut.output_stage_ready)@(negedge fft_clk);
      else if(boundary==1)
        while(!dut.output_replay_valid || !dut.output_stage_ready)@(negedge fft_clk);
      else if(boundary==2)
        while(!dut.output_stage_valid || dut.output_stage_position!=100)@(negedge fft_clk);
      else if(boundary<7)
        while(!dut.output_stage_final_valid || !dut.output_replay_accept)@(negedge fft_clk);
      else
        while(dut.output_request!==1'b1)@(negedge fft_clk);
      aux_fault_expected=1;
      if(boundary<2)begin
        output_bad_metadata=dut.output_stage_offer_metadata^37'h10000;
        force dut.output_stage_offer_metadata=output_bad_metadata;
      end else if(boundary==2)force dut.output_stage_position=9'd1;
      else if(boundary==3)force dut.output_stage_last=1'b0;
      else if(boundary==4)force dut.core_status_valid=1'b1;
      else if(boundary==5 || boundary==7)resetn=0;
      else fft_resetn=0;
      #0.001;
      if(boundary>=5 && (dut.fast_running!==0 || output_valid!==0))
        $fatal(1,"output stage reset did not fence current output");
      @(posedge fft_clk);#0.001;@(negedge fft_clk);
      release dut.output_stage_offer_metadata;release dut.output_stage_position;
      release dut.output_stage_last;release dut.core_status_valid;
      if(boundary>=5)begin
        repeat(12)@(negedge fft_clk);resetn=1;fft_resetn=1;
      end
      repeat(100)begin
        @(negedge fft_clk);
        if(dut.output_request!==0 || output_valid || dut.job_accept || dut.output_released_valid || dut.reader_release)
          $fatal(1,"output identity cancellation escaped boundary=%0d",boundary);
      end
      if(aux_reads!=0 || aux_releases!=0 || (boundary<5 && fault!==1))
        $fatal(1,"output identity cancellation missing boundary=%0d",boundary);
      aux_recover;
      $display("OUTPUT_IDENTITY_BOUNDARY_PASS boundary=%0d cancelled_outputs=0 fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_output_identity_boundaries;
    begin
      for(output_boundary=0;output_boundary<9;output_boundary=output_boundary+1)output_identity_boundary(output_boundary);
      run_registered_abort_boundaries;
      $display("OUTPUT_IDENTITY_BOUNDARIES_PASS cases=9 current_publication_fenced=1 fresh_recovery=1");
    end
  endtask

  integer abort_checks=0,abort_fault_edges=0,abort_private_captures=0,abort_private_writes=0;
  reg abort_request_before,abort_product_before,abort_expected_latch;
  always @(posedge fft_clk)begin
    abort_expected_latch=dut.fast_running && dut.result_fault===1'b1;
    abort_request_before=dut.output_request;abort_product_before=dut.product_bank.owner_request;
    if(dut.fast_running)begin
      abort_checks=abort_checks+1;
      if(abort_expected_latch)begin
        if(dut.product_commit_authorized!==0 || dut.output_replay_accept!==0 ||
           dut.job_accept || dut.completion_accept)
          $fatal(1,"guard fault did not fence current publication/reuse");
        abort_fault_edges=abort_fault_edges+1;
        if(!dut.fast_fault && dut.forward_buffer.capture_take)abort_private_captures=abort_private_captures+1;
        if(!dut.fast_fault && dut.output_bank.input_accept)abort_private_writes=abort_private_writes+1;
      end
    end
    #0.001;
    if(abort_expected_latch && dut.fast_running)begin
      if(dut.fast_fault!==1 || dut.output_request!==abort_request_before ||
         dut.product_bank.owner_request!==abort_product_before)
        $fatal(1,"guard fault escaped global latch or changed ownership");
    end
  end
  task automatic report_registered_abort;
    begin
      if(abort_checks<10000)$fatal(1,"vacuous abort observer");
      $display("REGISTERED_ABORT_PASS checks=%0d fault_edges=%0d private_captures=%0d private_writes=%0d current_publication_fenced=1 next_edge_global_abort=1",
        abort_checks,abort_fault_edges,abort_private_captures,abort_private_writes);
    end
  endtask

  integer abort_boundary;
  task automatic registered_abort_boundary(input integer boundary);
    reg old_request;
    begin
      aux_reset;aux_ready=0;aux_send;
      if(boundary==0)while(!dut.core_output_valid || dut.core_output_user[8:0]!=100)@(negedge fft_clk);
      else if(boundary==1)while(!dut.forward_buffer_valid || dut.forward_buffer_position!=100)@(negedge fft_clk);
      else if(boundary==2)while(!dut.output_stage_valid || dut.output_stage_position!=100)@(negedge fft_clk);
      else if(boundary==3)while(!dut.output_replay_accept)@(negedge fft_clk);
      else while(dut.next_inverse!=(boundary==5) || !dut.completion_permit)@(negedge fft_clk);
      if(dut.fast_fault || dut.result_fault)$fatal(1,"direct guard fault premise");
      old_request=dut.output_request;aux_fault_expected=1;
      if(boundary<2 || boundary==4)begin force dut.owners[0].result_guard.fault_reasons=8'h04;force pulse_guard_reference[0].original.fault_reasons=8'h04; end 
      else begin force dut.owners[1].result_guard.fault_reasons=8'h04;force pulse_guard_reference[1].original.fault_reasons=8'h04; end 
      #0.001;
      if(dut.result_fault!==1 || dut.fast_fault!==0 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
        $fatal(1,"direct guard fault current-edge veto missing");
      @(posedge fft_clk);#0.001;
      if(dut.fast_fault!==1 || dut.output_request!==old_request)$fatal(1,"direct fault latch/publication boundary");
      @(negedge fft_clk);
      begin release dut.owners[0].result_guard.fault_reasons;release pulse_guard_reference[0].original.fault_reasons; end begin release dut.owners[1].result_guard.fault_reasons;release pulse_guard_reference[1].original.fault_reasons; end 
      // A previously published good block can remain visible until the
      // existing fast-to-slow fault synchronizer propagates. Reader is held.
      repeat(8)begin
        @(negedge fft_clk);
        if(dut.output_request!==old_request || dut.job_accept || dut.completion_accept || aux_reads)
          $fatal(1,"new work escaped during fault CDC propagation");
      end
      repeat(100)begin
        @(negedge fft_clk);
        if(dut.output_request!==old_request || output_valid || dut.job_accept || dut.completion_accept ||
           dut.reader_release || dut.output_released_valid)$fatal(1,"guard fault leaked cancelled work");
      end
      if(fault!==1 || aux_reads!=0 || aux_releases!=0)$fatal(1,"guard fault quarantine evidence missing");
      aux_recover;
      $display("REGISTERED_ABORT_BOUNDARY_PASS boundary=%0d new_publications=0 fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_registered_abort_boundaries;
    begin
      for(abort_boundary=0;abort_boundary<6;abort_boundary=abort_boundary+1)registered_abort_boundary(abort_boundary);
      if(abort_private_captures<1 || abort_private_writes<1)$fatal(1,"private fault-edge allowance not exercised");
      run_local_fault_boundaries;
      $display("REGISTERED_ABORT_BOUNDARIES_PASS cases=6 private_delta_exercised=1 fresh_recovery=1");
    end
  endtask

  integer local_checks=0,local_delays=0,local_pending_checks=0;
  reg local_pending=0,local_sample_running,local_expected_fault;
  reg [32:0] local_expected_snapshot;
  reg local_output_before,local_product_before;
  always @(posedge fft_clk)begin
    local_sample_running=dut.fast_running;
    local_expected_snapshot=dut.admission_reject_expanded;
    local_expected_fault=dut.fast_fault || dut.result_fault || (|dut.local_fault_snapshot);
    local_output_before=dut.output_request;local_product_before=dut.product_bank.owner_request;
    if(!dut.fast_running)local_pending=0;
    else begin
      local_checks=local_checks+1;
      if(dut.local_fault_profile!==1)$fatal(1,"local fault profile not selected");
      if((|dut.admission_reject_expanded)!==(|dut.sticky_fault_sources))
        $fatal(1,"local fault source reduction differs from original");
      if(local_pending)begin
        local_pending_checks=local_pending_checks+1;
        if(dut.product_commit_authorized!==0 || dut.output_replay_accept!==0 ||
           dut.job_accept || dut.completion_accept)$fatal(1,"local fault latency escaped public fence");
      end
      if((|dut.sticky_fault_sources)===1 && dut.fast_fault===0 && dut.result_fault===0 &&
         (|dut.local_fault_snapshot)===0)local_delays=local_delays+1;
    end
    #0.001;
    if(local_sample_running && dut.fast_running)begin
      if(dut.local_fault_snapshot!==local_expected_snapshot || dut.fast_fault!==local_expected_fault)
        $fatal(1,"local fault pipeline is not exact sampled arithmetic");
      if(local_pending && (dut.fast_fault!==1 || dut.output_request!==local_output_before ||
         dut.product_bank.owner_request!==local_product_before))
        $fatal(1,"local fault bound or ownership failure");
      local_pending=(|local_expected_snapshot)===1;
    end else local_pending=0;
  end
  task automatic report_local_fault;
    begin
      if(local_checks<10000)$fatal(1,"vacuous local fault observer");
      $display("LOCAL_FAULT_PASS checks=%0d delayed_edges=%0d pending_checks=%0d exact_sources=1 bounded_abort=1 publication_fenced=1",
        local_checks,local_delays,local_pending_checks);
    end
  endtask

  integer local_boundary;
  task automatic local_fault_boundary(input integer boundary);
    reg output_before,product_before;
    begin
      aux_reset;aux_ready=0;aux_send;
      if(boundary<2)while(!dut.staged_product_valid || !dut.staged_product_last ||
          !dut.staged_product_ready)@(negedge fft_clk);
      else if(boundary==2 || boundary==5)while(!dut.output_replay_accept)@(negedge fft_clk);
      else while(dut.next_inverse!=(boundary==4) || !dut.completion_permit)@(negedge fft_clk);
      if(dut.fast_fault || dut.result_fault || (|dut.local_fault_snapshot))$fatal(1,"local fault boundary premise");
      output_before=dut.output_request;product_before=dut.product_bank.owner_request;
      aux_fault_expected=1;
      if(boundary==1)begin force dut.core_status_valid=1'b1;force dut.core_status_data=8'h80;end
      else if(boundary==5)force dut.retained_fault_now=1'b1;
      else force dut.input_fault_now=1'b1;
      #0.001;
      if(dut.fast_fault!==0 || (|dut.sticky_fault_sources)!==1 || dut.output_replay_accept!==0 ||
         dut.product_commit_authorized!==0)$fatal(1,"local fault immediate veto");
      @(posedge fft_clk);#0.001;
      if(dut.fast_fault!==0 || (|dut.local_fault_snapshot)!==1)$fatal(1,"local fault latency not exercised");
      @(negedge fft_clk);
      release dut.input_fault_now;release dut.retained_fault_now;
      release dut.core_status_valid;release dut.core_status_data;
      repeat(8)begin
        @(negedge fft_clk);
        if(dut.output_request!==output_before || dut.product_bank.owner_request!==product_before ||
           dut.job_accept || dut.completion_accept || aux_reads || aux_releases)
          $fatal(1,"local fault boundary allowed new ownership or reuse");
      end
      repeat(100)begin
        @(negedge fft_clk);
        if(fault!==1 || output_valid || aux_reads || aux_releases)$fatal(1,"local fault quarantine missing");
      end
      aux_recover;
      $display("LOCAL_FAULT_BOUNDARY_PASS boundary=%0d new_publications=0 fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_local_fault_boundaries;
    begin
      for(local_boundary=0;local_boundary<6;local_boundary=local_boundary+1)local_fault_boundary(local_boundary);
      run_product_current_fence_boundaries;
      $display("LOCAL_FAULT_BOUNDARIES_PASS cases=6 delayed_fault_exercised=1 fresh_recovery=1");
    end
  endtask

  integer product_fence_boundary;
  task automatic product_current_fence_boundary(input integer boundary);
    reg output_before,product_before;
    begin
      aux_reset;aux_ready=0;aux_send;
      while(!dut.staged_product_valid || !dut.staged_product_last || !dut.staged_product_ready)@(negedge fft_clk);
      if(dut.fast_fault || dut.result_fault || (|dut.local_fault_snapshot))$fatal(1,"product current fence premise");
      output_before=dut.output_request;product_before=dut.product_bank.owner_request;
      aux_fault_expected=1;
      if(boundary==1)force dut.core_output_valid=1'b1;
      else if(boundary==2)force dut.event_frame=1'b1;
      else if(boundary==3)force dut.input_job_start=1'b1;
      else begin force dut.core_status_valid=1'b1;force dut.core_status_data=8'h00;end
      #0.001;
      if(dut.fast_fault!==0 || dut.result_fault!==0 || dut.common_current_fault!==1 ||
         dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
        $fatal(1,"product current fault not fenced boundary=%0d",boundary);
      @(posedge fft_clk);#0.001;
      if(dut.output_request!==output_before || dut.product_bank.owner_request!==product_before ||
         dut.fast_fault!==0 || (|dut.local_fault_snapshot)!==1)
        $fatal(1,"product fault-edge ownership/latency boundary=%0d",boundary);
      @(negedge fft_clk);
      release dut.core_output_valid;release dut.event_frame;release dut.input_job_start;
      release dut.core_status_valid;release dut.core_status_data;
      if(boundary>=4)begin
        if(boundary==4)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.product_bank.owner_request!==0 || dut.output_request!==0 || output_valid)
          $fatal(1,"product pending-fault reset failed");
      end else begin
        repeat(8)begin
          @(negedge fft_clk);
          if(dut.output_request!==output_before || dut.product_bank.owner_request!==product_before ||
             dut.job_accept || dut.completion_accept || aux_reads || aux_releases)
            $fatal(1,"product cancellation ownership/reuse failure");
        end
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases)$fatal(1,"product cancellation quarantine missing");
        end
      end
      aux_recover;
      $display("PRODUCT_CURRENT_FENCE_BOUNDARY_PASS boundary=%0d new_publications=0 fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_product_current_fence_boundaries;
    begin
      for(product_fence_boundary=0;product_fence_boundary<6;product_fence_boundary=product_fence_boundary+1)
        product_current_fence_boundary(product_fence_boundary);
      run_forward_private_status_boundaries;
      $display("PRODUCT_CURRENT_FENCE_BOUNDARIES_PASS cases=6 current_fault_fenced=1 pending_reset=1 fresh_recovery=1");
    end
  endtask

  integer balanced_checks=0,balanced_captures=0;
  always @(posedge fft_clk)if(dut.fast_running)begin
    if(dut.forward_buffer.capture_descriptor_equal !==
       (dut.forward_buffer.capture_descriptor==dut.forward_buffer.descriptor))
      $fatal(1,"balanced descriptor comparison differs from original");
    if(dut.forward_buffer.capture_valid && dut.forward_buffer.capture_ready)
      balanced_captures=balanced_captures+1;
    balanced_checks=balanced_checks+1;
  end
  task automatic report_balanced_forward_identity;
    begin
      if(balanced_checks<10000 || balanced_captures<9216)$fatal(1,"vacuous balanced descriptor check");
      $display("BALANCED_FORWARD_IDENTITY_PASS checks=%0d captures=%0d same_edge=1 four_state_exact=1",
        balanced_checks,balanced_captures);
    end
  endtask

  integer private_status_checks=0,private_status_edges=0,private_status_completions=0,private_status_guard_delays=0;
  reg private_status_pending=0,private_status_running,private_status_current,private_status_old;
  reg private_status_output_before,private_status_product_before;
  always @(posedge fft_clk)begin
    private_status_running=dut.fast_running;
    private_status_current=dut.forward_buffer_fault===1'b1;
    private_status_old=dut.forward_buffer_private_fault===1'b1;
    private_status_output_before=dut.output_request;
    private_status_product_before=dut.product_bank.owner_request;
    if(!dut.fast_running)private_status_pending=0;
    else begin
      private_status_checks=private_status_checks+1;
      if(private_status_current)begin
        if(dut.forward_buffer_valid!==0 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
          $fatal(1,"private bank status lost current publication veto");
        if(!private_status_old)begin
          private_status_edges=private_status_edges+1;
          if(dut.completion_accept)private_status_completions=private_status_completions+1;
        end
      end
      if(private_status_old && (dut.registered_quarantine!==1 || dut.job_accept || dut.completion_accept))
        $fatal(1,"private bank status allowed reuse after capture");
    end
    #0.001;
    if(private_status_running && dut.fast_running)begin
      if(private_status_current)begin
        if(dut.forward_buffer_private_fault!==1 || dut.registered_quarantine!==1 ||
           dut.output_request!==private_status_output_before ||
           dut.product_bank.owner_request!==private_status_product_before)
          $fatal(1,"private bank status capture/ownership failure");
        if(!private_status_old && dut.result_fault===0)private_status_guard_delays=private_status_guard_delays+1;
      end
      if(private_status_pending && dut.fast_fault!==1)$fatal(1,"private status global fault bound");
      private_status_pending=private_status_old;
    end else private_status_pending=0;
  end
  task automatic report_forward_private_status;
    begin
      if(private_status_checks<10000)$fatal(1,"vacuous private status observer");
      $display("FORWARD_PRIVATE_STATUS_PASS checks=%0d new_fault_edges=%0d private_completions=%0d guard_delays=%0d current_publication_fenced=1 registered_reuse_fenced=1 bounded_global_fault=1",
        private_status_checks,private_status_edges,private_status_completions,private_status_guard_delays);
    end
  endtask

  integer private_status_boundary;
  task automatic forward_private_status_boundary(input integer boundary);
    reg output_before,product_before;
    begin
      aux_reset;aux_ready=0;aux_send;
      if(boundary<3 || boundary>=9)begin
        while(!dut.core_output_valid || dut.core_output_user[8:0]!=(boundary==0?0:boundary==2?511:100))@(negedge fft_clk);
      end else if(boundary==3)while(!dut.guard_commit[0])@(negedge fft_clk);
      else if(boundary==4)while(!dut.forward_buffer_valid || dut.forward_buffer_position!=100)@(negedge fft_clk);
      else if(boundary==5)while(!dut.staged_product_valid || !dut.staged_product_last || !dut.staged_product_ready)@(negedge fft_clk);
      else if(boundary==6)while(!dut.output_replay_accept)@(negedge fft_clk);
      else while(dut.next_inverse!=(boundary==8) || !dut.completion_permit)@(negedge fft_clk);
      if(dut.fast_fault || dut.forward_buffer_fault || dut.forward_buffer_private_fault)$fatal(1,"private status boundary premise");
      output_before=dut.output_request;product_before=dut.product_bank.owner_request;aux_fault_expected=1;
      if(boundary<3 || boundary>=9)force dut.forward_buffer.capture_descriptor=70'h1;
      else if(boundary==3)force dut.forward_buffer.reserve_valid=1'bx;
      else if(boundary==5)force dut.forward_buffer.capture_valid=1'b1;
      else force dut.forward_buffer.seal_valid=1'b1;
      #0.001;
      if(dut.forward_buffer_fault!==1 || dut.forward_buffer_private_fault!==0 ||
         dut.forward_buffer_valid!==0 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
        $fatal(1,"private status current boundary veto case=%0d",boundary);
      @(posedge fft_clk);#0.001;
      if(dut.forward_buffer_private_fault!==1 || dut.registered_quarantine!==1 ||
         dut.output_request!==output_before || dut.product_bank.owner_request!==product_before)
        $fatal(1,"private status boundary capture case=%0d",boundary);
      @(negedge fft_clk);
      release dut.forward_buffer.capture_descriptor;release dut.forward_buffer.reserve_valid;
      release dut.forward_buffer.capture_valid;release dut.forward_buffer.seal_valid;
      if(boundary>=9)begin
        if(boundary==9)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.forward_buffer_private_fault!==0 || dut.output_request!==0 || dut.product_bank.owner_request!==0 || output_valid)
          $fatal(1,"private status pending reset leaked");
      end else begin
        repeat(12)begin
          @(negedge fft_clk);
          if(dut.output_request!==output_before || dut.product_bank.owner_request!==product_before ||
             dut.job_accept || dut.completion_accept || aux_reads || aux_releases)
            $fatal(1,"private status delay leaked ownership/reuse");
        end
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases)$fatal(1,"private status quarantine missing");
        end
      end
      aux_recover;
      $display("FORWARD_PRIVATE_STATUS_BOUNDARY_PASS boundary=%0d new_publications=0 fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_forward_private_status_boundaries;
    begin
      for(private_status_boundary=0;private_status_boundary<11;private_status_boundary=private_status_boundary+1)
        forward_private_status_boundary(private_status_boundary);
      run_product_retirement_boundaries;
      $display("FORWARD_PRIVATE_STATUS_BOUNDARIES_PASS cases=11 private_delta_exercised=1 fresh_recovery=1");
    end
  endtask

  integer parallel_identity_checks=0,parallel_identity_captures=0,parallel_identity_refills=0;
  reg parallel_identity_expected,parallel_identity_take;
  always @(posedge fft_clk)begin
    parallel_identity_take=0;
    if(dut.fast_running)begin
      parallel_identity_checks=parallel_identity_checks+1;
      parallel_identity_expected=(dut.product_identity_stage.input_metadata ==
        (dut.product_writer_metadata_load ? dut.staged_product_metadata : dut.product_writer_metadata)) === 1'b1;
      if(dut.product_identity_stage.identity_good !== parallel_identity_expected)
        $fatal(1,"parallel product reference differs from original mux equality");
      parallel_identity_take=dut.product_identity_stage.take_input && !dut.product_identity_stage.fault;
      if(parallel_identity_take)begin
        parallel_identity_captures=parallel_identity_captures+1;
        if(dut.product_writer_metadata_load)parallel_identity_refills=parallel_identity_refills+1;
      end
    end
    #0.001;
    if(dut.fast_running && parallel_identity_take &&
       dut.staged_product_identity_good !== parallel_identity_expected)
      $fatal(1,"parallel product certificate not captured with word");
  end
  task automatic report_parallel_product_identity;
    begin
      if(parallel_identity_checks<10000 || parallel_identity_captures<9216 || parallel_identity_refills<18)
        $fatal(1,"vacuous parallel product identity observer");
      $display("PARALLEL_PRODUCT_IDENTITY_PASS checks=%0d captures=%0d first_refills=%0d four_state_exact=1 same_edge_capture=1",
        parallel_identity_checks,parallel_identity_captures,parallel_identity_refills);
    end
  endtask

  integer retirement_checks=0,retirement_publications=0,retirement_retires=0,retirement_extra_holds=0;
  reg retirement_running,retirement_publish,retirement_retire,retirement_request_before;
  always @(posedge fft_clk)begin
    retirement_running=dut.fast_running;
    retirement_request_before=dut.product_owner_request;
    retirement_publish=dut.product_bank.input_accept && dut.product_bank.input_framing_valid &&
      dut.product_bank.write_position==511 && dut.product_commit_authorized;
    retirement_retire=dut.staged_product_valid && dut.staged_product_last && dut.product_retire_ready;
    if(retirement_running)begin
      retirement_checks=retirement_checks+1;
      if(dut.product_published_receipt && dut.product_bank.input_accept)
        $fatal(1,"product write after ownership publication");
      if(retirement_publish)begin
        if(dut.product_published_receipt!==0 || dut.product_retire_ready!==0)
          $fatal(1,"private final slot retired before registered publication");
        retirement_publications=retirement_publications+1;
      end
      if(retirement_retire)begin
        if(dut.product_published_receipt!==1 || dut.product_stage_ready!==0 || dut.product_bank.input_accept!==0)
          $fatal(1,"private final receipt allowed reuse or duplicate write");
        retirement_retires=retirement_retires+1;
      end
    end
    #0.001;
    if(retirement_running && dut.fast_running)begin
      if((dut.product_owner_request!==retirement_request_before) !== retirement_publish)
        $fatal(1,"product ownership differs from actual checked bank publication");
      if(retirement_publish && !dut.product_stage_fault)begin
        if(dut.product_identity_stage.full!==1 || dut.staged_product_last!==1 || dut.product_published_receipt!==1)
          $fatal(1,"missing extra private final hold");
        retirement_extra_holds=retirement_extra_holds+1;
      end
      if(retirement_retire && dut.product_identity_stage.full!==0)
        $fatal(1,"private slot did not retire on registered receipt");
    end
  end
  task automatic report_product_retirement_receipt;
    begin
      if(retirement_checks<10000 || retirement_publications<18 || retirement_retires<18 || retirement_extra_holds<18)
        $fatal(1,"vacuous product retirement observer");
      $display("PRODUCT_RETIREMENT_RECEIPT_PASS checks=%0d publications=%0d retires=%0d extra_holds=%0d exact_publication=1 no_post_publication_write=1 receipt_retirement=1",
        retirement_checks,retirement_publications,retirement_retires,retirement_extra_holds);
    end
  endtask

  integer retirement_boundary;
  task automatic product_retirement_boundary(input integer boundary);
    reg request_before;
    reg [115:0] held_word;
    begin
      aux_reset;aux_ready=boundary==0;aux_send;
      if(boundary==0 || boundary==4)begin
        while(!dut.staged_product_valid || !dut.staged_product_last || !dut.staged_product_ready)@(negedge fft_clk);
      end else begin
        while(!dut.product_published_receipt)@(negedge fft_clk);
        if(!dut.product_identity_stage.full || !dut.staged_product_last)$fatal(1,"missing private receipt boundary");
      end
      request_before=dut.product_owner_request;
      if(boundary==0)begin
        begin force dut.product_commit_authorized=1'b0;force product_original_accept=1'b0; end 
        held_word={dut.staged_product_data,dut.staged_product_position,dut.staged_product_last,dut.staged_product_metadata};
        repeat(128)begin
          @(negedge fft_clk);
          if(!dut.product_identity_stage.full || dut.product_retire_ready || dut.product_published_receipt ||
             dut.product_owner_request!==request_before || aux_reads ||
             {dut.staged_product_data,dut.staged_product_position,dut.staged_product_last,dut.staged_product_metadata}!==held_word)
            $fatal(1,"unpublished final was lost while permission delayed");
        end
        begin release dut.product_commit_authorized;release product_original_accept; end aux_finish;
      end else if(boundary<3)begin
        aux_fault_expected=1;
        if(boundary==1)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.product_identity_stage.full!==0 || dut.product_owner_request!==0 || dut.product_owner_ack_sync!==0 || output_valid)
          $fatal(1,"reset retained private final/ownership");
        aux_recover;
      end else begin
        aux_fault_expected=1;
        if(boundary==3)begin force dut.core_status_valid=1'b1;force dut.core_status_data=8'h00;end
        else force dut.product_bank.input_metadata_certified=1'b0;
        #0.001;
        if(boundary==4 && dut.product_bank_framing_fault_now!==1)$fatal(1,"bad certificate not detected");
        @(posedge fft_clk);#0.001;
        if(dut.product_owner_request!==request_before || dut.output_request!==0)
          $fatal(1,"retirement boundary created publication");
        @(negedge fft_clk);
        release dut.core_status_valid;release dut.core_status_data;release dut.product_bank.input_metadata_certified;
        repeat(12)@(negedge fft_clk);
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases || dut.job_accept || dut.completion_accept)
            $fatal(1,"retirement boundary quarantine failed");
        end
        aux_recover;
      end
      $display("PRODUCT_RETIREMENT_BOUNDARY_PASS boundary=%0d fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_product_retirement_boundaries;
    begin
      for(retirement_boundary=0;retirement_boundary<5;retirement_boundary=retirement_boundary+1)
        product_retirement_boundary(retirement_boundary);
      run_private_descriptor_boundaries;
      $display("PRODUCT_RETIREMENT_BOUNDARIES_PASS cases=5 delayed_publication=1 pending_reset=1 checked_receipt=1");
    end
  endtask

  wire descriptor_old_reserve_ready,descriptor_old_capture_ready,descriptor_old_output_valid;
  wire descriptor_old_output_last,descriptor_old_done,descriptor_old_busy,descriptor_old_fault,descriptor_old_private_fault;
  wire [35:0] descriptor_old_data;
  wire [8:0] descriptor_old_position;
  wire [4:0] descriptor_old_exponent;
  wire [69:0] descriptor_old_metadata;
  starlink_pss_forward_return_private_status descriptor_reference (
    .clk(fft_clk),.resetn(dut.fast_running),.abort_epoch(dut.forward_buffer.abort_epoch),
    .reserve_valid(dut.forward_buffer.reserve_valid),
    .reserve_descriptor(dut.forward_buffer.reserve_descriptor),
    .capture_valid(dut.forward_buffer.capture_valid),
    .capture_data(dut.forward_buffer.capture_data),
    .capture_position(dut.forward_buffer.capture_position),
    .capture_last(dut.forward_buffer.capture_last),
    .capture_exponent(dut.forward_buffer.capture_exponent),
    .capture_descriptor(dut.forward_buffer.capture_descriptor),
    .seal_valid(dut.forward_buffer.seal_valid),
    .output_ready(dut.forward_buffer.output_ready),
    .reserve_ready(descriptor_old_reserve_ready),.capture_ready(descriptor_old_capture_ready),
    .output_valid(descriptor_old_output_valid),.output_data(descriptor_old_data),
    .output_position(descriptor_old_position),.output_last(descriptor_old_output_last),
    .output_exponent(descriptor_old_exponent),.output_descriptor(descriptor_old_metadata),
    .done_pulse(descriptor_old_done),.busy(descriptor_old_busy),.fault(descriptor_old_fault),
    .private_fault(descriptor_old_private_fault)
  );
  integer private_descriptor_checks=0,private_descriptor_loads=0,private_descriptor_fault_loads=0,private_descriptor_differences=0;
  task automatic compare_private_descriptor;
    begin
      if({dut.forward_buffer.reserve_ready,dut.forward_buffer.capture_ready,dut.forward_buffer.output_valid,
          dut.forward_buffer.done_pulse,dut.forward_buffer.busy,dut.forward_buffer.fault,dut.forward_buffer.private_fault} !==
         {descriptor_old_reserve_ready,descriptor_old_capture_ready,descriptor_old_output_valid,
          descriptor_old_done,descriptor_old_busy,descriptor_old_fault,descriptor_old_private_fault})
        $fatal(1,"private descriptor changed current controls");
      if(dut.forward_buffer.output_valid &&
         {dut.forward_buffer.output_data,dut.forward_buffer.output_position,dut.forward_buffer.output_last,
          dut.forward_buffer.output_exponent,dut.forward_buffer.output_descriptor} !==
         {descriptor_old_data,descriptor_old_position,descriptor_old_output_last,descriptor_old_exponent,descriptor_old_metadata})
        $fatal(1,"private descriptor changed valid replay");
      if({dut.forward_buffer.state,dut.forward_buffer.fault_q,dut.forward_buffer.replay_valid,dut.forward_buffer.write_count,
          dut.forward_buffer.read_count,dut.forward_buffer.exponent,dut.forward_buffer.output_position} !==
         {descriptor_reference.state,descriptor_reference.fault_q,descriptor_reference.replay_valid,descriptor_reference.write_count,
          descriptor_reference.read_count,descriptor_reference.exponent,descriptor_reference.output_position})
        $fatal(1,"private descriptor changed other bank state");
      if(dut.forward_buffer.descriptor !== descriptor_reference.descriptor)begin
        if(dut.forward_buffer.fault!==1 || descriptor_old_fault!==1 || dut.forward_buffer.output_valid!==0 ||
           dut.forward_buffer.reserve_ready!==0 || dut.forward_buffer.capture_ready!==0)
          $fatal(1,"private descriptor difference escaped quarantine");
        private_descriptor_differences=private_descriptor_differences+1;
      end
      private_descriptor_checks=private_descriptor_checks+1;
    end
  endtask
  always @(posedge fft_clk)begin
    if(dut.fast_running)begin
      compare_private_descriptor;
      if(dut.forward_buffer.reserve_valid && dut.forward_buffer.reserve_ready)begin
        private_descriptor_loads=private_descriptor_loads+1;
        if(dut.forward_buffer.fault_now===1)private_descriptor_fault_loads=private_descriptor_fault_loads+1;
      end
    end
    #0.001;
    if(dut.fast_running)compare_private_descriptor;
  end
  task automatic report_private_forward_descriptor;
    begin
      if(private_descriptor_checks<10000 || private_descriptor_loads<18)$fatal(1,"vacuous descriptor comparison");
      $display("PRIVATE_FORWARD_DESCRIPTOR_PASS checks=%0d loads=%0d fault_loads=%0d private_differences=%0d controls_exact=1 valid_payload_exact=1 quarantined_difference=1",
        private_descriptor_checks,private_descriptor_loads,private_descriptor_fault_loads,private_descriptor_differences);
    end
  endtask

  integer descriptor_boundary;
  task automatic private_forward_descriptor_boundary(input integer boundary);
    reg [69:0] offered_descriptor;
    begin
      aux_reset;aux_ready=0;aux_send;
      while(!dut.forward_buffer.reserve_valid || !dut.forward_buffer.reserve_ready)@(negedge fft_clk);
      if(dut.forward_buffer.fault || dut.forward_buffer.descriptor!==descriptor_reference.descriptor)
        $fatal(1,"descriptor boundary premise");
      aux_fault_expected=1;
      if(boundary==1)force dut.forward_buffer.seal_valid=1'b1;
      else if(boundary==2)force dut.forward_buffer.capture_valid=1'bx;
      else if(boundary==3)begin
        force dut.forward_buffer.seal_valid=1'bz;
        force dut.forward_buffer.reserve_descriptor={70{1'bx}};
      end else force dut.forward_buffer.capture_valid=1'b1;
      #0.001;
      offered_descriptor=dut.forward_buffer.reserve_descriptor;
      if(dut.forward_buffer.fault!==1 || dut.forward_buffer.reserve_ready!==1 ||
         dut.forward_buffer.output_valid!==0 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
        $fatal(1,"descriptor rejection/publication fence missing");
      @(posedge fft_clk);#0.001;
      if(dut.forward_buffer.descriptor!==offered_descriptor ||
         dut.forward_buffer.descriptor===descriptor_reference.descriptor ||
         dut.forward_buffer.fault_q!==1 || descriptor_reference.fault_q!==1 ||
         dut.product_owner_request!==0 || dut.output_request!==0)
        $fatal(1,"private descriptor delta not safely captured");
      @(negedge fft_clk);
      release dut.forward_buffer.capture_valid;release dut.forward_buffer.seal_valid;
      release dut.forward_buffer.reserve_descriptor;
      if(boundary>=4)begin
        if(boundary==4)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.forward_buffer.descriptor!==0 || descriptor_reference.descriptor!==0 ||
           dut.product_owner_request!==0 || dut.output_request!==0 || output_valid)
          $fatal(1,"private descriptor reset retained stale authority");
      end else begin
        repeat(12)@(negedge fft_clk);
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases || dut.job_accept || dut.completion_accept ||
             dut.forward_buffer.reserve_ready || dut.forward_buffer.capture_ready)
            $fatal(1,"private descriptor quarantine escaped");
        end
      end
      aux_recover;
      $display("PRIVATE_DESCRIPTOR_BOUNDARY_PASS boundary=%0d fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_private_descriptor_boundaries;
    begin
      for(descriptor_boundary=0;descriptor_boundary<6;descriptor_boundary=descriptor_boundary+1)
        private_forward_descriptor_boundary(descriptor_boundary);
      run_output_retirement_boundaries;
      $display("PRIVATE_DESCRIPTOR_BOUNDARIES_PASS cases=6 rejected_reservation=1 private_delta=1 fresh_recovery=1");
    end
  endtask

  integer out_retirement_checks=0,out_retirement_publications=0,out_retirement_retires=0,out_retirement_extra_holds=0;
  reg out_retirement_running,out_retirement_publish,out_retirement_retire,out_retirement_request_before;
  always @(posedge fft_clk)begin
    out_retirement_running=dut.fast_running;
    out_retirement_request_before=dut.output_request;
    out_retirement_publish=dut.output_bank.input_accept && dut.output_bank.input_framing_valid &&
      dut.output_bank.write_position==511 && dut.output_replay_accept;
    out_retirement_retire=dut.output_stage_valid && dut.output_stage_last && dut.output_retire_ready;
    if(out_retirement_running)begin
      out_retirement_checks=out_retirement_checks+1;
      if(dut.output_published_receipt && dut.output_bank.input_accept)
        $fatal(1,"product write after ownership publication");
      if(out_retirement_publish)begin
        if(dut.output_published_receipt!==0 || dut.output_retire_ready!==0)
          $fatal(1,"private final slot retired before registered publication");
        out_retirement_publications=out_retirement_publications+1;
      end
      if(out_retirement_retire)begin
        if(dut.output_published_receipt!==1 || dut.output_stage_ready!==0 || dut.output_bank.input_accept!==0)
          $fatal(1,"private final receipt allowed reuse or duplicate write");
        out_retirement_retires=out_retirement_retires+1;
      end
    end
    #0.001;
    if(out_retirement_running && dut.fast_running)begin
      if((dut.output_request!==out_retirement_request_before) !== out_retirement_publish)
        $fatal(1,"product ownership differs from actual checked bank publication");
      if(out_retirement_publish && !dut.output_stage_fault)begin
        if(dut.output_identity_stage.full!==1 || dut.output_stage_last!==1 || dut.output_published_receipt!==1)
          $fatal(1,"missing extra private final hold");
        out_retirement_extra_holds=out_retirement_extra_holds+1;
      end
      if(out_retirement_retire && dut.output_identity_stage.full!==0)
        $fatal(1,"private slot did not retire on registered receipt");
    end
  end
  task automatic report_output_retirement_receipt;
    begin
      if(out_retirement_checks<10000 || out_retirement_publications<18 || out_retirement_retires<18 || out_retirement_extra_holds<18)
        $fatal(1,"vacuous product retirement observer");
      $display("OUTPUT_RETIREMENT_RECEIPT_PASS checks=%0d publications=%0d retires=%0d extra_holds=%0d exact_publication=1 no_post_publication_write=1 receipt_retirement=1",
        out_retirement_checks,out_retirement_publications,out_retirement_retires,out_retirement_extra_holds);
    end
  endtask

  integer out_retirement_boundary;
  task automatic output_retirement_boundary(input integer boundary);
    reg request_before;
    reg [115:0] held_word;
    begin
      aux_reset;aux_ready=boundary==0;aux_send;
      if(boundary==4)begin
        while(!dut.output_stage_offer_valid || !dut.output_stage_ready || !dut.output_identity_stage.input_last)@(negedge fft_clk);
      end else if(boundary==0 || boundary==5)begin
        while(!dut.output_stage_valid || !dut.output_stage_last || !dut.output_stage_consume)@(negedge fft_clk);
      end else begin
        while(!dut.output_published_receipt)@(negedge fft_clk);
        if(!dut.output_identity_stage.full || !dut.output_stage_last)$fatal(1,"missing private receipt boundary");
      end
      request_before=dut.output_request;
      if(boundary==0)begin
        force dut.output_stage_final_valid=1'b0;
        held_word={dut.output_stage_data,dut.output_stage_position,dut.output_stage_last,dut.output_stage_metadata};
        repeat(128)begin
          @(negedge fft_clk);
          if(!dut.output_identity_stage.full || dut.output_retire_ready || dut.output_published_receipt ||
             dut.output_request!==request_before || aux_reads ||
             {dut.output_stage_data,dut.output_stage_position,dut.output_stage_last,dut.output_stage_metadata}!==held_word)
            $fatal(1,"unpublished final was lost while permission delayed");
        end
        release dut.output_stage_final_valid;aux_finish;
      end else if(boundary<3)begin
        aux_fault_expected=1;
        if(boundary==1)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.output_identity_stage.full!==0 || dut.output_request!==0 || dut.output_ack_sync!==0 || output_valid)
          $fatal(1,"reset retained private final/ownership");
        aux_recover;
      end else begin
        aux_fault_expected=1;
        if(boundary==3)begin force dut.core_status_valid=1'b1;force dut.core_status_data=8'h00;end
        else if(boundary==4)begin
          if(dut.output_writer_metadata===37'h1fffffffff)$fatal(1,"corruption must differ from held header");
          force dut.output_identity_stage.input_metadata=70'h1fffffffff;
        end
        else begin force dut.output_replay_accept=1'b0;force phase_original_accept=1'b0; end 
        #0.001;
        @(posedge fft_clk);#0.001;
        if(boundary==4 && (dut.output_stage_identity_good!==0 || dut.output_bank_framing_fault_now!==1))
          $fatal(1,"captured bad metadata did not reject actual final word");
        if(dut.output_request!==request_before)
          $fatal(1,"retirement boundary created publication");
        @(negedge fft_clk);
        release dut.core_status_valid;release dut.core_status_data;release dut.output_identity_stage.input_metadata;begin release dut.output_replay_accept;release phase_original_accept; end 
        repeat(12)@(negedge fft_clk);
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases || dut.job_accept || dut.completion_accept)
            $fatal(1,"retirement boundary quarantine failed");
        end
        aux_recover;
      end
      $display("OUTPUT_RETIREMENT_BOUNDARY_PASS boundary=%0d fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_output_retirement_boundaries;
    begin
      for(out_retirement_boundary=0;out_retirement_boundary<6;out_retirement_boundary=out_retirement_boundary+1)
        output_retirement_boundary(out_retirement_boundary);
      run_private_replay_sequence_boundaries;
      $display("OUTPUT_RETIREMENT_BOUNDARIES_PASS cases=6 delayed_publication=1 pending_reset=1 checked_receipt=1");
    end
  endtask

  // Independent original private-sequence input, fed the same public stream.
  starlink_pss_kernel_rom #(.ROM_FILE("upper_edge_pss_kernel_q17.mem"),
    .DATA_WIDTH(18),.PRIVATE_PAYLOAD_BUBBLES(1),.PRIVATE_SEQUENCE_ADVANCE(1),
    .BALANCED_BLOCK_IDENTITY_EQ(1),.PARALLEL_INPUT_CAPACITY(1)) replay_kernel_reference (
    .clk(fft_clk),.resetn(dut.fast_running),.flush(1'b0),
    .input_valid(dut.joiner.input_valid),.input_private_valid(dut.joiner.input_valid),
    .input_ready(),.input_bin_index(dut.forward_buffer_position),
    .input_block_exponent(dut.forward_buffer_exponent),.input_last(dut.forward_buffer_last),
    .input_block_start_index(dut.forward_buffer_descriptor[68:5]),
    .output_ready(dut.joiner.output_ready),.downstream_capacity(dut.forward_parallel_capacity),
    .output_valid(),.output_kernel_i(),.output_kernel_q(),.output_bin_index(),
    .output_block_exponent(),.output_last(),.output_block_start_index(),
    .accepted_pulse(),.emitted_pulse(),.input_block_complete_pulse(),
    .sequence_error_pulse(),.metadata_error_pulse(),.protocol_fault()
  );
  integer private_replay_checks=0,private_replay_takes=0,private_replay_only=0;
  integer private_replay_final_only=0,private_replay_differences=0;
  reg replay_private_take,replay_public_take,replay_request_before,replay_output_before;
  reg replay_only_this_edge,replay_was_running;
  task automatic compare_private_replay_kernel;
    begin
      if({dut.joiner.kernel_rom.input_ready,dut.joiner.kernel_rom.output_valid,
          dut.joiner.kernel_rom.accepted_pulse,dut.joiner.kernel_rom.emitted_pulse,
          dut.joiner.kernel_rom.input_block_complete_pulse,dut.joiner.kernel_rom.sequence_error_pulse,
          dut.joiner.kernel_rom.metadata_error_pulse,dut.joiner.kernel_rom.protocol_fault} !==
         {replay_kernel_reference.input_ready,replay_kernel_reference.output_valid,
          replay_kernel_reference.accepted_pulse,replay_kernel_reference.emitted_pulse,
          replay_kernel_reference.input_block_complete_pulse,replay_kernel_reference.sequence_error_pulse,
          replay_kernel_reference.metadata_error_pulse,replay_kernel_reference.protocol_fault})
        $fatal(1,"private replay changed kernel public controls");
      if(dut.joiner.kernel_rom.output_valid &&
         {dut.joiner.kernel_rom.output_kernel_word,dut.joiner.kernel_rom.output_bin_index,
          dut.joiner.kernel_rom.output_block_exponent,dut.joiner.kernel_rom.output_last,dut.joiner.kernel_rom.output_block_start_index} !==
         {replay_kernel_reference.output_kernel_word,replay_kernel_reference.output_bin_index,
          replay_kernel_reference.output_block_exponent,replay_kernel_reference.output_last,replay_kernel_reference.output_block_start_index})
        $fatal(1,"private replay changed valid kernel payload");
      if({dut.joiner.kernel_rom.expected_bin_index,dut.joiner.kernel_rom.expected_next_block_start,dut.joiner.kernel_rom.have_previous_block} !==
         {replay_kernel_reference.expected_bin_index,replay_kernel_reference.expected_next_block_start,replay_kernel_reference.have_previous_block})begin
        if(dut.forward_buffer_fault!==1 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0 ||
           dut.job_accept || dut.completion_accept)
          $fatal(1,"private replay state difference escaped quarantine");
        private_replay_differences=private_replay_differences+1;
      end
      private_replay_checks=private_replay_checks+1;
    end
  endtask
  always @(posedge fft_clk)begin
    replay_was_running=dut.fast_running;
    replay_private_take=dut.joiner.kernel_rom.private_sequence_accept===1'b1;
    replay_public_take=dut.joiner.kernel_rom.input_accept===1'b1;
    replay_only_this_edge=replay_private_take && !replay_public_take;
    replay_request_before=dut.product_bank.owner_request;
    replay_output_before=dut.output_request;
    if(replay_was_running)begin
      compare_private_replay_kernel;
      if(replay_public_take && !replay_private_take)$fatal(1,"public replay lacks private bookkeeping");
      if(replay_private_take)private_replay_takes=private_replay_takes+1;
      if(replay_only_this_edge)begin
        if(dut.forward_buffer_fault!==1 || dut.product_commit_authorized!==0 || dut.output_replay_accept!==0 ||
           dut.forward_buffer.state!==3 || dut.forward_buffer.replay_valid!==1)
          $fatal(1,"private replay offer lacks sealed ownership/current rejection");
        private_replay_only=private_replay_only+1;
        if(dut.forward_buffer_last)private_replay_final_only=private_replay_final_only+1;
      end
    end
    #0.001;
    if(replay_was_running && dut.fast_running)begin
      compare_private_replay_kernel;
      if(replay_only_this_edge &&
         (dut.forward_buffer_private_fault!==1 || dut.forward_buffer_private_replay_valid!==0 ||
          dut.product_bank.owner_request!==replay_request_before || dut.output_request!==replay_output_before ||
          dut.registered_quarantine!==1))
        $fatal(1,"private replay divergence survived edge or changed ownership");
    end
  end
  task automatic report_private_replay_sequence;
    begin
      if(private_replay_checks<10000 || private_replay_takes<9216)$fatal(1,"vacuous private replay observer");
      $display("PRIVATE_REPLAY_SEQUENCE_PASS checks=%0d takes=%0d private_only=%0d final_only=%0d quarantined_differences=%0d public_exact=1 receipt_fenced=1",
        private_replay_checks,private_replay_takes,private_replay_only,private_replay_final_only,private_replay_differences);
    end
  endtask

  integer private_replay_boundary_index;
  task automatic private_replay_sequence_boundary(input integer boundary);
    integer position_target,kind,expected_index;
    reg product_before,output_before;
    begin
      aux_reset;aux_ready=0;aux_send;
      position_target=boundary>=9?511:boundary/3==0?0:boundary/3==1?100:511;
      kind=boundary>=9?0:boundary%3;
      while(!(dut.forward_buffer_valid && dut.kernel_ready && dut.forward_buffer_position==position_target))
        @(negedge fft_clk);
      product_before=dut.product_bank.owner_request;output_before=dut.output_request;
      expected_index=dut.joiner.kernel_rom.expected_bin_index;
      if(expected_index!=position_target)$fatal(1,"private replay boundary ordinal");
      aux_fault_expected=1;
      if(kind==0)force dut.forward_buffer.capture_valid=1'b1;
      else if(kind==1)force dut.forward_buffer.seal_valid=1'b1;
      else force dut.forward_buffer.reserve_valid=1'bx;
      #0.001;
      if(dut.forward_buffer_fault!==1 || dut.joiner.kernel_rom.input_accept!==0 ||
         dut.joiner.kernel_rom.private_sequence_accept!==1 ||
         dut.product_commit_authorized!==0 || dut.output_replay_accept!==0)
        $fatal(1,"private replay boundary did not separate private progress/public veto");
      @(posedge fft_clk);#0.001;
      if(dut.joiner.kernel_rom.expected_bin_index!==9'((expected_index+1)%512) ||
         dut.forward_buffer_private_fault!==1 || dut.forward_buffer_private_replay_valid!==0 ||
         dut.product_bank.owner_request!==product_before || dut.output_request!==output_before)
        $fatal(1,"private replay boundary post-edge quarantine");
      if(position_target==511 &&
         (dut.joiner.kernel_rom.have_previous_block!==1 ||
          dut.joiner.kernel_rom.expected_next_block_start!==64'd1447 ||
          dut.joiner.kernel_rom.input_block_complete_pulse!==0))
        $fatal(1,"private final bookkeeping became public completion");
      @(negedge fft_clk);
      release dut.forward_buffer.capture_valid;release dut.forward_buffer.seal_valid;release dut.forward_buffer.reserve_valid;
      if(boundary>=9)begin
        if(boundary==9)resetn=0;else fft_resetn=0;
        repeat(12)@(negedge fft_clk);
        if(dut.joiner.kernel_rom.expected_bin_index!==0 || dut.joiner.kernel_rom.have_previous_block!==0 ||
           dut.joiner.kernel_rom.expected_next_block_start!==0 || output_valid)
          $fatal(1,"reset retained private replay history");
      end else begin
        $display("PRIVATE_REPLAY_PENDING_FAULT boundary=%0d slow_fault=%b local_fault=%b quarantine=%b",boundary,fault,dut.forward_buffer_private_fault,dut.registered_quarantine);
        // Fault reporting crosses two slow-clock flops. Ownership/progress
        // must already be fenced during that reporting interval.
        repeat(12)begin
          @(negedge fft_clk);
          if(dut.forward_buffer_private_fault!==1 || dut.registered_quarantine!==1 ||
             output_valid || aux_reads || aux_releases || dut.job_accept || dut.completion_accept ||
             dut.product_bank.owner_request!==product_before || dut.output_request!==output_before)
            $fatal(1,"private replay early quarantine failed");
        end
        repeat(100)begin
          @(negedge fft_clk);
          if(fault!==1 || output_valid || aux_reads || aux_releases || dut.job_accept || dut.completion_accept ||
             dut.product_bank.owner_request!==product_before || dut.output_request!==output_before)
            $fatal(1,"private replay boundary escaped quarantine");
        end
      end
      aux_recover;
      $display("PRIVATE_REPLAY_SEQUENCE_BOUNDARY_PASS boundary=%0d fresh_reads=512 fresh_releases=1",boundary);
    end
  endtask
  task automatic run_private_replay_sequence_boundaries;
    begin
      for(private_replay_boundary_index=0;private_replay_boundary_index<11;private_replay_boundary_index=private_replay_boundary_index+1)
        private_replay_sequence_boundary(private_replay_boundary_index);
      $display("PRIVATE_REPLAY_SEQUENCE_BOUNDARIES_PASS cases=11 first_mid_last=1 current_veto=1 both_resets=1");
    end
  endtask

  wire old_admission_request=dut.CERTIFIED_ADMISSION && dut.job_valid &&
    dut.guard_capacity[dut.next_inverse] && dut.cutover_admission_capacity &&
    (!dut.next_inverse || dut.inverse_descriptor_live);
  wire old_admission_permit;
  starlink_pss_admission_certificate #(.CHECKS(36),.PRIVATE_FACT_CAPTURE(1)) old_admission (
    .clk(fft_clk),.resetn(dut.fast_running),.request(old_admission_request),
    .quarantine(dut.registered_quarantine),.consume(dut.job_accept),
    .checks_good(dut.admission_checks),.permit(old_admission_permit),
    .snapshot_valid(),.snapshot_good()
  );
  integer retry_checks=0,retry_bad=0,retry_grants=0,retry_waits=0;
  integer retry_request_grants=0;
  reg retry_holding=0;
  reg [71:0] retry_identity;
  wire old_job_accept=dut.job_valid && old_admission_permit && dut.guard_ready[dut.next_inverse];
  task automatic check_retry_admission;
    begin
      if(dut.fast_running===1)begin
        retry_checks=retry_checks+1;
        if(dut.job_accept!==old_job_accept)$fatal(1,"retry admission differs from original current-capacity certificate");
        if(dut.admission_request===1 && dut.admission_gate.snapshot_valid===1 &&
           dut.admission_gate.sampled_good===0)retry_bad=retry_bad+1;
        if(dut.job_accept===1 && (dut.guard_capacity[dut.next_inverse]!==1 ||
           dut.cutover_admission_capacity!==1 ||
           (dut.next_inverse===1 && dut.inverse_descriptor_live!==1)))
          $fatal(1,"accepted job lacks current owned capacity");
      end
    end
  endtask
  always @(posedge fft_clk)begin
    check_retry_admission;
    if(!dut.fast_running || !dut.admission_request)begin
      retry_holding=0;retry_request_grants=0;
    end else begin
      if(!retry_holding)begin
        retry_holding=1;retry_identity={dut.engine_metadata,dut.held_phase,dut.held_lease};
      end else if(retry_identity!=={dut.engine_metadata,dut.held_phase,dut.held_lease})
        if(dut.preparation_fault_now!==1 && dut.registered_quarantine!==1)
          $fatal(1,"held request changed identity without current fault");
      if(dut.job_accept)begin
        retry_grants=retry_grants+1;retry_request_grants=retry_request_grants+1;
        if(retry_request_grants!=1)$fatal(1,"held job admitted twice");
      end
      if(!old_admission_request)retry_waits=retry_waits+1;
    end
    #0.001;check_retry_admission;
  end
  task automatic report_retry_admission;
    begin
      if(retry_checks<10000 || retry_grants<36)$fatal(1,"vacuous retry admission proof");
      $display("RETRY_ADMISSION_PASS checks=%0d grants=%0d rejected_snapshots=%0d capacity_waits=%0d original_accept_exact=1 held_identity=1 once_per_request=1",retry_checks,retry_grants,retry_bad,retry_waits);
    end
  endtask

  integer retry_boundary_index;
  reg [69:0] retry_bad_descriptor;
  task automatic retry_admission_boundary(input integer which);
    integer wanted_inverse,n;
    begin
      wanted_inverse=which<4 ? which/2 : (which<8 ? which%2 : 0);
      aux_reset;aux_ready=1;
      fork
        aux_send;
        begin
          while(!(dut.fast_running && dut.next_inverse==wanted_inverse &&
                  dut.state==dut.VERIFY_LEASE && dut.preparation_valid===1))
            @(negedge fft_clk);
          if(which==1 || which==3)force dut.cutover_admission_capacity=1'b0;
          else if(wanted_inverse==0)force dut.owners[0].result_guard.mailbox_input_ready=1'b0;
          else force dut.owners[1].result_guard.mailbox_input_ready=1'b0;
          repeat(10)begin
            @(negedge fft_clk);
            if(dut.job_accept!==0 || dut.config_valid!==0 || dut.engine_input_enable!==0)
              $fatal(1,"unready held request started a core job");
          end
          if(dut.state!==dut.ARM_JOB || dut.admission_request!==1 ||
             dut.admission_gate.snapshot_valid!==1 || dut.admission_gate.sampled_good!==0)
            $fatal(1,"retrying rejected snapshot was not exercised");
          if(which<4)begin
            release dut.owners[0].result_guard.mailbox_input_ready;release dut.owners[1].result_guard.mailbox_input_ready;release dut.cutover_admission_capacity;
            n=0;
            while(dut.job_accept!==1 && n<6)begin @(negedge fft_clk);n=n+1;end
            if(dut.job_accept!==1 || fault!==0)$display("RETRY_CAPACITY_INPUTS reset=%b protocol=%b active=%b await=%b return=%b input_reserved=%b output_reserved=%b mailbox_ready=%b internal_capacity=%b stage_ready=%b bank_ready=%b complete_ready=%b",dut.owners[1].result_guard.resetn,dut.owners[1].result_guard.protocol_fault,dut.owners[1].result_guard.active,dut.owners[1].result_guard.awaiting_ack,dut.owners[1].result_guard.return_valid,dut.owners[1].result_guard.input_bank_reserved,dut.owners[1].result_guard.output_bank_reserved,dut.owners[1].result_guard.mailbox_input_ready,dut.owners[1].result_guard.admission_capacity,dut.output_stage_ready,dut.output_bank_ready,dut.output_complete_ready);
            if(dut.job_accept!==1 || fault!==0)$fatal(1,"capacity recovery did not grant bounded admission case=%0d state=%0d guard_capacity=%b guard_ready=%b cutover=%b inverse_live=%b fault=%b quarantine=%b snapshot=%h valid=%b consumed=%b old_permit=%b age=%0d",which,dut.state,dut.guard_capacity,dut.guard_ready,dut.cutover_admission_capacity,dut.inverse_descriptor_live,fault,dut.registered_quarantine,dut.admission_gate.snapshot_good,dut.admission_gate.snapshot_valid,dut.admission_gate.consumed,old_admission_permit,dut.preparation_age);
          end else if(which<8)begin
            if(which<6)resetn=0;else fft_resetn=0;
            #0.001;
            if(dut.admission_permit!==0 || dut.job_accept!==0 || output_valid!==0)
              $fatal(1,"one-sided reset did not cancel pending grant");
            repeat(12)@(negedge fft_clk);
            release dut.owners[0].result_guard.mailbox_input_ready;release dut.owners[1].result_guard.mailbox_input_ready;release dut.cutover_admission_capacity;
            resetn=1;fft_resetn=1;
          end else begin
            aux_fault_expected=1;
            if(which==9)begin
              retry_bad_descriptor=dut.engine_metadata ^ 70'h1000;
              force dut.engine_metadata=retry_bad_descriptor;
            end
            n=0;
            while(fault!==1 && n<100)begin
              @(negedge fft_clk);n=n+1;
              if(dut.job_accept!==0 || dut.config_valid!==0 || dut.engine_input_enable!==0 || output_valid)
                $fatal(1,"expired or substituted pending job escaped");
            end
            if(fault!==1)$fatal(1,"pending request not quarantined within timeout bound");
            release dut.engine_metadata;release dut.owners[0].result_guard.mailbox_input_ready;release dut.owners[1].result_guard.mailbox_input_ready;release dut.cutover_admission_capacity;
          end
        end
      join
      if(which<4)aux_finish;
      else begin
        repeat(50)begin
          @(negedge fft_clk);
          if(output_valid || aux_reads || aux_releases || dut.job_accept || dut.config_valid || dut.engine_input_enable)
            $fatal(1,"cancelled admission produced stale work");
        end
        aux_recover;
      end
      $display("RETRY_ADMISSION_BOUNDARY_PASS case=%0d inverse=%0d fresh_reads=512 fresh_releases=1",which,wanted_inverse);
    end
  endtask
  task automatic run_retry_admission_boundaries;
    begin
      for(retry_boundary_index=0;retry_boundary_index<10;retry_boundary_index=retry_boundary_index+1)
        retry_admission_boundary(retry_boundary_index);
      $display("RETRY_ADMISSION_BOUNDARIES_PASS cases=10 capacity_stalls=4 one_sided_resets=4 timeout=1 descriptor_fault=1");
    end
  endtask

  // Same-input originals: all outputs, effective occupancy and remaining
  // private fields stay exact; the two retimed storage bits differ by design.
  generate for(genvar owner=0;owner<2;owner=owner+1)begin : pulse_guard_reference
  starlink_pss_result_guard_owner_view #(
    .CERTIFIED_PRIVATE_ADMISSION(1),
    .PRIVATE_ACK_RETIREMENT(owner==1),
    .PRIVATE_QUARANTINE_OFFER(owner==1),
    .USE_PRIVATE_DESCRIPTOR_OFFER(1),
    .ENABLE_OFFERED_FAULT_SUMMARY(1),
    .REQUIRE_KNOWN_COMPLETED_INPUT(1),
    .USE_PHASE_INPUT_FAULT(0),
    .USE_COMPLETED_INPUT_FAULT(1),
    .USE_PREFLIGHT_REASON_ONLY(1),
    .USE_FORWARD_RETIREMENT(1)
  ) original (
    .clk(dut.owners[owner].result_guard.clk),
    .resetn(dut.owners[owner].result_guard.resetn),
    .job_valid(dut.owners[owner].result_guard.job_valid),
    .private_descriptor_offer(dut.owners[owner].result_guard.private_descriptor_offer),
    .job_ready(),
    .admission_capacity(),
    .job_descriptor(dut.owners[owner].result_guard.job_descriptor),
    .input_bank_reserved(dut.owners[owner].result_guard.input_bank_reserved),
    .output_bank_reserved(dut.owners[owner].result_guard.output_bank_reserved),
    .certified_input_beat(dut.owners[owner].result_guard.certified_input_beat),
    .certified_input_complete(dut.owners[owner].result_guard.certified_input_complete),
    .offered_input_beat(dut.owners[owner].result_guard.offered_input_beat),
    .offered_input_complete(dut.owners[owner].result_guard.offered_input_complete),
    .offered_local_fault_now(),
    .offered_local_faults_now(),
    .final_fence_certified(dut.owners[owner].result_guard.final_fence_certified),
    .external_fault_now(dut.owners[owner].result_guard.external_fault_now),
    .phase_input_fault_now(dut.owners[owner].result_guard.phase_input_fault_now),
    .completed_input_certified(dut.owners[owner].result_guard.completed_input_certified),
    .completed_input_fault_now(dut.owners[owner].result_guard.completed_input_fault_now),
    .preflight_fault_evidence_now(dut.owners[owner].result_guard.preflight_fault_evidence_now),
    .core_event_frame_started(dut.owners[owner].result_guard.core_event_frame_started),
    .core_output_tdata(dut.owners[owner].result_guard.core_output_tdata),
    .core_output_tuser(dut.owners[owner].result_guard.core_output_tuser),
    .core_output_tvalid(dut.owners[owner].result_guard.core_output_tvalid),
    .core_output_tlast(dut.owners[owner].result_guard.core_output_tlast),
    .core_status_tdata(dut.owners[owner].result_guard.core_status_tdata),
    .core_status_tvalid(dut.owners[owner].result_guard.core_status_tvalid),
    .mailbox_input_valid(),
    .mailbox_private_valid(),
    .mailbox_commit_valid(),
    .mailbox_input_ready(dut.owners[owner].result_guard.mailbox_input_ready),
    .mailbox_input_fault(dut.owners[owner].result_guard.mailbox_input_fault),
    .inverse_phase(dut.owners[owner].result_guard.inverse_phase),
    .forward_mailbox_fault(dut.owners[owner].result_guard.forward_mailbox_fault),
    .forward_retirement_valid(),
    .forward_private_offer(),
    .mailbox_input_data(),
    .mailbox_input_position(),
    .mailbox_input_last(),
    .mailbox_input_metadata(),
    .busy(),
    .commit_pulse(),
    .protocol_fault(),
    .fault_reasons(),
    .owner_active(),
    .owner_awaiting_ack(),
    .owner_fault_now(),
    .owner_ack_accept()
  );
  integer checks=0,pulses=0,storage_edges=0,immediate_acks=0;
  task automatic compare_guard;
    begin
      if(dut.owners[owner].result_guard.job_ready !== original.job_ready)$fatal(1,"pulse guard %0d differs: job_ready",owner);
      if(dut.owners[owner].result_guard.admission_capacity !== original.admission_capacity)$fatal(1,"pulse guard %0d differs: admission_capacity",owner);
      if(dut.owners[owner].result_guard.offered_local_fault_now !== original.offered_local_fault_now)$fatal(1,"pulse guard %0d differs: offered_local_fault_now",owner);
      if(dut.owners[owner].result_guard.offered_local_faults_now !== original.offered_local_faults_now)$fatal(1,"pulse guard %0d differs: offered_local_faults_now",owner);
      if(dut.owners[owner].result_guard.mailbox_input_valid !== original.mailbox_input_valid)$fatal(1,"pulse guard %0d differs: mailbox_input_valid",owner);
      if(dut.owners[owner].result_guard.mailbox_private_valid !== original.mailbox_private_valid)$fatal(1,"pulse guard %0d differs: mailbox_private_valid",owner);
      if(dut.owners[owner].result_guard.mailbox_commit_valid !== original.mailbox_commit_valid)$fatal(1,"pulse guard %0d differs: mailbox_commit_valid",owner);
      if(dut.owners[owner].result_guard.forward_retirement_valid !== original.forward_retirement_valid)$fatal(1,"pulse guard %0d differs: forward_retirement_valid",owner);
      if(dut.owners[owner].result_guard.forward_private_offer !== original.forward_private_offer)$fatal(1,"pulse guard %0d differs: forward_private_offer",owner);
      if(dut.owners[owner].result_guard.mailbox_input_data !== original.mailbox_input_data)$fatal(1,"pulse guard %0d differs: mailbox_input_data",owner);
      if(dut.owners[owner].result_guard.mailbox_input_position !== original.mailbox_input_position)$fatal(1,"pulse guard %0d differs: mailbox_input_position",owner);
      if(dut.owners[owner].result_guard.mailbox_input_last !== original.mailbox_input_last)$fatal(1,"pulse guard %0d differs: mailbox_input_last",owner);
      if(dut.owners[owner].result_guard.mailbox_input_metadata !== original.mailbox_input_metadata)$fatal(1,"pulse guard %0d differs: mailbox_input_metadata",owner);
      if(dut.owners[owner].result_guard.busy !== original.busy)$fatal(1,"pulse guard %0d differs: busy",owner);
      if(dut.owners[owner].result_guard.commit_pulse !== original.commit_pulse)$fatal(1,"pulse guard %0d differs: commit_pulse",owner);
      if(dut.owners[owner].result_guard.protocol_fault !== original.protocol_fault)$fatal(1,"pulse guard %0d differs: protocol_fault",owner);
      if(dut.owners[owner].result_guard.fault_reasons !== original.fault_reasons)$fatal(1,"pulse guard %0d differs: fault_reasons",owner);
      if(dut.owners[owner].result_guard.owner_active !== original.owner_active)$fatal(1,"pulse guard %0d differs: owner_active",owner);
      if(dut.owners[owner].result_guard.owner_awaiting_ack !== original.owner_awaiting_ack)$fatal(1,"pulse guard %0d differs: owner_awaiting_ack",owner);
      if(dut.owners[owner].result_guard.owner_fault_now !== original.owner_fault_now)$fatal(1,"pulse guard %0d differs: owner_fault_now",owner);
      if(dut.owners[owner].result_guard.owner_ack_accept !== original.owner_ack_accept)$fatal(1,"pulse guard %0d differs: owner_ack_accept",owner);
      if(dut.owners[owner].result_guard.active_private !== original.active_private)$fatal(1,"pulse guard %0d differs: active_private",owner);
      if(dut.owners[owner].result_guard.awaiting_ack !== original.awaiting_ack)$fatal(1,"pulse guard %0d differs: awaiting_ack",owner);
      if(dut.owners[owner].result_guard.descriptor !== original.descriptor)$fatal(1,"pulse guard %0d differs: descriptor",owner);
      if(dut.owners[owner].result_guard.input_count !== original.input_count)$fatal(1,"pulse guard %0d differs: input_count",owner);
      if(dut.owners[owner].result_guard.output_count !== original.output_count)$fatal(1,"pulse guard %0d differs: output_count",owner);
      if(dut.owners[owner].result_guard.input_complete_seen !== original.input_complete_seen)$fatal(1,"pulse guard %0d differs: input_complete_seen",owner);
      if(dut.owners[owner].result_guard.frame_seen !== original.frame_seen)$fatal(1,"pulse guard %0d differs: frame_seen",owner);
      if(dut.owners[owner].result_guard.status_seen !== original.status_seen)$fatal(1,"pulse guard %0d differs: status_seen",owner);
      if(dut.owners[owner].result_guard.exponent_seen !== original.exponent_seen)$fatal(1,"pulse guard %0d differs: exponent_seen",owner);
      if(dut.owners[owner].result_guard.status_exponent !== original.status_exponent)$fatal(1,"pulse guard %0d differs: status_exponent",owner);
      if(dut.owners[owner].result_guard.output_exponent !== original.output_exponent)$fatal(1,"pulse guard %0d differs: output_exponent",owner);
      if(dut.owners[owner].result_guard.age !== original.age)$fatal(1,"pulse guard %0d differs: age",owner);
      if(dut.owners[owner].result_guard.return_occupied !== original.return_occupied)$fatal(1,"pulse guard %0d differs: return_occupied",owner);
      if(dut.owners[owner].result_guard.return_last !== original.return_last)$fatal(1,"pulse guard %0d differs: return_last",owner);
      if(dut.owners[owner].result_guard.return_data !== original.return_data)$fatal(1,"pulse guard %0d differs: return_data",owner);
      if(dut.owners[owner].result_guard.return_position !== original.return_position)$fatal(1,"pulse guard %0d differs: return_position",owner);
      if(dut.owners[owner].result_guard.return_exponent !== original.return_exponent)$fatal(1,"pulse guard %0d differs: return_exponent",owner);
      if(dut.owners[owner].result_guard.CERTIFIED_PRIVATE_ADMISSION !== (1))$fatal(1,"reference parameter mismatch CERTIFIED_PRIVATE_ADMISSION");
      if(dut.owners[owner].result_guard.PRIVATE_ACK_RETIREMENT !== (owner==1))$fatal(1,"reference parameter mismatch PRIVATE_ACK_RETIREMENT");
      if(dut.owners[owner].result_guard.PRIVATE_QUARANTINE_OFFER !== (owner==1))$fatal(1,"reference parameter mismatch PRIVATE_QUARANTINE_OFFER");
      if(dut.owners[owner].result_guard.USE_PRIVATE_DESCRIPTOR_OFFER !== (1))$fatal(1,"reference parameter mismatch USE_PRIVATE_DESCRIPTOR_OFFER");
      if(dut.owners[owner].result_guard.ENABLE_OFFERED_FAULT_SUMMARY !== (1))$fatal(1,"reference parameter mismatch ENABLE_OFFERED_FAULT_SUMMARY");
      if(dut.owners[owner].result_guard.REQUIRE_KNOWN_COMPLETED_INPUT !== (1))$fatal(1,"reference parameter mismatch REQUIRE_KNOWN_COMPLETED_INPUT");
      if(dut.owners[owner].result_guard.USE_PHASE_INPUT_FAULT !== (0))$fatal(1,"reference parameter mismatch USE_PHASE_INPUT_FAULT");
      if(dut.owners[owner].result_guard.USE_COMPLETED_INPUT_FAULT !== (1))$fatal(1,"reference parameter mismatch USE_COMPLETED_INPUT_FAULT");
      if(dut.owners[owner].result_guard.USE_PREFLIGHT_REASON_ONLY !== (1))$fatal(1,"reference parameter mismatch USE_PREFLIGHT_REASON_ONLY");
      if(dut.owners[owner].result_guard.USE_FORWARD_RETIREMENT !== (1))$fatal(1,"reference parameter mismatch USE_FORWARD_RETIREMENT");
      checks=checks+1;
    end
  endtask
  always @(posedge fft_clk)begin
    compare_guard;
    if(dut.fast_running && original.commit_pulse===1)begin
      pulses=pulses+1;
      if(dut.owners[owner].result_guard.active_storage!==original.active_private ||
         dut.owners[owner].result_guard.ack_storage!==original.awaiting_ack)
        storage_edges=storage_edges+1;
      if(original.owner_ack_accept===1)immediate_acks=immediate_acks+1;
    end
    #0.001;compare_guard;
  end
  task automatic report_one;
    begin
      if(checks<10000 || pulses<18 || storage_edges<18)$fatal(1,"vacuous guard pulse comparison");
      $display("GUARD_PULSE_PASS owner=%0d checks=%0d pulses=%0d storage_edges=%0d immediate_acks=%0d outputs_exact=1 effective_state_exact=1",owner,checks,pulses,storage_edges,immediate_acks);
    end
  endtask
  end endgenerate
  task automatic report_pulse_guards;
    begin pulse_guard_reference[0].report_one;pulse_guard_reference[1].report_one;end
  endtask

// Original full publication authorization, independent of the reduced fault view.
wire phase_original_accept =
 (dut.REPLAY_QUIET_PUBLICATION === 0) ?
 (dut.output_replay_valid && dut.output_descriptor_valid &&
  dut.output_bank_ready && dut.output_stage_final_valid && !dut.common_current_fault) :
 ((dut.REPLAY_QUIET_PUBLICATION === 1 && dut.REPLAY_FENCE_PROFILE) ?
 (dut.output_replay_valid && dut.output_descriptor_valid &&
  dut.output_bank_ready && dut.output_stage_final_valid &&
  dut.replay_publication_context && !dut.replay_publication_fault) : 1'b0);
integer phase_checks=0,phase_accepts=0,phase_preflight=0,phase_differences=0;
task check_phase_publication;
begin
  if(dut.output_replay_accept !== phase_original_accept)
    $fatal(1,"publication original predicate mismatch");
  if(dut.REPLAY_QUIET_PUBLICATION === 1 && dut.REPLAY_FENCE_PROFILE)begin
    // Never mirror or suppress this comparison, including deliberate output vetoes.
    if((dut.replay_publication_context && !dut.replay_publication_fault) !==
       (dut.replay_publication_context && !dut.replay_phase_fault))
      $fatal(1,"publication unforced phase predicate mismatch");
    if(dut.preparing === 1'b1 && dut.preparation_fault_now === 1'b1)
      phase_preflight=phase_preflight+1;
    if(dut.replay_publication_fault !== dut.replay_phase_fault)
      phase_differences=phase_differences+1;
  end
  phase_checks=phase_checks+1;
end
endtask
always @(posedge fft_clk)begin
  check_phase_publication;
  if(dut.output_replay_accept === 1'b1)phase_accepts=phase_accepts+1;
  #0.001;check_phase_publication;
end
task report_phase_publication;
begin
  $display("PHASE_PUBLICATION_PASS checks=%0d accepts=%0d preflight=%0d fault_differences=%0d exact=1",
    phase_checks,phase_accepts,phase_preflight,phase_differences);
end
endtask


// Compare the original authorization at the actual writer-ready boundary.
wire product_original_accept = dut.original_product_commit_authorized;
integer product_checks=0,product_differences=0,product_publications=0,product_reader_edges=0;
reg product_prior_request=0;
task check_product_publication;
begin
 if(dut.fast_running === 1'b1 && dut.product_bank_ready === 1'b1)begin
   if(dut.product_bank_valid !== 1'b0)$fatal(1,"product ownership overlap");
   if(dut.product_commit_authorized !== product_original_accept)
     $fatal(1,"product writer authorization mismatch");
 end
 if(dut.product_bank_valid !== 1'b0 && dut.product_commit_authorized === 1'b1)
   $fatal(1,"reader-owned or unknown bank permitted new publication");
 if(dut.product_commit_authorized !== product_original_accept)
   product_differences=product_differences+1;
 if(dut.product_bank_valid === 1'b1)product_reader_edges=product_reader_edges+1;
 product_checks=product_checks+1;
end
endtask
always @(posedge fft_clk)begin
 check_product_publication;
 #0.001;check_product_publication;
 if(dut.fast_running === 1'b1 && dut.product_owner_request !== product_prior_request)
   product_publications=product_publications+1;
 product_prior_request=dut.product_owner_request;
end
task report_product_publication;
begin
 $display("PRODUCT_PUBLICATION_PASS checks=%0d publications=%0d reader_edges=%0d authorization_differences=%0d writer_exact=1",
   product_checks,product_publications,product_reader_edges,product_differences);
end
endtask

endmodule
`default_nettype wire

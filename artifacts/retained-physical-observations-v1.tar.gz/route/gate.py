"""Independent eight-test route-preparation replay; no vendor commands."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
runner=tree/'hdl/library/starlink_pss_acquisition/retained_output_actual/route_retained_output.tcl'
test=tree/'tests/test_starlink_retained_output_route.py'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
expected='034d1eaa197757b762644acd0cad9dc267338ae23fd5d757290c8485d0f1ac9a'
assert sha(runner)==expected and not (root/'preparation-gate.json').exists()
pins={str(path.relative_to(tree)):sha(path) for path in (runner,test)}
for name in pins:
    target=root/'reviewed_source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(tree/name,target)
(root/'preparation-source-pins.json').write_text(json.dumps(pins,indent=2))
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
env['TMPDIR']=str(root)
cmd=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',str(test),
     '--basetemp',str(root/'cases'),'--junitxml',str(root/'preparation-tests.xml')]
(root/'preparation-command.json').write_text(json.dumps({'command':cmd,'cwd':str(tree)},indent=2))
with (root/'preparation-tests.log').open('x') as out:
    p=subprocess.run(cmd,cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=120)
unchanged=pins=={name:sha(tree/name) for name in pins}
xml=ET.parse(root/'preparation-tests.xml').getroot()
counts={key:sum(int(s.get(key,0)) for s in xml.findall('.//testsuite')) for key in ('tests','failures','errors','skipped')}
result={'exit':p.returncode,'unchanged':unchanged,'counts':counts,'expected_tests':8,'runner_sha':expected}
(root/'preparation-gate.json').write_text(json.dumps(result,indent=2))
print((root/'preparation-tests.log').read_text(),flush=True)
assert p.returncode==0 and unchanged and counts=={'tests':8,'failures':0,'errors':0,'skipped':0}

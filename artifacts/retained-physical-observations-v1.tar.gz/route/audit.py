"""Independent diagnostic-route audit; tool success and timing failure are separate."""
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
route=root/'route'
execution=json.loads((root/'execution.json').read_text())
assert execution['vendor_exit']==0 and not execution['timed_out']
assert all(execution[k] for k in ('source_dcp_unchanged','original_runner_unchanged','frozen_runner_unchanged'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(route/'retained_output_routed.dcp')==execution['routed_dcp_sha256']
paths=dict(line.split('=',1) for line in (route/'paths.txt').read_text().splitlines())
expected={('source_100','source_100'):(2.572,0.100),('source_100','island_175'):(-1.255,0.143),
          ('island_175','source_100'):(-1.494,0.128),('island_175','island_175'):(-4.068,0.052)}
for (source,dest),slacks in expected.items():
    for kind,slack in zip(('max','min'),slacks):
        assert float(paths[f'{source}.{dest}.{kind}.slack'])==slack
        assert paths[f'{source}.{dest}.{kind}.reported_paths']=='20'
        text=(route/f'{source}_{dest}_{kind}.rpt').read_text()
        reported=re.findall(r'^Slack \([^\n]*?\)\s*:\s*(-?\d+\.\d+)ns',text,re.M)
        assert len(reported)==20 and float(reported[0])==slack
timing=(route/'timing_unqualified.rpt').read_text()
row=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s*$',timing,re.M)
assert row and row.groups()==('-4.068','-1952.796','1266','11062','0.052','0.000','0','11062','1.830','0.000','0','5122')
assert 'Timing constraints are not met.' in timing
status=(route/'route_status.rpt').read_text()
assert re.search(r'fully routed nets\.+\s*:\s*7224\s*:',status)
assert re.search(r'nets with routing errors\.+\s*:\s*0\s*:',status)
util=(route/'utilization.rpt').read_text()
for label,value in (('Slice LUTs',2334),('Slice Registers',4768)):
    assert re.search(r'\| '+re.escape(label)+r'\s*\|\s*'+str(value)+r'\s*\|',util)
def commands(path):
    return [line.strip() for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
synthesis=root.parent/'retained-synthesis-parent.JqxbVb4y/synthesis'
assert commands(route/'inherited_constraints.xdc')==commands(synthesis/'inherited_constraints.xdc')
assert 'No valid timing exceptions found.' in (route/'exceptions.rpt').read_text()
critical=(route/'island_175_island_175_max.rpt').read_text().split('Slack (VIOLATED)',2)[1]
assert 'product_bank/metadata_out_hold_reg[24]/C' in critical
assert 'owners[0].result_guard/descriptor_reg[64]/CE' in critical
assert '9.493ns' in critical and 'logic 1.758ns' in critical and 'route 7.735ns' in critical
result={'vendor_exit':0,'routed_dcp_sha256':execution['routed_dcp_sha256'],
 'route_complete':True,'fully_routed_nets':7224,'routing_errors':0,
 'timing_pass':False,'wns_ns':-4.068,'tns_ns':-1952.796,'setup_failing_endpoints':1266,
 'whs_ns':0.052,'hold_failing_endpoints':0,'pulse_width_slack_ns':1.830,
 'lut':2334,'ff':4768,'dsp':21,'ramb18':15,
 'clockpair_slacks':{f'{a}->{b}':{'setup':v[0],'hold':v[1]} for (a,b),v in expected.items()},
 'critical_path':{'source':'product_bank/metadata_out_hold[24]',
                  'destination':'owners[0].result_guard/descriptor[64]/CE',
                  'delay_ns':9.493,'logic_ns':1.758,'routing_ns':7.735,'lut_levels':10,
                  'same_clock_domain':True},
 'constraints_unchanged':True,'cdc_and_external_io_qualified':False,'deployment_eligible':False}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

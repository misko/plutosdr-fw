"""Independent mapped-resource/source/constraint audit, explicitly not CDC signoff."""
import collections
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
build=root/'synthesis'
receipt=json.loads((root/'execution.json').read_text())
assert receipt['vendor_exit']==0 and not receipt['timed_out'] and not receipt['changed_prepared_files']
assert receipt['qualified_source_check_exit']==receipt['copied_source_check_exit']==0
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
dcp=build/'retained_output_synth.dcp'
assert sha(dcp)==receipt['dcp_sha256']
assert (build/'dcp_receipt.txt').read_text().strip()=='retained_output_synth.dcp.sha256='+sha(dcp)
assert (build/'generated_ip_before.txt').read_bytes()==(build/'generated_ip_after.txt').read_bytes()
resources={}
for line in (build/'resource_and_paths.txt').read_text().splitlines():
    key,value=line.split('=',1);resources[key]=value
assert {key:resources[key] for key in ('black_boxes','dsp48e1','ramb18e1','ramb36e1')}=={
 'black_boxes':'0','dsp48e1':'21','ramb18e1':'15','ramb36e1':'0'}
hierarchy={}
for line in (build/'hierarchy.rpt').read_text().splitlines():
    columns=[v.strip() for v in line.split('|')[1:-1]]
    if len(columns)==10 and columns[2].isdigit():
        hierarchy[columns[0]]={'module':columns[1],'lut':int(columns[2]),'ff':int(columns[6]),
                              'ram36':int(columns[7]),'ram18':int(columns[8]),'dsp':int(columns[9])}
top=hierarchy['starlink_pss_fft_bank_owned_retained_output_probe']
assert top=={'module':'(top)','lut':2239,'ff':4758,'ram36':0,'ram18':15,'dsp':21}
assert len([name for name in hierarchy if name=='shared_xfft'])==1
assert hierarchy['shared_xfft']['dsp']==17 and hierarchy['shared_xfft']['ram18']==11
assert hierarchy['product']['dsp']==4
for name in ('source_bank','product_bank','output_bank','joiner'):
    assert hierarchy[name]['ram18']==1 and hierarchy[name]['ram36']==0
assert all('unchanged' not in name for name in hierarchy)
assert all(name in hierarchy for name in ('owners[0].result_guard','owners[1].result_guard','epoch_barrier','retained_owner','cutover'))
manifest=json.loads((build/'inputs/manifest.json').read_text())
runtime=[p for p in manifest['compiled'] if '/retained_output/' in p and '/tb/' not in p and p.endswith('.v')]
assert len(runtime)==16
for name in runtime:
    pin=manifest['files'][name]['sha256']
    assert sha(build/'inputs'/name)==pin
profile=(build/'effective_profile.txt').read_text()
for param in ('ENABLE_RETAINED_OUTPUT','REGISTERED_SCHEDULING','BOUNDARY_ROUND_SAT','REGISTER_OPERANDS','LOCAL_FIRST_ADMISSION'):
    assert profile.count(param+'=1')==1
assert sha(build/'clocks.xdc')=='bac30eff84cc71d1f273104b716b388b55e51d33be10f9beaf1901232193ba3f'
xdc=(build/'inherited_constraints.xdc').read_text()
commands=[line.strip() for line in xdc.splitlines() if line.strip() and not line.lstrip().startswith('#')]
assert commands==['create_clock -period 10.000 -name source_100 [get_ports clk]',
                 'create_clock -period 5.714 -name island_175 [get_ports fft_clk]',
                 'current_instance -quiet'],commands
assert 'No valid timing exceptions found.' in (build/'exceptions.rpt').read_text()
xdc_receipts=[]
for group in (build/'constraint_inputs.txt').read_text().split('path=')[1:]:
    lines=group.splitlines();path=Path(lines[0]);digest=lines[1].split('=',1)[1]
    assert sha(path)==digest
    xdc_receipts.append({'path':str(path),'sha256':digest,'properties':lines[2:]})
assert len(xdc_receipts)==2
for source in ('source_100','island_175'):
    for dest in ('source_100','island_175'):
        for kind in ('min','max'):
            assert resources[f'{source}.{dest}.{kind}.reported_paths']=='20'
            report=build/f'{source}_{dest}_{kind}.rpt'
            assert len(re.findall(r'^Slack ',report.read_text(),re.M))==20
timing=(build/'check_timing_unqualified.rpt').read_text()
for category in ('no_clock','unconstrained_internal_endpoints','loops','latch_loops'):
    assert f'checking {category} (0)' in timing
assert 'checking no_input_delay (114)' in timing and 'checking no_output_delay (124)' in timing
cdc=(build/'cdc_unqualified.rpt').read_text()
assert re.search(r'^CDC-1\s+Critical\s+4\b',cdc,re.M)
assert re.search(r'^CDC-10\s+Critical\s+1\b',cdc,re.M)
assert re.search(r'^CDC-15\s+Warning\s+139\b',cdc,re.M)
log=(root/'stdout.log').read_text()
assert not re.search(r'^ERROR:',log,re.M)
assert not re.search(r'implicit (?:definition|declaration)|undriven',log,re.I)
warnings=collections.Counter(re.findall(r'^WARNING: \[([^]]+)\]',log,re.M))
report={'dcp_sha256':sha(dcp),'source_hierarchy_resources_verified':True,'constraints_verified':True,
 'scope':'isolated synthesis resource/source audit; unchanged comparable constraints, not physical signoff',
 'resources':top,'delta_from_L1_synthesis':{'lut':2239-1945,'ff':4758-4547,'dsp':0,'ram18':0},
 'runtime_files':runtime,'constraint_files':xdc_receipts,'warning_counts':dict(warnings),
 'cdc':{'critical':5,'warning':139,'info':3,'qualified':False},
 'unconstrained_io':{'inputs':114,'outputs':124},'all_eight_clockpair_reports':True,
 'clock_model_warning':'Independent rounded primary clocks have no common period in 1000 cycles; not a board-derived clock model.',
 'timing_qualified':False,'deployment_eligible':False}
(root/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:report[k] for k in ('dcp_sha256','resources','delta_from_L1_synthesis','cdc','unconstrained_io')}))

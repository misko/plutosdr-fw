"""Independent small preparation regression, pinned to the proposed copied runner."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
assert len(sys.argv)==4
prepared=Path(sys.argv[1]);expected=sys.argv[2];expected_tests=int(sys.argv[3])
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
assets={
 'synthesize_retained_output.tcl':'hdl/library/starlink_pss_acquisition/retained_output_actual/synthesize_retained_output.tcl',
 'clocks.xdc':'hdl/library/starlink_pss_acquisition/fft_bank_owned_resource_probe.xdc',
 'threads.tcl':'hdl/library/starlink_pss_acquisition/fft_bank_owned_synth_threads.tcl',
 'prepare.py':'tools/prepare_starlink_retained_output_synthesis.py',
 'offline_tests.py':'tests/test_starlink_retained_output_synthesis.py',
}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert not (root/'preparation-gate.json').exists()
assert sha(prepared/'SHA256SUMS')==expected
pins={name:sha(tree/path) for name,path in assets.items()}
assert pins=={name:sha(prepared/name) for name in assets}
(root/'preparation-source-pins.json').write_text(json.dumps(pins,indent=2))
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
(root/'tmp').mkdir()
env['TMPDIR']=str(root/'tmp')
cmd=[sys.executable,'-B','-m','pytest','-q','-p','no:cacheprovider',
     'tests/test_starlink_retained_output_synthesis.py','--basetemp',str(root/'cases'),
     '--junitxml',str(root/'preparation-tests.xml')]
(root/'preparation-command.json').write_text(json.dumps({'command':cmd,'cwd':str(tree),'expected_tests':expected_tests},indent=2))
with (root/'preparation-tests.log').open('x') as out:
    p=subprocess.run(cmd,cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=300)
unchanged=pins=={name:sha(tree/path) for name,path in assets.items()}=={name:sha(prepared/name) for name in assets}
xml=ET.parse(root/'preparation-tests.xml').getroot()
counts={key:sum(int(s.get(key,0)) for s in xml.findall('.//testsuite')) for key in ('tests','failures','errors','skipped')}
result={'exit':p.returncode,'unchanged':unchanged,'counts':counts,'expected_tests':expected_tests,'prepared_sha':expected,
        'runner_sha':pins['synthesize_retained_output.tcl'],'copier_sha':pins['prepare.py']}
(root/'preparation-gate.json').write_text(json.dumps(result,indent=2))
print((root/'preparation-tests.log').read_text(),flush=True)
assert p.returncode==0 and unchanged
assert counts=={'tests':expected_tests,'failures':0,'errors':0,'skipped':0},counts

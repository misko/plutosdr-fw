"""One bounded actual FFT campaign after independent251; no implicit retries."""
import ast
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
bundle=root.parent/'retained-output-actual-prelaunch-frame-v5'
expected='c3936f7e8552d7d377ca1e6fc5ba220d0667b68d00a24e24f524de33e75cbae8'
python='/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11'
snapshot=bundle/'source_snapshot'
runner=snapshot/'hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl'
cli=snapshot/'tools/prepare_starlink_retained_output_actual.py'
output=root/'run'
assert not output.exists()
assert hashlib.sha256((bundle/'manifest.json').read_bytes()).hexdigest()==expected
assert hashlib.sha256(Path(python).read_bytes()).hexdigest()=='2874a0b9344d06b7767aebb1e6e25a759ffcbdb544e99400ecc74dc6092d1174'
parent=root.parent/'retained-frame-parent.mgnSs5jw'
receipt=json.loads((parent/'execution.json').read_text())
assert receipt=={'exit':0,'changed':[],'source_count':80,'counts':{'tests':251,'failures':0,'errors':0,'skipped':0}}
xml=ET.parse(parent/'results.xml').getroot()
assert len(xml.findall('.//testcase'))==251
assert not any(xml.findall('.//'+name) for name in ('failure','error','skipped'))
pins=json.loads((parent/'source-pins.json').read_text())
assert {p:hashlib.sha256((snapshot/p).read_bytes()).hexdigest() for p in pins}==pins
manifest=json.loads((bundle/'manifest.json').read_text())
previous=root.parent/'retained-output-actual-prelaunch-logger-v4'
old_manifest=json.loads((previous/'manifest.json').read_text())
assert manifest['compiled']==old_manifest['compiled']
assert manifest['vectors']==old_manifest['vectors']
for name in ['profile.tcl',*manifest['vectors'],*[p for p in manifest['compiled'] if p!='bench.sv']]:
    assert (bundle/name).read_bytes()==(previous/name).read_bytes(),name
# Parse only the reviewed literal inverse recipe, independently compare all old bytes.
constants={}
helper=snapshot/'tests/starlink_oracle/retained_frame_contract.py'
for statement in ast.parse(helper.read_text()).body:
    if isinstance(statement,ast.Assign) and len(statement.targets)==1 and isinstance(statement.targets[0],ast.Name):
        constants[statement.targets[0].id]=ast.literal_eval(statement.value)
restored=(bundle/'bench.sv').read_text()
for addition in constants['ADDITIONS']:
    assert restored.count(addition)==1
    restored=restored.replace(addition,'',1)
assert restored.count(constants['NEW_FRAME'])==1
restored=restored.replace(constants['NEW_FRAME'],constants['OLD_FRAME'],1)
assert restored.count('actual_frames!=1||!actual_frame_closed)')==1
restored=restored.replace('actual_frames!=1||!actual_frame_closed)','actual_frames!=1)',1)
assert restored==(previous/'bench.sv').read_text()
assert hashlib.sha256(restored.encode()).hexdigest()=='6d498ee2f8ba788e775e711753f13f85657e0c500f75ad5ffa3a6ae8cdc1575f'
(root/'parent251-audit.json').write_text(json.dumps({'tests':251,'source_pins':80,
 'exact_previous_bench_inverse':True,'unchanged_profile_vectors_runtime_compiled_list':True},indent=2))
env={k:v for k,v in os.environ.items() if k not in {'PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH'}}
def verify(path,logname):
    p=subprocess.run([python,'-B',str(cli),'verify',str(path),'--expected',expected,'--live'],
                     cwd='/',env=env,capture_output=True,text=True,timeout=30)
    (root/logname).write_text(p.stdout+p.stderr)
    return p.returncode
assert verify(bundle,'before.log')==0
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
cmd=['/opt/Xilinx/Vivado/2022.2/bin/vivado','-mode','batch','-notrace',
     '-log',str(root/'vivado.log'),'-journal',str(root/'vivado.jou'),'-source',str(runner),
     '-tclargs',str(bundle),python,expected,str(output)]
(root/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'wall_limit_seconds':900,
 'sources_fw':'e1fa85a290e60c40bc16cc13608f48f1239e7ab2',
 'sources_hdl':'28a822025a3ba5e47608b8875ff252baf73e8f42','manifest_sha256':expected,
 'kind':'ACTUAL_VENDOR_FFT_SEVEN_CONTEXTS_NOT_PHYSICAL_RX'},indent=2))
start=time.monotonic();timed_out=False
with (root/'stdout.log').open('x') as log:
    process=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (root/'process.json').write_text(json.dumps({'pid':process.pid,'process_group':process.pid}))
    print('Parent actual FFT process started; pid='+str(process.pid),flush=True)
    try:
        code=process.wait(timeout=900)
    except subprocess.TimeoutExpired:
        timed_out=True
        os.killpg(process.pid,signal.SIGTERM)
        try: code=process.wait(timeout=15)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=15)
env.pop('LD_LIBRARY_PATH',None)
after=verify(bundle,'after.log')
copied=verify(output/'inputs','copied-after.log') if (output/'inputs/manifest.json').is_file() else None
result={'vendor_exit':code,'timed_out':timed_out,'wall_seconds':time.monotonic()-start,
 'original_source_check_exit':after,'copied_source_check_exit':copied,
 'result_file_exists':(output/'results.json').is_file()}
(root/'execution.json').write_text(json.dumps(result,indent=2))
print('\n'.join((root/'stdout.log').read_text().splitlines()[-25:]),flush=True)
print(json.dumps(result),flush=True)
assert code==0 and not timed_out and after==0 and copied==0 and result['result_file_exists'],result

"""Parent-only unchanged scripted composition plus additive summary observations."""
import hashlib
import json
from pathlib import Path
import sys

tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_closed_input_candidate as closed
from tests.starlink_oracle import retained_output_prototype as old

root = Path(__file__).resolve().parent
candidate = old.RTL.parent / 'retained_output_summary_candidate'
inverse_path = tree / 'tests/starlink_oracle/retained_offer_summary_inverse.json'
inverse = json.loads(inverse_path.read_text())
assert len(inverse) == 4 and sum(map(len, inverse.values())) == 21
for name, patches in inverse.items():
    text = (candidate / name).read_text()
    for before, after in reversed(patches):
        assert text.count(after) == 1, name
        text = text.replace(after, before, 1)
    assert text == (closed.RTL / name).read_text(), name
sources = [candidate / p.name if p.name in inverse else p for p in closed.sources()]
helpers = [tree / 'tests/starlink_oracle' / name for name in (
    'retained_closed_input_candidate.py', 'retained_control_candidate.py',
    'retained_output_prototype.py', 'retained_closed_input_inverse.json',
    'retained_private_offer_inverse.json')]
pins = set(sources + helpers + [inverse_path, old.RTL / 'tb/tb_retained_composition.sv'])
pins.update(old.BASELINE / name for name in old.PINS)
def snapshot():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pins)}
before = snapshot()
(root / 'sources-before.json').write_text(json.dumps(before, indent=2))
extra = '''
  integer parent_summary_checks=0,parent_premise_checks=0;
  always @(posedge fft_clk or negedge fft_clk)begin
    #0.001;
    if(dut.retained.island.fast_running===1'b1)begin
      if(dut.retained.island.input_fault_now===1'b0 || dut.retained.island.input_fault_now===1'b1)begin
        if(dut.retained.island.offered_common_current_fault!==dut.retained.island.original_common_current_fault)
          $fatal(1,"parent known input fault common summary mismatch");
      end else if(dut.retained.island.offered_common_current_fault!==1'b1)
        $fatal(1,"parent unknown input fault lacks summary veto");
      if(dut.retained.island.input_fault_now===1'b0)begin
        if({dut.retained.island.summary_offer_beat,dut.retained.island.summary_offer_complete}!==
           {dut.retained.island.certified_input_beat,dut.retained.island.certified_input_complete})
          $fatal(1,"parent input offer premise mismatch");
        parent_premise_checks=parent_premise_checks+1;
      end
      parent_summary_checks=parent_summary_checks+1;
    end
  end
  final begin
    if(parent_summary_checks<1000 || parent_premise_checks<1000)$fatal(1,"parent summary witness missing");
    $display("PARENT_SUMMARY checks=%0d premise=%0d",parent_summary_checks,parent_premise_checks);
  end
'''
results = []
for mode in (0, 1):
    for stall in (0, 2, 5):
        name = f'mode{mode}-stall{stall}'
        text = closed.composition(1, 1)
        assert text.count('endmodule') == 1
        text = text.replace('endmodule', f'  defparam dut.INPUT_OFFER_FAULT_SUMMARY={mode};\n' + extra + 'endmodule')
        output = old.run_sv(root / name, text, sources, parameters=[f'-Ptb.STALL={stall}'])
        results.append(dict(mode=mode, stall=stall, output=output))
        print(name + ' PASS', flush=True)
after = snapshot()
(root / 'sources-after.json').write_text(json.dumps(after, indent=2))
assert before == after
receipt = dict(scope='scripted FFT composition smoke; not actual FFT, complete fault matrix or timing',
    source_count=len(before), source_unchanged=True, inverse_anchors=21, cases=results)
(root / 'result.json').write_text(json.dumps(receipt, indent=2))
print(json.dumps(dict(passed=len(results), source_count=len(before), source_unchanged=True)))

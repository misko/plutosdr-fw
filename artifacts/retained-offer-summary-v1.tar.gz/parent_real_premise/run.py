"""Parent replay of frozen real-input premise and three independent mutations."""
import hashlib
import json
from pathlib import Path
import sys

tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_output_prototype as old
root = Path(__file__).resolve().parent
bench = old.RTL.parent / 'retained_output_summary_candidate/tb_offer_input_premise.sv'
guard = old.BASELINE / 'starlink_pss_realtime_input_guard_local_admission.v'
helper = tree / 'tests/starlink_oracle/retained_output_prototype.py'
pins = {bench: '1eaad1feedf449c9a1d2c0fd43f500527eac46288ae42f1adf3ef0665fd5db4f',
        guard: '55438743eede0d346cec67351e079eb6ae21da437d4088a131a2a258b43ff233',
        helper: '0066ae35105d57dfd3e7c924e036c4d518102853c6eb8ecde1c254ad9c2e3488'}
def check():
    for path, digest in pins.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, path
check()
snapshot = root / 'source_snapshot'
snapshot.mkdir()
for path in pins:
    (snapshot / path.name).write_bytes(path.read_bytes())
text = bench.read_text()
results = [dict(case='reference', output=old.run_sv(root / 'reference', text, [guard]))]
for name, token, replacement in [
    ('missing_ready', 'input_valid&&input_transport_ready', 'input_valid&&dut.eligible'),
    ('wrong_last', 'offered_beat&&input_last', 'offered_beat&&!input_last'),
    ('wrong_owner', 'offered_beat&&route,offered_end&&route', 'offered_beat&&!route,offered_end&&route')]:
    assert text.count(token) == 1
    output = old.run_sv(root / name, text.replace(token, replacement), [guard],
        expected_failure='per-owner summary route mismatch' if name == 'wrong_owner' else 'real input offered premise mismatch')
    results.append(dict(case=name, rejected=True, output=output))
check()
result = dict(scope='real guard 512 healthy clocked inputs plus non-sampling XZ probes; not whole-composition fault/ACK test',
    source_pins={str(p): h for p, h in pins.items()}, source_unchanged=True, results=results)
(root / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))

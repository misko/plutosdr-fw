"""Source-specific offered fault summary, never a delivery/certificate substitute."""
import hashlib
import json
import re
from pathlib import Path

from tests.starlink_oracle import retained_closed_input_candidate as closed
from tests.starlink_oracle import retained_output_prototype as old

RTL = old.RTL.parent / 'retained_output_summary_candidate'
PINS = {
    'starlink_pss_fft_bank_owned_retained_output_probe.v': '62f7941bc76ac320bfdee235aeae9a5f3c3bd86e251e92f571162f8183a0abec',
    'starlink_pss_fft_retained_output_impl.v': '1d01972d11486772b627a3afdd594f06e41c0f98b830288e93b371af0506ef1e',
    'starlink_pss_core_job_cutover.v': '6f3a42178b824c28f0f6bfe3c4aeb56a2c23b84fc9aa38ab3be0d5609c4cba19',
    'starlink_pss_result_guard_owner_view.v': '53c336df4dd378a27b12f7c4d382d25290c81c0881b8e6c4f914faa67482d320',
}
PATCHES = json.loads(Path(__file__).with_name('retained_offer_summary_inverse.json').read_text())


def inverse(name, text):
    for before, after in reversed(PATCHES[name]):
        if text.count(after) != 1:
            raise ValueError('offered summary inverse boundary')
        text = text.replace(after, before, 1)
    if hashlib.sha256(text.encode()).hexdigest() != PINS[name]:
        raise ValueError('offered summary whole-source inverse')
    return text


def sources():
    for name, pin in PINS.items():
        assert hashlib.sha256((closed.RTL / name).read_bytes()).hexdigest() == pin
        inverse(name, (RTL / name).read_text())
    return [RTL / p.name if p.parent == closed.RTL and p.name in PINS else p
            for p in closed.sources()]


def composition(mode=1, private=1, completed=1):
    """Original full arithmetic/guard shadows and exact source/stall/reset script."""
    text = closed.composition(private, completed)
    extra = f'  defparam dut.INPUT_OFFER_FAULT_SUMMARY={mode};\n' + '''
  integer summary_checks=0,summary_zero_checks=0,summary_fault_checks=0,summary_ack_checks=0;
  task summary_check;
    begin
      if(dut.retained.island.fast_running)begin
        if(dut.retained.island.input_fault_now===1'b0)begin
          if({dut.retained.island.summary_offer_beat,dut.retained.island.summary_offer_complete}!==
             {dut.retained.island.certified_input_beat,dut.retained.island.certified_input_complete})
            $fatal(1,"composition offered premise mismatch");
          summary_zero_checks=summary_zero_checks+1;
        end
        if(''' + str(mode) + ''')begin
          if(dut.retained.island.input_fault_now===1'b0 || dut.retained.island.input_fault_now===1'b1)begin
            if(dut.retained.island.common_current_fault!==dut.retained.island.original_common_current_fault)
              $fatal(1,"known input fault common summary mismatch");
          end else if(dut.retained.island.common_current_fault!==1'b1)
            $fatal(1,"unknown input fault not fail closed");
        end else if(dut.retained.island.common_current_fault!==dut.retained.island.original_common_current_fault)
          $fatal(1,"disabled common summary changed");
        if(dut.retained.island.input_fault_now!==1'b0)begin
          if(dut.retained.island.reader_release!==0 || dut.retained.island.job_accept!==0)
            $fatal(1,"direct input fault lost global release/admission veto");
          summary_fault_checks=summary_fault_checks+1;
        end
        if(dut.retained.island.reader_release)summary_ack_checks=summary_ack_checks+1;
        summary_checks=summary_checks+1;
      end
    end
  endtask
  always @(posedge fft_clk)begin summary_check();#0.001;summary_check();end
  final begin
    if(summary_checks<1000||summary_zero_checks<1000)$fatal(1,"summary witness inventory");
    $display("OFFER_SUMMARY_WITNESS checks=%0d known_zero=%0d direct_fault=%0d real_ack=%0d",
      summary_checks,summary_zero_checks,summary_fault_checks,summary_ack_checks);
  end
'''
    assert text.count('endmodule') == 1
    return text.replace('endmodule', extra + 'endmodule')


def guard_equivalence(mode=1):
    """Untouched 23 healthy/37 rejection/12 reset guard stimulus; full shadows."""
    text = old.guard_equivalence_bench()
    before = '.WATCHDOG_CYCLES(2048)) shadow('
    after = f'''.WATCHDOG_CYCLES(2048),.ENABLE_OFFERED_FAULT_SUMMARY({mode})) shadow(
    .offered_input_beat(stimulus.dut.certified_input_beat),
    .offered_input_complete(stimulus.dut.certified_input_complete),'''
    assert text.count(before) == 1
    text = text.replace(before, after)
    extra = '''
  integer local_summary_checks=0;
  always @(posedge stimulus.clk or negedge stimulus.clk)begin
    #0.001;
    if(''' + str(mode) + ''')begin
      if(shadow.owner_fault_now !== (shadow.external_fault_now || shadow.offered_local_fault_now))
        $fatal(1,"guard local fault decomposition mismatch");
    end else if(shadow.offered_local_fault_now!==0)$fatal(1,"disabled summary not zero");
    local_summary_checks=local_summary_checks+1;
  end
  final begin
    if(local_summary_checks<10000)$fatal(1,"local summary inventory");
    $display("LOCAL_SUMMARY_WITNESS checks=%0d",local_summary_checks);
  end
'''
    return text.replace('endmodule', extra + 'endmodule')


def cutover_algebra():
    """Real module combinational outputs, forced state only: not reachability."""
    return '''`timescale 1ns/1ps
module tb;
  reg clk=0,resetn,core_resetn,raw_frame,raw_output,raw_status,input_beat,input_complete;
  reg[2:0]raw_vendor_faults;
  reg owner_open,configured,reset_flushed,fresh_frame,fresh_full;
  starlink_pss_core_job_cutover #(.ENABLE_OFFERED_FAULT_SUMMARY(1)) dut(
    .clk(clk),.resetn(resetn),.core_resetn(core_resetn),.job_accept(1'b0),.job_inverse(1'b0),
    .producer_closed(1'b0),.config_accept(1'b0),.input_beat(input_beat),.input_complete(input_complete),
    .offered_input_beat(input_beat),.offered_input_complete(input_complete),
    .raw_frame(raw_frame),.raw_output(raw_output),.raw_status(raw_status),.raw_vendor_faults(raw_vendor_faults));
  reg[14:0]values;integer n,k,checks=0;
  task check;
    begin
      {resetn,core_resetn,owner_open,configured,reset_flushed,fresh_frame,fresh_full,
        raw_frame,raw_output,raw_status,raw_vendor_faults,input_beat,input_complete}=values;
      #0.001;
      if(dut.offered_fault_now!==dut.fault_now)$fatal(1,"cutover offered literal predicate mismatch");
      checks=checks+1;
    end
  endtask
  initial begin
    force dut.owner_open=owner_open;force dut.configured=configured;force dut.reset_flushed=reset_flushed;
    force dut.fresh_frame=fresh_frame;force dut.fresh_full=fresh_full;
    for(n=0;n<32768;n=n+1)begin
      values=n;check();
      for(k=0;k<15;k=k+1)begin values=n;values[k]=1'bx;check();values[k]=1'bz;check();end
    end
    if(checks!=1015808)$fatal(1,"cutover algebra inventory");
    $display("OFFLINE_PASS cutover summary algebra checks=%0d forced_state_not_reachability",checks);$finish;
  end
endmodule
'''


def assert_literal_summary_partition():
    """Whole expressions, not Boolean simplification or a general graph parser."""
    guard = (RTL / 'starlink_pss_result_guard_owner_view.v').read_text()
    original = guard[guard.index('  wire effective_input_full ='):guard.index('  // No inherited external-fault echo.')]
    summary = guard[guard.index('  wire summary_effective_input_full ='):guard.index('  assign offered_local_fault_now =')]
    names = re.findall(r'wire (?:\[[^]]+\] )?(\w+)\s*=', original)
    expected = re.sub(r'\bcertified_input_beat\b', 'offered_input_beat', original)
    expected = re.sub(r'\bcertified_input_complete\b', 'offered_input_complete', expected)
    expected = re.sub(r'\bexternal_fault_now\b', "1'b0", expected)
    for name in names:
        expected = re.sub(r'\b' + name + r'\b', 'summary_' + name, expected)
    assert summary == expected
    assert len(names) == 12
    top = (RTL / 'starlink_pss_fft_retained_output_impl.v').read_text()
    external = top[top.index('  wire external_fault_now ='):top.index('  // Direct unknown input fault')]
    summary_external = top[top.index('  wire offered_external_fault_now ='):top.index('  wire forward_handoff_ack')]
    expected = external.replace('wire external_fault_now', 'wire offered_external_fault_now')
    expected = expected.replace('= input_fault_now ||', "= (input_fault_now !== 1'b0) ||")
    expected = expected.replace('cutover_fault_now', 'cutover_offered_fault_now')
    assert expected == summary_external
    assert '.offered_input_beat(summary_offer_beat && this_raw_owner)' in top
    assert '.offered_input_complete(summary_offer_complete && this_raw_owner)' in top
    return names

"""Bounded source/real-module/behavioral tests, never vendor timing evidence."""
import pytest

from tests.starlink_oracle import retained_offer_summary_candidate as c
from tests.starlink_oracle import retained_output_prototype as old


@pytest.mark.parametrize('name', c.PINS)
def test_whole_source_inverse(name):
    restored = c.inverse(name, (c.RTL / name).read_text())
    assert restored == (c.closed.RTL / name).read_text()
    c.closed.inverse(name, restored)


@pytest.mark.parametrize('name', c.PINS)
@pytest.mark.parametrize('kind', ['missing', 'duplicate', 'unrelated'])
def test_inverse_mutations(name, kind):
    text = (c.RTL / name).read_text()
    token = c.PATCHES[name][-1][1]
    if kind == 'missing':
        text = text.replace(token, '')
    elif kind == 'duplicate':
        text = text.replace(token, token * 2)
    else:
        text += '\n'
    with pytest.raises(ValueError, match='inverse'):
        c.inverse(name, text)


def test_literal_dependent_summary_partition():
    assert len(c.assert_literal_summary_partition()) == 12


def test_real_input_guard_512_and_four_state_premise(tmp_path):
    old.run_sv(tmp_path / 'input', (c.RTL / 'tb_offer_input_premise.sv').read_text(),
               [old.BASELINE / 'starlink_pss_realtime_input_guard_local_admission.v'])


@pytest.mark.parametrize('kind', ['ready', 'last', 'owner'])
def test_real_premise_mutations(tmp_path, kind):
    text = (c.RTL / 'tb_offer_input_premise.sv').read_text()
    token, replacement = {
        'ready': ('input_valid&&input_transport_ready', 'input_valid&&dut.eligible'),
        'last': ('offered_beat&&input_last', 'offered_beat&&!input_last'),
        'owner': ('offered_beat&&route,offered_end&&route', 'offered_beat&&!route,offered_end&&route'),
    }[kind]
    assert text.count(token) == 1
    old.run_sv(tmp_path / kind, text.replace(token, replacement),
               [old.BASELINE / 'starlink_pss_realtime_input_guard_local_admission.v'],
               expected_failure='per-owner summary route mismatch' if kind == 'owner' else 'real input offered premise mismatch')


def test_cutover_real_module_algebra(tmp_path):
    old.run_sv(tmp_path / 'cutover', c.cutover_algebra(), [c.RTL / 'starlink_pss_core_job_cutover.v'])


@pytest.mark.parametrize('mode', [0, 1])
def test_original_guard_all_state_output_and_summary(tmp_path, mode):
    old.run_sv(tmp_path / 'guard', c.guard_equivalence(mode), [
        old.BASELINE / 'starlink_pss_realtime_result_guard.v',
        old.RTL / 'baseline_tests/tb_starlink_pss_realtime_result_guard.sv',
        c.RTL / 'starlink_pss_result_guard_owner_view.v'])


@pytest.mark.parametrize('mode', [0, 1])
@pytest.mark.parametrize('stall', [0, 2, 5])
def test_composition_exact_original_shadows(tmp_path, mode, stall):
    old.run_sv(tmp_path / 'composition', c.composition(mode), c.sources(), parameters=[f'-Ptb.STALL={stall}'])
    from tests.starlink_oracle.retained_output_graph import state_inventory
    inventory = state_inventory((tmp_path / 'composition/sim.vvp').read_text(), 'tb.dut.retained.island')
    assert inventory['declared_bits'] == 2480
    assert len([r for r in inventory['arrays'] if r['path'].endswith('.payload_memory')]) == 3


@pytest.mark.parametrize('literal', ['-1', '2', "32'bx", "32'bz"])
def test_unknown_mode_rejected(tmp_path, literal):
    old.run_sv(tmp_path / 'bad-mode', c.composition(literal), c.sources(),
               expected_failure='offered fault summary mode must be known zero or one')

`timescale 1ns/1ps
module tb;
  reg clk=0,resetn,core_resetn,raw_frame,raw_output,raw_status,input_beat,input_complete;
  reg[2:0]raw_vendor_faults;
  reg owner_open,configured,reset_flushed,fresh_frame,fresh_full;
  starlink_pss_core_job_cutover #(.ENABLE_OFFERED_FAULT_SUMMARY(1)) dut(
    .clk(clk),.resetn(resetn),.core_resetn(core_resetn),.job_accept(1'b0),.job_inverse(1'b0),
    .producer_closed(1'b0),.config_accept(1'b0),.input_beat(input_beat),.input_complete(input_complete),
    .offered_input_beat(input_beat),.offered_input_complete(input_complete),
    .raw_frame(raw_frame),.raw_output(raw_output),.raw_status(raw_status),.raw_vendor_faults(raw_vendor_faults));
  reg[14:0]values;integer n,k,checks=0;
  task check;
    begin
      {resetn,core_resetn,owner_open,configured,reset_flushed,fresh_frame,fresh_full,
        raw_frame,raw_output,raw_status,raw_vendor_faults,input_beat,input_complete}=values;
      #0.001;
      if(dut.offered_fault_now!==dut.fault_now)$fatal(1,"cutover offered literal predicate mismatch");
      checks=checks+1;
    end
  endtask
  initial begin
    force dut.owner_open=owner_open;force dut.configured=configured;force dut.reset_flushed=reset_flushed;
    force dut.fresh_frame=fresh_frame;force dut.fresh_full=fresh_full;
    for(n=0;n<32768;n=n+1)begin
      values=n;check();
      for(k=0;k<15;k=k+1)begin values=n;values[k]=1'bx;check();values[k]=1'bz;check();end
    end
    if(checks!=1015808)$fatal(1,"cutover algebra inventory");
    $display("OFFLINE_PASS cutover summary algebra checks=%0d forced_state_not_reachability",checks);$finish;
  end
endmodule

`timescale 1ns/1ps
module tb;
  reg input_fault_now,input_guard_fault,vendor_fault_now,fast_fault,kernel_fault,product_overflow;
  reg product_bank_fault,product_bank_framing_fault_now,handoff_fault_now,cutover_fault_now,retained_fault_now;
  reg output_bank_fault,output_bank_framing_fault_now,preparation_fault_now,result_fault;
  reg[1:0]source_fault_fast=0;reg[7:0]cutover_reasons=0,retained_reasons=0;
  reg[1:0]original_local,alternative_local;reg alternative_cutover;
  wire[1:0]guard_offered_local_fault=(input_fault_now===0)?original_local:alternative_local;
  wire cutover_offered_fault_now=(input_fault_now===0)?cutover_fault_now:alternative_cutover;
  wire forward_fault_now=external_fault_now||original_local[0];
  wire inverse_fault_now=external_fault_now||original_local[1];
  wire external_fault_now = input_fault_now || input_guard_fault || source_fault_fast[1] ||
    vendor_fault_now || fast_fault || kernel_fault || product_overflow || product_bank_fault ||
    product_bank_framing_fault_now || handoff_fault_now || cutover_fault_now ||
    (|cutover_reasons) || retained_fault_now || (|retained_reasons);
  wire offered_external_fault_now = (input_fault_now != 1'b0) || input_guard_fault || source_fault_fast[1] ||
    vendor_fault_now || fast_fault || kernel_fault || product_overflow || product_bank_fault ||
    product_bank_framing_fault_now || handoff_fault_now || cutover_offered_fault_now ||
    (|cutover_reasons) || retained_fault_now || (|retained_reasons);
  wire original_common_current_fault = external_fault_now || forward_fault_now || inverse_fault_now ||
    output_bank_fault || output_bank_framing_fault_now || preparation_fault_now || result_fault;
  wire offered_common_current_fault = offered_external_fault_now ||
    guard_offered_local_fault[0] || guard_offered_local_fault[1] ||
    output_bank_fault || output_bank_framing_fault_now || preparation_fault_now || result_fault;
  function automatic q(input integer x);
    case(x%4)0:q=0;1:q=1;2:q=1'bx;3:q=1'bz;endcase
  endfunction
  integer n,i,value,checks=0,known_checks=0,unknown_checks=0;
  reg counter_i,counter_l;
  wire original_counter=counter_i||(!counter_i&&counter_l);
  wire absorbed_counter=counter_i||counter_l;
  task check;
    begin
      #0.001;
      if(input_fault_now===0||input_fault_now===1)begin
        if(offered_common_current_fault!==original_common_current_fault)
          $fatal(1,"common independent root/decomposition mismatch root=%0d",i);
        known_checks=known_checks+1;
      end else begin
        if(offered_common_current_fault!==1)$fatal(1,"unknown direct input fault not known-one");
        if(original_common_current_fault===0)$fatal(1,"unknown input fault old predicate unexpectedly zero");
        unknown_checks=unknown_checks+1;
      end
      checks=checks+1;
    end
  endtask
  initial begin
input_guard_fault=0;source_fault_fast[1]=0;vendor_fault_now=0;fast_fault=0;kernel_fault=0;product_overflow=0;product_bank_fault=0;product_bank_framing_fault_now=0;handoff_fault_now=0;cutover_fault_now=0;cutover_reasons[0]=0;retained_fault_now=0;retained_reasons[0]=0;output_bank_fault=0;output_bank_framing_fault_now=0;preparation_fault_now=0;result_fault=0;
    original_local=0;alternative_local=0;alternative_cutover=0;input_fault_now=0;
    for(i=0;i<17;i=i+1)for(value=0;value<4;value=value+1)begin
input_guard_fault=0;source_fault_fast[1]=0;vendor_fault_now=0;fast_fault=0;kernel_fault=0;product_overflow=0;product_bank_fault=0;product_bank_framing_fault_now=0;handoff_fault_now=0;cutover_fault_now=0;cutover_reasons[0]=0;retained_fault_now=0;retained_reasons[0]=0;output_bank_fault=0;output_bank_framing_fault_now=0;preparation_fault_now=0;result_fault=0;
      case(i)
0:input_guard_fault=q(value);
1:source_fault_fast[1]=q(value);
2:vendor_fault_now=q(value);
3:fast_fault=q(value);
4:kernel_fault=q(value);
5:product_overflow=q(value);
6:product_bank_fault=q(value);
7:product_bank_framing_fault_now=q(value);
8:handoff_fault_now=q(value);
9:cutover_fault_now=q(value);
10:cutover_reasons[0]=q(value);
11:retained_fault_now=q(value);
12:retained_reasons[0]=q(value);
13:output_bank_fault=q(value);
14:output_bank_framing_fault_now=q(value);
15:preparation_fault_now=q(value);
16:result_fault=q(value);
      endcase
      check();
    end
input_guard_fault=0;source_fault_fast[1]=0;vendor_fault_now=0;fast_fault=0;kernel_fault=0;product_overflow=0;product_bank_fault=0;product_bank_framing_fault_now=0;handoff_fault_now=0;cutover_fault_now=0;cutover_reasons[0]=0;retained_fault_now=0;retained_reasons[0]=0;output_bank_fault=0;output_bank_framing_fault_now=0;preparation_fault_now=0;result_fault=0;
    for(n=0;n<16384;n=n+1)begin
      input_fault_now=q(n);original_local[0]=q(n/4);original_local[1]=q(n/16);
      alternative_local[0]=q(n/64);alternative_local[1]=q(n/256);
      cutover_fault_now=q(n/1024);alternative_cutover=q(n/4096);check();
    end
    counter_i=1'bx;counter_l=1;#0.001;
    if(original_counter!==1'bx||absorbed_counter!==1)$fatal(1,"four-state absorption counterexample missing");
    if(checks!=16452||known_checks!=8260||unknown_checks!=8192)$fatal(1,"common summary algebra inventory");
    $display("OFFLINE_PASS common actual expressions roots17 checks=%0d known=%0d unknown_tightening=%0d absorption_X_vs_1",checks,known_checks,unknown_checks);$finish;
  end
endmodule

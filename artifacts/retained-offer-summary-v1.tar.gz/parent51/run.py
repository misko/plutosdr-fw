"""Parent full51 offline gate with immutable source snapshots and bounded pytest."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_offer_summary_candidate as c
old = c.old
test = tree / 'tests/test_starlink_retained_offer_summary.py'
assert hashlib.sha256(test.read_bytes()).hexdigest() == '2fdd8ec285ff2898f053fae7cb9094720e1aec45ed601c5dd4e5a0138fe422c3'
assert hashlib.sha256((tree / 'tests/starlink_oracle/retained_offer_summary_candidate.py').read_bytes()).hexdigest() == 'e945d76e9d02e6cee2389f35524c031390a4925ceb708585e087e07d3455a84b'
sources = set(c.sources())
sources.update([test, c.RTL / 'tb_offer_input_premise.sv', c.RTL / 'tb_offer_fault_ack.sv',
    old.RTL / 'baseline_tests/tb_starlink_pss_realtime_result_guard.sv',
    old.RTL / 'tb/tb_retained_composition.sv'])
for directory in (old.RTL, c.closed.RTL, c.closed.private.CANDIDATE):
    sources.update(directory.glob('*.v'))
sources.update(old.BASELINE / name for name in old.PINS)
for name in ('retained_offer_summary_candidate.py', 'retained_offer_summary_inverse.json',
             'retained_closed_input_candidate.py', 'retained_closed_input_inverse.json',
             'retained_control_candidate.py', 'retained_private_offer_inverse.json',
             'retained_output_prototype.py', 'retained_output_graph.py'):
    sources.add(tree / 'tests/starlink_oracle' / name)
def snapshot():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(sources)}
before = snapshot()
(root / 'sources-before.json').write_text(json.dumps(before, indent=2))
for path in sorted(sources):
    target = root / 'source_snapshot' / path.relative_to(tree)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(path.read_bytes())
env = {k:v for k,v in os.environ.items() if k not in ('PYTHONHOME', 'PYTHONPATH', 'PYTHONOPTIMIZE', 'LD_LIBRARY_PATH')}
command = ['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python', '-B', '-m', 'pytest', '-q',
           str(test), '--basetemp=' + str(root / 'pytest'), '--junitxml=' + str(root / 'junit.xml'), '-p', 'no:cacheprovider']
(root / 'command.json').write_text(json.dumps(command))
start = time.monotonic()
result = subprocess.run(command, cwd=tree, env=env, capture_output=True, text=True, timeout=120)
(root / 'pytest.log').write_text(result.stdout + result.stderr)
after = snapshot()
(root / 'sources-after.json').write_text(json.dumps(after, indent=2))
receipt = dict(exit_code=result.returncode, seconds=time.monotonic()-start,
    source_count=len(before), source_unchanged=before==after,
    scope='full51 offline candidate tests; no actual FFT/routing/RF claim')
(root / 'execution.json').write_text(json.dumps(receipt, indent=2))
print(result.stdout + result.stderr)
print(json.dumps(receipt))
assert result.returncode == 0 and before == after
suites = list(ET.parse(root / 'junit.xml').getroot().iter('testsuite'))
assert sum(int(s.attrib['tests']) for s in suites) == 51
assert all(int(s.attrib.get(k, '0')) == 0 for s in suites for k in ('errors', 'failures', 'skipped'))

// Independent abstract combinational proof, not reachable-state/RX simulation.
// A abstracts eligible&&input_valid; delivery_gate abstracts slot_open&&input_started.
// These independent four-state inputs overapproximate actual guard states.
`timescale 1ns/1ps
module tb;
  reg a, ready, ordinal_equal, last, final_position, identity_equal, delivery_gate, duplicate;
  reg owner;
  wire metadata_valid = ordinal_equal && (last == final_position) && identity_equal;
  wire core_valid = a && metadata_valid;
  wire framing_error = a && !metadata_valid;
  wire delivery_error = delivery_gate && ready && !core_valid;
  wire fault = framing_error || delivery_error || duplicate;
  wire certified_beat = core_valid && ready && !fault;
  wire certified_end = certified_beat && final_position;
`ifdef MUTATE_NO_READY
  wire offer_beat = a;
`else
  wire offer_beat = a && ready;
`endif
`ifdef MUTATE_INVERT_LAST
  wire offer_end = offer_beat && !last;
`else
  wire offer_end = offer_beat && last;
`endif
  integer n,k,q,zero_cases=0,owner_cases=0,malformed_offer=0,gap=0,duplicate_cases=0;
  reg [7:0] values;
  function automatic reg four(input integer v);
    case(v) 0:four=0;1:four=1;2:four=1'bx;3:four=1'bz;endcase
  endfunction
  initial begin
    for(n=0;n<65536;n=n+1)begin
      for(k=0;k<8;k=k+1)values[k]=four((n>>(2*k))&3);
      {a,ready,ordinal_equal,last,final_position,identity_equal,delivery_gate,duplicate}=values;
      #1;
      if(fault===0)begin
        if(offer_beat!==certified_beat || offer_end!==certified_end)
          $fatal(1,"known-zero premise failed n=%0d controls=%b",n,values);
        zero_cases=zero_cases+1;
        for(q=0;q<4;q=q+1)begin
          owner=four(q);#1;
          if((offer_beat&&owner)!==(certified_beat&&owner) ||
             (offer_end&&owner)!==(certified_end&&owner))
            $fatal(1,"per-owner premise failed n=%0d owner=%b",n,owner);
          owner_cases=owner_cases+1;
        end
      end
      if(offer_beat===1 && certified_beat===0 && framing_error===1)malformed_offer=malformed_offer+1;
      if(offer_beat===0 && delivery_error===1)gap=gap+1;
      if(offer_beat===0 && duplicate===1)duplicate_cases=duplicate_cases+1;
    end
    if(zero_cases==0 || owner_cases!=4*zero_cases || malformed_offer==0 || gap==0 || duplicate_cases==0)
      $fatal(1,"missing positive or negative premise coverage");
    $display("PASS abstract valuations65536 known_zero=%0d owner_cases=%0d malformed_offer=%0d gap=%0d duplicate=%0d",
      zero_cases,owner_cases,malformed_offer,gap,duplicate_cases);
    $finish;
  end
endmodule

"""Bounded abstract-premise check; no RTL or vendor mutation."""
import hashlib
import json
from pathlib import Path
import subprocess
root = Path(__file__).resolve().parent
source = root / 'premise.sv'
before = hashlib.sha256(source.read_bytes()).hexdigest()
results = []
for name, define in [('reference', None), ('missing_ready', 'MUTATE_NO_READY'), ('wrong_last', 'MUTATE_INVERT_LAST')]:
    command = ['iverilog', '-g2012', '-s', 'tb', '-o', str(root / (name + '.vvp'))]
    if define:
        command.append('-D' + define)
    command.append(str(source))
    compiled = subprocess.run(command, capture_output=True, text=True, timeout=30)
    assert compiled.returncode == 0, compiled.stderr
    result = subprocess.run(['vvp', str(root / (name + '.vvp'))], capture_output=True, text=True, timeout=30)
    (root / (name + '.log')).write_text(result.stdout + result.stderr)
    if define:
        assert result.returncode != 0 and 'known-zero premise failed' in result.stdout
    else:
        assert result.returncode == 0 and 'PASS abstract valuations65536 known_zero=1852 owner_cases=7408' in result.stdout
    results.append(dict(name=name, returncode=result.returncode, output=result.stdout))
assert hashlib.sha256(source.read_bytes()).hexdigest() == before
receipt = dict(scope='abstract four-state combinational premise, not reachability or whole receiver proof', source_sha256=before, source_unchanged=True, results=results)
(root / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))

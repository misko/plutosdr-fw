# Retained offered-summary source graph audit

Final offline audit: PASS, original command exit 0 (tool receipt `8e8979`).
No simulation, Vivado, synthesis, route, source edit, or radio operation occurred.
Only this independent recovery directory and the explicitly retained earlier
audit-attempt directories were written.

## Frozen result

- Script: `audit_graph.py`, SHA-256 `d0285b2df3e7694e9286f07d34c89372939ca61337ad34af9bc5c02790ebe7e2`.
- Result: `results.json`, SHA-256 `777640df53b7ac28118f1aa9bbe7e7f0f2023726f6ac5e021405c1ffcb6de5f1`.
- Base VVP: `base/graph.vvp`, SHA-256 `6c6bd16bce973ee11939fe74c8dfae45370fb692a3064167fc4480ba154c6149`.
- Pre/post receipts: `source-before.json` and `source-after.json`; all 27 inputs
  match before, copied, and after. This includes all 16 selected runtime files,
  references/inverse recipe, and this audit's source/harness/boundary.
- All 10 Icarus elaborations exited 0 with empty diagnostic logs. VVP was never run.
- Whole-source inverse reconstructs all four preceding closed-candidate files
  exactly; see `whole-source-inverse.json`.

Candidate SHA-256 values:

| File | SHA-256 |
|---|---|
| core_job_cutover | c67b62486356215a12cd8e9c2b220c5a877a661bd1b15a13b25f9904171ba330 |
| bank_owned_retained_output_probe | 7367d534792385eab3b4264f2e36849b18222e6fe848ef7dbc0887394de8bf94 |
| fft_retained_output_impl | 3b98a25b8c5d50a18da1692511ae1647c2969fadf5c55d679278b2d5a7bbf0ff |
| result_guard_owner_view | 8b853ee26ab18b4639ab0faf156fd75661f86030773c14f5a9843140c52b5d02 |

## Structural findings

The full selected RTL continuous graph has **5,347 nodes, including 69 LS nodes,
and no directed cycles**. All parsed operation and reference kinds are checked.
The actual elaborated R/B/O/L/private-offer/closed/summary parameters are 1;
the offered-summary parameter reaches both owners and cutover as 1.

The new common summary contains all 19 required root signals/groups. It excludes
the full external fault, forward/inverse current owner faults, original full
cutover fault, both input certificates, the original common expression, and both
owners' full internal fault/owner-fault predicates. The corresponding original
common cone contains the six old echo/certificate signals as positive controls.
The new offers do not depend on the input certificates.

Five compiled, exact-source mutations restore external, forward owner, inverse
owner, full cutover, or certified-beat echoes. All are rejected by ancestry;
**none produces a cycle**, so these are not labeled cycle-mutant kills.
Removing the direct input fault or offered cutover fault is rejected by missing
compiled ancestry. Removing either scalar owner OR operand is rejected by the
independent exact-compiled-source operand check. These are nine executed mutants.

Ten small parser controls cover immediate alias drivers, a disconnected sink
sharing an upstream register, LS/multiple suffixes, undefined references, unknown
operations, wire-array traversal, real RAM cuts, membership annotations, a real
wire-array loop, and missing array elements.

## Precise boundaries and limitations

The three `guard_return_*` arrays are **wire arrays**, not registers. Their
`.array/port` dependencies traverse both actual element `.net` drivers. Element
container annotations are not counted as driver inputs. True payload/kernel
storage remains a state boundary. The common cone ends at 110 declared variables;
it no longer incorrectly ends at `guard_return_metadata` itself.

The graph is conservative at whole-vector parts/concats. Consequently an
individual owner-bit presence is not proved from vector ancestry alone; the
additional exact scalar source-operand check and its two missing-owner mutants
cover that specific distinction. Alias normalization uses immediate drivers,
not all shared upstream ancestors. All runtime `always` blocks are edge-triggered;
the two pinned arithmetic functions have only argument/local/constant inputs.

The real 19-port FFT interface is retained (48-bit data, 24-bit output user,
8-bit configuration/status, unchanged control/event names). Its 12 outputs are
explicit independent opaque variables; ten enter the common cone. The scripted
model's combinational frame-event generation was intentionally not imported as
vendor circuitry. This is not a graph of vendor internals, CDC proof, reachability
proof, bit-level logic equivalence, numerical evaluation, or mapped timing result.

The necessary metadata paths still exist: product/source read metadata through
the direct input guard fault; product metadata through handoff and preparation;
product write metadata through bank framing. The new common cone has 1,241 nodes
versus 1,240 for the original expression in this same elaboration. Node count is
not depth or delay: the result demonstrates removal of specified echoes, not a
global metadata-path removal or a timing improvement.

## Retained development attempts

- `retained-summary-graph-island.bsIkvPOd`: exit 1 before compilation, rejected
  earlier guard comment SHA. Narrow confirmed current `8b853ee2` is the reviewed
  comment clarification, not a logic change.
- `retained-summary-graph-island-v2.dFxs8QaF`: base passed; audit exited 1 because
  the owner-echo negative also exposed external fault and the test expected the
  injected root to be the first reported root. Final tests record all echoes.
- `retained-summary-graph-island-v3.XqFnNINy`: exit 1 on missing-owner mutation
  acceptance by conservative vector ancestry. Final scalar-operand check closes
  this receipt gap without pretending the graph is bit-precise.
- `retained-summary-graph-island-v4.hSeDAVGb`: exited 0 for its then-defined gates,
  but subsequent boundary review identified the three wire arrays misclassified
  as state cuts. **Superseded, not complete-graph qualification.** Final v5 adds
  explicit array connectivity and executed controls; all prior files are intact.

The original command was sanitized Python `-B audit_graph.py` with
`LD_LIBRARY_PATH`, `PYTHONHOME`, `PYTHONPATH`, and `PYTHONOPTIMIZE` unset. Each
`command.json` records the actual Icarus invocation and exclusive case paths.
Success was published only after all pre/post source-integrity checks passed.

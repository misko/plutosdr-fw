// GRAPH BOUNDARY ONLY. No simulation, vendor implementation, or timing model.
// Exact real FFT interface. Every output is an independent opaque variable.
`timescale 1ns/1ps
module starlink_pss_fft512_bfp18_rt_candidate (
  input wire aclk, aresetn,
  input wire [7:0] s_axis_config_tdata,
  input wire s_axis_config_tvalid,
  output reg s_axis_config_tready,
  input wire [47:0] s_axis_data_tdata,
  input wire s_axis_data_tvalid,
  output reg s_axis_data_tready,
  input wire s_axis_data_tlast,
  output reg [47:0] m_axis_data_tdata,
  output reg [23:0] m_axis_data_tuser,
  output reg m_axis_data_tvalid, m_axis_data_tlast,
  output reg [7:0] m_axis_status_tdata,
  output reg m_axis_status_tvalid,
  output reg event_frame_started, event_tlast_unexpected,
    event_tlast_missing, event_data_in_channel_halt
);
endmodule

#!/usr/bin/env python3
"""Independent source-specific continuous RTL graph. Never executes VVP.

Parser basis: reviewed product_interface_graph.py, with full scoped names,
immediate-driver alias normalization, typed boundary closure and source gates.
No physical timing, CDC, reachability, or opaque FFT implementation claim.
"""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
ACQ = SOURCE / 'hdl/library/starlink_pss_acquisition'
DIRECT = Path('/tmp/starlink-rom-prefetch.j829ht/fw')
PREFIX = 'graph_top.dut.retained.island'
TOKEN = re.compile(r'\b(?:LS?_0x|v0x)[0-9a-f]+(?:_\d+)*\b')
ALLOWED = {'net', 'net/2u', 'net/2s', 'net/s', 'arith/sum', 'array/port',
           'cmp/eeq', 'cmp/eq', 'cmp/gt', 'cmp/ne', 'cmp/nee', 'concat',
           'concat8', 'functor', 'part', 'part/v', 'reduce/and', 'reduce/nor',
           'reduce/or', 'reduce/xor', 'shift/l', 'ufunc/vec4'}
FOUR = {
    'starlink_pss_core_job_cutover.v': 'c67b62486356215a12cd8e9c2b220c5a877a661bd1b15a13b25f9904171ba330',
    'starlink_pss_fft_bank_owned_retained_output_probe.v': '7367d534792385eab3b4264f2e36849b18222e6fe848ef7dbc0887394de8bf94',
    'starlink_pss_fft_retained_output_impl.v': '3b98a25b8c5d50a18da1692511ae1647c2969fadf5c55d679278b2d5a7bbf0ff',
    'starlink_pss_result_guard_owner_view.v': '8b853ee26ab18b4639ab0faf156fd75661f86030773c14f5a9843140c52b5d02',
}
REQUIRED = ['input_fault_now', 'input_guard_fault', 'source_fault_fast',
            'vendor_fault_now', 'fast_fault', 'kernel_fault', 'product_overflow',
            'product_bank_fault', 'product_bank_framing_fault_now',
            'handoff_fault_now', 'cutover_offered_fault_now', 'cutover_reasons',
            'retained_fault_now', 'retained_reasons', 'guard_offered_local_fault',
            'output_bank_fault', 'output_bank_framing_fault_now',
            'preparation_fault_now', 'result_fault']
EXCLUDED = ['external_fault_now', 'forward_fault_now', 'inverse_fault_now',
            'original_common_current_fault', 'cutover_fault_now',
            'certified_input_beat', 'certified_input_complete']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, sort_keys=True)
        handle.write('\n')


def clean_env():
    return {k: v for k, v in os.environ.items()
            if k not in {'LD_LIBRARY_PATH', 'PYTHONHOME', 'PYTHONPATH', 'PYTHONOPTIMIZE'}}


def parse(text):
    definitions, scopes, graph, names, kinds = {}, {}, {}, {}, {}
    current = None
    for line in text.splitlines():
        scope = re.match(r'(S_\S+) \.scope (\S+), "([^"]+)".*;', line)
        if scope:
            label, kind, name = scope.groups()
            parents = re.findall(r'\bS_0x[0-9a-f]+\b', line.split(' .scope ', 1)[1])
            parent = parents[-1] if parents else None
            if parent is not None and parent not in scopes:
                raise ValueError('UNKNOWN_PARENT_SCOPE ' + line)
            scopes[label] = (scopes[parent] + '.' if parent else '') + name
            current = label
        selection = re.match(r'\s*\.scope (S_\S+);', line)
        if selection:
            current = selection.group(1)
        match = re.match(r'(\w+) \.(\S+) (.*);', line)
        if not match:
            continue
        label, op, body = match.groups()
        if label in definitions:
            raise ValueError('DUPLICATE_DEFINITION ' + label)
        definitions[label] = {'operation': op, 'body': body,
                              'scope': scopes.get(current, '')}
        continuous = op.startswith('net') or label.startswith(('L_', 'LS_'))
        if continuous:
            if op not in ALLOWED:
                raise ValueError('UNKNOWN_OPERATION ' + op)
            if op.startswith('ufunc') and not any(
                    name in body for name in ('.round_and_saturate', '.boundary_round_and_saturate')):
                raise ValueError('UNREVIEWED_FUNCTION ' + body)
            graph[label] = set(TOKEN.findall(body))
        if op.startswith(('net', 'var', 'array')):
            signal = re.search(r'"([^"]*)"', body)
            if signal:
                name = (scopes.get(current, '') + '.' + signal.group(1)).strip('.')
                names.setdefault(name, []).append(label)
                kinds[label] = name
    referenced = set().union(set(), *graph.values())
    missing = referenced - definitions.keys()
    if missing:
        raise ValueError('UNRESOLVED_REFERENCES ' + repr(sorted(missing)))
    unexpected = {ref: definitions[ref]['operation'] for ref in referenced - graph.keys()
                  if not definitions[ref]['operation'].startswith(('var', 'array'))}
    if unexpected:
        raise ValueError('UNREVIEWED_BOUNDARY ' + repr(unexpected))
    return graph, names, definitions, kinds


def ancestors(graph, roots):
    seen, pending = set(), list(roots)
    while pending:
        node = pending.pop()
        if node not in seen:
            seen.add(node)
            pending.extend(graph.get(node, ()))
    return seen


def first_cycle(graph):
    color, path = {}, []
    def visit(node):
        if color.get(node) == 1:
            return path[path.index(node):] + [node]
        if color.get(node) == 2:
            return None
        color[node] = 1
        path.append(node)
        for child in sorted(graph.get(node, ())):
            found = visit(child)
            if found:
                return found
        path.pop()
        color[node] = 2
        return None
    for node in sorted(graph):
        found = visit(node)
        if found:
            return found
    return None


def drivers(graph, names, name):
    if name not in names:
        raise ValueError('MISSING_SIGNAL ' + name)
    if len(names[name]) != 1:
        raise ValueError('DUPLICATE_SIGNAL ' + name)
    node = names[name][0]
    # Immediate alias source only. Never broaden a source into all ancestors.
    return graph[node] if node in graph else {node}


def analyse(path):
    graph, names, definitions, kinds = parse(path.read_text())
    cycle = first_cycle(graph)
    if cycle:
        raise ValueError('CONTINUOUS_CYCLE ' + repr(cycle))
    parameters = {}
    for entry in definitions.values():
        if entry['operation'] == 'param/l':
            match = re.match(r'"([^"]+)".*[+]C4<([01]+)>', entry['body'])
            if match:
                parameters[entry['scope'] + '.' + match[1]] = int(match[2], 2)
    for name in ('ENABLE_RETAINED_OUTPUT', 'REGISTERED_SCHEDULING', 'BOUNDARY_ROUND_SAT',
                 'REGISTER_OPERANDS', 'LOCAL_FIRST_ADMISSION', 'PRIVATE_DESCRIPTOR_OFFER',
                 'CLOSED_INPUT_CUTOVER', 'INPUT_OFFER_FAULT_SUMMARY'):
        if parameters.get('graph_top.dut.' + name) != 1:
            raise ValueError('WRONG_ACTUAL_PARAMETER ' + name)
        if name != 'ENABLE_RETAINED_OUTPUT' and parameters.get(PREFIX + '.' + name) != 1:
            raise ValueError('WRONG_FORWARDED_PARAMETER ' + name)
    for child in ('cutover', 'owners[0].result_guard', 'owners[1].result_guard'):
        if parameters.get(PREFIX + '.' + child + '.ENABLE_OFFERED_FAULT_SUMMARY') != 1:
            raise ValueError('WRONG_SUMMARY_PARAMETER ' + child)
    whole = ancestors(graph, drivers(graph, names, PREFIX + '.common_current_fault'))
    present, absent = {}, {}
    for name in REQUIRED:
        roots = drivers(graph, names, PREFIX + '.' + name)
        present[name] = bool(roots & whole)
        if not present[name]:
            raise ValueError('MISSING_REQUIRED_ROOT ' + name)
    forbidden = EXCLUDED + [f'owners[{i}].result_guard.{n}' for i in range(2)
                            for n in ('fault_now', 'owner_fault_now')]
    for name in forbidden:
        roots = drivers(graph, names, PREFIX + '.' + name)
        absent[name] = not bool(roots & whole)
        if not absent[name]:
            raise ValueError('FORBIDDEN_ECHO ' + name)
    # Preserve independent offered summary paths for each owner, not just vector presence.
    for owner in range(2):
        name = f'owners[{owner}].result_guard.offered_local_fault_now'
        if not drivers(graph, names, PREFIX + '.' + name) & whole:
            raise ValueError('MISSING_OWNER_SUMMARY ' + name)
    # Offers must not depend on full certificates. The input fault stays direct.
    for name in ('summary_offer_beat', 'summary_offer_complete'):
        cone = ancestors(graph, drivers(graph, names, PREFIX + '.' + name))
        for forbidden_name in ('certified_input_beat', 'certified_input_complete'):
            if drivers(graph, names, PREFIX + '.' + forbidden_name) & cone:
                raise ValueError('OFFER_CERTIFICATE_ECHO ' + name)
    boundary = sorted(whole - graph.keys())
    original_cone = ancestors(graph, drivers(graph, names, PREFIX + '.original_common_current_fault'))
    echo_controls = {name: bool(drivers(graph, names, PREFIX + '.' + name) & original_cone)
                     for name in EXCLUDED if name != 'original_common_current_fault'}
    if not all(echo_controls.values()):
        raise ValueError('OLD_CONE_POSITIVE_CONTROL ' + repr(echo_controls))
    fft_scope = PREFIX + '.shared_xfft'
    vendor_expected = {'s_axis_config_tready': 1, 's_axis_data_tready': 1,
        'm_axis_data_tdata': 48, 'm_axis_data_tuser': 24,
        'm_axis_data_tvalid': 1, 'm_axis_data_tlast': 1,
        'm_axis_status_tdata': 8, 'm_axis_status_tvalid': 1,
        'event_frame_started': 1, 'event_tlast_unexpected': 1,
        'event_tlast_missing': 1, 'event_data_in_channel_halt': 1}
    vendor_outputs = []
    for name, width in vendor_expected.items():
        labels = names.get(fft_scope + '.' + name, [])
        if len(labels) != 1 or labels[0] in graph:
            raise ValueError('OPAQUE_OUTPUT_NOT_VARIABLE ' + name)
        entry = definitions[labels[0]]
        if entry['operation'] != 'var' or not re.match(r'"[^"]+", ' + str(width-1) + r' 0$', entry['body']):
            raise ValueError('OPAQUE_OUTPUT_WRONG_WIDTH ' + name)
        vendor_outputs.append({'name': fft_scope + '.' + name, 'width': width,
                               'label': labels[0], 'in_common_cone': labels[0] in whole})
    return {'nodes': len(graph), 'ls_nodes': sum(n.startswith('LS_') for n in graph),
            'operations': dict(collections.Counter(definitions[n]['operation'] for n in graph)),
            'required': present, 'excluded': absent, 'common_cone_nodes': len(whole),
            'boundary': [dict(label=n, name=kinds.get(n), **definitions[n]) for n in boundary],
            'opaque_vendor_outputs': vendor_outputs,
            'parameter_readback': {k: v for k, v in parameters.items()
                                   if k.startswith(('graph_top.dut.', PREFIX)) and
                                   any(k.endswith('.'+n) for n in ('ENABLE_RETAINED_OUTPUT',
                                   'REGISTERED_SCHEDULING', 'BOUNDARY_ROUND_SAT', 'REGISTER_OPERANDS',
                                   'LOCAL_FIRST_ADMISSION', 'PRIVATE_DESCRIPTOR_OFFER',
                                   'CLOSED_INPUT_CUTOVER', 'INPUT_OFFER_FAULT_SUMMARY',
                                   'ENABLE_OFFERED_FAULT_SUMMARY'))},
            'original_common_cone_nodes': len(original_cone), 'old_cone_echo_positive_controls': echo_controls,
            'netlist_sha256': sha(path), 'cycles': [],
            'scope': 'Continuous RTL only; declared sequential state/RAM and explicit opaque FFT outputs are cuts. No timing, CDC, reachability or vendor-internal proof.'}


def parser_tests():
    fixture = ('v0x11_0 .var "source", 0 0;\n'
               'L_0x12_0 .functor BUFZ 1, v0x11_0, C4<0>, C4<0>, C4<0>;\n'
               'v0x13_0 .net "alias", 0 0, L_0x12_0;\n'
               'LS_0x14_0_0 .concat [ 1 1 0 0], L_0x12_0, C4<0>;\n'
               'L_0x15_0 .functor BUFZ 1, LS_0x14_0_0, C4<0>, C4<0>, C4<0>;\n'
               'v0x16_0 .net "sink", 0 0, L_0x15_0;\n')
    graph, names, _, _ = parse(fixture)
    if not drivers(graph, names, 'alias') & ancestors(graph, drivers(graph, names, 'sink')):
        raise ValueError('ALIAS_CONNECTED_CONTROL')
    disconnected = fixture.replace('LS_0x14_0_0, C4<0>', 'v0x11_0, C4<0>')
    graph, names, _, _ = parse(disconnected)
    if drivers(graph, names, 'alias') & ancestors(graph, drivers(graph, names, 'sink')):
        raise ValueError('ALIAS_DISCONNECTED_CONTROL')
    cyclic = fixture.replace('L_0x12_0, C4<0>;\n', 'L_0x15_0, C4<0>;\n')
    if not first_cycle(parse(cyclic)[0]):
        raise ValueError('LS_MULTI_SUFFIX_CYCLE_NOT_CAUGHT')
    for value, marker in ((fixture.replace('v0x11_0, C4<0>', 'v0xaa_0, C4<0>'), 'UNRESOLVED'),
                          (fixture.replace('.concat ', '.mystery '), 'UNKNOWN_OPERATION')):
        try:
            parse(value)
        except ValueError as error:
            if marker not in str(error):
                raise
        else:
            raise ValueError('PARSER_NEGATIVE_ACCEPTED ' + marker)
    return ['immediate_alias_connected', 'shared_upstream_disconnected',
            'LS_multi_suffix_cycle', 'undefined_variable_rejection', 'unknown_operation_rejection']


def freeze():
    output = ROOT / 'frozen'
    output.mkdir()
    sources = sorted((ACQ / 'retained_output/baseline').glob('*.v'))
    if len(sources) != 9:
        raise ValueError('BASELINE_CLOSURE_COUNT')
    sources += [ACQ / 'retained_output' / name for name in (
        'starlink_pss_mailbox_owner_view.v', 'starlink_pss_retained_epoch_barrier.v',
        'starlink_pss_retained_output_owner.v')]
    sources += [ACQ / 'retained_output_summary_candidate' / name for name in FOUR]
    for name, expected in FOUR.items():
        if sha(ACQ / 'retained_output_summary_candidate' / name) != expected:
            raise ValueError('SOURCE_CHANGED ' + name)
    dependencies = sources + [SOURCE / 'tests/starlink_oracle/retained_offer_summary_inverse.json',
        SOURCE / 'tests/starlink_oracle/retained_output_graph.py',
        DIRECT / 'tests/starlink_oracle/product_interface_graph.py',
        ACQ / 'retained_output/tb/scripted_fft_ports.sv']
    dependencies += [ACQ / 'retained_output_closed_candidate' / name for name in FOUR]
    inventory = []
    for index, source in enumerate(dependencies):
        target = output / f'{index:02d}_{source.name}'
        shutil.copyfile(source, target)
        if sha(source) != sha(target):
            raise ValueError('COPY_CHANGED ' + str(source))
        inventory.append({'source': str(source), 'frozen': str(target), 'sha256': sha(target),
                          'compiled': index < 16})
    for source in (ROOT / 'audit_graph.py', ROOT / 'opaque_fft.sv', ROOT / 'graph_top.sv'):
        inventory.append({'source': str(source), 'frozen': str(source),
                          'sha256': sha(source), 'compiled': source.suffix == '.sv'})
    write_json(ROOT / 'source-before.json', inventory)
    version = subprocess.run(['iverilog', '-V'], env=clean_env(), text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    write_json(ROOT / 'compiler.json', {'executable': shutil.which('iverilog'),
        'sha256': sha(shutil.which('iverilog')), 'version_status': version.returncode,
        'version': version.stdout, 'simulation_launched': False})
    inverse = json.loads(Path(inventory[16]['frozen']).read_text())
    restored = {}
    for name in FOUR:
        text = next(Path(row['frozen']).read_text() for row in inventory[:16]
                    if row['source'].endswith('/' + name))
        for old, new in reversed(inverse[name]):
            if text.count(new) != 1:
                raise ValueError('WHOLE_INVERSE_ANCHOR ' + name)
            text = text.replace(new, old)
        reference = next(Path(row['frozen']).read_text() for row in inventory[20:24]
                         if row['source'].endswith('/' + name))
        if text != reference:
            raise ValueError('WHOLE_INVERSE_MISMATCH ' + name)
        restored[name] = hashlib.sha256(text.encode()).hexdigest()
    write_json(ROOT / 'whole-source-inverse.json', restored)
    # All procedural always blocks are edge-triggered. Function bodies are local pure arithmetic.
    for row in inventory[:16]:
        text = Path(row['frozen']).read_text()
        text = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
        if re.search(r'\balways_(?:comb|latch)\b', text):
            raise ValueError('COMBINATIONAL_PROCEDURE ' + row['source'])
        for match in re.finditer(r'\balways\b\s*([^\n]*)', text):
            if not re.match(r'@\s*\(\s*(?:pos|neg)edge\b', match.group(1)):
                raise ValueError('UNREVIEWED_ALWAYS ' + match.group(0))
    # These two exact-source pure arithmetic functions use only their argument,
    # local temporaries and constant parameters. VVP preserves actual arguments
    # as .ufunc dependencies; no external state may be read from their bodies.
    arithmetic = Path(inventory[7]['frozen']).read_text()
    for match in re.finditer(r'function automatic.*?endfunction', arithmetic, re.S):
        body = re.sub(r'//[^\n]*', '', match.group())
        known = {'function', 'automatic', 'input', 'signed', 'reg', 'begin', 'end',
                 'endfunction', 'if', 'else', 'DATA_WIDTH', 'SUM_WIDTH', 'ROUND_SHIFT',
                 'COMPONENT_MAX', 'COMPONENT_MIN', 'round_and_saturate',
                 'boundary_round_and_saturate', 'value', 'quotient', 'remainder',
                 'increment', 'rounded', 'low_ones', 'positive_overflow',
                 'negative_overflow', 'payload'}
        body = re.sub(r"\d+'[bhd][0-9a-fA-FxzXZ]+", '0', body)
        if set(re.findall(r'\b[A-Za-z_]\w*\b', body)) - known:
            raise ValueError('FUNCTION_EXTERNAL_READ')
    return inventory


def compile_case(name, inventory, mutation=None):
    output = ROOT / name
    output.mkdir()
    files = [Path(row['frozen']) for row in inventory if row['compiled']]
    if mutation:
        old, new = mutation
        top = next(p for p in files if p.name.endswith('fft_retained_output_impl.v'))
        text = top.read_text()
        if text.count(old) != 1:
            raise ValueError('MUTATION_ANCHOR ' + name)
        replacement = output / top.name
        replacement.write_text(text.replace(old, new))
        files[files.index(top)] = replacement
        write_json(output / 'mutation.json', {'old': old, 'new': new,
                                              'sha256': sha(replacement)})
    command = ['iverilog', '-g2012', '-Wall', '-s', 'graph_top', '-o', str(output / 'graph.vvp')]
    command += [str(p) for p in files]
    write_json(output / 'command.json', command)
    completed = subprocess.run(command, cwd=output, env=clean_env(), text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / 'compile.log').write_text(completed.stdout)
    write_json(output / 'exit.json', {'returncode': completed.returncode})
    if completed.returncode or not (output / 'graph.vvp').is_file():
        raise ValueError('COMPILE_FAILED ' + name)
    if re.search(r'implicit definition|error:|sorry:', completed.stdout, re.I):
        raise ValueError('COMPILER_DIAGNOSTIC ' + name)
    return output / 'graph.vvp'


def run():
    inventory = freeze()
    try:
        controls = parser_tests()
        netlist = compile_case('base', inventory)
        base = analyse(netlist)
        write_json(ROOT / 'base/analysis.json', base)
        negatives = []
        anchor = 'wire offered_common_current_fault = offered_external_fault_now ||'
        for echo in ('external_fault_now', 'forward_fault_now', 'inverse_fault_now',
                     'cutover_fault_now', 'certified_input_beat'):
            netlist = compile_case('restored_' + echo, inventory,
                                   (anchor, anchor + ' ' + echo + ' ||'))
            try:
                analyse(netlist)
            except ValueError as error:
                if not str(error).startswith('FORBIDDEN_ECHO '):
                    raise
                graph, names, _, _ = parse(netlist.read_text())
                common = ancestors(graph, drivers(graph, names, PREFIX + '.common_current_fault'))
                if not drivers(graph, names, PREFIX + '.' + echo) & common:
                    raise ValueError('INJECTED_ECHO_NOT_WITNESSED ' + echo)
                found = [name for name in EXCLUDED if drivers(graph, names, PREFIX + '.' + name) & common]
                negatives.append({'mutation': echo, 'rejection': str(error),
                                  'detected_echoes': found, 'actual_cycle': first_cycle(graph),
                                  'netlist_sha256': sha(netlist)})
            else:
                raise ValueError('RESTORED_ECHO_ACCEPTED ' + echo)
        for name, old, new, expected in [
            ('missing_direct_input_fault', "wire offered_external_fault_now = (input_fault_now !== 1'b0) ||",
             'wire offered_external_fault_now =', 'MISSING_REQUIRED_ROOT input_fault_now'),
            ('missing_cutover_summary', 'handoff_fault_now || cutover_offered_fault_now ||',
             'handoff_fault_now ||', 'MISSING_REQUIRED_ROOT cutover_offered_fault_now'),
            ('missing_owner0', 'guard_offered_local_fault[0] || guard_offered_local_fault[1] ||',
             'guard_offered_local_fault[1] ||', 'MISSING_OWNER_SUMMARY owners[0].result_guard.offered_local_fault_now'),
            ('missing_owner1', 'guard_offered_local_fault[0] || guard_offered_local_fault[1] ||',
             'guard_offered_local_fault[0] ||', 'MISSING_OWNER_SUMMARY owners[1].result_guard.offered_local_fault_now')]:
            netlist = compile_case(name, inventory, (old, new))
            try:
                analyse(netlist)
            except ValueError as error:
                if str(error) != expected:
                    raise
                negatives.append({'mutation': name, 'rejection': str(error),
                                  'netlist_sha256': sha(netlist)})
            else:
                raise ValueError('MISSING_ROOT_ACCEPTED ' + name)
        write_json(ROOT / 'results.json', {'status': 'PASS', 'base': base,
                                         'parser_controls': controls, 'mutants': negatives})
        print(json.dumps({'status': 'PASS', 'nodes': base['nodes'], 'ls_nodes': base['ls_nodes'],
                          'mutants': len(negatives), 'results_sha256': sha(ROOT / 'results.json')}))
    finally:
        checks = [dict(source=row['source'], before=row['sha256'],
                       after=sha(row['source']), frozen_after=sha(row['frozen'])) for row in inventory]
        write_json(ROOT / 'source-after.json', checks)
        if any(row['before'] != row['after'] or row['before'] != row['frozen_after'] for row in checks):
            raise ValueError('SOURCE_INTEGRITY_FAILED')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    run()

proc version args {return 2022.2}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-summary-actual-first.jtRe2yOy/pytest/candidate_bundle0/bundle} {/usr/bin/true} b5d112562b7db31164dc4a6ff92404de8e7d7d5d96b1c1b23e1a7dbac9d2c368 {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-summary-actual-first.jtRe2yOy/pytest/test_exact_old_runner_admissio3/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-summary-actual-first.jtRe2yOy/pytest/candidate_bundle0/bundle/source_snapshot/hdl/library/starlink_pss_acquisition/retained_summary_actual/simulate_retained_summary_actual.tcl}

// Source-bound elaboration only. Inputs remain independent variables.
module graph_top;
  reg clk, resetn, fft_clk, fft_resetn, input_valid, input_last, output_ready;
  reg [35:0] input_data;
  reg [8:0] input_position;
  reg [63:0] input_block_start;
  wire input_ready, output_valid, output_last, fault;
  wire [35:0] output_data;
  wire [8:0] output_position;
  wire [74:0] output_metadata;
  starlink_pss_fft_bank_owned_retained_output_probe #(
    .ENABLE_RETAINED_OUTPUT(1), .REGISTERED_SCHEDULING(1),
    .BOUNDARY_ROUND_SAT(1), .REGISTER_OPERANDS(1),
    .LOCAL_FIRST_ADMISSION(1), .PRIVATE_DESCRIPTOR_OFFER(1),
    .CLOSED_INPUT_CUTOVER(1), .INPUT_OFFER_FAULT_SUMMARY(1)
  ) dut (.*);
endmodule

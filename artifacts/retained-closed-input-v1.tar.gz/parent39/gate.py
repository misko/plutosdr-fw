"""Root frozen closed-input composition gate; no vendor or timing claim."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

out=Path(__file__).resolve().parent
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
pins=json.loads((out.parent/'retained-private-parent.PmtrTqnC/source-pins.json').read_text())
prefix='hdl/library/starlink_pss_acquisition/retained_output_closed_candidate/'
pins.update({
 'tests/test_starlink_retained_closed_input.py':'d27fdb6f727e0d431034a103d488b7b26bb539ca9a8d80a7eb90ff7d0bc41673',
 'tests/starlink_oracle/retained_closed_input_candidate.py':'98169f56d5e842ed623e74c5c96944e8b24a009fb1740ba648672b8615f7107e',
 'tests/starlink_oracle/retained_closed_input_inverse.json':'df227b48473b22e6bb02db54400d214c6e159a1daba241a4bd06f9fc17cff2e6',
 prefix+'starlink_pss_core_job_cutover.v':'6f3a42178b824c28f0f6bfe3c4aeb56a2c23b84fc9aa38ab3be0d5609c4cba19',
 prefix+'starlink_pss_fft_bank_owned_retained_output_probe.v':'62f7941bc76ac320bfdee235aeae9a5f3c3bd86e251e92f571162f8183a0abec',
 prefix+'starlink_pss_fft_retained_output_impl.v':'1d01972d11486772b627a3afdd594f06e41c0f98b830288e93b371af0506ef1e',
 prefix+'starlink_pss_result_guard_owner_view.v':'53c336df4dd378a27b12f7c4d382d25290c81c0881b8e6c4f914faa67482d320',
 prefix+'tb_input_closed_premise.sv':'152d5b59b0173fde2faa47d8d47f80e777327470f0a86ad4e8907135f025a2da',
})
graph='tests/starlink_oracle/retained_output_graph.py'
pins[graph]=hashlib.sha256((tree/graph).read_bytes()).hexdigest()
def current():return {n:hashlib.sha256((tree/n).read_bytes()).hexdigest() for n in pins}
assert current()==pins
(out/'source-pins.json').write_text(json.dumps(pins,indent=2))
for n in pins:
    target=out/'source_snapshot'/n
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((tree/n).read_bytes())
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest',
 'tests/test_starlink_retained_closed_input.py','-q','-p','no:cacheprovider',
 '--basetemp='+str(out/'cases'),'--junitxml='+str(out/'tests.xml')]
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
(out/'command.json').write_text(json.dumps(cmd))
p=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=180)
(out/'tests.log').write_text(p.stdout+p.stderr)
receipt={'exit':p.returncode,'source_count':len(pins),'sources_unchanged':current()==pins,
 'scope':'39 offline closed-input/combined tests; unchanged previous40 pins; no FFT or timing qualification'}
(out/'execution.json').write_text(json.dumps(receipt,indent=2))
assert p.returncode==0 and current()==pins,p.stdout+p.stderr
suites=ET.parse(out/'tests.xml').getroot().findall('testsuite')
assert sum(int(s.attrib['tests']) for s in suites)==39
assert all(int(s.attrib[k])==0 for s in suites for k in ('failures','errors','skipped'))
composition=[]
for log in (out/'cases').rglob('simulation.log'):
    if log.parent.name!='composition':continue
    text=log.read_text()
    assert text.count('CLOSED_INPUT_WITNESS ')==1
    assert text.count('PRIVATE_OFFER_WITNESS owner=0 ')==1
    assert text.count('PRIVATE_OFFER_WITNESS owner=1 ')==1
    assert 'FATAL' not in text and 'OFFLINE_PASS' in text
    composition.append(str(log.relative_to(out)))
assert len(composition)==12
receipt['full_mode_stall_compositions']=composition
(out/'audit.json').write_text(json.dumps(receipt,indent=2))
print(p.stdout)
print(json.dumps(receipt))

`timescale 1ns/1ps
module tb;
  localparam ENABLE_CLOSED_INPUT_VIEW=1;
  reg resetn,core_resetn,owner_open,configured,reset_flushed,fresh_frame,fresh_full;
  reg raw_frame,raw_output,raw_status;reg[2:0]raw_vendor_faults;
  wire input_beat=0,input_complete=0;
  wire fault_now,gold_fault_now,closed_input_fault_now;
  wire known = (core_resetn === 1'b0 || core_resetn === 1'b1) &&
    (raw_frame === 1'b0 || raw_frame === 1'b1) &&
    (raw_output === 1'b0 || raw_output === 1'b1) &&
    (raw_status === 1'b0 || raw_status === 1'b1) &&
    (^raw_vendor_faults !== 1'bx) &&
    (input_beat === 1'b0 || input_beat === 1'b1) &&
    (input_complete === 1'b0 || input_complete === 1'b1);
  wire any_raw = raw_frame || raw_output || raw_status;
  wire configured_owner = owner_open && configured && core_resetn === 1'b1 && reset_flushed;
  wire orphan = any_raw && !configured_owner;
  wire premature_reset = owner_open && configured && core_resetn === 1'b0;
  wire early_result = (raw_output || raw_status) &&
    (!(fresh_frame || raw_frame) || !(fresh_full || input_complete));
  assign fault_now = resetn && (!known || raw_vendor_faults !== 3'b0 || orphan || early_result || premature_reset);
  wire gold_known = (core_resetn === 1'b0 || core_resetn === 1'b1) &&
    (raw_frame === 1'b0 || raw_frame === 1'b1) &&
    (raw_output === 1'b0 || raw_output === 1'b1) &&
    (raw_status === 1'b0 || raw_status === 1'b1) &&
    (^raw_vendor_faults !== 1'bx) &&
    (1'b0 === 1'b0 || 1'b0 === 1'b1) &&
    (1'b0 === 1'b0 || 1'b0 === 1'b1);
  wire gold_any_raw = raw_frame || raw_output || raw_status;
  wire gold_configured_owner = owner_open && configured && core_resetn === 1'b1 && reset_flushed;
  wire gold_orphan = gold_any_raw && !gold_configured_owner;
  wire gold_premature_reset = owner_open && configured && core_resetn === 1'b0;
  wire gold_early_result = (raw_output || raw_status) &&
    (!(fresh_frame || raw_frame) || !(fresh_full || 1'b0));
  assign gold_fault_now = resetn && (!gold_known || raw_vendor_faults !== 3'b0 || gold_orphan || gold_early_result || gold_premature_reset);
  wire closed_known = (core_resetn === 1'b0 || core_resetn === 1'b1) &&
    (raw_frame === 1'b0 || raw_frame === 1'b1) &&
    (raw_output === 1'b0 || raw_output === 1'b1) &&
    (raw_status === 1'b0 || raw_status === 1'b1) &&
    (^raw_vendor_faults !== 1'bx) &&
    (1'b0 === 1'b0 || 1'b0 === 1'b1) &&
    (1'b0 === 1'b0 || 1'b0 === 1'b1);
  wire closed_early_result = (raw_output || raw_status) &&
    (!(fresh_frame || raw_frame) || !(fresh_full || 1'b0));
  assign closed_input_fault_now = ENABLE_CLOSED_INPUT_VIEW ? resetn &&
    (!closed_known || raw_vendor_faults !== 3'b0 || orphan || closed_early_result || premature_reset) : 1'b0;

  reg[12:0]values;integer n,k,checks=0;
  task check;
    begin
      {resetn,core_resetn,owner_open,configured,reset_flushed,fresh_frame,fresh_full,
        raw_frame,raw_output,raw_status,raw_vendor_faults}=values;
      #1;
      if(closed_input_fault_now!==gold_fault_now || fault_now!==gold_fault_now)
        $fatal(1,"literal closed predicate four-state mismatch values=%b",values);
      checks=checks+1;
    end
  endtask
  initial begin
    for(n=0;n<8192;n=n+1)begin
      values=n;check();
      for(k=0;k<13;k=k+1)begin values=n;values[k]=1'bx;check();values[k]=1'bz;check();end
    end
    if(checks!=221184)$fatal(1,"algebra inventory");
    $display("OFFLINE_PASS literal closed predicate checks=%0d binary8192 single_XZ212992",checks);$finish;
  end
endmodule

`timescale 1ns/1ps
module tb;
  reg clk=0,resetn=0,job_valid=0;
  reg[69:0]job_descriptor=70'h12345;
  reg input_bank_reserved=1,output_bank_reserved=1;
  reg certified_input_beat=0,certified_input_complete=0,final_fence_certified=0;
  reg external_fault_now=0,phase_input_fault_now=0,completed_input_certified=1;
  reg full_fault=0,closed_fault=0,preflight_fault_evidence_now=0;
  reg core_event_frame_started=0,core_output_tvalid=0,core_output_tlast=0;
  reg[47:0]core_output_tdata=0;reg[23:0]core_output_tuser=0;
  reg[7:0]core_status_tdata=0;reg core_status_tvalid=0;
  reg mailbox_input_ready=1,mailbox_input_fault=0,inverse_phase=0,forward_mailbox_fault=0;
starlink_pss_realtime_result_guard #(.USE_COMPLETED_INPUT_FAULT(1),.USE_FORWARD_RETIREMENT(1)) reference(.clk(clk),.resetn(resetn),.job_valid(job_valid),.job_descriptor(job_descriptor),.input_bank_reserved(input_bank_reserved),.output_bank_reserved(output_bank_reserved),.certified_input_beat(certified_input_beat),.certified_input_complete(certified_input_complete),.final_fence_certified(final_fence_certified),.external_fault_now(external_fault_now),.phase_input_fault_now(phase_input_fault_now),.completed_input_certified(completed_input_certified),.completed_input_fault_now(full_fault),.preflight_fault_evidence_now(preflight_fault_evidence_now),.core_event_frame_started(core_event_frame_started),.core_output_tdata(core_output_tdata),.core_output_tuser(core_output_tuser),.core_output_tvalid(core_output_tvalid),.core_output_tlast(core_output_tlast),.core_status_tdata(core_status_tdata),.core_status_tvalid(core_status_tvalid),.mailbox_input_ready(mailbox_input_ready),.mailbox_input_fault(mailbox_input_fault),.inverse_phase(inverse_phase),.forward_mailbox_fault(forward_mailbox_fault));
starlink_pss_result_guard_owner_view #(.USE_COMPLETED_INPUT_FAULT(1),.USE_FORWARD_RETIREMENT(1),.REQUIRE_KNOWN_COMPLETED_INPUT(0)) naive(.clk(clk),.resetn(resetn),.job_valid(job_valid),.job_descriptor(job_descriptor),.input_bank_reserved(input_bank_reserved),.output_bank_reserved(output_bank_reserved),.certified_input_beat(certified_input_beat),.certified_input_complete(certified_input_complete),.final_fence_certified(final_fence_certified),.external_fault_now(external_fault_now),.phase_input_fault_now(phase_input_fault_now),.completed_input_certified(completed_input_certified),.completed_input_fault_now(closed_fault),.preflight_fault_evidence_now(preflight_fault_evidence_now),.core_event_frame_started(core_event_frame_started),.core_output_tdata(core_output_tdata),.core_output_tuser(core_output_tuser),.core_output_tvalid(core_output_tvalid),.core_output_tlast(core_output_tlast),.core_status_tdata(core_status_tdata),.core_status_tvalid(core_status_tvalid),.mailbox_input_ready(mailbox_input_ready),.mailbox_input_fault(mailbox_input_fault),.inverse_phase(inverse_phase),.forward_mailbox_fault(forward_mailbox_fault));
starlink_pss_result_guard_owner_view #(.USE_COMPLETED_INPUT_FAULT(1),.USE_FORWARD_RETIREMENT(1),.REQUIRE_KNOWN_COMPLETED_INPUT(1)) hardened(.clk(clk),.resetn(resetn),.job_valid(job_valid),.job_descriptor(job_descriptor),.input_bank_reserved(input_bank_reserved),.output_bank_reserved(output_bank_reserved),.certified_input_beat(certified_input_beat),.certified_input_complete(certified_input_complete),.final_fence_certified(final_fence_certified),.external_fault_now(external_fault_now),.phase_input_fault_now(phase_input_fault_now),.completed_input_certified(completed_input_certified),.completed_input_fault_now(closed_fault),.preflight_fault_evidence_now(preflight_fault_evidence_now),.core_event_frame_started(core_event_frame_started),.core_output_tdata(core_output_tdata),.core_output_tuser(core_output_tuser),.core_output_tvalid(core_output_tvalid),.core_output_tlast(core_output_tlast),.core_status_tdata(core_status_tdata),.core_status_tvalid(core_status_tvalid),.mailbox_input_ready(mailbox_input_ready),.mailbox_input_fault(mailbox_input_fault),.inverse_phase(inverse_phase),.forward_mailbox_fault(forward_mailbox_fault));

  integer n,q,f,checks=0,zero_to_x=0,x_to_zero=0,known_equal=0,raw_checks=0;
  task tick;begin #5;clk=1;#0.001;#4.999;clk=0;end endtask
  task probe;
    begin
      for(q=0;q<4;q=q+1)for(f=0;f<2;f=f+1)begin
        case(q)0:completed_input_certified=0;1:completed_input_certified=1;
          2:completed_input_certified=1'bx;3:completed_input_certified=1'bz;endcase
        external_fault_now=f;full_fault=f;closed_fault=(q<2)?f:0;
        #1;
        if(reference.faults_now!==hardened.faults_now || reference.faults_now!==naive.faults_now)
          $fatal(1,"unrestricted diagnostics changed");
        if(reference.mailbox_private_valid!==1 || hardened.mailbox_private_valid!==1)
          $fatal(1,"private storage changed into public certificate gate");
        if(q<2)begin
          if({reference.mailbox_input_valid,reference.mailbox_commit_valid,reference.forward_retirement_valid}!==
             {hardened.mailbox_input_valid,hardened.mailbox_commit_valid,hardened.forward_retirement_valid})
            $fatal(1,"known certificate public behavior changed");
          known_equal=known_equal+1;
        end else begin
          if({hardened.mailbox_input_valid,hardened.mailbox_commit_valid,hardened.forward_retirement_valid}!==3'b0)
            $fatal(1,"unknown complete certificate gained public visibility");
          if(f==0)begin
            if(reference.mailbox_input_valid!==1'bx)$fatal(1,"missing original X visibility specimen");
            x_to_zero=x_to_zero+1;
          end else begin
            if(reference.mailbox_input_valid!==0 || naive.mailbox_input_valid!==1'bx)
              $fatal(1,"missing naive zero-to-X counterexample");
            zero_to_x=zero_to_x+1;
          end
        end
        checks=checks+1;
      end
      completed_input_certified=1;external_fault_now=0;full_fault=0;closed_fault=0;
      // Actual raw flags and independent faults remain immediate public vetoes.
      for(q=0;q<6;q=q+1)begin
        case(q)0:external_fault_now=1;1:mailbox_input_fault=1;2:output_bank_reserved=0;
          3:core_event_frame_started=1;4:core_status_tvalid=1;5:core_output_tvalid=1;endcase
        full_fault=external_fault_now;closed_fault=full_fault;#1;
        if(reference.faults_now!==hardened.faults_now ||
           {reference.mailbox_input_valid,reference.mailbox_commit_valid,reference.forward_retirement_valid}!==
           {hardened.mailbox_input_valid,hardened.mailbox_commit_valid,hardened.forward_retirement_valid})
          $fatal(1,"current raw fault public equivalence");
        raw_checks=raw_checks+1;
        external_fault_now=0;mailbox_input_fault=0;output_bank_reserved=1;
        core_event_frame_started=0;core_status_tvalid=0;core_output_tvalid=0;
        full_fault=0;closed_fault=0;
      end
    end
  endtask
  initial begin
    tick();resetn=1;job_valid=1;tick();job_valid=0;
    for(n=0;n<512;n=n+1)begin
      certified_input_beat=1;certified_input_complete=(n==511);core_event_frame_started=(n==0);tick();
    end
    certified_input_beat=0;certified_input_complete=0;core_event_frame_started=0;
    core_output_tvalid=1;core_status_tvalid=1;tick();core_output_tvalid=0;core_status_tvalid=0;
    probe();
    for(n=1;n<512;n=n+1)begin
      core_output_tvalid=1;core_output_tuser=n;core_output_tlast=(n==511);tick();
    end
    core_output_tvalid=0;core_output_tlast=0;final_fence_certified=1;
    probe();tick();
    if(reference.awaiting_ack!==1 || hardened.awaiting_ack!==1)$fatal(1,"healthy final publication");
    // A retained old inverse's ACK must not depend on next job's complete flag.
    completed_input_certified=0;#1;
    if(hardened.owner_ack_accept!==1 || reference.idle_fault_now!==0)
      $fatal(1,"ACK incorrectly tied to shared completed-input certificate");
    tick();if(hardened.awaiting_ack!==0 || reference.awaiting_ack!==0)$fatal(1,"ACK not retired");
    external_fault_now=1;tick();
    if(reference.fault_reasons!==hardened.fault_reasons || hardened.protocol_fault!==1)
      $fatal(1,"full current diagnostic not sticky");
    resetn=0;tick();
    if(reference.fault_reasons!==0 || hardened.fault_reasons!==0)$fatal(1,"diagnostic reset changed");
    if(checks!=16||zero_to_x!=4||x_to_zero!=4||known_equal!=8||raw_checks!=12)
      $fatal(1,"visibility specimen inventory");
    $display("OFFLINE_PASS visibility known_equal8 original_X_to_zero4 naive_zero_to_X4 raw12 real_ACK_complete0");$finish;
  end
endmodule

`timescale 1ns/1ps
// Unrestricted predicate-state algebra, NOT reachable clocked protocol proof.
module tb;
  reg [12:0] stimulus;
  wire resetn=stimulus[12], core_resetn=stimulus[11];
  wire raw_frame=stimulus[10], raw_output=stimulus[9], raw_status=stimulus[8];
  wire [2:0] raw_vendor_faults=stimulus[7:5];
  wire owned=stimulus[4], configured=stimulus[3], flushed=stimulus[2];
  wire fresh_frame=stimulus[1], fresh_full=stimulus[0];
  wire original_fault, candidate_fault, closed_fault;
  integer tuple, bit_index, checks=0, unknown_checks=0;
  cutover_original original(
    .clk(1'b0), .resetn(resetn), .core_resetn(core_resetn),
    .job_accept(1'b0), .job_inverse(1'b0), .producer_closed(1'b0), .config_accept(1'b0),
    .input_beat(1'b0), .input_complete(1'b0),
    .raw_frame(raw_frame), .raw_output(raw_output), .raw_status(raw_status),
    .raw_vendor_faults(raw_vendor_faults), .fault_now(original_fault));
  starlink_pss_core_job_cutover #(.ENABLE_CLOSED_INPUT_VIEW(1)) candidate(
    .clk(1'b0), .resetn(resetn), .core_resetn(core_resetn),
    .job_accept(1'b0), .job_inverse(1'b0), .producer_closed(1'b0), .config_accept(1'b0),
    .input_beat(1'b0), .input_complete(1'b0),
    .raw_frame(raw_frame), .raw_output(raw_output), .raw_status(raw_status),
    .raw_vendor_faults(raw_vendor_faults), .fault_now(candidate_fault), .closed_input_fault_now(closed_fault));
  task check;
    begin
      #0.001;
      if(candidate_fault !== original_fault)
        $fatal(1,"FULL_PREDICATE_CHANGED tuple=%b old=%b new=%b",stimulus,original_fault,candidate_fault);
      if(closed_fault !== original_fault)
        $fatal(1,"ZERO_STROBE_PREDICATE_MISMATCH tuple=%b old=%b closed=%b",stimulus,original_fault,closed_fault);
      checks=checks+1;
    end
  endtask
  initial begin
    force original.owner_open=owned; force candidate.owner_open=owned;
    force original.configured=configured; force candidate.configured=configured;
    force original.reset_flushed=flushed; force candidate.reset_flushed=flushed;
    force original.fresh_frame=fresh_frame; force candidate.fresh_frame=fresh_frame;
    force original.fresh_full=fresh_full; force candidate.fresh_full=fresh_full;
    for(tuple=0;tuple<8192;tuple=tuple+1)begin
      stimulus=tuple;check();
      for(bit_index=0;bit_index<13;bit_index=bit_index+1)begin
        stimulus=tuple;stimulus[bit_index]=1'bx;check();unknown_checks=unknown_checks+1;
        stimulus=tuple;stimulus[bit_index]=1'bz;check();unknown_checks=unknown_checks+1;
      end
    end
    if(checks!=221184 || unknown_checks!=212992)$fatal(1,"ALGEBRA_INVENTORY");
    $display("CLOSED_ALGEBRA_PASS boolean=8192 single_unknown=212992 total=221184 no_reachability_claim=1");
    $finish;
  end
endmodule

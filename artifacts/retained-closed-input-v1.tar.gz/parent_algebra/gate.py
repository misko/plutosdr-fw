"""Independent predicate evaluation with old source and named defect controls."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

out=Path(__file__).resolve().parent
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
base=tree/'hdl/library/starlink_pss_acquisition'
old=base/'retained_output/starlink_pss_core_job_cutover.v'
new=base/'retained_output_closed_candidate/starlink_pss_core_job_cutover.v'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before={str(p):sha(p) for p in (old,new,out/'bench.sv')}
(out/'source-pins.json').write_text(json.dumps(before,indent=2))
original=old.read_text()
assert original.count('module starlink_pss_core_job_cutover (')==1
renamed=original.replace('module starlink_pss_core_job_cutover (','module cutover_original (',1)
(out/'original.v').write_text(renamed)
(out/'candidate.v').write_bytes(new.read_bytes())
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
source=new.read_text()
anchor='(!closed_known || raw_vendor_faults !== 3\'b0 || orphan || closed_early_result || premature_reset)'
assert source.count(anchor)==1
cases={'baseline':source,
 'lost_vendor_fault':source.replace(anchor,'(!closed_known || orphan || closed_early_result || premature_reset)'),
 'lost_early_result':source.replace(anchor,'(!closed_known || raw_vendor_faults !== 3\'b0 || orphan || premature_reset)'),
 'lost_known_check':source.replace(anchor,'(raw_vendor_faults !== 3\'b0 || orphan || closed_early_result || premature_reset)')}
results={}
for label,body in cases.items():
    case=out/label;case.mkdir()
    (case/'candidate.v').write_text(body)
    command=['iverilog','-g2012','-Wall','-s','tb','-o',str(case/'sim.vvp'),
             str(out/'bench.sv'),str(out/'original.v'),str(case/'candidate.v')]
    p=subprocess.run(command,env=env,capture_output=True,text=True,timeout=30)
    (case/'compile.log').write_text(p.stdout+p.stderr)
    (case/'compile-command.json').write_text(json.dumps(command))
    assert p.returncode==0,p.stdout+p.stderr
    command=['vvp',str(case/'sim.vvp')]
    p=subprocess.run(command,env=env,capture_output=True,text=True,timeout=60)
    log=p.stdout+p.stderr
    (case/'simulation.log').write_text(log)
    (case/'execution.json').write_text(json.dumps({'command':command,'exit':p.returncode}))
    results[label]={'exit':p.returncode,'log':log}
    if label=='baseline':
        assert p.returncode==0 and log.count('CLOSED_ALGEBRA_PASS ')==1 and 'FATAL' not in log,log
    else:
        assert p.returncode!=0 and 'ZERO_STROBE_PREDICATE_MISMATCH' in log and 'CLOSED_ALGEBRA_PASS' not in log,log
assert {str(p):sha(p) for p in (old,new,out/'bench.sv')}==before
(out/'audit.json').write_text(json.dumps({'sources_unchanged':True,'results':results,
 'scope':'8192 Boolean tuples and single-X/Z variants; not exhaustive multi-X/Z or reachable protocol proof'},indent=2))
print(json.dumps(results))

# OFFLINE COMPILE-PLAN STUB; NO VIVADO OR COMPILATION.
set inputs /frozen/inputs
set sv_files {}
proc add_files args {}
proc get_filesets args {return sim_1}
proc get_files args {return [lindex $args end]}
proc set_property {name value selected} {
  global sv_files
  if {$name ne "file_type" || $value ne "SystemVerilog" || [file extension $selected] ni {.v .sv}} {error WRONG_LANGUAGE_OR_SCOPE}
  lappend sv_files $selected
}
set compiled_names {runtime.v witness.sv bench.sv}
  foreach name $compiled_names {
    set compiled_file [file join $inputs $name]
    if {[file extension $compiled_file] ni {.v .sv}} { error "unexpected compiled HDL extension" }
    add_files -fileset sim_1 -norecurse $compiled_file
  }

if {$sv_files ne {/frozen/inputs/runtime.v /frozen/inputs/witness.sv /frozen/inputs/bench.sv}} {error COMPILE_PLAN_INVENTORY}
puts OFFLINE_EXACT_LANGUAGE_FRAGMENT_PASS

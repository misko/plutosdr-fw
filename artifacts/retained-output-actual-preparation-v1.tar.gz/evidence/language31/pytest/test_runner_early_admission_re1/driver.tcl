proc version args {return 2023.1}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-language-tests.7tqwIaNj/pytest/retained_actual_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} 3a0eb7872722b65764178c813ec96946e61ce0ac226c0202ea0a70d24e559eeb {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-language-tests.7tqwIaNj/pytest/test_runner_early_admission_re1/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-language-tests.7tqwIaNj/pytest/retained_actual_bundle0/bundle/source_snapshot/hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl}

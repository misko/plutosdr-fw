proc version args {return 2022.2}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-final.2VAeyjCJ/pytest/retained_actual_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} e524c0ba1b3f4ac0135d58a891ee3dc4b7fbe37b338f4797032159072b8311fc {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-final.2VAeyjCJ/pytest/test_runner_early_admission_re0/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-final.2VAeyjCJ/pytest/test_runner_early_admission_re0/runner.tcl}

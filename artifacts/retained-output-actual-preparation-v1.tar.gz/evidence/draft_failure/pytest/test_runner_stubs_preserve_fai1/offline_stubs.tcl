# OFFLINE TCL STUBS: NO VIVADO/FFT/IP EXECUTION.
proc version args {return 2022.2}
proc set_param {name value} {if {$name ne "general.maxThreads" || $value != 2} {error THREADS}}
proc create_project args { return }
proc set_property args {}
proc current_project args {return OFFLINE}
set created 0
proc get_ips args {global created;if {$created} {return OFFLINE};return {}}
proc create_ip args {global created;set created 1}
proc generate_target args {
  upvar 1 wrapper_path wrapper
  file mkdir [file dirname $wrapper]
  set f [open $wrapper {WRONLY CREAT EXCL}]
  puts $f "ENTITY starlink_pss_fft512_bfp18_rt_candidate IS"
  puts $f "END starlink_pss_fft512_bfp18_rt_candidate;"
  foreach {key value} {
    C_S_AXIS_CONFIG_TDATA_WIDTH 8 C_S_AXIS_DATA_TDATA_WIDTH 48
    C_M_AXIS_DATA_TDATA_WIDTH 48 C_M_AXIS_DATA_TUSER_WIDTH 24 C_M_AXIS_STATUS_TDATA_WIDTH 8
    C_THROTTLE_SCHEME 0 C_CHANNELS 1 C_NFFT_MAX 9 C_ARCH 1 C_HAS_NFFT 0
    C_USE_FLT_PT 0 C_INPUT_WIDTH 18 C_TWIDDLE_WIDTH 16 C_OUTPUT_WIDTH 18
    C_HAS_SCALING 1 C_HAS_BFP 1 C_HAS_ROUNDING 1 C_HAS_ACLKEN 0 C_HAS_ARESETN 1
    C_HAS_OVFLO 0 C_HAS_NATURAL_INPUT 1 C_HAS_NATURAL_OUTPUT 1 C_HAS_CYCLIC_PREFIX 0
    C_HAS_XK_INDEX 1 C_DATA_MEM_TYPE 1 C_TWIDDLE_MEM_TYPE 1 C_BRAM_STAGES 0
    C_REORDER_MEM_TYPE 1 C_USE_HYBRID_RAM 0 C_OPTIMIZE_GOAL 0 C_CMPY_TYPE 1 C_BFLY_TYPE 1} {puts $f "$key => $value,"}
  close $f
}
proc add_files args {}
proc get_filesets args {return OFFLINE}
proc get_files args {return OFFLINE}
proc launch_simulation args {error EXPECTED_OFFLINE_LAUNCH_FAILURE}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-gate.dwywUQMK/pytest/retained_actual_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} 7174819a522858118aa18457c0d81f7a8554c56091255faca13d877ff1473c7c {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-gate.dwywUQMK/pytest/test_runner_stubs_preserve_fai1/actual_not_executed}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-actual-gate.dwywUQMK/pytest/retained_actual_bundle0/bundle/source_snapshot/hdl/library/starlink_pss_acquisition/retained_output_actual/simulate_retained_output_actual.tcl}

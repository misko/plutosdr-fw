"""plutosdr-fw tests."""

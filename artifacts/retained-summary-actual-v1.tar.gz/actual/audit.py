"""Independent actual artifact equality; never substitutes for owner execution."""
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
old=root.parent/'retained-control-actual-parent.HbyLZ8I2'
suffix='run/project/retained_output_actual.sim/sim_1/behav/xsim/actual_words.csv'
new_csv=(root/suffix).read_bytes()
old_csv=(old/suffix).read_bytes()
new=json.loads((root/'run/results.json').read_text())
prior=json.loads((old/'run/results.json').read_text())
outcome=json.loads((root/'outcome.json').read_text())
independent=json.loads((root/'result-check.json').read_text())
assert outcome['functional_accepted'] and outcome['vendor_exit']==0 and not outcome['timed_out']
assert independent['exit']==0 and json.loads(independent['stdout'])==new
assert new['kind']=='ACTUAL_VENDOR_FFT' and new['numerical_words']==77953
assert {k:v for k,v in new.items() if k!='offer_summary'}==prior
assert new_csv==old_csv
assert hashlib.sha256(new_csv).hexdigest()=='07321b026a637e5922c56a84a955e58549056337198c952a9d73b1245cb4efaa'
result=dict(csv_sha256=hashlib.sha256(new_csv).hexdigest(),csv_byte_equal=True,
    full_original_result_equal=True,numerical_rows=77953,contexts=len(new['contexts']),
    complete_pairs=new['terminal']['pairs'],aborted_forward=new['terminal']['aborted_F'],
    service_cycles=[v['service'] for v in new['contexts']],offer_summary=new['offer_summary'],
    actual_owner_accepted=True,physical_timing_qualified=False,deployment_eligible=False)
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

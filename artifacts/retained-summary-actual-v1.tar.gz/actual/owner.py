"""Root-owned actual FFT invocation after independently reviewed 67-test gate."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

root=Path(__file__).resolve().parent
bundle=root.parent/'retained-summary-actual-prelaunch-v1'
expected='b5d112562b7db31164dc4a6ff92404de8e7d7d5d96b1c1b23e1a7dbac9d2c368'
parent=root.parent/'retained-summary-actual-prep-parent.ZLxFAi3v'
python='/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11'
snapshot=bundle/'source_snapshot'
runner=snapshot/'hdl/library/starlink_pss_acquisition/retained_summary_actual/simulate_retained_summary_actual.tcl'
cli=snapshot/'tools/prepare_starlink_retained_summary_actual.py'
output=root/'run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(bundle/'manifest.json')==expected
assert sha(Path(python))=='2874a0b9344d06b7767aebb1e6e25a759ffcbdb544e99400ecc74dc6092d1174'
assert sha(runner)=='177a1961cdbeca4dc0f68a8994e31fc5b4145690c2f80fc26b916b8fba93f8d1'
gate=json.loads((parent/'audit.json').read_text())
assert gate['exit']==0 and gate['tests']==67 and gate['sources_unchanged'] and gate['prepared_files_unchanged'] and gate['manifest_sha256']==expected
pins=json.loads((parent/'source-pins.json').read_text())
assert len(pins)==116 and {n:sha(snapshot/n) for n in pins}==pins
script=json.loads((root.parent/'retained-summary-script-parent.jVE5ixKt/execution.json').read_text())
assert script['csv_byte_equal'] and script['entire_old_result_equal'] and script['numerical_rows']==77953 and script['source_unchanged']
assert shutil.disk_usage(root).free>2*1024**3
for name in ('run','stdout.log','vivado.log','vivado.jou','process.json','execution.json'):
    assert not (root/name).exists(),name
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
(root/'tmp').mkdir();env['TMPDIR']=str(root/'tmp')
def verify(action,path,name):
    cmd=[python,'-B',str(cli),action,str(path),'--expected',expected]
    if action=='verify':cmd+=['--live']
    p=subprocess.run(cmd,cwd='/',env={k:v for k,v in env.items() if k!='LD_LIBRARY_PATH'},capture_output=True,text=True,timeout=90)
    (root/name).write_text(json.dumps({'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2))
    return p.returncode
assert verify('verify',bundle,'before.json')==0
env['LD_LIBRARY_PATH']='/opt/Xilinx/Vivado/2022.2/lib/lnx64.o/SuSE'
cmd=['/opt/Xilinx/Vivado/2022.2/bin/vivado','-mode','batch','-notrace','-log',str(root/'vivado.log'),
     '-journal',str(root/'vivado.jou'),'-source',str(runner),'-tclargs',str(bundle),python,expected,str(output)]
(root/'command.json').write_text(json.dumps({'command':cmd,'cwd':str(root),'limit_seconds':900,'scope':'seven-context actual FFT, not continuous or physical RX'},indent=2))
start=time.monotonic();timed_out=False;interruption=None
with (root/'stdout.log').open('x') as log:
    p=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    (root/'process.json').write_text(json.dumps({'pid':p.pid,'process_group':p.pid,'start_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}))
    print('Actual retained-summary FFT started, pid='+str(p.pid),flush=True)
    try:code=p.wait(timeout=900)
    except (subprocess.TimeoutExpired,KeyboardInterrupt) as error:
        timed_out=isinstance(error,subprocess.TimeoutExpired);interruption=type(error).__name__
        try:os.killpg(p.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:code=p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            try:os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            code=p.wait(timeout=10)
result={'vendor_exit':code,'timed_out':timed_out,'interruption':interruption,'wall_seconds':time.monotonic()-start}
(root/'execution.json').write_text(json.dumps(result,indent=2))
result['original_check_exit']=verify('verify',bundle,'after.json')
result['copied_check_exit']=verify('verify',output/'inputs','copied-after.json') if (output/'inputs/manifest.json').is_file() else None
wrapper=output/'project/retained_output_actual.gen/sources_1/ip/starlink_pss_fft512_bfp18_rt_candidate/synth/starlink_pss_fft512_bfp18_rt_candidate.vhd'
result['generated_wrapper_sha256']=sha(wrapper) if wrapper.is_file() else None
result['generated_wrapper_matches_known']=result['generated_wrapper_sha256']=='a3a650654118016012bdfb8553114ee4a89866466d8ca774fa0f281640168a68'
result['independent_result_exit']=verify('results',output,'result-check.json') if (output/'inputs/manifest.json').is_file() else None
result['functional_accepted']=(code==0 and not timed_out and interruption is None and result['original_check_exit']==0 and result['copied_check_exit']==0 and result['independent_result_exit']==0 and result['generated_wrapper_matches_known'] and (output/'results.json').is_file())
result['physical_qualified']=False;result['deployment_eligible']=False
(root/'outcome.json').write_text(json.dumps(result,indent=2))
print('\n'.join((root/'stdout.log').read_text().splitlines()[-20:]),flush=True)
print(json.dumps(result),flush=True)
raise SystemExit(0 if result['functional_accepted'] else 1)

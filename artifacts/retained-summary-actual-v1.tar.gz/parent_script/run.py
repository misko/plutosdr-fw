"""Independent first scripted replay of additive actual-campaign adapter."""
import hashlib
import json
from pathlib import Path
import sys
import time

tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
root = Path(__file__).resolve().parent
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_summary_actual as c
from tests.starlink_oracle import retained_control_actual_bundle as qualified_bundle
assert c.old.sha(tree / 'tests/starlink_oracle/retained_summary_actual.py') == 'd27d062f24dfc197cb93e10970507bcf75240f9397a394fd2bfe96b55b02d310'
assert c.old.sha(c.RTL / 'witness.svh') == 'a9f12304f26a22e95f81684790b135b392c888306e2fc5e0d19c94a3dd3249b8'
qualified_bundle.verify_authority()
old_sources = qualified_bundle.sources(tree)
assert len(old_sources) == 97
assert hashlib.sha256(qualified_bundle.encoded(old_sources)).hexdigest() == 'b52ba499ffbec7b4596afaba5b180d8145381ea56a4af60ab4cce30c79631908'
names = set(old_sources)
names.update(str((c.candidate.RTL / name).relative_to(tree)) for name in c.PINS)
names.update(str(p.relative_to(tree)) for p in (c.RTL / 'witness.svh', c.RECIPE))
names.update('tests/starlink_oracle/' + n for n in ('retained_summary_actual.py', 'retained_offer_summary_candidate.py', 'retained_offer_summary_inverse.json'))
def snapshot():
    return {name:c.old.sha(tree / name) for name in sorted(names)}
before = snapshot()
(root / 'sources-before.json').write_text(json.dumps(before, indent=2))
for name in sorted(names):
    target = root / 'source_snapshot' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes((tree / name).read_bytes())
start = time.monotonic()
receipt = dict(scope='scripted actual-campaign adapter, not actual FFT or physical timing')
try:
    receipt['new_status'] = c.offline(root / 'summary')
    assert receipt['new_status'] == dict(compile=0, script_exit=0, kind='OFFLINE_SCRIPT_NOT_FFT', service_executed=False)
    new = c.verify_result(root / 'summary/simulation.log', root / 'summary/actual_words.csv', kind='OFFLINE_SCRIPT_NOT_FFT')
    receipt['old_status'] = c.qualified.offline(root / 'control')
    assert receipt['old_status'] == receipt['new_status']
    old = c.qualified.verify_result(root / 'control/simulation.log', root / 'control/actual_words.csv', kind='OFFLINE_SCRIPT_NOT_FFT')
    assert {k:v for k,v in new.items() if k != 'offer_summary'} == old
    new_csv = (root / 'summary/actual_words.csv').read_bytes()
    assert new_csv == (root / 'control/actual_words.csv').read_bytes()
    receipt.update(csv_sha256=hashlib.sha256(new_csv).hexdigest(), csv_byte_equal=True,
        entire_old_result_equal=True, numerical_rows=new['numerical_words'],
        offer_summary=new['offer_summary'])
    (root / 'summary-result.json').write_text(json.dumps(new, indent=2))
    (root / 'control-result.json').write_text(json.dumps(old, indent=2))
finally:
    after = snapshot()
    receipt.update(seconds=time.monotonic()-start, source_count=len(before), source_unchanged=before==after)
    (root / 'sources-after.json').write_text(json.dumps(after, indent=2))
    (root / 'execution.json').write_text(json.dumps(receipt, indent=2))
    print(json.dumps(receipt), flush=True)
    assert before == after

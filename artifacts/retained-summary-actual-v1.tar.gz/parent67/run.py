"""Independent complete preparation gate, immutable inputs and bounded tests."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parent
tree = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
bundle = root.parent / 'retained-summary-actual-prelaunch-v1'
expected = 'b5d112562b7db31164dc4a6ff92404de8e7d7d5d96b1c1b23e1a7dbac9d2c368'
sys.path.insert(0, str(tree))
from tests.starlink_oracle import retained_summary_actual_bundle as b
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(bundle / 'manifest.json') == expected
assert b.verify(bundle, expected, live=True)['sources'] == 116
pins = {n: sha(tree / n) for n in b.source_names()}
prepared = {str(p.relative_to(bundle)): sha(p) for p in bundle.rglob('*') if p.is_file()}
assert len(prepared) == 120
(root / 'source-pins.json').write_text(json.dumps(pins, indent=2))
(root / 'prepared-pins.json').write_text(json.dumps(prepared, indent=2))
for name in pins:
    target = root / 'source_snapshot' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(tree / name, target)
env = {k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
(root / 'tmp').mkdir()
env['TMPDIR'] = str(root / 'tmp')
cmd = [sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
       'tests/test_starlink_retained_summary_actual.py',
       'tests/test_starlink_retained_summary_actual_bundle.py',
       '--basetemp=' + str(root / 'pytest'), '--junitxml=' + str(root / 'results.xml')]
(root / 'command.json').write_text(json.dumps(cmd, indent=2))
start = time.monotonic()
with (root / 'pytest.log').open('x') as log:
    result = subprocess.run(cmd, cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
after = {n: sha(tree / n) for n in pins}
prepared_after = {str(p.relative_to(bundle)): sha(p) for p in bundle.rglob('*') if p.is_file()}
suites = ET.parse(root / 'results.xml').getroot().findall('testsuite')
counts = {n:sum(int(s.get(n, 0)) for s in suites) for n in ('tests','failures','errors','skipped')}
audit = dict(exit=result.returncode, **counts, seconds=time.monotonic()-start,
    sources_unchanged=after==pins, prepared_files_unchanged=prepared_after==prepared,
    manifest_sha256=expected, sources=len(pins))
(root / 'audit.json').write_text(json.dumps(audit, indent=2))
print((root / 'pytest.log').read_text(), flush=True)
print(json.dumps(audit), flush=True)
assert audit['exit'] == 0 and counts == dict(tests=67, failures=0, errors=0, skipped=0)
assert audit['sources_unchanged'] and audit['prepared_files_unchanged']
assert b.verify(bundle, expected, live=True)['sources'] == 116

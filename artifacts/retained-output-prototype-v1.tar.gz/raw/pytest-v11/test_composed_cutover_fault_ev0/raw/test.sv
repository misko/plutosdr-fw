// OFFLINE_NOT_FFT: real unchanged arithmetic/mailboxes, scripted FFT ports.
`timescale 1ns/1ps
module tb;
  parameter integer STALL=0;
  parameter integer FAULT_KIND=0,FAULT_OFFSET=0,FAULT_BOUNDARY=0;
  parameter real SLOW_PHASE=1.3;
  reg clk=0,fft_clk=0,resetn=0,fft_resetn=0;
  always #2.857143 fft_clk=~fft_clk;
  initial begin #(SLOW_PHASE);forever #5 clk=~clk;end
  reg input_valid=0;wire input_ready;reg[35:0]input_data=0;
  reg[8:0]input_position=0;reg input_last=0;reg[63:0]input_block_start=0;
  wire output_valid,output_last,fault;reg output_ready=1;
  wire[35:0]output_data;wire[8:0]output_position;wire[74:0]output_metadata;
  starlink_pss_fft_bank_owned_retained_output_probe #(.ENABLE_RETAINED_OUTPUT(1),
    .REGISTERED_SCHEDULING(1),.BOUNDARY_ROUND_SAT(1),.REGISTER_OPERANDS(1),
    .LOCAL_FIRST_ADMISSION(1)) dut(.*);
  `define D dut.retained.island
  reg[31:0]samples[0:1405];reg[35:0]forwards[0:1535],products[0:1535],inverses[0:1535];
  reg[4:0]fe[0:2],ie[0:2];
  integer fast_cycles=0,slow_cycles=0,forward_jobs=0,inverse_jobs=0,read_count=0;
  integer source_count=0,forward_words=0,product_words=0,inverse_words=0,status_count=0;
  integer overlap_inputs=0,overlap_reads=0,retained_finals=0,parked_wait_i=0;
  integer last_inverse_publish=-1,last_real_release=-1,first_dispatch=-1;
  integer selected_fixture=0,raw_words=0,raw_phase=0;
  reg inject_frame=0,inject_output=0,inject_status=0,inject_vendor=0,fault_injected=0,collision_done=0;
  integer inverse_publications=0,publication_anchor=0,fault_anchor=0,boundary_edge=0;
  reg stalled=0;reg[120:0]held_output;
  always @(posedge fft_clk)begin
    fast_cycles=fast_cycles+1;
    if(`D.fast_running)begin
      if(!fault_injected&&(fault!==0||`D.any_fast_fault!==0))$fatal(1,"composition health cycle=%0d state=%0d fault=%b cut=%h owner=%h f=%h i=%h",fast_cycles,`D.state,`D.any_fast_fault,`D.cutover_reasons,`D.retained_reasons,`D.owners[0].result_guard.faults_now,`D.owners[1].result_guard.faults_now);
      if(`D.job_accept)begin
        if(`D.next_inverse)begin
          if(inverse_jobs>0&&last_real_release<0)$fatal(1,"next inverse before real read release");
          if(`D.retained_published!==0)$fatal(1,"next inverse retained old owner");
          inverse_jobs=inverse_jobs+1;
        end else begin
          if(forward_jobs>0)begin
            if(last_inverse_publish<0||`D.retained_published!==1)$fatal(1,"no retained overlap at next F");
            if(first_dispatch<0)first_dispatch=fast_cycles-last_inverse_publish;
            $display("OFFLINE_DISPATCH block=%0d clocks=%0d",forward_jobs,fast_cycles-last_inverse_publish);
          end
          forward_jobs=forward_jobs+1;
        end
        selected_fixture=(forward_jobs-1)%3;raw_words=0;raw_phase=`D.next_inverse;
      end
      if(`D.core_status_valid&&inject_status===0)begin
        if(raw_words!=2||`D.core_status_data!=={3'b0,(raw_phase?ie[selected_fixture]:fe[selected_fixture])})$fatal(1,"third raw status");
        status_count=status_count+1;
      end
      if(`D.core_output_valid&&inject_output===0)begin
        if(`D.core_output_user[8:0]!==9'(raw_words)||`D.core_output_last!==(raw_words==511))$fatal(1,"raw ordinal");
        raw_words=raw_words+1;
      end
      if(`D.forward_retirement_valid&&`D.product_bank_ready)begin
        if(`D.return_data!==forwards[selected_fixture*512+`D.return_position]||`D.return_metadata[4:0]!==fe[selected_fixture])$fatal(1,"forward exact word");
        forward_words=forward_words+1;
      end
      if(`D.product_valid&&`D.product_bank_ready)begin
        if({`D.product_q,`D.product_i}!==products[selected_fixture*512+`D.product_position]||`D.product_exponent!==fe[selected_fixture])$fatal(1,"product exact word");
        product_words=product_words+1;
      end
      if(`D.guard_private_out[1]&&`D.output_bank_ready)begin
        if(`D.guard_return_data[1]!==inverses[selected_fixture*512+`D.guard_return_position[1]])$fatal(1,"private inverse exact word");
        inverse_words=inverse_words+1;
      end
      if(`D.guard_commit_out[1]&&`D.output_bank_ready)begin
        inverse_publications=inverse_publications+1;
        if(fault_injected)$fatal(1,"new inverse publication after current fault");
        last_inverse_publish=fast_cycles;last_real_release=-1;
        $display("OFFLINE_PUBLICATION block=%0d cycle=%0d",inverse_jobs-1,fast_cycles);
      end
      if(`D.reader_release)begin last_real_release=fast_cycles;$display("OFFLINE_REAL_ACK cycle=%0d",fast_cycles);end
      if(`D.retained_published&&`D.core_input_valid&&`D.core_input_ready&&!`D.routed_inverse)
        overlap_inputs=overlap_inputs+1;
      if(`D.retained_published&&!`D.core_aresetn&&output_valid)retained_finals=retained_finals+1;
      if(`D.retained_published&&`D.product_bank_valid&&`D.next_inverse&&`D.state==2)
        parked_wait_i=parked_wait_i+1;
      if(fast_cycles>1500000)$fatal(1,"whole-bench fast deadline");
    end
  end
  always @(negedge clk)begin
    slow_cycles=slow_cycles+1;
    output_ready=STALL==0 ? 1 : STALL==1 ? (slow_cycles%17<13) :
      (`D.retained_published&&fast_cycles-last_inverse_publish>2200);
  end
  always @(posedge clk)begin
    if(input_valid&&input_ready)source_count=source_count+1;
    if(resetn&&fft_resetn)begin
      if(stalled&&output_valid&&{output_data,output_position,output_last,output_metadata}!==held_output)$fatal(1,"retained read payload changed");
      stalled=output_valid&&!output_ready;held_output={output_data,output_position,output_last,output_metadata};
      if(output_valid&&output_ready)begin
        if(output_data!==inverses[(read_count/512)%3*512+read_count%512]||
          output_position!==9'(read_count%512)||output_last!==(read_count%512==511)||
          output_metadata!=={1'b1,64'(1000+(read_count/512)*447),fe[(read_count/512)%3],ie[(read_count/512)%3]})
          $fatal(1,"old reader exact identity/payload count=%0d",read_count);
        if(!`D.routed_inverse&&`D.cutover.owner_open)overlap_reads=overlap_reads+1;
        read_count=read_count+1;
      end
    end
  end
  integer block_index,word_index,drain_anchor;
  initial begin
    $readmemh("samples_ci16.mem",samples);$readmemh("forward_q17.mem",forwards);
    $readmemh("product_q17.mem",products);$readmemh("inverse_q17.mem",inverses);
    $readmemh("forward_exponents.mem",fe);$readmemh("inverse_exponents.mem",ie);
    repeat(10)@(negedge fft_clk);resetn=1;fft_resetn=1;
    for(block_index=0;block_index<3;block_index=block_index+1)begin
      for(word_index=0;word_index<512;word_index=word_index+1)begin
        @(negedge clk);input_valid=1;input_position=9'(word_index);input_last=word_index==511;
        input_block_start=1000+block_index*447;
        input_data={samples[block_index*447+word_index][31:16],2'b0,samples[block_index*447+word_index][15:0],2'b0};
        do begin @(posedge clk);end while(input_ready!==1'b1);
        #0.001;
      end
      @(negedge clk);input_valid=0;
    end
    if(FAULT_KIND!=0)wait(collision_done);
    drain_anchor=fast_cycles;
    while(read_count!=1536||!`D.retained_reusable)begin
      @(negedge fft_clk);
      if(fast_cycles-drain_anchor>=25000)$fatal(1,"25000-fast bounded result drain");
    end
    repeat(20)@(negedge fft_clk);
    if(source_count!=1536||forward_jobs!=3||inverse_jobs!=3||forward_words!=1536||
      product_words!=1536||inverse_words!=1536||status_count!=6||overlap_inputs==0||
      (STALL<2&&overlap_reads==0)||(STALL==2&&parked_wait_i==0)||retained_finals==0)$fatal(1,"inventory source%0d F%0d I%0d fw%0d p%0d iw%0d status%0d overlap%0d/%0d reset%0d",source_count,forward_jobs,inverse_jobs,forward_words,product_words,inverse_words,status_count,overlap_inputs,overlap_reads,retained_finals);
    $display("OFFLINE_PASS composition SCRIPTED_NOT_FFT source=%0d forward=%0d product=%0d inverse=%0d read=%0d overlap_input=%0d overlap_read=%0d first_dispatch=%0d",source_count,forward_words,product_words,inverse_words,read_count,overlap_inputs,overlap_reads,first_dispatch);$finish;
  end
  initial begin #9000000;$fatal(1,"absolute offline timeout");end
  initial if(FAULT_KIND!=0)begin : fault_stimulus
    if(FAULT_BOUNDARY==0)wait(`D.guard_commit_out[1]&&`D.output_bank_ready);
    else if(FAULT_BOUNDARY==1)wait(`D.forward_handoff_ack);
    else if(FAULT_BOUNDARY==2)begin
      wait(`D.forward_handoff_ack);wait(!`D.owners[0].result_guard.awaiting_ack);
    end else wait(read_count==128);
    // Observe each target before its actual sampled edge; no posedge drive race.
    boundary_edge=fast_cycles+1;
    if(FAULT_OFFSET>0)begin repeat(FAULT_OFFSET)@(posedge fft_clk);@(negedge fft_clk);end
    publication_anchor=inverse_publications;fault_anchor=fast_cycles;
    if(`D.shared_xfft.base_raw_valid!==0)$fatal(1,"injection would mask an actual scripted raw word");
    if(FAULT_BOUNDARY==0&&FAULT_OFFSET==13&&FAULT_KIND==1)begin
      // At precisely the next F's first input, frame is already one. An OR
      // offer of the same value is not an independently observable extra event.
      if(`D.event_frame!==1||`D.core_input_valid!==1||`D.core_input_ready!==1||
        `D.shared_xfft.input_count!=0)$fatal(1,"same-level frame collision premise");
      inject_frame=1;#0.001;if(`D.common_current_fault!==0)$fatal(1,"legal natural frame rejected");
      @(posedge fft_clk);#0.001;
      if(fast_cycles!=boundary_edge+FAULT_OFFSET)$fatal(1,"collision sampled-edge offset");
      @(negedge fft_clk);inject_frame=0;collision_done=1;
      $display("OFFLINE_UNOBSERVABLE same-level frame offer equals natural first-input frame at offset13; full healthy replay required");
      disable fault_stimulus;
    end
    fault_injected=1;
    case(FAULT_KIND)
      1:inject_frame=1;2:inject_status=1;3:inject_output=1;4:inject_vendor=1;
      5:inject_status=1'bx;6:inject_output=1'bz;7:inject_frame=1'bx;8:inject_vendor=1'bz;
    endcase
    #0.001;
    if(`D.common_current_fault!==1||`D.guard_commit_out[1]!==0)
      $fatal(1,"same-edge full-composition raw fault fence");
    @(posedge fft_clk);#0.001;
    if(fast_cycles!=boundary_edge+FAULT_OFFSET)$fatal(1,"actual raw fault sampled-edge offset");
    $display("OFFLINE_RAW_SAMPLE boundary_edge=%0d sample_edge=%0d offset=%0d",boundary_edge,fast_cycles,FAULT_OFFSET);
    @(negedge fft_clk);
    inject_frame=0;inject_status=0;inject_output=0;inject_vendor=0;
    repeat(24)@(negedge fft_clk);
    if(fault!==1||`D.fast_fault!==1||inverse_publications!=publication_anchor||`D.job_accept!==0||
      `D.retained_reusable!==0||output_valid!==0)$fatal(1,"24-fast quarantine/retained inventory");
    if(FAULT_BOUNDARY==3&&(read_count<128||read_count>132||forward_jobs!=2))
      $fatal(1,"preserved 128..132 provisional prefix with legitimate next F");
    $display("OFFLINE_PASS expected raw fault boundary=%0d kind=%0d offset=%0d Fjobs=%0d Ijobs=%0d Fwords=%0d Pwords=%0d Iwords=%0d reads=%0d retained=%0d",FAULT_BOUNDARY,FAULT_KIND,FAULT_OFFSET,forward_jobs,inverse_jobs,forward_words,product_words,inverse_words,read_count,`D.retained_published);$finish;
  end
  `undef D
endmodule

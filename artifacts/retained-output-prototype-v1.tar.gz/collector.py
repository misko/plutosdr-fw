"""One-shot evidence packaging; not a simulator or part of the 415-test gate."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import tarfile

BASE = Path('/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz')
RAW = BASE / 'retained-prototype-preparation-v1'
FROZEN = BASE / 'retained-output-prototype-final-v1'
FW = Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
OUT = BASE / 'retained-prototype-package-v1'
GRAPH = Path('pytest-v19/test_composition_continuous_gr0/graph/sim.vvp')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return {'sha256': h.hexdigest(), 'bytes': path.stat().st_size}


def walk(root):
    files, links = {}, {}
    for folder, dirs, names in os.walk(root, followlinks=False):
        for name in sorted(dirs + names):
            path = Path(folder) / name
            rel = path.relative_to(root).as_posix()
            if path.is_symlink():
                links[rel] = os.readlink(path)
            elif path.is_file():
                files[rel] = digest(path)
        dirs[:] = sorted(d for d in dirs if not (Path(folder) / d).is_symlink())
    return dict(sorted(files.items())), dict(sorted(links.items()))


def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')


def selected(rel):
    p = Path(rel)
    return (p.suffix not in ('.vvp', '.pyc') and '__pycache__' not in p.parts) or p == GRAPH


assert not OUT.exists(), 'exclusive new output required'
OUT.mkdir()
raw_before, raw_links = walk(RAW)
frozen_before, frozen_links = walk(FROZEN)
assert not frozen_links
for line in (FROZEN / 'source.sha256').read_text().splitlines():
    sha, name = line.split(maxsplit=1)
    assert digest(FROZEN / name)['sha256'] == sha
stage = OUT / 'contents'
stage.mkdir()
files = {}
for rel, receipt in raw_before.items():
    if selected(rel):
        files['raw/' + rel] = (RAW / rel, receipt)
for rel, receipt in frozen_before.items():
    files['final/' + rel] = (FROZEN / rel, receipt)
report = FW / 'docs/starlink-retained-output-prototype-20260910.md'
files['report.md'] = (report, digest(report))
collector = Path(__file__).resolve()
files['collector.py'] = (collector, digest(collector))
for rel, (source, receipt) in files.items():
    target = stage / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    assert digest(target) == receipt
write_json(stage / 'raw-inventory.json', {
    'root': str(RAW), 'files': raw_before, 'symlinks_not_followed': raw_links,
    'regular_count': len(raw_before), 'regular_bytes': sum(v['bytes'] for v in raw_before.values()),
    'included_regular_count': sum(selected(p) for p in raw_before),
    'excluded_policy': 'VVP and Python bytecode inventory-only except final graph VVP',
})
assert walk(RAW) == (raw_before, raw_links), 'raw input changed during collection'
assert walk(FROZEN) == (frozen_before, frozen_links), 'frozen source changed during collection'
assert digest(report) == files['report.md'][1]
write_json(stage / 'provenance.json', {
    'tested_fw': '464e9bf34309501dd37089521288b81ccdbe5b4d',
    'tested_hdl': '2e8a7de221889084ea58cc6c44dd9a8407c56c9f',
    'source_manifest': digest(FROZEN / 'source.sha256'),
    'original_handle': 19306, 'exit': 0, 'tests': 415, 'seconds': 38.28,
    'host': 'gauss x86_64; Icarus 12.0; Python 3.11.16; not ARM/Zynq',
    'raw_before_after_equal': True, 'frozen_before_after_equal': True,
    'scope': 'offline scripted FFT interface; no vendor FFT or physical qualification',
    'source_v11_snapshot_caveat': 'source-v11-before-producer-fix includes later helper/shadow additions; original compiled bench/logs remain authoritative',
    'packaging_tooling_separate_from_415_test_identity': True,
})
inventory, links = walk(stage)
assert not links
write_json(stage / 'receipt.json', inventory)
archive = OUT / 'retained-output-prototype-v1.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for rel in sorted([*inventory, 'receipt.json']):
        tar.add(stage / rel, arcname=rel, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len({m.name for m in members}) == len(members) == len(inventory) + 1
    actual = {}
    for member in members:
        assert member.isfile() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        data = tar.extractfile(member).read()
        actual[member.name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    expected = {**inventory, 'receipt.json': digest(stage / 'receipt.json')}
    assert actual == expected
summary = {
    'archive': archive.name, **digest(archive), 'safe_regular_members': len(members),
    'receipt_entries': len(inventory), 'raw_regular_files': len(raw_before),
    'raw_regular_bytes': sum(v['bytes'] for v in raw_before.values()),
    'raw_symlinks_recorded_not_followed': len(raw_links),
    'raw_and_frozen_before_after_equal': True, 'archive_verified': True,
}
write_json(OUT / 'retained-output-prototype-v1.receipt.json', summary)
print(json.dumps(summary, indent=2), flush=True)

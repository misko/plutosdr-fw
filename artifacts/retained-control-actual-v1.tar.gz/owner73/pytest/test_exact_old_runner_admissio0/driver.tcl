proc version args {return 2022.2}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-prelaunch-tests-v1.Lz40I0kG/pytest/candidate_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} 6052976138ac7843c02b2107901bc37b1a4d8384e374c008238e7dad67720ab6 {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-prelaunch-tests-v1.Lz40I0kG/pytest/test_exact_old_runner_admissio0/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-prelaunch-tests-v1.Lz40I0kG/pytest/test_exact_old_runner_admissio0/runner.tcl}

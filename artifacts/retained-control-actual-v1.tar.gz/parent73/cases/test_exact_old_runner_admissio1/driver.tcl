proc version args {return 2023.1}
set argc 4
set argv [list {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-parent.vZVvViyX/cases/candidate_bundle0/bundle} {/home/mouse9911/.local/share/uv/python/cpython-3.11.16-linux-x86_64-gnu/bin/python3.11} 6052976138ac7843c02b2107901bc37b1a4d8384e374c008238e7dad67720ab6 {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-parent.vZVvViyX/cases/test_exact_old_runner_admissio1/absent}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-parent.vZVvViyX/cases/candidate_bundle0/bundle/source_snapshot/hdl/library/starlink_pss_acquisition/retained_control_actual/simulate_retained_control_actual.tcl}

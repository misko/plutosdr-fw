"""Independent source-pinned replay of the reviewed 73-test preparation gate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

out=Path(__file__).resolve().parent
bundle=out.parent/'retained-control-actual-prelaunch-v1'
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
digest='7a9b32f10241d22c3f5a6d3967ca9841e2646bb94d714f4935c05f5e8d03635e'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(bundle/'manifest.json')==digest
m=json.loads((bundle/'manifest.json').read_text())
assert len(m['sources'])==97 and len(m['files'])==100
pins={n:v['sha256'] for n,v in m['sources'].items()}
def current():return {n:sha(tree/n) for n in pins}
assert current()==pins
for n,v in m['files'].items():
    assert sha(bundle/n)==v['sha256'] and (bundle/n).stat().st_size==v['bytes'],n
(out/'source-pins.json').write_text(json.dumps(pins,indent=2))
for n in pins:
    p=out/'source_snapshot'/n;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((tree/n).read_bytes())
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest','-q','-p','no:cacheprovider',
     'tests/test_starlink_retained_control_actual.py','tests/test_starlink_retained_control_actual_bundle.py',
     '--basetemp='+str(out/'cases'),'--junitxml='+str(out/'results.xml')]
(out/'command.json').write_text(json.dumps(cmd))
p=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=180)
(out/'tests.log').write_text(p.stdout+p.stderr)
receipt={'exit':p.returncode,'source_count':len(pins),'sources_unchanged':current()==pins,'scope':'offline preparation, not actual FFT'}
(out/'execution.json').write_text(json.dumps(receipt,indent=2))
assert p.returncode==0 and current()==pins,p.stdout+p.stderr
xml=ET.parse(out/'results.xml').getroot()
assert len(xml.findall('.//testcase'))==73
assert not any(xml.findall('.//'+n) for n in ('failure','error','skipped'))
for n,v in m['files'].items():
    assert sha(bundle/n)==v['sha256'] and (bundle/n).stat().st_size==v['bytes'],n
receipt.update(tests=73,prepared_files_unchanged=True,manifest_sha256=digest)
(out/'audit.json').write_text(json.dumps(receipt,indent=2))
print(p.stdout)
print(json.dumps(receipt))

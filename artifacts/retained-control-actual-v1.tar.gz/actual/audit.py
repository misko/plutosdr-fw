"""Independent raw campaign/reference comparison after consumed actual61512."""
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parent
prior=root.parent/'retained-actual-frame-parent.2nhHxm1Q/run'
current=root/'run'
rel=Path('project/retained_output_actual.sim/sim_1/behav/xsim')
outcome=json.loads((root/'outcome.json').read_text())
assert outcome['functional_accepted'] and outcome['vendor_exit']==0
old=json.loads((prior/'results.json').read_text())
new=json.loads((current/'results.json').read_text())
candidate=new.pop('candidate')
assert new==old,'complete original parsed result changed'
csv=(current/rel/'actual_words.csv').read_bytes()
assert csv==(prior/rel/'actual_words.csv').read_bytes(),'full CSV differs'
assert hashlib.sha256(csv).hexdigest()=='07321b026a637e5922c56a84a955e58549056337198c952a9d73b1245cb4efaa'
assert len(csv.splitlines())==77954
log=(current/rel/'simulate.log').read_text()
frames=[line for line in log.splitlines() if line.startswith('RACT_FRAME ')]
assert len(frames)==40
for line in frames:
    row={k:int(v) for k,v in (x.split('=') for x in line.split()[1:])}
    assert row['cycle']-row['admit']==8 and row['end_cycle']-row['cycle']==1
    assert (row['before'],row['on'],row['after'])==(2,1,3)
assert len(candidate['RCAND_JOB'])==40
assert candidate['RCAND_PROOF']==[dict(jobs=40,final_inputs=38,closed_pre=49419,closed_post=49419,public_pre=19456)]
result={'original_process':61512,'vendor_exit':0,'full_original_result_equal':True,
        'full_actual_csv_byte_equal':True,'csv_rows':77953,'csv_sha256':hashlib.sha256(csv).hexdigest(),
        'frames':40,'pairs':19,'contexts':7,'candidate_receipts':sum(map(len,candidate.values())),
        'scope':'actual vendor FFT seven contexts; not continuous, routed, calibrated or deployed'}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))

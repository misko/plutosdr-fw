# OFFLINE_STUB: stop before creating any project or generated FFT.
proc version args {return 2022.2}
proc set_param {name value} {if {$name ne "general.maxThreads" || $value!=2} {error THREADS}}
proc create_project args {global output;set f [open [file join $output clocks.xdc] a];puts $f {
// MUTATED};close $f;error OFFLINE_EXPECTED_CREATE_FAILURE}
set argc 2
set argv [list 3590d4db36dd313a1db55419f46f1897bf8b588756e8b406f55537b1d7c135ee {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/test_executed_create_failure_r1/run}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/synthesis_prepared0/bundle/synthesize_retained_control.tcl}

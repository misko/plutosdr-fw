proc version args {return 2022.2}
proc set_param args {}
proc create_project args {error UNEXPECTED_VENDOR_BOUNDARY}
set argc 2
set argv [list 0000000000000000000000000000000000000000000000000000000000000000 {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/test_runner_admission_rejects_0/run}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/test_runner_admission_rejects_0/bundle/synthesize_retained_control.tcl}

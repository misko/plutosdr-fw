proc version args {return 2022.2}
proc set_param args {}
proc create_project args {error UNEXPECTED_VENDOR_BOUNDARY}
set argc 3
set argv [list 3590d4db36dd313a1db55419f46f1897bf8b588756e8b406f55537b1d7c135ee {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/test_runner_admission_rejects_3/run}]
source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/test_runner_admission_rejects_3/bundle/synthesize_retained_control.tcl}

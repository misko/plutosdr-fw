proc get_clocks args {
set n [lindex $args end]
if {"none" eq "missing_clock" && $n eq "island_175"} {return {}}
return $n
}
proc get_property {property clock} {
if {$clock eq "source_100"} {return 10.0}
return 5.714
}
  foreach {name period} {source_100 10.0 island_175 5.714} {
    set clock [get_clocks -quiet $name]
    if {[llength $clock] != 1 || abs([get_property PERIOD $clock]-$period)>0.00001} { error "unexpected effective clock $name" }
  }

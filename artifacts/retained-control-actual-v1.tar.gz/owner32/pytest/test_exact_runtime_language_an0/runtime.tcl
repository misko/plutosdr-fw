source {/home/mouse9911/gits/starlink-build-recovery-20260910.vHzUVnBz/retained-control-synth-tests-v1.zt26L5ec/pytest/synthesis_prepared0/bundle/qualified/profile.tcl}
  set rtl_names {}
  foreach name $compiled_names {
    if {([string match */retained_output/*.v $name] || [string match */retained_output_closed_candidate/*.v $name]) && ![string match */tb/* $name]} { lappend rtl_names $name }
  }
  if {[llength $rtl_names] != 16} { error "exact16 runtime required" }
puts [join $rtl_names "\n"]

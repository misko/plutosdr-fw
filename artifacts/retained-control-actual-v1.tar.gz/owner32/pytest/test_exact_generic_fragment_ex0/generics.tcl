set kernel /frozen/kernel.mem
proc get_filesets args {return sources_1}
proc set_property {name value target} {global actual;set actual $value}
proc get_property args {global actual;return $actual}
  set generics [list KERNEL_ROM_FILE=$kernel ENABLE_RETAINED_OUTPUT=1 REGISTERED_SCHEDULING=1 BOUNDARY_ROUND_SAT=1 REGISTER_OPERANDS=1 LOCAL_FIRST_ADMISSION=1 PRIVATE_DESCRIPTOR_OFFER=1 CLOSED_INPUT_CUTOVER=1 UNREVIEWED=1]
  set_property generic $generics [get_filesets sources_1]
  if {[get_property GENERIC [get_filesets sources_1]] ne $generics} { error "exact retained/R1/B1/O1/L1/private-offer/closed-input generics" }
if {$actual ne [list KERNEL_ROM_FILE=/frozen/kernel.mem ENABLE_RETAINED_OUTPUT=1 REGISTERED_SCHEDULING=1 BOUNDARY_ROUND_SAT=1 REGISTER_OPERANDS=1 LOCAL_FIRST_ADMISSION=1 PRIVATE_DESCRIPTOR_OFFER=1 CLOSED_INPUT_CUTOVER=1]} {error WRONG_GENERIC_CONTRACT}

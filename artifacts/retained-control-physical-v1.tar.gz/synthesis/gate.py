"""Independent 32-test source-specific synthesis preparation replay."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parent
prepared=root.parent/'retained-control-synthesis-prepared-v1'
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
expected='3590d4db36dd313a1db55419f46f1897bf8b588756e8b406f55537b1d7c135ee'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(prepared/'SHA256SUMS')==expected
pins={name:digest for digest,name in (line.split('  ',1) for line in (prepared/'SHA256SUMS').read_text().splitlines())}
assert len(pins)==110
def unchanged():return all(sha(prepared/n)==s for n,s in pins.items())
assert unchanged()
assets={'prepare.py':'tools/prepare_starlink_retained_control_synthesis.py','offline_tests.py':'tests/test_starlink_retained_control_synthesis.py',
        'synthesize_retained_control.tcl':'hdl/library/starlink_pss_acquisition/retained_control_actual/synthesize_retained_control.tcl'}
assert all((tree/n).read_bytes()==(prepared/a).read_bytes() for a,n in assets.items())
(root/'before.json').write_text(json.dumps(pins,indent=2))
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
(root/'tmp').mkdir();env['TMPDIR']=str(root/'tmp')
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest','-q','-p','no:cacheprovider',
     'tests/test_starlink_retained_control_synthesis.py','--basetemp='+str(root/'cases'),'--junitxml='+str(root/'results.xml')]
(root/'gate-command.json').write_text(json.dumps(cmd))
p=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=120)
(root/'tests.log').write_text(p.stdout+p.stderr)
counts={k:sum(int(s.attrib[k]) for s in ET.parse(root/'results.xml').getroot().findall('testsuite')) for k in ('tests','failures','errors','skipped')}
receipt={'exit':p.returncode,'unchanged':unchanged() and all((tree/n).read_bytes()==(prepared/a).read_bytes() for a,n in assets.items()),
         'prepared_sha':expected,'expected_tests':32,'counts':counts,
         'runner_sha':sha(prepared/'synthesize_retained_control.tcl'),'copier_sha':sha(prepared/'prepare.py')}
(root/'preparation-gate.json').write_text(json.dumps(receipt,indent=2))
assert p.returncode==0 and receipt['unchanged'] and counts==dict(tests=32,failures=0,errors=0,skipped=0),p.stdout+p.stderr
print(p.stdout);print(json.dumps(receipt))

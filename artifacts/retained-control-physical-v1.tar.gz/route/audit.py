"""Independent diagnostic-route audit; tool success and timing failure are separate."""
import hashlib
import json
from pathlib import Path
import re

root=Path(__file__).resolve().parent
route=root/'route'
execution=json.loads((root/'execution.json').read_text())
assert execution['vendor_exit']==0 and not execution['timed_out']
assert all(execution[k] for k in ('source_dcp_unchanged','original_runner_unchanged','frozen_runner_unchanged'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(route/'retained_output_routed.dcp')==execution['routed_dcp_sha256']
paths=dict(line.split('=',1) for line in (route/'paths.txt').read_text().splitlines())
expected={('source_100','source_100'):(2.497,0.110),('source_100','island_175'):(-0.540,0.134),
          ('island_175','source_100'):(-1.276,0.130),('island_175','island_175'):(-2.697,0.037)}
for (source,dest),slacks in expected.items():
    for kind,slack in zip(('max','min'),slacks):
        assert float(paths[f'{source}.{dest}.{kind}.slack'])==slack
        assert paths[f'{source}.{dest}.{kind}.reported_paths']=='20'
        text=(route/f'{source}_{dest}_{kind}.rpt').read_text()
        reported=re.findall(r'^Slack \([^\n]*?\)\s*:\s*(-?\d+\.\d+)ns',text,re.M)
        assert len(reported)==20 and float(reported[0])==slack
timing=(route/'timing_unqualified.rpt').read_text()
row=re.search(r'^\s*(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s+(-?\d+\.\d+)\s+(-?\d+\.\d+)\s+(\d+)\s+(\d+)\s*$',timing,re.M)
assert row and row.groups()==('-2.697','-981.622','848','11055','0.037','0.000','0','11055','1.830','0.000','0','5118')
assert 'Timing constraints are not met.' in timing
status=(route/'route_status.rpt').read_text()
assert re.search(r'fully routed nets\.+\s*:\s*7233\s*:',status)
assert re.search(r'nets with routing errors\.+\s*:\s*0\s*:',status)
util=(route/'utilization.rpt').read_text()
for label,value in (('Slice LUTs',2333),('Slice Registers',4764)):
    assert re.search(r'\| '+re.escape(label)+r'\s*\|\s*'+str(value)+r'\s*\|',util)
for label,value in (('DSPs',21),('RAMB18',15),('Unique Control Sets',66)):
    assert re.search(r'\|\s+'+re.escape(label)+r'\s*\|\s*'+str(value)+r'\s*\|',util)
def commands(path):
    return [line.strip() for line in path.read_text().splitlines() if line.strip() and not line.lstrip().startswith('#')]
synthesis=root.parent/'retained-control-synth-parent.9xhaMMns/synthesis'
assert commands(route/'inherited_constraints.xdc')==commands(synthesis/'inherited_constraints.xdc')
assert 'No valid timing exceptions found.' in (route/'exceptions.rpt').read_text()
critical=(route/'island_175_island_175_max.rpt').read_text().split('Slack (VIOLATED)',2)[1]
assert 'product_bank/metadata_out_hold_reg[8]/C' in critical
assert 'retained_owner/fault_reasons_reg[6]/D' in critical
assert '8.085ns' in critical and 'logic 1.690ns' in critical and 'route 6.395ns' in critical
result={'vendor_exit':0,'routed_dcp_sha256':execution['routed_dcp_sha256'],
 'route_complete':True,'fully_routed_nets':7233,'routing_errors':0,
 'timing_pass':False,'wns_ns':-2.697,'tns_ns':-981.622,'setup_failing_endpoints':848,
 'whs_ns':0.037,'hold_failing_endpoints':0,'pulse_width_slack_ns':1.830,
 'lut':2333,'ff':4764,'dsp':21,'ramb18':15,
 'clockpair_slacks':{f'{a}->{b}':{'setup':v[0],'hold':v[1]} for (a,b),v in expected.items()},
 'critical_path':{'source':'product_bank/metadata_out_hold[8]',
                  'destination':'retained_owner/fault_reasons[6]/D',
                  'delay_ns':8.085,'logic_ns':1.690,'routing_ns':6.395,'lut_levels':10,
                  'same_clock_domain':True},
 'constraints_unchanged':True,'cdc_and_external_io_qualified':False,'deployment_eligible':False}
(root/'audit.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

`timescale 1ns/1ps
module tb;
  tb_starlink_pss_realtime_result_guard stimulus();
  starlink_pss_result_guard_owner_view #(.WATCHDOG_CYCLES(2048),.USE_PRIVATE_DESCRIPTOR_OFFER(1)) shadow(.private_descriptor_offer(private_offer),.clk(stimulus.dut.clk),
.resetn(stimulus.dut.resetn),
.job_valid(stimulus.dut.job_valid),
.job_descriptor(stimulus.dut.job_descriptor),
.input_bank_reserved(stimulus.dut.input_bank_reserved),
.output_bank_reserved(stimulus.dut.output_bank_reserved),
.certified_input_beat(stimulus.dut.certified_input_beat),
.certified_input_complete(stimulus.dut.certified_input_complete),
.final_fence_certified(stimulus.dut.final_fence_certified),
.external_fault_now(stimulus.dut.external_fault_now),
.phase_input_fault_now(stimulus.dut.phase_input_fault_now),
.completed_input_certified(stimulus.dut.completed_input_certified),
.completed_input_fault_now(stimulus.dut.completed_input_fault_now),
.preflight_fault_evidence_now(stimulus.dut.preflight_fault_evidence_now),
.core_event_frame_started(stimulus.dut.core_event_frame_started),
.core_output_tdata(stimulus.dut.core_output_tdata),
.core_output_tuser(stimulus.dut.core_output_tuser),
.core_output_tvalid(stimulus.dut.core_output_tvalid),
.core_output_tlast(stimulus.dut.core_output_tlast),
.core_status_tdata(stimulus.dut.core_status_tdata),
.core_status_tvalid(stimulus.dut.core_status_tvalid),
.mailbox_input_ready(stimulus.dut.mailbox_input_ready),
.mailbox_input_fault(stimulus.dut.mailbox_input_fault),
.inverse_phase(stimulus.dut.inverse_phase),
.forward_mailbox_fault(stimulus.dut.forward_mailbox_fault));

  reg [69:0] expected_private=0;
  integer private_changes=0,private_accepted=0,private_held=0,private_acks=0;
  wire private_offer = stimulus.dut.job_valid ? 1'b1 : 1'bx;
  always @(posedge stimulus.clk or negedge stimulus.resetn)begin
    if(!stimulus.resetn)expected_private=0;
    else begin
      if(stimulus.dut.job_accept)begin
        if(private_offer!==1'b1)$fatal(1,"accepted job missing private offer");
        private_accepted=private_accepted+1;
      end
      if(shadow.active || shadow.awaiting_ack)private_held=private_held+1;
      if(shadow.owner_ack_accept)private_acks=private_acks+1;
      if(!shadow.active && !shadow.awaiting_ack && !shadow.protocol_fault &&
         (1 ? private_offer : stimulus.dut.job_valid))begin
        expected_private=stimulus.dut.job_descriptor;
        private_changes=private_changes+1;
      end
    end
    #0.001;
    if(shadow.descriptor!==expected_private)$fatal(1,"independent private descriptor model");
  end
  final begin
    if(private_accepted<23||private_held<1000||private_acks<23||private_changes<23)
      $fatal(1,"private boundary inventory");
    $display("PRIVATE_BOUNDARY accepted=%0d held=%0d ack=%0d loads=%0d",private_accepted,private_held,private_acks,private_changes);
  end
  integer comparisons=0;
  always @(posedge stimulus.clk or negedge stimulus.clk)begin
    #0.001;if(shadow.job_ready !== stimulus.dut.job_ready) $fatal(1,"unconditional guard job_ready");
if(shadow.mailbox_input_valid !== stimulus.dut.mailbox_input_valid) $fatal(1,"unconditional guard mailbox_input_valid");
if(shadow.mailbox_private_valid !== stimulus.dut.mailbox_private_valid) $fatal(1,"unconditional guard mailbox_private_valid");
if(shadow.mailbox_commit_valid !== stimulus.dut.mailbox_commit_valid) $fatal(1,"unconditional guard mailbox_commit_valid");
if(shadow.forward_retirement_valid !== stimulus.dut.forward_retirement_valid) $fatal(1,"unconditional guard forward_retirement_valid");
if(shadow.mailbox_input_data !== stimulus.dut.mailbox_input_data) $fatal(1,"unconditional guard mailbox_input_data");
if(shadow.mailbox_input_position !== stimulus.dut.mailbox_input_position) $fatal(1,"unconditional guard mailbox_input_position");
if(shadow.mailbox_input_last !== stimulus.dut.mailbox_input_last) $fatal(1,"unconditional guard mailbox_input_last");
if((shadow.active || shadow.awaiting_ack) && shadow.mailbox_input_metadata !== stimulus.dut.mailbox_input_metadata) $fatal(1,"unconditional guard mailbox_input_metadata");
if(shadow.busy !== stimulus.dut.busy) $fatal(1,"unconditional guard busy");
if(shadow.commit_pulse !== stimulus.dut.commit_pulse) $fatal(1,"unconditional guard commit_pulse");
if(shadow.protocol_fault !== stimulus.dut.protocol_fault) $fatal(1,"unconditional guard protocol_fault");
if(shadow.fault_reasons !== stimulus.dut.fault_reasons) $fatal(1,"unconditional guard fault_reasons");
if(shadow.active_private !== stimulus.dut.active_private) $fatal(1,"unconditional guard active_private");
if(shadow.awaiting_ack !== stimulus.dut.awaiting_ack) $fatal(1,"unconditional guard awaiting_ack");
if((shadow.active || shadow.awaiting_ack) && shadow.descriptor !== stimulus.dut.descriptor) $fatal(1,"unconditional guard descriptor");
if(shadow.input_count !== stimulus.dut.input_count) $fatal(1,"unconditional guard input_count");
if(shadow.output_count !== stimulus.dut.output_count) $fatal(1,"unconditional guard output_count");
if(shadow.input_complete_seen !== stimulus.dut.input_complete_seen) $fatal(1,"unconditional guard input_complete_seen");
if(shadow.frame_seen !== stimulus.dut.frame_seen) $fatal(1,"unconditional guard frame_seen");
if(shadow.status_seen !== stimulus.dut.status_seen) $fatal(1,"unconditional guard status_seen");
if(shadow.exponent_seen !== stimulus.dut.exponent_seen) $fatal(1,"unconditional guard exponent_seen");
if(shadow.status_exponent !== stimulus.dut.status_exponent) $fatal(1,"unconditional guard status_exponent");
if(shadow.output_exponent !== stimulus.dut.output_exponent) $fatal(1,"unconditional guard output_exponent");
if(shadow.age !== stimulus.dut.age) $fatal(1,"unconditional guard age");
if(shadow.return_occupied !== stimulus.dut.return_occupied) $fatal(1,"unconditional guard return_occupied");
if(shadow.return_last !== stimulus.dut.return_last) $fatal(1,"unconditional guard return_last");
if(shadow.return_data !== stimulus.dut.return_data) $fatal(1,"unconditional guard return_data");
if(shadow.return_position !== stimulus.dut.return_position) $fatal(1,"unconditional guard return_position");
if(shadow.return_exponent !== stimulus.dut.return_exponent) $fatal(1,"unconditional guard return_exponent");
    if({shadow.owner_active,shadow.owner_awaiting_ack,shadow.owner_fault_now,shadow.owner_ack_accept} !==
      {stimulus.dut.active,stimulus.dut.awaiting_ack,stimulus.dut.fault_now,
      (stimulus.dut.awaiting_ack&&stimulus.dut.mailbox_input_ready&&!stimulus.dut.protocol_fault&&!stimulus.dut.idle_fault_now)})
      $fatal(1,"guard added owner observations");
    comparisons=comparisons+1;
  end
  final begin
    if(stimulus.healthy!=23||stimulus.rejected!=37||stimulus.reset_cases!=12||comparisons<10000)
      $fatal(1,"unchanged adversarial inventory");
    $display("OFFLINE_PASS unconditional exact guard/state healthy23 rejected37 reset12 comparisons=%0d",comparisons);
  end
endmodule

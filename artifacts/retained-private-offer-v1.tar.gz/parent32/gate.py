"""Root replay of default-off private descriptor candidate. Offline only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

out=Path(__file__).resolve().parent
tree=Path('/tmp/starlink-coarse-alternatives.Y3JzOI/high-rate60-paired')
acq=tree/'hdl/library/starlink_pss_acquisition'
fixed={
 'tests/starlink_oracle/retained_control_candidate.py':'480facb56c71f6d2c549b033d8beaaaff2cbaa4ff0df6352db3f6203b00d48a4',
 'tests/starlink_oracle/retained_private_offer_inverse.json':'bd533e70a7111d9ea0a920795da465466a9114e9ad41d4ca3407d0b06e380fc3',
 'tests/test_starlink_retained_control_candidate.py':'363241de3be8bf014c4becb0f729922ada37f838d8ac6731f2a438f29d363b29',
 'hdl/library/starlink_pss_acquisition/retained_output_candidate/starlink_pss_fft_bank_owned_retained_output_probe.v':'f4a0e7a3e4248cc1ec3cedee796ce591cab746c87ba25e4a1286befb46c9215e',
 'hdl/library/starlink_pss_acquisition/retained_output_candidate/starlink_pss_fft_retained_output_impl.v':'d72a34b765d32c82ba3dfd789c335397467ed1ac40765b42f4581121963198e6',
 'hdl/library/starlink_pss_acquisition/retained_output_candidate/starlink_pss_result_guard_owner_view.v':'71e9d5d2312833f0a9b12f5060a49f0c8b8529d9b9e43fca1e9959ecf5561a76',
}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(tree/n)==v for n,v in fixed.items())
paths=[p for p in (acq/'retained_output').rglob('*') if p.is_file()]
paths += [tree/n for n in fixed]
paths += [tree/'tests/starlink_oracle/retained_output_prototype.py']
before={str(p.relative_to(tree)):sha(p) for p in paths}
(out/'source-pins.json').write_text(json.dumps(before,indent=2))
for n in before:
    target=out/'source_snapshot'/n
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes((tree/n).read_bytes())
cmd=['/home/mouse9911/gits/pluto-plus-utils/.venv/bin/python','-B','-m','pytest',
 'tests/test_starlink_retained_control_candidate.py','-q','-p','no:cacheprovider',
 '--basetemp='+str(out/'cases'),'--junitxml='+str(out/'tests.xml')]
env={k:v for k,v in os.environ.items() if k not in ('PYTHONHOME','PYTHONPATH','PYTHONOPTIMIZE','LD_LIBRARY_PATH')}
(out/'command.json').write_text(json.dumps(cmd))
p=subprocess.run(cmd,cwd=tree,env=env,capture_output=True,text=True,timeout=180)
(out/'tests.log').write_text(p.stdout+p.stderr)
unchanged=all(sha(tree/n)==v for n,v in before.items())
receipt={'exit':p.returncode,'sources_unchanged':unchanged,'source_count':len(before),
 'scope':'private-offer candidate offline only; no actual FFT or physical result'}
(out/'execution.json').write_text(json.dumps(receipt,indent=2))
assert p.returncode==0 and unchanged,p.stdout+p.stderr
suites=ET.parse(out/'tests.xml').getroot().findall('testsuite')
assert sum(int(s.attrib['tests']) for s in suites)==32
assert all(int(s.attrib[k])==0 for s in suites for k in ('failures','errors','skipped'))
unknown=[]
for bench in (out/'cases').rglob('test.sv'):
    text=bench.read_text()
    if "wire private_offer = stimulus.dut.job_valid ? 1'b1 : 1'b" in text:
        unknown.append('unaccepted')
    elif "wire private_offer = 1'bx;" in text or "wire private_offer = 1'bz;" in text:
        unknown.append('accepted')
assert sorted(unknown)==['accepted','accepted','unaccepted','unaccepted']
receipt['unknown_offer_generated_cases']=unknown
(out/'audit.json').write_text(json.dumps(receipt,indent=2))
print(p.stdout)
print(json.dumps(receipt))

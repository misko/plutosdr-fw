The original 26-test terminal/log/XML/compiled simulations are retained unchanged in the parent directory.
Three candidate RTL files and inverse JSON are byte-identical to the tested source.
This helper/test source snapshot was reconstructed after the 32-case additions, using the exact prior literal helper and removal of the six additive targeted cases.
It is not a pre-run hash receipt. Generated guard/composition benches must match the original saved benches before this reconstruction is treated as provenance.
